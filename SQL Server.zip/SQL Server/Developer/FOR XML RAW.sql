USE AdventureWorks2014;
GO

-- FORMA BASICA COM ROW E ATRIBUTOS
SELECT ProductModelID, Name
FROM Production.ProductModel
WHERE ProductModelID=122 or ProductModelID=119
FOR XML RAW;
GO

-- COM ELEMENTS, GERA-SE SUBELEMENTOS DE ROW
SELECT ProductModelID, Name
FROM Production.ProductModel
WHERE ProductModelID=122 or ProductModelID=119
FOR XML RAW, ELEMENTS;
GO

-- DEVOLVE TIPO XML SEM ALTERAR CONSULTA
SELECT ProductModelID, Name
FROM Production.ProductModel
WHERE ProductModelID=122 or ProductModelID=119
FOR XML RAW, TYPE ;
GO

SELECT ProductID, Name, Color
FROM Production.Product
FOR XML RAW, ELEMENTS;
GO

-- TRATA VALORES NULOS
SELECT ProductID, Name, Color
FROM Production.Product
FOR XML RAW, ELEMENTS XSINIL ;
GO

-- RETORNA UM SCHEMA XDR
SELECT ProductModelID, Name
FROM Production.ProductModel
WHERE ProductModelID=122 or ProductModelID=119
FOR XML RAW, XMLDATA
GO

-- RETORNA SCHEMA XSD
SELECT ProductModelID, Name
FROM Production.ProductModel
WHERE ProductModelID=122 or ProductModelID=119
FOR XML RAW, XMLSCHEMA
GO

-- RENOMEIA A LINHA ROW
SELECT ProductModelID, Name
FROM Production.ProductModel
WHERE ProductModelID=122
FOR XML RAW ('ProductModel'), ELEMENTS
GO

-- DEFINE UM NODE RAIZ
SELECT ProductModelID, Name 
FROM Production.ProductModel
WHERE ProductModelID=122 or ProductModelID=119 or ProductModelID=115
FOR XML RAW ('ProductModel'), ELEMENTS, ROOT('MyRoot')
GO
