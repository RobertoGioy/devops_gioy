USE AdventureWorks2014;
GO

SELECT Name,
       ProductModelID as "@PmId"
FROM Production.ProductModel
WHERE ProductModelID=7
FOR XML PATH 
GO

SELECT BusinessEntityID '@EmpID', 
       FirstName  --'EmpName/First', 
       ,MiddleName --'EmpName/Middle', 
       ,LastName   --'EmpName/Last'
FROM   Person.Person E, Person.ContactType C
WHERE  E.BusinessEntityID = C.ContactTypeID
AND    E.BusinessEntityID=1
FOR XML PATH ('TESTE')
GO

SELECT BusinessEntityID '@EmpID', 
       FirstName  'EmpName/First', 
       MiddleName 'EmpName/Middle', 
       LastName   'EmpName/Last'
FROM   Person.Person E, Person.ContactType C
WHERE  E.BusinessEntityID = C.ContactTypeID
AND    E.BusinessEntityID=1
FOR XML PATH