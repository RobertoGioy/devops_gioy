USE AdventureWorks2014;
GO

-- CRIA XML PADRAO COM ATRIBUTOS
SELECT	Cust.CustomerID, 
		OrderHeader.CustomerID,
		OrderHeader.SalesOrderID, 
		OrderHeader.Status
FROM	Sales.Customer Cust, Sales.SalesOrderHeader OrderHeader
WHERE	Cust.CustomerID = OrderHeader.CustomerID
ORDER BY Cust.CustomerID
FOR XML AUTO
GO


SELECT	OrderHeader.CustomerID,
		OrderHeader.SalesOrderID, 
		OrderHeader.Status,
		Cust.CustomerID
FROM	Sales.Customer Cust, Sales.SalesOrderHeader OrderHeader
WHERE	Cust.CustomerID = OrderHeader.CustomerID
FOR XML AUTO
GO

SELECT	Cust.CustomerID, 
		OrderHeader.CustomerID,
		OrderHeader.SalesOrderID, 
		OrderHeader.Status
FROM	Sales.Customer Cust, Sales.SalesOrderHeader OrderHeader
WHERE	Cust.CustomerID = OrderHeader.CustomerID
ORDER BY Cust.CustomerID
FOR XML AUTO, ELEMENTS
GO

SELECT Cust.CustomerID, 
       OrderHeader.CustomerID,
       OrderHeader.SalesOrderID, 
       Detail.SalesOrderID, Detail.LineTotal, Detail.ProductID, 
       Product.Name,
       Detail.OrderQty
FROM Sales.Customer AS Cust
INNER JOIN Sales.SalesOrderHeader AS OrderHeader 
    ON Cust.CustomerID = OrderHeader.CustomerID
INNER JOIN Sales.SalesOrderDetail AS Detail
    ON OrderHeader.SalesOrderID = Detail.SalesOrderID
INNER JOIN Production.Product AS Product
    ON Product.ProductID = Detail.ProductID
WHERE Cust.CustomerID IN (29672, 29734)
ORDER BY OrderHeader.CustomerID,
         OrderHeader.SalesOrderID
FOR XML AUTO;