USE [DBADMSQL]
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'sp_who3')
	DROP PROCEDURE [dbo].[sp_who3]
GO
PRINT 'creating procedure [dbo].[sp_who3]...';
GO
CREATE PROCEDURE [dbo].[sp_who3]
AS
BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #tb_blocked(
		hostID INT
	  , SPID INT
	  , a VARCHAR (1000)
	  , b INT
	  , textBuffer VARCHAR (4000)
	);
	CREATE CLUSTERED INDEX ix_blocked ON #tb_blocked (SPID);

	CREATE TABLE #tb_inputBuffer (
		a VARCHAR (14)
	  , b INT
	  , textBuffer VARCHAR (4000)
	);

	-- insere na tabela temp todas as ses�es com status de blocked
	INSERT INTO #tb_blocked
	SELECT
		HOST_ID ()
	  , p.spid
	  , NULL
	  , NULL 
	  , NULL 
	FROM
		master.sys.sysprocesses p
	WHERE
		(p.spid IN (SELECT blocked FROM master.sys.sysprocesses sp WHERE sp.blocked <> 0 AND sp.spid <> sp.blocked)) 
		OR (p.blocked <> 0 AND P.spid <> p.blocked);

	DECLARE @spid INT
	DECLARE Buffer_Cursor CURSOR LOCAL FOR
		SELECT SPID FROM #tb_blocked

	OPEN Buffer_Cursor;
	FETCH NEXT FROM Buffer_Cursor INTO @spid

	WHILE @@FETCH_STATUS = 0
	BEGIN
		DELETE FROM #tb_inputBuffer;

		INSERT INTO #tb_inputBuffer EXEC ('DBCC INPUTBUFFER (' + @spid + ') WITH NO_INFOMSGS');

		UPDATE	#tb_blocked
		SET		textBuffer = #tb_inputBuffer.textBuffer
		FROM	#tb_inputBuffer
		WHERE	SPID = @spid

		FETCH NEXT FROM Buffer_Cursor INTO @spid
	END

	CLOSE Buffer_Cursor;
	DEALLOCATE Buffer_Cursor;

	SELECT DISTINCT 
		@@SERVERNAME AS ServerName
	  , DB_NAME (a.dbid) AS DBName
	  , a.spid
	  , a.blocked
	  , a.ecid
	  , a.waittime
	  , a.[status]
	  , a.cpu
	  , a.physical_io
	  , a.hostname
	  , a.loginame
	  , a.last_batch
	  , a.open_tran
	  , a.memusage
	  , b.textBuffer
	FROM
		master.sys.sysprocesses a
		RIGHT OUTER JOIN #tb_blocked b ON (a.spid = b.SPID)
	WHERE
		(a.spid IN (SELECT blocked FROM master.sys.sysprocesses c WHERE c.blocked <> 0 AND c.blocked <> c.spid))
		OR (a.blocked <> 0 AND a.blocked <> a.spid)
	ORDER BY
		a.blocked;
END
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'sp_who4')
	DROP PROCEDURE [dbo].[sp_who4]
GO
PRINT 'creating procedure [dbo].[sp_who4]...';
GO
CREATE PROCEDURE [dbo].[sp_who4]
	@timeblocking	TINYINT = 3
  , @alert			BIT = 0 -- 0 = FALSE, 1 = TRUE
AS
BEGIN
	SET NOCOUNT ON;
	SET CONCAT_NULL_YIELDS_NULL OFF;

	BEGIN TRY
		-- ofensores
		CREATE TABLE #dm_requests (
			session_id				SMALLINT
		  , blocking_session_id		SMALLINT
		  , database_id				SMALLINT
		  , wait_type				NVARCHAR (60)
		  , wait_resource			NVARCHAR (256)
		  , [status]				NVARCHAR (30)
		  , start_time				DATETIME
		  , statement_start_offset	INT
		  , statement_end_offset	INT
		  , [sql_handle]			VARBINARY (64)
		);

		INSERT INTO #dm_requests
		SELECT
			r.session_id
		  , r.blocking_session_id
		  , r.database_id
		  , r.wait_type
		  , r.wait_resource
		  , r.[status]
		  , r.start_time
		  , r.statement_start_offset
		  , r.statement_end_offset
		  , r.[sql_handle]
		FROM
			sys.dm_exec_requests r
		ORDER BY
			r.start_time;

		CREATE CLUSTERED INDEX ix_ofensores_session_id ON #dm_requests (session_id, blocking_session_id);

		-- impactados
		CREATE TABLE #dm_sessions (
			session_id				SMALLINT
		  , last_request_end_time	DATETIME
		  , login_name				NVARCHAR (128)
		  , [host_name]				NVARCHAR (128)
		  , [program_name]			NVARCHAR (128)
		  , cpu_time				INT
		  ,	memory_usage			INT
		  , login_time				DATETIME
		  , open_tran				TINYINT
		);

		INSERT INTO #dm_sessions
		SELECT
			es.session_id
		  , es.last_request_end_time
		  , es.login_name
		  , es.[host_name]
		  , es.[program_name]
		  , es.cpu_time
		  , es.memory_usage
		  , es.login_time
		  , COUNT (es.session_id)
		FROM
			sys.dm_exec_sessions es
			LEFT JOIN sys.dm_tran_session_transactions tst ON (es.session_id = tst.session_id)
		GROUP BY
			es.session_id
		  , es.last_request_end_time
		  , es.login_name
		  , es.[host_name]
		  , es.[program_name]
		  , es.cpu_time
		  , es.memory_usage
		  , es.login_time;

		CREATE CLUSTERED INDEX ix_impactados_session_id ON #dm_sessions (session_id);

		-- seleciona o causador do bloqueio e dispara o alerta via e-mail
		IF (@alert = 1)
		BEGIN
			DECLARE
				@server_name		VARCHAR (128)
			  , @database_name		VARCHAR (128)
			  , @blockingsessionid	INT
			  , @status				NVARCHAR (30)
			  , @hostname			NVARCHAR (128)
			  , @login_name			NVARCHAR (128)
			  , @program_name		NVARCHAR (128)
			  , @lastbatch			DATETIME
			  , @textbuffer			NVARCHAR (4000)
			  , @subject			NVARCHAR (256)
			  , @body				NVARCHAR (4000)
			  , @timeblock			INT

			SELECT 
				@server_name		= @@SERVERNAME
			  , @database_name		= UPPER (ISNULL (ISNULL (DB_NAME (r.database_id), stmt.dbid), 'master'))
			  , @blockingsessionid	= ISNULL (s.session_id, 0)
			  , @status				= ISNULL (r.[status], 'Sleeping')
			  , @hostname			= s.host_name
			  , @login_name			= s.login_name
			  , @program_name		= s.program_name
			  , @lastbatch			= s.last_request_end_time
			  , @textbuffer			= stmt.[text]
			  , @timeblock			= DATEDIFF (MINUTE, s.last_request_end_time, GETDATE ())
			FROM
				#dm_sessions s
				INNER JOIN sys.dm_exec_connections c	ON (s.session_id = c.session_id)
				LEFT JOIN #dm_requests r				ON (s.session_id = r.session_id)
				OUTER APPLY sys.dm_exec_sql_text (c.most_recent_sql_handle) stmt
			WHERE
				(s.session_id IN (SELECT r2.blocking_session_id FROM #dm_requests r2 WHERE r2.blocking_session_id <> 0) OR r.blocking_session_id <> 0)
				AND DATEDIFF (MINUTE, s.last_request_end_time, GETDATE ()) > @timeblocking
				AND ISNULL (r.blocking_session_id, 0) = 0
			ORDER BY
				s.last_request_end_time;
		
			-- se houver bloqueio, dispara notificacao
			IF (@server_name IS NOT NULL)
			BEGIN
				SET @subject = 'WARNING - LOCKING PROCESSES: INSTANCE ' + @server_name + ' - DATABASE ' + @database_name+ '';
				SET @body = 'MONITORIA, ' + CHAR (13);
				SET @body = @body + 'FAVOR ACIONAR DBA PARA VERIFICAR BLOQUEIOS DA INSTANCIA ' + @server_name + '' + CHAR (10) + CHAR (13);
				SET @body = @body + ' - DATABASE: ' + @database_name + CHAR (10) + CHAR (13);
				SET @body = @body + ' - SPID: ' + CONVERT (VARCHAR, @blockingsessionid) + CHAR (10) + CHAR (13);
				SET @body = @body + ' - STATUS: ' + @status + CHAR (10) + CHAR (13);
				SET @body = @body + ' - HOSTNAME: ' + @hostname + CHAR (10) + CHAR (13);
				SET @body = @body + ' - LOGIN: ' + @login_name + CHAR (10) + CHAR (13);
				SET @body = @body + ' - LOCKING TIME ESTIMATED: ' + CONVERT (VARCHAR, @timeblock) + ' MINUTES' + CHAR (10) + CHAR (13);
				SET @body = @body + ' - LASTBATCH TIME: ' + CONVERT (VARCHAR, @lastbatch) + CHAR (10) + CHAR (13);
				SET @body = @body + ' - PROGRAM NAME: ' + @program_name + CHAR (10) + CHAR (13);
				SET @body = @body + ' - LOCK QUERY: ' + @textbuffer;

				EXECUTE msdb.dbo.sp_send_dbmail 
					@profile_name = 'ProfSqlDBA'
				  , @recipients = 'dba@company.com.br'
				  , @subject = @subject
				  , @body = @body
				  , @importance = 'HIGH'
				  , @append_query_error = 1;
			END
		END
		ELSE BEGIN
			SELECT
				'DBAcmd'			= 'KILL ' + CAST (s.session_id AS VARCHAR)
			  , 'ServerName'		= @@SERVERNAME
			  , 'DatabaseName'		= UPPER (ISNULL (ISNULL (DB_NAME (r.database_id), stmt.dbid), 'master'))
			  , 'SessionID'			= s.session_id
			  , 'BlockingSessionID' = ISNULL (r.blocking_session_id,0)
			  , 'Status'			= ISNULL (r.[status], 'Sleeping')
			  , 'OpenTran'			= S.open_tran
			  , 'TimeInMinute'		= DATEDIFF (MINUTE, s.last_request_end_time, GETDATE ())
			  , 'HostName'			= s.host_name
			  , 'ProgramName'		= s.program_name
			  , 'Loginame'			= s.login_name
			  , 'LastBatch'			= s.last_request_end_time
			  , 'CpuTime'			= ISNULL (s.cpu_time, 0)
			  , 'MemoryUsage'		= ISNULL (s.memory_usage, 0)
			  , 'WaitType'			= r.wait_type
			  , 'WaitResource'		= r.wait_resource
			  , 'LoginTime'			= s.login_time
			  , 'TSQL'				= stmt.[text]
			  , 'ActualText'		= ISNULL (SUBSTRING (stmt.[text], r.statement_start_offset / 2, (CASE WHEN r.statement_end_offset = -1 THEN LEN (CONVERT (NVARCHAR (MAX), stmt.[text])) * 2 ELSE r.statement_end_offset END - r.statement_start_offset) / 2), '')
			FROM
				#dm_sessions s
				INNER JOIN sys.dm_exec_connections c	ON (s.session_id = c.session_id)
				LEFT JOIN #dm_requests r				ON (s.session_id = r.session_id)
				OUTER APPLY sys.dm_exec_sql_text (c.most_recent_sql_handle) stmt
			WHERE
				(s.session_id IN (SELECT r2.blocking_session_id FROM #dm_requests r2 WHERE r2.blocking_session_id <> 0) OR r.blocking_session_id <> 0)
			ORDER BY
				BlockingSessionID
			  , LastBatch;
		END
	END TRY
	BEGIN CATCH
		SELECT 
			ERROR_NUMBER ()
		  , ERROR_SEVERITY ()
		  , ERROR_STATE ()
		  , ERROR_LINE ()
		  , ERROR_PROCEDURE ()
		  , ERROR_MESSAGE ()
	END CATCH
END
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'sp_who5')
	DROP PROCEDURE [dbo].[sp_who5]
GO
PRINT 'creating procedure [dbo].[sp_who5]...';
GO
CREATE PROCEDURE [dbo].[sp_who5]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		SPID					= r.session_id
	  , BlockedBy				= CASE WHEN lead_blocker = 1 THEN -1 ELSE r.blocking_session_id END
	  , ElapsedTime				= r.total_elapsed_time
	  , CpuTime					= r.cpu_time
	  , IOReads					= r.logical_reads + r.reads
	  , Writes					= r.writes
	  , Executions				= ec.execution_count
	  , CommandType				= r.command
	  , LastWaitType			= r.last_wait_type
	  , ObjectName				= OBJECT_SCHEMA_NAME (stmt.objectid, stmt.dbid) + '.' + OBJECT_NAME (stmt.objectid, stmt.dbid)
	  , SQLStatement			= SUBSTRING (stmt.[text], r.statement_start_offset / 2, (CASE WHEN r.statement_end_offset = -1 THEN LEN (CONVERT (NVARCHAR (MAX), stmt.[text])) * 2 ELSE r.statement_end_offset END - r.statement_start_offset) / 2)
	  , [Status]				= s.[status]
	  , Loginame				= s.login_name
	  , DatabaseName			= DB_NAME (r.database_id)
	  , StartTime				= r.start_time
	  , Protocol				= c.net_transport
	  , TransactionIsolation	= 
		CASE 
			WHEN s.transaction_isolation_level = 0 THEN 'Unspecified'
			WHEN s.transaction_isolation_level = 1 THEN 'Read Uncommited'
			WHEN s.transaction_isolation_level = 2 THEN 'Read Commited'
			WHEN s.transaction_isolation_level = 3 THEN 'Repeatable'
			WHEN s.transaction_isolation_level = 4 THEN 'Serializable'
			WHEN s.transaction_isolation_level = 5 THEN 'Snapshot'
		END
	  , ConnectionReads			= c.num_reads
	  , ConnectionWrites		= c.num_writes
	  , ClientAddress			= c.client_net_address
	  , ClientTcpPort			= c.client_tcp_port
	  , Authentication			= c.auth_scheme
	  , PlanHandle				= r.plan_handle
	  , DatetimeSnapshot		= GETDATE ()
	FROM
		sys.dm_exec_requests r
		LEFT JOIN sys.dm_exec_sessions s	ON (r.session_id = s.session_id)
		LEFT JOIN sys.dm_exec_connections c ON (s.session_id = c.session_id)
		OUTER APPLY sys.dm_exec_sql_text (r.sql_handle) stmt
		OUTER APPLY (
			SELECT
				execution_count = MAX (cp.usecounts)
			FROM
				sys.dm_exec_cached_plans cp
			WHERE
				cp.plan_handle = r.plan_handle
		) ec
		OUTER APPLY (
			SELECT 
				lead_blocker = 1
			FROM
				master.sys.sysprocesses p
			WHERE 
				p.spid IN (SELECT blocked FROM master.sys.sysprocesses)
				AND p.blocked = 0
				AND p.spid = r.session_id
		) lb
	WHERE
		r.sql_handle IS NOT NULL
		AND r.session_id <> @@SPID
	ORDER BY
		CASE WHEN lead_blocker = 1 THEN -1 * 1000 ELSE - r.blocking_session_id END
	  , R.blocking_session_id DESC
	  , IOReads DESC
	  , r.session_id
END
GO