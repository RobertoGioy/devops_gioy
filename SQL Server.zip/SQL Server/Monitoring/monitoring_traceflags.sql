USE [DBADMSQL]
GO

IF (OBJECT_ID ('dbat_monitoria_traceflags') IS NOT NULL)
	DROP TABLE [dbo].[dbat_monitoria_traceflags]
GO
PRINT 'creating table [dbo].[dbat_monitoria_traceflags]...';
GO
CREATE TABLE [dbo].[dbat_monitoria_traceflags] (
	Id INT IDENTITY (1,1) NOT NULL
	, traceflag INT NOT NULL
	, descricao VARCHAR (8000)
	, expectedstate BIT NOT NULL CONSTRAINT [DF_traceflags_expectedstate] DEFAULT (1)
	, CONSTRAINT [PK_monitoria_traceflags] PRIMARY KEY CLUSTERED (Id) WITH (FILLFACTOR = 95)
)
ON [PRIMARY];
GO

INSERT INTO [dbo].[dbat_monitoria_traceflags] (traceflag, descricao) VALUES (
	1204, 'Retorna os recursos e tipos de bloqueios que participam de um deadlock e tamb�m o comando atual afetado. Mais informacoes em https://msdn.microsoft.com/pt-br/library/ms188396.aspx'
)
GO
INSERT INTO [dbo].[dbat_monitoria_traceflags] (traceflag, descricao) VALUES (
	1222, 'Retorna os recursos e os tipos de bloqueios que participam de um deadlock e tamb�m o comando atual afetado, em um formato XML que n�o obedece a nenhum esquema XSD. Mais informacoes em https://msdn.microsoft.com/pt-br/library/ms188396.aspx'
)
GO
INSERT INTO [dbo].[dbat_monitoria_traceflags] (traceflag, descricao) VALUES (
	3226, 'Suprime as mensagens de backups completados com sucesso, no errorlog. Mais informacoes em https://msdn.microsoft.com/pt-br/library/ms188396.aspx'
)
GO
INSERT INTO [dbo].[dbat_monitoria_traceflags] (traceflag, descricao) VALUES (
	3605, 'Imprime as mensagens dos comandos DBCC executados, no errorlog. Mais informacoes em http://sql-articles.com/articles/general/day-1-trace-flag-3604-3605/'
)
GO
INSERT INTO [dbo].[dbat_monitoria_traceflags] (traceflag, descricao) VALUES (
	3042, 'Ignora o algoritmo padr�o de pr�-aloca��o de compacta��o de backup para permitir que o arquivo de backup cres�a somente quando necess�rio para alcan�ar seu tamanho final. Mais informacoes em https://msdn.microsoft.com/pt-br/library/ms188396.aspx'
)
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbap_monitoria_traceflags')
	DROP PROCEDURE [dbo].[dbap_monitoria_traceflags]
GO
PRINT 'creating procedure [dbo].[dbap_monitoria_traceflags]...';
GO
CREATE PROCEDURE [dbo].[dbap_monitoria_traceflags]
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE
		@strFlagMais VARCHAR (100) = ''
	  , @strFlagMenos VARCHAR (100) = ''
	  , @strIncorrectStatus VARCHAR (100) = ''
	  , @errorMessage VARCHAR (2000) = ''
	  , @errorSeverity INT
	  , @errorState INT

	CREATE TABLE #tracestatus (
		traceflagId	INT NOT NULL
	  , istatus		INT NULL
	  , iglobal		INT NULL
	  , isession	INT NULL
	);

	BEGIN TRY
		-- carrega flags
		INSERT INTO #tracestatus
		EXECUTE ('DBCC TRACESTATUS (-1) WITH NO_INFOMSGS');

		-- executa validacao
		SELECT
			mt.traceflag
		  , mt.expectedstate
		  , ts.traceflagId
		  , ts.istatus
		INTO
			#traceValidation
		FROM
			dbo.dbat_monitoria_traceflags mt
			FULL OUTER JOIN #tracestatus ts ON mt.traceflag = ts.traceflagId

		-- identifica traceflags em falta na configuracao
		SELECT @strFlagMenos = @strFlagMenos + CONVERT (VARCHAR (10), traceflag) + ' - ' FROM #traceValidation WHERE traceflagId IS NULL;
		-- identifica traceflags a mais na configuracao
		SELECT @strFlagMais = @strFlagMais + CONVERT (VARCHAR (10), traceflagId) + ' - ' FROM #traceValidation WHERE traceflag IS NULL;
		-- identifica traceflags que estao com status diferente da tabela de configuracao
		SELECT 
			@strIncorrectStatus = @strIncorrectStatus + CONVERT (VARCHAR (10), traceflag) + ' - ' 
		FROM 
			#traceValidation
		WHERE
			expectedstate <> istatus
			AND traceflag IS NOT NULL
			AND traceflagId IS NOT NULL;

		IF (@strFlagMenos <> '')
			SET @errorMessage = @errorMessage + 'Traceflags em falta, adicionar: ' + @strFlagMenos + '.';
		IF (@strFlagMais <> '')
			SET @errorMessage = @errorMessage + 'Traceflags a mais, desabilitar: ' + @strFlagMais + '.';
		IF (@strIncorrectStatus <> '')
			SET @errorMessage = @errorMessage + 'Estas Traceflags nao estao com status esperado, corrigir: ' + @strIncorrectStatus + '.';

		DROP TABLE #tracestatus, #traceValidation;
	END TRY

	BEGIN CATCH
		SET @errorMessage = '[' + @@SERVERNAME + ']: Falha ao carregar e verificar Traceflags.';
		SET @errorSeverity = 16;
		SET @errorState = 1;

		RAISERROR (@errorMessage, @errorSeverity, @errorState);
	END CATCH

	IF (@errorMessage <> '')
		RAISERROR (@errorMessage, 16, 1);
	ELSE
		RETURN 1;
END
GO