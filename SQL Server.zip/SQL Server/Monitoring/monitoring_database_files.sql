USE [DBADMSQL]
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbat_monitoring_dbfiles')
BEGIN
PRINT 'creating table [dbo].[dbat_monitoring_dbfiles]...';
CREATE TABLE [dbo].[dbat_monitoring_dbfiles] (
	id				INT IDENTITY (1,1) NOT NULL CONSTRAINT [pk_monitoring_dbfiles] PRIMARY KEY CLUSTERED WITH (FILLFACTOR = 90)
  , dbname			SYSNAME NOT NULL
  , fileid			SMALLINT NULL
  , usage			VARCHAR (16) NULL
  , file_size_mb	DECIMAL (15,2) NOT NULL CONSTRAINT [df_file_size_mb] DEFAULT (0)
  , space_used_mb	DECIMAL (15,2) NOT NULL CONSTRAINT [df_space_used_mb] DEFAULT (0)
  , free_space_mb	DECIMAL (15,2) NOT NULL CONSTRAINT [df_free_space_mb] DEFAULT (0)
  , used_percent	DECIMAL (15,2) NOT NULL CONSTRAINT [df_used_percent] DEFAULT (0)
  , free_percent	DECIMAL (15,2) NOT NULL CONSTRAINT [df_free_percent] DEFAULT (0)
  , logical_name	SYSNAME NOT NULL
  , physical_name	SYSNAME NOT NULL
  , filegroupname	SYSNAME NULL
);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbat_monitoring_dbfiles_log')
BEGIN
PRINT 'creating table [dbo].[dbat_monitoring_dbfiles_log]...';
CREATE TABLE [dbo].[dbat_monitoring_dbfiles_log] (
	logid			INT IDENTITY (1,1) NOT NULL
  , dbname			SYSNAME NOT NULL
  , fileid			SMALLINT NULL
  , type_desc		VARCHAR (16) NULL
  , file_size_mb	DECIMAL (15,2) NOT NULL
  , space_used_mb	DECIMAL (15,2) NOT NULL
  , free_space_mb	DECIMAL (15,2) NOT NULL
  , used_percent	DECIMAL (15,2) NOT NULL
  , free_percent	DECIMAL (15,2) NOT NULL
  , logical_name	SYSNAME NOT NULL
  , physical_name	SYSNAME NOT NULL
  , filegroupname	SYSNAME NULL
  , monitoring_id	TINYINT NOT NULL CONSTRAINT [ck_monitoring_id] CHECK (monitoring_id > 0 AND monitoring_id < 5)
  , logdate			DATETIME NOT NULL
  , CONSTRAINT [pk_monitoring_dbfiles_log] PRIMARY KEY CLUSTERED (logdate, logid) WITH (FILLFACTOR = 90)
);
END
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbap_load_dbfiles')
	DROP PROCEDURE [dbo].[dbap_load_dbfiles]
GO
PRINT 'creating procedure [dbo].[dbap_load_dbfiles]...';
GO
CREATE PROCEDURE [dbo].[dbap_load_dbfiles]
AS
BEGIN
	/*
		Author:	BETO GIOY
		Description: Carrega as informacoes dos data files e log files das bases de dados. Informacoes sao usadas na monitoria dos dbfiles.
	*/
	SET NOCOUNT ON;

	-- limpa a tabela
	TRUNCATE TABLE [dbo].[dbat_monitoring_dbfiles];

	-- insere informacoes dos data files de cada filegroup
	INSERT INTO [dbo].[dbat_monitoring_dbfiles] (
		dbname
	  , fileid
	  , usage
	  , file_size_mb
	  , space_used_mb
	  , free_space_mb
	  , used_percent
	  , free_percent
	  , logical_name
	  , physical_name
	  , filegroupname
	)
	EXEC master.dbo.sp_msforeachdb 'USE [?];
	SELECT 
		DB_NAME ()
	  , f.fileid
	  , CASE f.status & 0x40 WHEN 0x40 THEN ''log_only'' ELSE ''data_only'' END
	  , f.size / 128.0
	  , FILEPROPERTY (f.name, ''SpaceUsed'') / 128.0
	  , (f.size - FILEPROPERTY (f.name, ''SpaceUsed'')) / 128.0
	  , ((FILEPROPERTY (f.name, ''SpaceUsed'') / 128.0) / (f.size / 128.0)) * 100.0
	  , (((f.size - FILEPROPERTY (f.name, ''SpaceUsed'')) / 128.0) / (f.size / 128.0)) * 100.0
	  , f.name
	  , f.filename
	  , g.groupname
	FROM
		sys.sysfiles f
		JOIN sys.sysfilegroups g ON (f.groupid = g.groupid)
	ORDER BY
		f.fileid '

	-- insere informa��es dos log files
	INSERT INTO [dbo].[dbat_monitoring_dbfiles] (
		dbname
	  , fileid
	  , usage
	  , file_size_mb
	  , space_used_mb
	  , free_space_mb
	  , used_percent
	  , free_percent
	  , logical_name
	  , physical_name
	  , filegroupname
	)
	EXEC master.dbo.sp_msforeachdb 'USE [?];
	SELECT 
		DB_NAME ()
	  , f.fileid
	  , CASE f.status & 0x40 WHEN 0x40 THEN ''log_only'' ELSE ''data_only'' END
	  , f.size / 128.0
	  , FILEPROPERTY (f.name, ''SpaceUsed'') / 128.0
	  , (f.size - FILEPROPERTY (f.name, ''SpaceUsed'')) / 128.0
	  , ((FILEPROPERTY (f.name, ''SpaceUsed'') / 128.0) / (f.size / 128.0)) * 100.0
	  , (((f.size - FILEPROPERTY (f.name, ''SpaceUsed'')) / 128.0) / (f.size / 128.0)) * 100.0
	  , f.name
	  , f.filename
	  , g.groupname
	FROM
		sys.sysfiles f
		JOIN sys.sysfilegroups g ON (f.groupid = g.groupid)
	WHERE
		f.status & 0x40 = 0x40
	ORDER BY
		f.fileid '
END
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbap_monitoring_dbfiles')
	DROP PROCEDURE [dbo].[dbap_monitoring_dbfiles]
GO
PRINT 'creating procedure [dbo].[dbap_monitoring_dbfiles]...';
GO
CREATE PROCEDURE [dbo].[dbap_monitoring_dbfiles]
	@exec_type TINYINT = 1	-- 1 = log tempdb, 2 = data tempdb, 3 = log databases, 4 = data databases
  , @recipients VARCHAR (256) = 'dba@company.com.br'
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE 
		@subject VARCHAR(128)
	  , @body VARCHAR (8000)
	  , @stmt VARCHAR (8000)
	  , @dbname SYSNAME
	  , @filegroupname SYSNAME
	  , @used_percent DECIMAL (15,2) ;

	PRINT 'inicio...';
	PRINT 'carrega a tabela de controle com os dados...';

	EXECUTE [dbo].[dbap_load_dbfiles];

	-- 1. log tempdb > 70%
	IF (@exec_type = 1)
	BEGIN
		PRINT 'verifica consumo dos arquivos de log da tempdb...';

		SELECT
			@used_percent =	used_percent
		FROM
			[dbo].[dbat_monitoring_dbfiles]
		WHERE
			dbname = 'tempdb' AND usage = 'log_only' AND used_percent > 70.0;

		IF (@used_percent > 0)
		BEGIN
			SET @subject = 'WARNING - LOG FILE TEMPDB USAGE ' + CAST (@used_percent AS VARCHAR (9)) + '% IN THE INSTANCE ' + CAST (@@SERVERNAME AS VARCHAR) + '';
			SET @body = 'MONITORIA, ' + CHAR (13);
			SET @body = @body + 'FAVOR ACIONAR DBA PARA VERIFICAR LOG FILES DA TEMPDB DA INSTANCIA ' + CAST (@@SERVERNAME AS VARCHAR) + '' + CHAR (13);
			SET @body = @body + 'USE OS COMANDOS ABAIXO:' + CHAR (13);
			SET @body = @body + 'SELECT dbname, usage, used_percent, physical_name FROM [dbo].[dbat_monitoring_dbfiles] WHERE dbname = ''tempdb'' AND usage = ''log_only'' AND used_percent > 70.0' + CHAR (13);
			SET @body = @body + 'DBCC SQLPERF (LOGSPACE);' + CHAR (13) + CHAR (13);
			SET @body = @body + 'CHECKPOINT INICIADO' + CHAR (13);
			
			PRINT 'envia e-mail...';

			EXECUTE msdb.dbo.sp_send_dbmail 
				@profile_name = 'ProfSqlDBA'
			  , @recipients = @recipients
			  , @subject = @subject
			  , @body = @body
			  , @importance = 'HIGH'
			  , @append_query_error = 1;

			PRINT 'insere dados na tabela de historico...';
			INSERT INTO [dbo].[dbat_monitoring_dbfiles_log] (
				dbname
			  , fileid
			  , type_desc
			  , file_size_mb
			  , space_used_mb
			  , free_space_mb
			  , used_percent
			  , free_percent
			  , logical_name
			  , physical_name
			  , filegroupname
			  , monitoring_id
			  , logdate
			)
			SELECT
				dbname
			  , fileid
			  , usage
			  , file_size_mb
			  , space_used_mb
			  , free_space_mb
			  , used_percent
			  , free_percent
			  , logical_name
			  , physical_name
			  , NULL
			  , 1 /* LOG FILES TEMPDB */
			  , GETDATE ()
			FROM
				[dbo].[dbat_monitoring_dbfiles]
			WHERE
				dbname = 'tempdb' AND usage = 'log_only' AND used_percent > 70.0;
			
			PRINT 'executa checkpoint...';
			SET @stmt = 'USE [tempdb]; CHECKPOINT;';
			EXECUTE sp_executesql @stmt;
		END
	END

	-- 2. dados tempdb > 65%
	ELSE IF (@exec_type = 2)
	BEGIN
		PRINT 'verifica consumo dos arquivos de dados da tempdb...';

		SELECT
			@filegroupname = filegroupname
		  , @used_percent =	used_percent
		FROM
			[dbo].[dbat_monitoring_dbfiles]
		WHERE
			dbname = 'tempdb' AND usage = 'data_only' AND used_percent > 65.0;

		IF (@used_percent > 0)
		BEGIN
			SET @subject = 'WARNING - DATA FILE TEMPDB USAGE ' + CAST (@used_percent AS VARCHAR (9)) + '% OF THE FILEGROUP ' + @filegroupname + ' IN THE INSTANCE ' + CAST (@@SERVERNAME AS VARCHAR) + '';
			SET @body = 'MONITORIA, ' + CHAR (13);
			SET @body = @body + 'FAVOR ACIONAR DBA PARA VERIFICAR DATA FILES DA TEMPDB DA INSTANCIA ' + CAST (@@SERVERNAME AS VARCHAR) + '' + CHAR (13);
			SET @body = @body + 'USE OS COMANDOS ABAIXO:' + CHAR (13);
			SET @body = @body + 'SELECT dbname, usage, used_percent, physical_name FROM [dbo].[dbat_monitoring_dbfiles] WHERE dbname = ''tempdb'' AND usage = ''data_only'' AND used_percent > 65.0' + CHAR (13);
			
			PRINT 'envia e-mail...';

			EXECUTE msdb.dbo.sp_send_dbmail 
				@profile_name = 'ProfSqlDBA'
			  , @recipients = @recipients
			  , @subject = @subject
			  , @body = @body
			  , @importance = 'HIGH'
			  , @append_query_error = 1;

			PRINT 'insere dados na tabela de historico...';
			INSERT INTO [dbo].[dbat_monitoring_dbfiles_log] (
				dbname
			  , fileid
			  , type_desc
			  , file_size_mb
			  , space_used_mb
			  , free_space_mb
			  , used_percent
			  , free_percent
			  , logical_name
			  , physical_name
			  , filegroupname
			  , monitoring_id
			  , logdate
			)
			SELECT
				dbname
			  , fileid
			  , usage
			  , file_size_mb
			  , space_used_mb
			  , free_space_mb
			  , used_percent
			  , free_percent
			  , logical_name
			  , physical_name
			  , filegroupname
			  , 2 /* DATA FILES TEMPDB */
			  , GETDATE ()
			FROM
				[dbo].[dbat_monitoring_dbfiles]
			WHERE
				dbname = 'tempdb' AND usage = 'data_only' AND used_percent > 65.0;
		END
	END

	-- 3. log databases > 70%
	ELSE IF (@exec_type = 3)
	BEGIN
		PRINT 'verifica consumo dos arquivos de log das outras bases de dados...';

		SELECT
			@dbname = dbname
		  , @used_percent =	used_percent
		FROM
			[dbo].[dbat_monitoring_dbfiles]
		WHERE
			dbname <> 'tempdb' AND usage = 'log_only' AND used_percent > 70.0

		IF (@used_percent > 0)
		BEGIN
			SET @subject = 'WARNING - LOG FILES DATABASE ' + @dbname + ' USAGE ' + CAST (@used_percent AS VARCHAR (9)) + '% IN THE INSTANCE ' + CAST (@@SERVERNAME AS VARCHAR) + '';
			SET @body = 'MONITORIA, ' + CHAR (13);
			SET @body = @body + 'FAVOR ACIONAR DBA PARA VERIFICAR LOG FILES DA INSTANCIA ' + CAST (@@SERVERNAME AS VARCHAR) + '' + CHAR (13);
			SET @body = @body + 'USE OS COMANDOS ABAIXO:' + CHAR (13);
			SET @body = @body + 'SELECT dbname, usage, used_percent, physical_name FROM [dbo].[dbat_monitoring_dbfiles] WHERE dbname <> ''tempdb'' AND usage = ''log_only'' AND used_percent > 70.0' + CHAR (13);
			SET @body = @body + 'CHECKPOINT INICIADO' + CHAR (13);

			PRINT 'envia e-mail...';

			EXECUTE msdb.dbo.sp_send_dbmail 
				@profile_name = 'ProfSqlDBA'
			  , @recipients = @recipients
			  , @subject = @subject
			  , @body = @body
			  , @importance = 'HIGH'
			  , @append_query_error = 1;

			PRINT 'insere dados na tabela de historico...';
			INSERT INTO [dbo].[dbat_monitoring_dbfiles_log] (
				dbname
			  , fileid
			  , type_desc
			  , file_size_mb
			  , space_used_mb
			  , free_space_mb
			  , used_percent
			  , free_percent
			  , logical_name
			  , physical_name
			  , filegroupname
			  , monitoring_id
			  , logdate
			)
			SELECT
				dbname
			  , fileid
			  , usage
			  , file_size_mb
			  , space_used_mb
			  , free_space_mb
			  , used_percent
			  , free_percent
			  , logical_name
			  , physical_name
			  , NULL
			  , 3 /* LOG FILES DATABASES */
			  , GETDATE ()
			FROM
				[dbo].[dbat_monitoring_dbfiles]
			WHERE
				dbname <> 'tempdb' AND usage = 'log_only' AND used_percent > 70.0;

			PRINT 'executa checkpoint...';
			DECLARE DBCURSOR CURSOR LOCAL FOR
				SELECT 
					dbname
				FROM
					[dbo].[dbat_monitoring_dbfiles]
				WHERE
					dbname <> 'tempdb' AND usage = 'log_only' AND used_percent > 70.0;

			OPEN DBCURSOR;
			FETCH NEXT FROM DBCURSOR INTO @dbname;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @stmt = 'USE ' + @dbname + '; CHECKPOINT;';
				EXECUTE sp_executesql @stmt;

				FETCH NEXT FROM DBCURSOR INTO @dbname;
			END

			CLOSE DBCURSOR;
			DEALLOCATE DBCURSOR;
		END
	END

	-- 4. data databases > 90%
	ELSE IF (@exec_type = 4)
	BEGIN
		PRINT 'verifica consumo dos arquivos de dados das outras bases de dados...';

		SELECT
			@dbname = dbname
		  , @filegroupname = filegroupname
		  , @used_percent =	AVG (used_percent)
		FROM
			[dbo].[dbat_monitoring_dbfiles]
		WHERE
			dbname <> 'tempdb' AND usage = 'data_only'
		GROUP BY
			dbname
		  , filegroupname
		HAVING
			AVG (used_percent) > 90.0

		IF (@used_percent > 0)
		BEGIN
			SET @subject = 'WARNING - DATA FILES DATABASE ' + @dbname + ' USAGE ' + CAST (@used_percent AS VARCHAR (9)) + '% OF THE FILEGROUP ' + @filegroupname + ' IN THE INSTANCE ' + CAST (@@SERVERNAME AS VARCHAR) + '';
			SET @body = 'MONITORIA, ' + CHAR (13);
			SET @body = @body + 'FAVOR ACIONAR DBA PARA VERIFICAR DATA FILES DA INSTANCIA ' + CAST (@@SERVERNAME AS VARCHAR) + '' + CHAR (13);
			SET @body = @body + 'USE OS COMANDOS ABAIXO:' + CHAR (13);
			SET @body = @body + 'SELECT dbname, filegroupname, AVG (used_percent) FROM [dbo].[dbat_monitoring_dbfiles] dbname <> ''tempdb'' AND usage = ''data_only'' GROUP BY dbname , filegroupname HAVING AVG (used_percent) > 90.0' + CHAR (13);
			
			PRINT 'envia e-mail...';

			EXECUTE msdb.dbo.sp_send_dbmail 
				@profile_name = 'ProfSqlDBA'
			  , @recipients = @recipients
			  , @subject = @subject
			  , @body = @body
			  , @importance = 'HIGH'
			  , @append_query_error = 1;

			PRINT 'insere dados na tabela de historico...';
			INSERT INTO [dbo].[dbat_monitoring_dbfiles_log] (
				dbname
			  , fileid
			  , type_desc
			  , file_size_mb
			  , space_used_mb
			  , free_space_mb
			  , used_percent
			  , free_percent
			  , logical_name
			  , physical_name
			  , filegroupname
			  , monitoring_id
			  , logdate
			)
			SELECT
				dbname
			  , fileid
			  , usage
			  , file_size_mb
			  , space_used_mb
			  , free_space_mb
			  , used_percent
			  , free_percent
			  , logical_name
			  , physical_name
			  , filegroupname
			  , 4 /* DATA FILES DATABASES */
			  , GETDATE ()
			FROM
				[dbo].[dbat_monitoring_dbfiles]
			WHERE
				dbname <> 'tempdb' AND usage = 'data_only'
			GROUP BY
				dbname
			  , fileid
			  , usage
			  , file_size_mb
			  , space_used_mb
			  , free_space_mb
			  , used_percent
			  , free_percent
			  , logical_name
			  , physical_name
			  , filegroupname
			HAVING
				AVG (used_percent) > 90.0;
		END
	END
END
GO