USE [DBADMSQL]
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbap_diskspace_details')
	DROP PROCEDURE [dbo].[dbap_diskspace_details]
GO
PRINT 'creating procedure [dbo].[dbap_diskspace_details]...';
GO
CREATE PROCEDURE [dbo].[dbap_diskspace_details]
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @stmt VARCHAR (4000);

	SET @stmt = 'powershell.exe -c "Get-WmiObject -Class Win32_Volume -Filter ''DriveType = 3'' | select name,capacity,freespace | foreach{$_.name+''|''+$_.capacity/1048576+''%''+$_.freespace/1048576+''*''}"';

	CREATE TABLE #output (line VARCHAR (255));
	CREATE TABLE #powershell (line VARCHAR (255));
	CREATE TABLE #drivers (drive CHAR (1));
	CREATE TABLE #instances (instance VARCHAR (50));
	CREATE TABLE #diskspace (drivename VARCHAR (100), capacity DECIMAL (19,2), freespace DECIMAL (19,2));

	CREATE TABLE #dbat_diskspace_details (
		sql_version		VARCHAR (20)
	  , active_node		SQL_VARIANT
	  , instance_name	SQL_VARIANT
	  , drivename		VARCHAR (100)
	  , disk_type		VARCHAR (30) NULL
	  , content			VARCHAR (30) NULL
	  , capacity		BIGINT
	  , freespace		BIGINT
	  , spaceused		BIGINT
	  , logdate			DATETIME
	);

	CREATE TABLE #discos (
		disco		VARCHAR (100) NULL
	  , subDir		VARCHAR (150) NULL
	  , depth		INT NULL
	  , tipoDisco	VARCHAR (50) NULL
	  , contem		VARCHAR (250) NULL
	);

	CREATE TABLE #disco_final (
		disco		VARCHAR (100) NULL
	  , tipoDisco	VARCHAR (50) NULL
	  , contem		VARCHAR (250) NULL
	);

	INSERT INTO #output EXEC master.dbo.xp_cmdshell @stmt;

	INSERT INTO #diskspace
	SELECT
		RTRIM (LTRIM (SUBSTRING (line, 1, CHARINDEX('|', line) -1))) AS drivename
	  , ROUND (CAST (RTRIM (LTRIM (SUBSTRING (line, CHARINDEX('|', line) + 1, (CHARINDEX('%', line) - 1) - CHARINDEX('|', line)))) AS DECIMAL (19,2)),0) AS capacity
	  , ROUND (CAST (RTRIM (LTRIM (SUBSTRING (line, CHARINDEX('%', line) + 1, (CHARINDEX('*', line) - 1) - CHARINDEX('%', line)))) AS DECIMAL (19,2)),0) AS freespace
	FROM
		#output
	WHERE
		line LIKE '[A-Z][:]%'
	ORDER BY
		drivename;

	SET @stmt = 'powershell.exe -noprofile -command "Get-Service | Where-Object {$_.Name -like ''MSSQL$*'' -or $_.Name -eq ''MSSQLSERVER'' -and $_.status -eq ''Running''} | select name | foreach{$_.name+''|''}"';

	INSERT INTO #powershell EXEC master.dbo.xp_cmdshell @stmt;

	INSERT INTO #instances
	SELECT RTRIM (LTRIM (SUBSTRING (line, 1, CHARINDEX('|', line) -1))) FROM #powershell;

	-- caso tenha mais de uma instancia no mesmo node, usa a funcao fn_servershareddrives () para que apresente apenas os discos dependentes da instancia em questao
	IF (SELECT COUNT (instance) FROM #instances WHERE instance IS NOT NULL) > 1
		INSERT INTO #drivers
		SELECT DriveName FROM ::fn_servershareddrives ();
	ELSE
		INSERT INTO #drivers
		SELECT DISTINCT LEFT (line, 1) FROM #output;

	-- carrega tabela de apoio
	DECLARE @Tsql VARCHAR (100), @disco VARCHAR (100);
	DECLARE discos_Cursor CURSOR LOCAL FOR
		SELECT
			a.drivename
		FROM 
			#diskspace a JOIN #drivers b ON (a.drivename = b.drive)
		WHERE
			LEN (a.drivename) = 3 AND a.drivename <> 'C:\';

	OPEN discos_Cursor;
	FETCH NEXT FROM discos_Cursor INTO @disco

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Tsql = 'DIR ' + @disco + ' /ad /b';

		INSERT INTO #discos (subDir)
		EXEC master.dbo.xp_cmdshell @Tsql;

		UPDATE #discos SET disco = @disco WHERE disco IS NULL;

		FETCH NEXT FROM discos_Cursor INTO @disco
	END

	CLOSE discos_Cursor;
	DEALLOCATE discos_Cursor;

	-- descobre os discos tipo Mount Volume
	UPDATE	
		#discos
	SET		
		disco = a.disco + a.subDir + '\'
	  , subDir = NULL
	  ,	tipoDisco = 'Mount Volume'
	FROM	
		#discos a JOIN #diskspace b ON (a.disco + a.subDir + '\' = b.drivename);

	-- descobre os discos fisicos (disks)
	UPDATE #discos SET tipoDisco = 'Disk' WHERE tipoDisco IS NULL;

	-- define o conteudo dos discos
	UPDATE	#discos
	SET		contem = 
			CASE 
				WHEN UPPER (disco) LIKE '%TEMPDB%' THEN 'TempDB'
				WHEN UPPER (disco) LIKE '%DADOS%' THEN 'Dados'
				WHEN UPPER (disco) LIKE '%LOG%' THEN 'Log'
				WHEN UPPER (disco) LIKE '%BACKUP%' THEN 'Backup'
				WHEN UPPER (disco) LIKE '%BACKTRAN%' THEN 'BackTran'
				WHEN UPPER (disco) LIKE '%MSSQL%' THEN 'InSQL'
				WHEN UPPER (disco) LIKE '%MSDTC%' THEN 'MSDTC'
			END
	WHERE	contem IS NULL;

	-- classifica os discos sem as pastas acima com Sem uso
	UPDATE	#discos
	SET		contem = '** Sem Uso'
	FROM	#discos
	WHERE	disco NOT IN (SELECT disco FROM #discos WHERE contem IS NOT NULL);

	DECLARE @tipoDisco VARCHAR (50), @contem VARCHAR (30);
	DECLARE discoFinal_Cursor CURSOR LOCAL FOR
		SELECT disco, tipoDisco, contem FROM #discos WHERE contem IS NOT NULL

	OPEN discoFinal_Cursor;
	FETCH NEXT FROM discoFinal_Cursor INTO @disco, @tipoDisco, @contem

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @contem = CASE WHEN @contem = 'BackTran' THEN 'Backup' ELSE @contem END

		IF NOT EXISTS (SELECT disco FROM #disco_final WHERE disco = @disco)
			INSERT INTO #disco_final (disco, tipoDisco, contem) VALUES (@disco, @tipoDisco, @contem);
		ELSE
			IF NOT EXISTS (SELECT disco FROM #disco_final WHERE disco = @disco AND contem LIKE '%' + @contem + '%')
				UPDATE #disco_final SET contem = contem + ' + ' + @contem WHERE disco = @disco;

		FETCH NEXT FROM discoFinal_Cursor INTO @disco, @tipoDisco, @contem
	END

	CLOSE discoFinal_Cursor;
	DEALLOCATE discoFinal_Cursor;

	-- insere os dados na tabela temp
	INSERT INTO #dbat_diskspace_details (
		sql_version
	  , active_node
	  , instance_name
	  , drivename
	  , disk_type
	  , content
	  , capacity
	  , freespace
	  , spaceused
	  , logdate
	)
	SELECT
		CASE 
			WHEN (@@MICROSOFTVERSION / 0X01000000) = 8 THEN 'SQL SERVER 2000'
			WHEN (@@MICROSOFTVERSION / 0X01000000) = 9 THEN 'SQL SERVER 2005'
			WHEN (@@MICROSOFTVERSION / 0X01000000) = 10 THEN 'SQL SERVER 2008'
			WHEN (@@MICROSOFTVERSION / 0X01000000) = 11 THEN 'SQL SERVER 2012'
			WHEN (@@MICROSOFTVERSION / 0X01000000) = 12 THEN 'SQL SERVER 2014'
		END 
	  , SERVERPROPERTY ('ComputerNamePhysicalNetBIOS')
	  , SERVERPROPERTY ('ServerName')
	  , df.disco
	  , df.tipoDisco
	  , df.contem
	  , ds.capacity
	  , ds.freespace
	  , ds.capacity - ds.freespace
	  , GETDATE ()
	FROM
		#disco_final df JOIN #diskspace ds ON (df.disco = ds.drivename)
	WHERE
		ds.drivename NOT LIKE '%MSDTC%';

	-- gera o report detalhado
	DECLARE
		@instance_name SQL_VARIANT = NULL
	  , @content VARCHAR (30) = NULL
	  , @data DATETIME = NULL
	  , @dias INT = 1
	
	-- IF @data IS NULL SET @data = GETDATE () - 1;

	SELECT
		dd.sql_version
	  , dd.active_node
	  , dd.instance_name
	  , dd.drivename
	  , dd.disk_type
	  , dd.content
	  , dd.capacity
	  , dd.freespace
	  , dd.spaceused
	  , CONVERT (DECIMAL (19,2), (CONVERT (NUMERIC (19,2), dd.spaceused) / CONVERT (NUMERIC (19,2), dd.capacity)) * 100.0) AS [% Used]
	  , CASE
			WHEN CONVERT (DECIMAL (19,2), (CONVERT (NUMERIC (19,2), dd.spaceused) / CONVERT (NUMERIC (19,2), dd.capacity)) * 100.0)> 70
			THEN CONVERT (BIGINT, (dd.capacity * 0.3)) - dd.freespace
			ELSE 0
		END AS [Space Missing]
	  , dd.spaceused - (CONVERT (BIGINT, (dd.capacity * 0.3)) - dd.freespace) AS [Target Use]
	  , dd.logdate
	FROM
		#dbat_diskspace_details dd
	WHERE
		(instance_name = @instance_name OR @instance_name IS NULL)
	AND (content = @content OR @content IS NULL)
	--AND logdate BETWEEN DATEADD (DD, - @dias, @data + ' 23:59:59.997') AND @data + ' 23:59:59.997'
	ORDER BY
		drivename
	  , disk_type
	  , logdate;

	-- gera o report consolidado
	SELECT
		sql_version
	  , active_node
	  , instance_name
	  , content
	  , COUNT (disk_type) AS Disks
	  , SUM (capacity) AS capacity
	  , SUM (freespace) AS freespace
	  , SUM (spaceused) AS spaceused
	  , CONVERT (DECIMAL (19,2), (CONVERT (NUMERIC (19,2), SUM (spaceused)) / CONVERT (NUMERIC (19,2), SUM (capacity))) * 100.0) AS [% Used]
	  , logdate
	FROM
		#dbat_diskspace_details
	WHERE
		(instance_name = @instance_name OR @instance_name IS NULL)
	AND (content = @content OR @content IS NULL)
	--AND logdate BETWEEN DATEADD (DD, - @dias, @data + ' 23:59:59.997') AND @data + ' 23:59:59.997'
	GROUP BY
		sql_version
	  , active_node
	  , instance_name
	  , content
	  , logdate
	ORDER BY
		content
	  , logdate

	DROP TABLE #dbat_diskspace_details, #disco_final, #discos, #diskspace, #drivers, #instances, #output, #powershell;
END
GO