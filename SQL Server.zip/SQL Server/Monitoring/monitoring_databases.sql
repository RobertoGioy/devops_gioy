USE [DBADMSQL]
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbap_alert_log')
	DROP PROCEDURE [dbo].[dbap_alert_log]
GO
PRINT 'creating procedure [dbo].[dbap_alert_log]...';
GO
CREATE PROCEDURE [dbo].[dbap_alert_log]
	@dbname SYSNAME = NULL
AS
BEGIN
	SET NOCOUNT ON;

	IF DB_ID (@dbname) IS NULL RETURN;

	-- LOG PERCENTAGE USAGE
	SELECT 'LOG PERCENTAGE USAGE' AS INFO;

	SELECT
		@@SERVERNAME AS ServerName
	  , pc.counter_name
	  , pc.instance_name as dbname
	  , pc.cntr_value as logusage
	FROM
		sys.dm_os_performance_counters pc
	WHERE
		pc.object_name LIKE '%Databases%'
		AND pc.counter_name LIKE '%Percent Log Used%'
		AND LTRIM (RTRIM (pc.instance_name)) LIKE @dbname
		AND pc.instance_name NOT LIKE '%mssqlsystemresource%'
	ORDER BY
		pc.cntr_value DESC;

	-- VLF not reused wait desc
	SELECT 'VLF NOT REUSED WAIT DESC' AS INFO;

	SELECT 
		name AS dbname
	  , log_reuse_wait_desc 
	FROM 
		master.sys.databases 
	WHERE 
		name LIKE @dbname
	ORDER BY
		name;

	-- Log bytes and records usage, ordering by Begintime
	SELECT 'LOG BYTES AND RECORDS USAGE, ORDERING BY BEGIN TIME' AS INFO;

	SELECT
		[Session ID]		= st.session_id
	  , [Login Name]		= es.login_name
	  , [Database]			= DB_NAME (dt.database_id)
	  , [Begin Time]		= dt.database_transaction_begin_time
	  , [Status]			= er.[status]
	  , [Log Reuse Wait]	= db.log_reuse_wait_desc
	  , [Log Records]		= dt.database_transaction_log_record_count
	  , [Log Bytes]			= dt.database_transaction_log_bytes_used
	  , [Log Reserved]		= dt.database_transaction_log_bytes_reserved
	  , [Last T-SQL]		= est.[text]
	  , [Last Exec Plan]	= eqp.query_plan
	FROM
		master.sys.dm_tran_database_transactions dt
		INNER JOIN master.sys.dm_tran_session_transactions st	ON (dt.transaction_id = st.transaction_id)
		INNER JOIN master.sys.dm_exec_sessions es				ON (st.session_id = es.session_id)
		INNER JOIN master.sys.dm_exec_connections ec			ON (es.session_id = ec.session_id)
		LEFT JOIN master.sys.databases db						ON (es.database_id = db.database_id)
		LEFT OUTER JOIN master.sys.dm_exec_requests er			ON (es.session_id = er.session_id)
		CROSS APPLY master.sys.dm_exec_sql_text (ec.most_recent_sql_handle) est
		OUTER APPLY master.sys.dm_exec_query_plan (er.plan_handle) eqp
	WHERE
		dt.database_transaction_log_bytes_used > 0
		AND DB_NAME (dt.database_id) = @dbname
	ORDER BY
		[Begin Time];

	-- Opentran Generated on Messages Painel
	SELECT 'OPENTRAN GENERATED ON MESSAGES PAINEL' AS INFO;

	DBCC OPENTRAN (@dbname);
END
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbap_alert_data_tempdb')
	DROP PROCEDURE [dbo].[dbap_alert_data_tempdb]
GO
PRINT 'creating procedure [dbo].[dbap_alert_data_tempdb]...';
GO
CREATE PROCEDURE [dbo].[dbap_alert_data_tempdb]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 'TOP 10 TEMPDB DATA CONSUMERS' AS INFO;

	SELECT
		tsp.session_id
	  , tsp.request_id
	  , (SELECT SUM (size) * 1.0/128 FROM tempdb.sys.database_files WHERE type_desc = 'ROWS') AS temp_size_db
	  , tsp.task_alloc AS task_page_alloc
	  , tsp.task_alloc * 1.0/128 AS task_alloc_MB
	  , ((tsp.task_alloc * 1.0/128) / (SELECT SUM (size) * 1.0/128 FROM tempdb.sys.database_files WHERE type_desc = 'ROWS')) AS percent_used
	  , es.login_time
	  , es.last_request_start_time
	  , es.login_name
	  , es.nt_domain
	  , es.nt_user_name
	  , es.[status]
	  , es.[host_name]
	  , (SELECT SUBSTRING (st.[text], er.statement_start_offset / 2, (CASE WHEN er.statement_end_offset = -1 THEN LEN (CONVERT (NVARCHAR (MAX), st.[text])) * 2 ELSE er.statement_end_offset END - er.statement_start_offset) / 2) FROM master.sys.dm_exec_sql_text (er.sql_handle) st) AS query_text
	  , (SELECT query_plan FROM master.sys.dm_exec_query_plan(er.plan_handle)) qp
	FROM (
		SELECT
			tsu.session_id
		  , tsu.request_id
		  , SUM (tsu.internal_objects_alloc_page_count + tsu.user_objects_alloc_page_count) AS task_alloc
		  , SUM (tsu.internal_objects_dealloc_page_count + tsu.user_objects_dealloc_page_count) AS task_dealloc
		FROM
			master.sys.dm_db_task_space_usage tsu
		GROUP BY
			tsu.session_id
		  , tsu.request_id
	) AS tsp
		LEFT JOIN master.sys.dm_exec_requests er ON (tsp.request_id = er.request_id AND tsp.session_id = er.session_id)
		LEFT JOIN master.sys.dm_exec_sessions es ON (tsp.session_id = es.session_id)
	ORDER BY
		tsp.task_alloc DESC;
	
	SELECT 'SNAPSHOT VERSION STORE INFO' AS INFO;

	SELECT 
		asdt.transaction_id
	  , asdt.session_id
	  , asdt.elapsed_time_seconds / 60 AS elapse_time_min
	  , asdt.elapsed_time_seconds / 360 AS elapse_time_hour
	  , asdt.is_snapshot
	  , asdt.transaction_sequence_num
	  , asdt.first_snapshot_sequence_num
	  , asdt.commit_sequence_num
	  , asdt.average_version_chain_traversed
	  , asdt.max_version_chain_traversed
	FROM
		master.sys.dm_tran_active_snapshot_database_transactions asdt
	ORDER BY
		asdt.elapsed_time_seconds DESC;
END
GO