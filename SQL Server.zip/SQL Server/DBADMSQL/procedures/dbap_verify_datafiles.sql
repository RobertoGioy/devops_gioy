USE [DBADMSQL]
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbap_verify_datafiles')
	DROP PROCEDURE [dbo].[dbap_verify_datafiles]
GO
PRINT 'creating procedure [dbo].[dbap_verify_datafiles]...';
GO
CREATE PROCEDURE [dbo].[dbap_verify_datafiles]
	@dbname SYSNAME
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @stmt NVARCHAR (MAX);

	IF DB_ID (@dbname) IS NULL RETURN;

	SELECT 'DB FILES USAGE' AS info;
	SET @stmt = 'USE [' + @dbname + '];
	SELECT
		mf.type_desc
	  , mf.name AS logical_name
	  , mf.physical_name
	  , fg.name AS filegroupname
	  , CAST ((mf.size / 128.0) AS DECIMAL(19,2)) AS size_mb
	  , CAST (FILEPROPERTY (mf.name, ''SpaceUsed'') / 128.0 AS DECIMAL(19,2)) AS spaceused_mb
	  , CAST ((mf.size - FILEPROPERTY (mf.name, ''SpaceUsed'')) / 128.0 AS DECIMAL(19,2)) AS freespace_mb
	  , CAST (((FILEPROPERTY (mf.name, ''SpaceUsed'') / 128.0) / (mf.size / 128.0)) * 100.0 AS DECIMAL(19,2)) AS used_perc
	  , CAST ((((mf.size - FILEPROPERTY (mf.name, ''SpaceUsed'')) / 128.0) / (mf.size / 128.0)) * 100.0 AS DECIMAL(19,2)) AS free_perc
	FROM
		master.sys.master_files mf
		LEFT JOIN sys.filegroups fg ON mf.data_space_id = fg.data_space_id
	WHERE
		mf.database_id = DB_ID (''' + @dbname + ''');';

	EXECUTE sp_executesql @stmt;

	SELECT 'FILGROUPS USAGE' AS info;
	SET @stmt = 'USE [' + @dbname + '];
	WITH FILES AS (
	SELECT
		mf.data_space_id AS FilegroupId
	  , ds.name AS FilegroupName
	  , SUM (CAST ((mf.size * 8) / 1024.0 AS DECIMAL (19,2))) AS Filegroup_size_mb
	  , SUM (CAST ((FILEPROPERTY (mf.name, ''SpaceUsed'') * 8) / 1024 AS DECIMAL (19,2))) AS spaceused_mb
	  , SUM (CAST (((mf.size - FILEPROPERTY (mf.name, ''SpaceUsed'')) * 8) / 1024 AS DECIMAL (19,2))) AS freespace_mb
	FROM
		master.sys.master_files mf
		INNER JOIN sys.data_spaces ds ON mf.data_space_id = ds.data_space_id
	WHERE
		mf.database_id = DB_ID (''' + @dbname + ''')
	GROUP BY
		mf.data_space_id
	  , ds.name
	)
	SELECT
		f.FilegroupName
	  , f.Filegroup_size_mb
	  , f.spaceused_mb
	  , f.freespace_mb
	  , CAST ((f.freespace_mb / f.Filegroup_size_mb) * 100.0 AS NUMERIC (19,2)) AS free_perc
	FROM
		FILES f
	ORDER BY
		f.FilegroupName'

	EXECUTE sp_executesql @stmt;
END
GO