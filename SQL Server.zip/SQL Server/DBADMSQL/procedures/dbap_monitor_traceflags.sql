USE [DBADMSQL]
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbap_monitor_traceflags')
	DROP PROCEDURE [dbo].[dbap_monitor_traceflags]
GO
PRINT 'creating procedure [dbo].[dbap_monitor_traceflags]...';
GO
CREATE PROCEDURE [dbo].[dbap_monitor_traceflags]
AS
BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #traceflags (
		traceflag	INT
	  , [status]	SMALLINT NULL
	  , [global]	SMALLINT NULL
	  , [session]	SMALLINT NULL
	);

	-- carrega flags
	INSERT INTO #traceflags
	EXECUTE ('DBCC TRACESTATUS () WITH NO_INFOMSGS');

	IF EXISTS (SELECT traceflag FROM dbo.dbat_monitor_traceflags tf WHERE tf.flagstatus = 1 AND tf.traceflag NOT IN (SELECT traceflag FROM #traceflags))
	BEGIN
		DECLARE @subject VARCHAR (100), @body NVARCHAR (MAX)

		SET @subject = 'TRACE FLAGS DESABILITADOS - SERVIDOR: ' + @@SERVERNAME + '';
		SET @body = 'Trace flags ativos diferentes do baseline (T1204 - T1222 - T3226 - T3605 - T3042). Por favor verificar.';

		EXEC msdb.dbo.sp_send_dbmail 
			@profile_name = 'ProfSqlDba'
		  , @recipients = 'dba@company.com.br'
		  , @subject = @subject
		  , @body = @body
		  , @query = 'SET NOCOUNT ON; DBCC TRACESTATUS () WITH NO_INFOMSGS;'
		  , @importance = 'High'
		  , @append_query_error = 1;
	END

	DROP TABLE #traceflags;
END
GO