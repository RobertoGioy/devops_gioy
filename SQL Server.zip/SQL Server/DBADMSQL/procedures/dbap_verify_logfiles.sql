USE [DBADMSQL]
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbap_verify_logfiles')
	DROP PROCEDURE [dbo].[dbap_verify_logfiles]
GO
PRINT 'creating procedure [dbo].[dbap_verify_logfiles]...';
GO
CREATE PROCEDURE [dbo].[dbap_verify_logfiles]
	@dbname SYSNAME = NULL
AS
BEGIN
	SET NOCOUNT ON;

	IF DB_ID (@dbname) IS NULL RETURN;

	-- LOG PERCENTAGE USAGE
	SELECT 'LOG PERCENTAGE USAGE' AS INFO;

	SELECT
		@@SERVERNAME AS ServerName
	  , pc.counter_name
	  , pc.instance_name as dbname
	  , pc.cntr_value as logusage
	FROM
		sys.dm_os_performance_counters pc
	WHERE
		pc.object_name LIKE '%Databases%'
		AND pc.counter_name LIKE '%Percent Log Used%'
		AND LTRIM (RTRIM (pc.instance_name)) LIKE @dbname
		AND pc.instance_name NOT LIKE '%mssqlsystemresource%'
	ORDER BY
		pc.cntr_value DESC;

	-- VLF not reused wait desc
	SELECT 'VLF NOT REUSED WAIT DESC' AS INFO;

	SELECT 
		name AS dbname
	  , log_reuse_wait_desc 
	FROM 
		master.sys.databases 
	WHERE 
		name LIKE @dbname
	ORDER BY
		name;

	-- Log bytes and records usage, ordering by Begintime
	SELECT 'LOG BYTES AND RECORDS USAGE, ORDERING BY BEGIN TIME' AS INFO;

	SELECT
		[Session ID]		= st.session_id
	  , [Login Name]		= es.login_name
	  , [Database]			= DB_NAME (dt.database_id)
	  , [Begin Time]		= dt.database_transaction_begin_time
	  , [Status]			= er.[status]
	  , [Log Reuse Wait]	= db.log_reuse_wait_desc
	  , [Log Records]		= dt.database_transaction_log_record_count
	  , [Log Bytes]			= dt.database_transaction_log_bytes_used
	  , [Log Reserved]		= dt.database_transaction_log_bytes_reserved
	  , [Last T-SQL]		= est.[text]
	  , [Last Exec Plan]	= eqp.query_plan
	FROM
		master.sys.dm_tran_database_transactions dt
		INNER JOIN master.sys.dm_tran_session_transactions st	ON (dt.transaction_id = st.transaction_id)
		INNER JOIN master.sys.dm_exec_sessions es				ON (st.session_id = es.session_id)
		INNER JOIN master.sys.dm_exec_connections ec			ON (es.session_id = ec.session_id)
		LEFT JOIN master.sys.databases db						ON (es.database_id = db.database_id)
		LEFT OUTER JOIN master.sys.dm_exec_requests er			ON (es.session_id = er.session_id)
		CROSS APPLY master.sys.dm_exec_sql_text (ec.most_recent_sql_handle) est
		OUTER APPLY master.sys.dm_exec_query_plan (er.plan_handle) eqp
	WHERE
		dt.database_transaction_log_bytes_used > 0
		AND DB_NAME (dt.database_id) = @dbname
	ORDER BY
		[Begin Time];

	-- Opentran Generated on Messages Painel
	SELECT 'OPENTRAN GENERATED ON MESSAGES PAINEL' AS INFO;

	DBCC OPENTRAN (@dbname);
END
GO