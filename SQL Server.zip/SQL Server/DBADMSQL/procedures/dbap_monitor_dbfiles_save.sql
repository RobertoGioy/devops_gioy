USE [DBADMSQL]
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbap_monitor_dbfiles_save')
	DROP PROCEDURE [dbo].[dbap_monitor_dbfiles_save]
GO
PRINT 'creating procedure [dbo].[dbap_monitor_dbfiles_save]...';
GO
CREATE PROCEDURE [dbo].[dbap_monitor_dbfiles_save]
AS
BEGIN
	/*
		Author:	BETO GIOY
		Description: Carrega as informacoes dos data files e log files das bases de dados. Informacoes sao usadas na monitoria dos dbfiles.
	*/
	SET NOCOUNT ON;

	-- limpa a tabela
	TRUNCATE TABLE [dbo].[dbat_monitor_dbfiles];

	-- insere informacoes dos data files de cada filegroup
	INSERT INTO [dbo].[dbat_monitor_dbfiles] (
		dbname
	  , fileid
	  , usage
	  , file_size_mb
	  , space_used_mb
	  , free_space_mb
	  , used_percent
	  , free_percent
	  , logical_name
	  , physical_name
	  , filegroupname
	)
	EXEC master.dbo.sp_msforeachdb 'USE [?];
	SELECT 
		DB_NAME ()
	  , f.fileid
	  , CASE f.status & 0x40 WHEN 0x40 THEN ''log_only'' ELSE ''data_only'' END
	  , f.size / 128.0
	  , FILEPROPERTY (f.name, ''SpaceUsed'') / 128.0
	  , (f.size - FILEPROPERTY (f.name, ''SpaceUsed'')) / 128.0
	  , ((FILEPROPERTY (f.name, ''SpaceUsed'') / 128.0) / (f.size / 128.0)) * 100.0
	  , (((f.size - FILEPROPERTY (f.name, ''SpaceUsed'')) / 128.0) / (f.size / 128.0)) * 100.0
	  , f.name
	  , f.filename
	  , g.groupname
	FROM
		sys.sysfiles f
		JOIN sys.sysfilegroups g ON (f.groupid = g.groupid)
	ORDER BY
		f.fileid '

	-- insere informa��es dos log files
	INSERT INTO [dbo].[dbat_monitor_dbfiles] (
		dbname
	  , fileid
	  , usage
	  , file_size_mb
	  , space_used_mb
	  , free_space_mb
	  , used_percent
	  , free_percent
	  , logical_name
	  , physical_name
	  , filegroupname
	)
	EXEC master.dbo.sp_msforeachdb 'USE [?];
	SELECT 
		DB_NAME ()
	  , f.fileid
	  , CASE f.status & 0x40 WHEN 0x40 THEN ''log_only'' ELSE ''data_only'' END
	  , f.size / 128.0
	  , FILEPROPERTY (f.name, ''SpaceUsed'') / 128.0
	  , (f.size - FILEPROPERTY (f.name, ''SpaceUsed'')) / 128.0
	  , ((FILEPROPERTY (f.name, ''SpaceUsed'') / 128.0) / (f.size / 128.0)) * 100.0
	  , (((f.size - FILEPROPERTY (f.name, ''SpaceUsed'')) / 128.0) / (f.size / 128.0)) * 100.0
	  , f.name
	  , f.filename
	  , g.groupname
	FROM
		sys.sysfiles f
		JOIN sys.sysfilegroups g ON (f.groupid = g.groupid)
	WHERE
		f.status & 0x40 = 0x40
	ORDER BY
		f.fileid '
END
GO