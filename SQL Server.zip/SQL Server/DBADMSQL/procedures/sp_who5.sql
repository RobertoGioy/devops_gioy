USE [DBADMSQL]
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'sp_who5')
	DROP PROCEDURE [dbo].[sp_who5]
GO
PRINT 'creating procedure [dbo].[sp_who5]...';
GO
CREATE PROCEDURE [dbo].[sp_who5]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		SPID					= r.session_id
	  , BlockedBy				= CASE WHEN lead_blocker = 1 THEN -1 ELSE r.blocking_session_id END
	  , ElapsedTime				= r.total_elapsed_time
	  , CpuTime					= r.cpu_time
	  , IOReads					= r.logical_reads + r.reads
	  , Writes					= r.writes
	  , Executions				= ec.execution_count
	  , CommandType				= r.command
	  , LastWaitType			= r.last_wait_type
	  , ObjectName				= OBJECT_SCHEMA_NAME (stmt.objectid, stmt.dbid) + '.' + OBJECT_NAME (stmt.objectid, stmt.dbid)
	  , SQLStatement			= SUBSTRING (stmt.[text], r.statement_start_offset / 2, (CASE WHEN r.statement_end_offset = -1 THEN LEN (CONVERT (NVARCHAR (MAX), stmt.[text])) * 2 ELSE r.statement_end_offset END - r.statement_start_offset) / 2)
	  , [Status]				= s.[status]
	  , Loginame				= s.login_name
	  , DatabaseName			= DB_NAME (r.database_id)
	  , StartTime				= r.start_time
	  , Protocol				= c.net_transport
	  , TransactionIsolation	= 
		CASE 
			WHEN s.transaction_isolation_level = 0 THEN 'Unspecified'
			WHEN s.transaction_isolation_level = 1 THEN 'Read Uncommited'
			WHEN s.transaction_isolation_level = 2 THEN 'Read Commited'
			WHEN s.transaction_isolation_level = 3 THEN 'Repeatable'
			WHEN s.transaction_isolation_level = 4 THEN 'Serializable'
			WHEN s.transaction_isolation_level = 5 THEN 'Snapshot'
		END
	  , ConnectionReads			= c.num_reads
	  , ConnectionWrites		= c.num_writes
	  , ClientAddress			= c.client_net_address
	  , ClientTcpPort			= c.client_tcp_port
	  , Authentication			= c.auth_scheme
	  , PlanHandle				= r.plan_handle
	  , DatetimeSnapshot		= GETDATE ()
	FROM
		sys.dm_exec_requests r
		LEFT JOIN sys.dm_exec_sessions s	ON (r.session_id = s.session_id)
		LEFT JOIN sys.dm_exec_connections c ON (s.session_id = c.session_id)
		OUTER APPLY sys.dm_exec_sql_text (r.sql_handle) stmt
		OUTER APPLY (
			SELECT
				execution_count = MAX (cp.usecounts)
			FROM
				sys.dm_exec_cached_plans cp
			WHERE
				cp.plan_handle = r.plan_handle
		) ec
		OUTER APPLY (
			SELECT 
				lead_blocker = 1
			FROM
				master.sys.sysprocesses p
			WHERE 
				p.spid IN (SELECT blocked FROM master.sys.sysprocesses)
				AND p.blocked = 0
				AND p.spid = r.session_id
		) lb
	WHERE
		r.sql_handle IS NOT NULL
		AND r.session_id <> @@SPID
	ORDER BY
		CASE WHEN lead_blocker = 1 THEN -1 * 1000 ELSE - r.blocking_session_id END
	  , R.blocking_session_id DESC
	  , IOReads DESC
	  , r.session_id
END
GO