USE [DBADMSQL]
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'sp_who3')
	DROP PROCEDURE [dbo].[sp_who3]
GO
PRINT 'creating procedure [dbo].[sp_who3]...';
GO
CREATE PROCEDURE [dbo].[sp_who3]
AS
BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #tb_blocked(
		hostID INT
	  , SPID INT
	  , a VARCHAR (1000)
	  , b INT
	  , textBuffer VARCHAR (4000)
	);
	CREATE CLUSTERED INDEX ix_blocked ON #tb_blocked (SPID);

	CREATE TABLE #tb_inputBuffer (
		a VARCHAR (14)
	  , b INT
	  , textBuffer VARCHAR (4000)
	);

	-- insere na tabela temp todas as ses�es com status de blocked
	INSERT INTO #tb_blocked
	SELECT
		HOST_ID ()
	  , p.spid
	  , NULL
	  , NULL 
	  , NULL 
	FROM
		master.sys.sysprocesses p
	WHERE
		(p.spid IN (SELECT blocked FROM master.sys.sysprocesses sp WHERE sp.blocked <> 0 AND sp.spid <> sp.blocked)) 
		OR (p.blocked <> 0 AND P.spid <> p.blocked);

	DECLARE @spid INT
	DECLARE Buffer_Cursor CURSOR LOCAL FOR
		SELECT SPID FROM #tb_blocked

	OPEN Buffer_Cursor;
	FETCH NEXT FROM Buffer_Cursor INTO @spid

	WHILE @@FETCH_STATUS = 0
	BEGIN
		DELETE FROM #tb_inputBuffer;

		INSERT INTO #tb_inputBuffer EXEC ('DBCC INPUTBUFFER (' + @spid + ') WITH NO_INFOMSGS');

		UPDATE	#tb_blocked
		SET		textBuffer = #tb_inputBuffer.textBuffer
		FROM	#tb_inputBuffer
		WHERE	SPID = @spid

		FETCH NEXT FROM Buffer_Cursor INTO @spid
	END

	CLOSE Buffer_Cursor;
	DEALLOCATE Buffer_Cursor;

	SELECT DISTINCT 
		@@SERVERNAME AS ServerName
	  , DB_NAME (a.dbid) AS DBName
	  , a.spid
	  , a.blocked
	  , a.ecid
	  , a.waittime
	  , a.[status]
	  , a.cpu
	  , a.physical_io
	  , a.hostname
	  , a.loginame
	  , a.last_batch
	  , a.open_tran
	  , a.memusage
	  , b.textBuffer
	FROM
		master.sys.sysprocesses a
		RIGHT OUTER JOIN #tb_blocked b ON (a.spid = b.SPID)
	WHERE
		(a.spid IN (SELECT blocked FROM master.sys.sysprocesses c WHERE c.blocked <> 0 AND c.blocked <> c.spid))
		OR (a.blocked <> 0 AND a.blocked <> a.spid)
	ORDER BY
		a.blocked;
END
GO