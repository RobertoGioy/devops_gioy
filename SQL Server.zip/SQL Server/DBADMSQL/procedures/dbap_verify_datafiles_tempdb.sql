USE [DBADMSQL]
GO

IF EXISTS (SELECT 1 FROM sys.procedures WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbap_verify_datafiles_tempdb')
	DROP PROCEDURE [dbo].[dbap_verify_datafiles_tempdb]
GO
PRINT 'creating procedure [dbo].[dbap_verify_datafiles_tempdb]...';
GO
CREATE PROCEDURE [dbo].[dbap_verify_datafiles_tempdb]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 'TOP 10 TEMPDB DATA CONSUMERS' AS INFO;

	SELECT
		tsp.session_id
	  , tsp.request_id
	  , (SELECT SUM (size) * 1.0/128 FROM tempdb.sys.database_files WHERE type_desc = 'ROWS') AS temp_size_db
	  , tsp.task_alloc AS task_page_alloc
	  , tsp.task_alloc * 1.0/128 AS task_alloc_MB
	  , ((tsp.task_alloc * 1.0/128) / (SELECT SUM (size) * 1.0/128 FROM tempdb.sys.database_files WHERE type_desc = 'ROWS')) AS percent_used
	  , es.login_time
	  , es.last_request_start_time
	  , es.login_name
	  , es.nt_domain
	  , es.nt_user_name
	  , es.[status]
	  , es.[host_name]
	  , (SELECT SUBSTRING (st.[text], er.statement_start_offset / 2, (CASE WHEN er.statement_end_offset = -1 THEN LEN (CONVERT (NVARCHAR (MAX), st.[text])) * 2 ELSE er.statement_end_offset END - er.statement_start_offset) / 2) FROM master.sys.dm_exec_sql_text (er.sql_handle) st) AS query_text
	  , (SELECT query_plan FROM master.sys.dm_exec_query_plan(er.plan_handle)) qp
	FROM (
		SELECT
			tsu.session_id
		  , tsu.request_id
		  , SUM (tsu.internal_objects_alloc_page_count + tsu.user_objects_alloc_page_count) AS task_alloc
		  , SUM (tsu.internal_objects_dealloc_page_count + tsu.user_objects_dealloc_page_count) AS task_dealloc
		FROM
			master.sys.dm_db_task_space_usage tsu
		GROUP BY
			tsu.session_id
		  , tsu.request_id
	) AS tsp
		LEFT JOIN master.sys.dm_exec_requests er ON (tsp.request_id = er.request_id AND tsp.session_id = er.session_id)
		LEFT JOIN master.sys.dm_exec_sessions es ON (tsp.session_id = es.session_id)
	ORDER BY
		tsp.task_alloc DESC;
	
	SELECT 'SNAPSHOT VERSION STORE INFO' AS INFO;

	SELECT 
		asdt.transaction_id
	  , asdt.session_id
	  , asdt.elapsed_time_seconds / 60 AS elapse_time_min
	  , asdt.elapsed_time_seconds / 360 AS elapse_time_hour
	  , asdt.is_snapshot
	  , asdt.transaction_sequence_num
	  , asdt.first_snapshot_sequence_num
	  , asdt.commit_sequence_num
	  , asdt.average_version_chain_traversed
	  , asdt.max_version_chain_traversed
	FROM
		master.sys.dm_tran_active_snapshot_database_transactions asdt
	ORDER BY
		asdt.elapsed_time_seconds DESC;
END
GO