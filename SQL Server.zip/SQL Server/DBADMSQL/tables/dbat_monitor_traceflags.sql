USE [DBADMSQL]
GO

IF (OBJECT_ID ('dbat_monitor_traceflags') IS NOT NULL)
	DROP TABLE [dbo].[dbat_monitor_traceflags]
GO
PRINT 'creating table [dbo].[dbat_monitor_traceflags]...';
GO
CREATE TABLE [dbo].[dbat_monitor_traceflags] (
	traceflag INT NOT NULL
  , flagstatus TINYINT NOT NULL
  , flagDesc NVARCHAR (400) NULL
)
ON [PRIMARY];
GO

INSERT INTO [dbo].[dbat_monitor_traceflags] (traceflag, flagstatus, flagDesc) VALUES (
	1118, 0, 'Remove a maioria das aloca��es de �nica p�gina do servidor, reduzindo a conten��o na p�gina SGAM.'
)
GO
INSERT INTO [dbo].[dbat_monitor_traceflags] (traceflag, flagstatus, flagDesc) VALUES (
	1204, 1, 'Retorna os recursos e tipos de bloqueios que participam de um deadlock e tamb�m o comando atual afetado.'
)
GO
INSERT INTO [dbo].[dbat_monitor_traceflags] (traceflag, flagstatus, flagDesc) VALUES (
	1222, 1, 'Retorna os recursos e os tipos de bloqueios que participam de um deadlock e tamb�m o comando atual afetado, em um formato XML que n�o obedece a nenhum esquema XSD.'
)
GO
INSERT INTO [dbo].[dbat_monitor_traceflags] (traceflag, flagstatus, flagDesc) VALUES (
	2551, 0, 'Gera um dump filtrado para os processos do SQL Server.'
)
GO
INSERT INTO [dbo].[dbat_monitor_traceflags] (traceflag, flagstatus, flagDesc) VALUES (
	3226, 1, 'Suprime as mensagens de backups completados com sucesso, no errorlog.'
)
GO
INSERT INTO [dbo].[dbat_monitor_traceflags] (traceflag, flagstatus, flagDesc) VALUES (
	3605, 1, 'Imprime as mensagens dos comandos DBCC executados, no errorlog.'
)
GO
INSERT INTO [dbo].[dbat_monitor_traceflags] (traceflag, flagstatus, flagDesc) VALUES (
	3042, 1, 'Ignora o algoritmo padr�o de pr�-aloca��o de compacta��o de backup para permitir que o arquivo de backup cres�a somente quando necess�rio para alcan�ar seu tamanho final.'
)
GO
INSERT INTO [dbo].[dbat_monitor_traceflags] (traceflag, flagstatus, flagDesc) VALUES (
	8004, 0, 'Cria dump de mem�ria para a primeira ocorr�ncia de out-of-memory.'
)
GO
