USE [DBADMSQL]
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbat_monitor_dbfiles')
BEGIN
PRINT 'creating table [dbo].[dbat_monitor_dbfiles]...';
CREATE TABLE [dbo].[dbat_monitor_dbfiles] (
	id				INT IDENTITY (1,1) NOT NULL CONSTRAINT [pk_monitor_dbfiles] PRIMARY KEY CLUSTERED WITH (FILLFACTOR = 90)
  , dbname			SYSNAME NOT NULL
  , fileid			SMALLINT NULL
  , usage			VARCHAR (16) NULL
  , file_size_mb	DECIMAL (15,2) NOT NULL CONSTRAINT [df_file_size_mb] DEFAULT (0)
  , space_used_mb	DECIMAL (15,2) NOT NULL CONSTRAINT [df_space_used_mb] DEFAULT (0)
  , free_space_mb	DECIMAL (15,2) NOT NULL CONSTRAINT [df_free_space_mb] DEFAULT (0)
  , used_percent	DECIMAL (15,2) NOT NULL CONSTRAINT [df_used_percent] DEFAULT (0)
  , free_percent	DECIMAL (15,2) NOT NULL CONSTRAINT [df_free_percent] DEFAULT (0)
  , logical_name	SYSNAME NOT NULL
  , physical_name	SYSNAME NOT NULL
  , filegroupname	SYSNAME NULL
);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE SCHEMA_NAME(schema_id) = 'dbo' AND name = 'dbat_monitor_dbfiles_history')
BEGIN
PRINT 'creating table [dbo].[dbat_monitor_dbfiles_history]...';
CREATE TABLE [dbo].[dbat_monitor_dbfiles_history] (
	historyid		INT IDENTITY (1,1) NOT NULL
  , dbname			SYSNAME NOT NULL
  , fileid			SMALLINT NULL
  , type_desc		VARCHAR (16) NULL
  , file_size_mb	DECIMAL (15,2) NOT NULL
  , space_used_mb	DECIMAL (15,2) NOT NULL
  , free_space_mb	DECIMAL (15,2) NOT NULL
  , used_percent	DECIMAL (15,2) NOT NULL
  , free_percent	DECIMAL (15,2) NOT NULL
  , logical_name	SYSNAME NOT NULL
  , physical_name	SYSNAME NOT NULL
  , filegroupname	SYSNAME NULL
  , monitoring_id	TINYINT NOT NULL CONSTRAINT [ck_monitoring_id] CHECK (monitoring_id > 0 AND monitoring_id < 5)
  , historydate		DATETIME NOT NULL
  , CONSTRAINT [pk_monitor_dbfiles_history] PRIMARY KEY CLUSTERED (historydate, historyid) WITH (FILLFACTOR = 90)
);
END
GO