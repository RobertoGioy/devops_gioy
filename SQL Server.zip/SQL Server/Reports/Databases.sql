/*
 *	AUTHOR: BETO GIOY
 *	ACTION: DOCUMENTAR E CRIAR SCRIPT DAS BASES DE DADOS.
 */

USE [master]

SET NOCOUNT ON;

DECLARE @driver NVARCHAR (256) = N'C:'	--> SETAR O DIRETORIO DESEJADO PARA CRIAR O SCRIPT

DECLARE @dbid		INT
DECLARE @fileid		SMALLINT
DECLARE @banco		NVARCHAR (128)
DECLARE @filename	NVARCHAR (256)
DECLARE @str		VARCHAR (4000)

CREATE TABLE #TBAUX (fileid SMALLINT, [filename] NVARCHAR (400));
CREATE TABLE #docdbs (cmd NVARCHAR (MAX));

--> INICIO DO PROCESSO
SET @str = '--> 1. INICIO DO PROCESSO' + CHAR (13) + '';
SET @str = @str + '--> SERVIDOR: ' + SUBSTRING (@@SERVERNAME, 1, 24) + CHAR (13) + '';
INSERT INTO #docdbs (cmd) VALUES (@str);
PRINT @str;

SELECT
	@dbid = MIN (database_id)
FROM
	sys.databases 
WHERE
	name NOT IN ('tempdb', 'pubs', 'msdb', 'NorthWind')
	AND (name NOT LIKE '%TMP' OR name NOT LIKE 'TMP%')
	AND [state] = 0;

WHILE @dbid IS NOT NULL
BEGIN
	SET @banco = DB_NAME (@dbid);
	SET @str = '-- BANCO => ' + @banco + ', dbid => ' + LTRIM (STR (DB_ID (@banco)));
	INSERT INTO #docdbs (cmd) VALUES (@str);
	PRINT @str;

	IF (DATABASEPROPERTYEX (@banco, 'Status') = 'ONLINE')
	BEGIN
		SET @str = 'USE [' + @banco + '];';
		SET @str = @str + '	INSERT INTO #TBAUX';
		SET @str = @str + ' SELECT fileid, filename FROM sysfiles';
		EXEC (@str);

		SET @str = 'EXEC sp_attach_db' + CHAR (13) + CHAR (9) + '@dbname = N''' + @banco + '''';

		SELECT @fileid = MIN (fileid) FROM #TBAUX;

		WHILE @fileid IS NOT NULL
		BEGIN
			SELECT @filename = [filename] FROM #TBAUX WHERE fileid = @fileid;

			SET @str = @str + CHAR (13) + ',' + CHAR (9) + '@filename' + CONVERT (VARCHAR, @fileid) + '= N''' + RTRIM (@filename) + '''';

			SELECT @fileid = MIN (fileid) FROM #TBAUX WHERE fileid > @fileid;
		END

		SET @str = @str + CHAR (13) + 'GO' + CHAR (13);

		INSERT INTO #docdbs (cmd) VALUES (@str);
		PRINT @str;
	END

	DELETE FROM #TBAUX;

	SELECT
		@dbid = MIN (database_id)
	FROM
		sys.databases 
	WHERE
		name NOT IN ('tempdb', 'pubs', 'msdb', 'NorthWind')
		AND (name NOT LIKE '%TMP' OR name NOT LIKE 'TMP%')
		AND [state] = 0
		AND database_id > @dbid;
END

--> GERA O ARQUIVO TEXTO
PRINT '--> 2. GERA ARQUIVO TEXTO';
SET @str = 'bcp #docdbs OUT ''' + @driver + '\document\Databases_' + DATENAME (DW, GETDATE ()) + '';
SET @str = @str + '.sql'' -c -T -S ' + @@SERVERNAME + ' -e ''' + @driver + '\document\DATABASES.err'';';
--EXEC xp_cmdshell @str, no_output;
PRINT @str;

DROP TABLE #TBAUX, #docdbs;
GO