/*
 *	AUTHOR: BETO GIOY
 *	ACTION: DOCUMENTAR E CRIAR SCRIPT DOS LOGINS EXISTENTES NO SERVIDOR.
 */

USE [master]

SET NOCOUNT ON;

IF OBJECT_ID ('sp_hexadecimal') IS NOT NULL
	DROP PROCEDURE sp_hexadecimal
GO
CREATE PROCEDURE sp_hexadecimal
	@binvalue VARBINARY (256)
,	@hexvalue VARCHAR (256) OUTPUT
AS
DECLARE @charvalue VARCHAR (256)
DECLARE @i INT
DECLARE @length INT
DECLARE @hexstring CHAR (16)

SELECT @charvalue = '0x';
SELECT @i = 1;
SELECT @length = DATALENGTH (@binvalue);
SELECT @hexstring = '0123456789ABCDEF';

WHILE (@i <= @length)
BEGIN
	DECLARE @tempint INT, @firstint INT, @secondint INT

	SELECT @tempint = CONVERT (INT, SUBSTRING (@binvalue, @i, 1));
	SELECT @firstint = FLOOR (@tempint / 16);
	SELECT @secondint = @tempint - (@firstint * 16);
	SELECT @charvalue = @charvalue + SUBSTRING (@hexstring, @firstint + 1, 1) + SUBSTRING (@hexstring, @secondint + 1, 1);
	SELECT @i = @i + 1;
END
SELECT @hexvalue = @charvalue;
GO

/*
 *	http://support.microsoft.com/kb/246133/pt-br
 */

DECLARE @driver NVARCHAR (256) = N'C:'	--> SETAR O DIRETORIO DESEJADO PARA CRIAR O SCRIPT

DECLARE @name SYSNAME
DECLARE @type CHAR (1)
DECLARE @is_disabled BIT
DECLARE @hasaccess BIT
DECLARE @denylogin BIT
DECLARE @err INT
DECLARE @str VARCHAR (4000)
DECLARE @binpwd VARBINARY (500)
DECLARE @txtpwd VARCHAR (256)
DECLARE @is_policy_checked VARCHAR (3)
DECLARE @is_expiration_checked VARCHAR (3)

CREATE TABLE #doclogins (cmd NVARCHAR (MAX));

--> INICIO DO PROCESSO
SET @str = '--> 1. INICIO DO PROCESSO' + CHAR (13) + '';
SET @str = @str + '--> SERVIDOR: ' + SUBSTRING (@@SERVERNAME, 1, 24) + CHAR (13) + '';
INSERT INTO #doclogins (cmd) VALUES (@str);
PRINT @str;

DECLARE login_curs CURSOR LOCAL FOR
SELECT
	p.name
,	p.[type]
,	p.is_disabled
,	l.hasaccess
,	l.denylogin
FROM
	sys.server_principals p
	LEFT JOIN sys.syslogins l ON (p.name = l.name)
WHERE
	p.[type] IN ('S', 'G', 'U')
	AND p.name <> 'BUILTIN\Administrators'
	AND p.name <> 'AUTHORITY\SYSTEM'
	AND p.name NOT LIKE '##%'
	AND p.name NOT LIKE 'NT%';

OPEN login_curs
FETCH NEXT FROM login_curs INTO @name, @type, @is_disabled, @hasaccess, @denylogin

IF (@@FETCH_STATUS = -1)
BEGIN
	PRINT 'No Login(s) found.';
	CLOSE login_curs;
	DEALLOCATE login_curs;
END

WHILE @@FETCH_STATUS <> -1
BEGIN
	IF @@FETCH_STATUS = -2
	BEGIN
		IF (@type IN ('G', 'U'))	-- NT AUTHENTICATION ACCOUNT/GROUP
		BEGIN
			SET @str = 'IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = ''' + @name + ''')' + CHAR (13) + 'BEGIN' + CHAR (13);
			SET @str = @str + CHAR (9) + 'PRINT ''CREATE LOGIN NT AUTHENTICATION [' + @name + ']'';' + CHAR (13);
			SET @str = @str + CHAR (9) + 'CREATE LOGIN ' +QUOTENAME (@name) + ' FROM WINDOWS;';
		END
		ELSE BEGIN					-- SQL AUTHENTICATION
			-- OBTAIN PASSWORD
			SET @binpwd = CAST (LOGINPROPERTY (@name, 'PasswordHash') AS VARBINARY (256))
			EXEC master..sp_hexadecimal @binpwd, @txtpwd OUT;
			-- OBTAIN PASSWORD POLICY STATE
			SELECT @is_policy_checked = CASE is_policy_checked WHEN 1 THEN 'ON' WHEN 0 THEN 'OFF' ELSE NULL END FROM sys.sql_logins WHERE name = @name;
			SELECT @is_expiration_checked = CASE is_expiration_checked WHEN 1 THEN 'ON' WHEN 0 THEN 'OFF' ELSE NULL END FROM sys.sql_logins WHERE name = @name;

			SET @str = 'IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = ''' + @name + ''')' + CHAR (13) + 'BEGIN' + CHAR (13);
			SET @str = @str + CHAR (9) + 'PRINT ''CREATE LOGIN SQL AUTHENTICATION [' + @name + ']'';' + CHAR (13);
			SET @str = @str + CHAR (9) + 'CREATE LOGIN ' + QUOTENAME (@name) + ' WITH PASSWORD = ' + @txtpwd + ' HASHED';
			IF (@is_policy_checked IS NOT NULL)
				SET @str = @str + ', CHECK_POLICY = ' + @is_policy_checked;
			IF (@is_expiration_checked IS NOT NULL)
				SET @str = @str + ', CHECK_EXPIRATION = ' + @is_expiration_checked;
		END

		IF (@denylogin = 1)			-- LOGIN IS DENIED ACCESS
			SET @str = @str + CHAR (13) + CHAR (9) + 'DENY CONNECT SQL TO ' + QUOTENAME (@name) + ';';
		ELSE IF (@hasaccess = 0)	-- LOGIN EXIST BUT DOES NOT HAVE ACCESS
			SET @str = @str + CHAR (13) + CHAR (9) + 'REVOKE CONNECT SQL TO ' + QUOTENAME (@name) + ';';
		IF (@is_disabled = 1)		-- LOGIN IS DISABLED
			SET @str = @str + CHAR (13) + CHAR (9) + 'ALTER LOGIN ' + + QUOTENAME (@name) + 'DISABLE;';

		SET @str = @str + CHAR (13) + 'END' + CHAR (13) + 'GO';
		INSERT INTO #doclogins (cmd) VALUES (@str);
		PRINT @str;
	END

	FETCH NEXT FROM login_curs INTO @name, @type, @is_disabled, @hasaccess, @denylogin
END

CLOSE login_curs;
DEALLOCATE login_curs;

--> GERA O ARQUIVO TEXTO
PRINT '--> 2. GERA ARQUIVO TEXTO';
SET @str = 'bcp #doclogins OUT ''' + @driver + '\document\Logins_' + DATENAME (DW, GETDATE ()) + '';
SET @str = @str + '.sql'' -c -T -S ' + @@SERVERNAME + ' -e ''' + @driver + '\document\LOGINS.err'';';
--EXEC xp_cmdshell @str, no_output;
PRINT @str;

DROP TABLE #doclogins;
GO