/*
 *	AUTHOR: BETO GIOY
 *	ACTION: DOCUMENTAR E CRIAR SCRIPT DOS JOBS EXISTENTES NO SERVIDOR.
 */

USE [master]

SET NOCOUNT ON;

DECLARE @driver NVARCHAR (256) = N'C:'	--> SETAR O DIRETORIO DESEJADO PARA CRIAR O SCRIPT

DECLARE @jobid		VARCHAR (40)
DECLARE @login		VARCHAR (30)
DECLARE @jobname	VARCHAR (200)
DECLARE @steps		TINYINT
DECLARE @scheduleID INT
DECLARE @str		VARCHAR (8000)

CREATE TABLE #docjobs (cmd NVARCHAR (MAX));

--> INICIO DO PROCESSO
SET @str = '--> 1. INICIO DO PROCESSO' + CHAR (13) + '';
SET @str = @str + '--> SERVIDOR: ' + SUBSTRING (@@SERVERNAME, 1, 24) + CHAR (13) + '';
INSERT INTO #docjobs (cmd) VALUES (@str);
PRINT @str;

--> ADICIONA JOB
SELECT @jobid = MIN (CAST (job_id AS VARCHAR (40))) FROM msdb..sysjobs;

WHILE @jobid IS NOT NULL
BEGIN
	SELECT
		@login = l.name
	FROM
		msdb..sysjobs j JOIN master..syslogins l ON (j.owner_sid = l.[sid])
	WHERE 
		J.job_id = @jobid;

	SELECT @jobname = name FROM msdb..sysjobs WHERE job_id = @jobid;

	SET @str = '--> Job => ' + @jobname;
	PRINT @str;
	
	SELECT @str = 'EXEC msdb..sp_add_job
		@job_name				= ''' + @jobname + '''
	,	@enabled				= ' + CAST ([enabled] AS VARCHAR (10)) + '
	,	@description			= ''' + [description] + '''
	,	@start_step_id			= ' + CAST (start_step_id AS VARCHAR (10)) + '
	,	@category_id			= ' + CAST (category_id AS VARCHAR (10)) + '
	,	@owner_login_name		= ''' + @login + '''
	,	@notify_level_eventlog	= ' + CAST (notify_level_eventlog AS VARCHAR (5)) + '
	,	@notify_level_email		= ' + CAST (notify_level_email AS VARCHAR (5)) + '
	,	@notify_level_netsend	= ' + CAST (notify_level_netsend AS VARCHAR (5)) + '
	,	@notify_level_page		= ' + CAST (notify_level_page AS VARCHAR (5)) + '
	,	@delete_level			= ' + CAST (delete_level AS VARCHAR (5)) + ''
	FROM
		msdb..sysjobs
	WHERE
		job_id = @jobid;

	SET @str = @str + CHAR (13) + 'GO';
	INSERT INTO #docjobs (cmd) VALUES (@str);
	PRINT @str;

	--> ADICIONA STEPS
	SELECT @steps = MIN (step_id) FROM msdb..sysjobsteps WHERE job_id = @jobid;

	WHILE @steps IS NOT NULL
	BEGIN
		SELECT @str = 'EXEC msdb..sp_add_jobstep
			@job_name				= ''' + @jobname + '''
		,	@step_id				= ' + CAST (step_id AS VARCHAR (5)) + '
		,	@step_name				= ''' + step_name + '''
		,	@subsystem				= ''' + subsystem + '''
		,	@command				= ''' + command + '' + CASE WHEN [server] IS NOT NULL THEN '
		,	@additional_parameters	= ''' + CAST (additional_parameters AS VARCHAR (2000)) + '' ELSE '' END + '''
		,	@cmdexec_success_code	= ' + CAST (cmdexec_success_code AS VARCHAR (5)) + '
		,	@on_success_action		= ' + CAST (on_success_action AS VARCHAR (5)) + '
		,	@on_success_step_id		= ' + CAST (on_success_step_id AS VARCHAR (5)) + '
		,	@on_fail_action			= ' + CAST (on_fail_action AS VARCHAR (5)) + '
		,	@on_fail_step_id		= ' + CAST (on_fail_step_id AS VARCHAR (5)) + CASE WHEN [server] IS NOT NULL THEN '
		,	@server					= ' + [server] ELSE '' END + '
		,	@database_name			= ''' + database_name + '' + CASE WHEN [server] IS NOT NULL THEN '
		,	@database_user_name		= ' + database_user_name ELSE '' END + '''
		,	@retry_attempts			= ' + CAST (retry_attempts AS VARCHAR (5)) + '
		,	@retry_interval			= ' + CAST (retry_interval AS VARCHAR (5)) + '
		,	@os_run_priority		= ' + CAST (os_run_priority AS VARCHAR (5)) + '
		,	@on_fail_step_id		= ' + CAST (on_fail_step_id AS VARCHAR (5)) + CASE WHEN [server] IS NOT NULL THEN '
		,	@output_file_name		= ' + output_file_name ELSE '' END + '
		,	@flags					= ' + CAST (flags AS VARCHAR (5)) + ';'
		FROM
			msdb..sysjobsteps
		WHERE
			step_id = @steps
			AND job_id = @jobid;

		SET @str = @str + CHAR (13) + 'GO';
		INSERT INTO #docjobs (cmd) VALUES (@str);
		PRINT @str;

		SELECT @steps = MIN (step_id) FROM msdb..sysjobsteps WHERE job_id = @jobid AND step_id > @steps;
	END

	--> ADICIONA OS SCHEDULES DO JOB
	SELECT @scheduleID = MIN (schedule_id) FROM msdb..sysjobschedules WHERE job_id = @jobid;

	WHILE @scheduleID IS NOT NULL
	BEGIN
		SELECT @str = 'EXEC msdb..sp_add_jobschedule
			@job_name				= ''' + @jobname + '''
		,	@name					= ''' + name + '''
		,	@enabled				= ' + CAST ([enabled] AS CHAR (1)) + '
		,	@freq_type				= '+ CAST (freq_type AS VARCHAR (10)) + '
		,	@freq_interval			= ' + CAST (freq_interval AS VARCHAR (10)) + '
		,	@freq_subday_type		= ' + CAST (freq_subday_type AS VARCHAR (5)) + '
		,	@freq_subday_interval	= ' + CAST (freq_subday_interval AS VARCHAR (5)) + '
		,	@freq_relative_interval = ' + CAST (freq_relative_interval AS VARCHAR (5)) + '
		,	@freq_recurrence_factor = ' + CAST (freq_recurrence_factor AS VARCHAR (5)) + '
		,	@active_start_date		= ' + CAST (active_start_date AS VARCHAR (8)) + '
		,	@active_end_date		= ' + CAST (active_end_date AS VARCHAR (8)) + '
		,	@active_start_time		= ' + CAST (active_start_time AS VARCHAR (8)) + '
		,	@active_end_time		= ' + CAST (active_end_time AS VARCHAR (8)) + ';'
		FROM
			msdb..sysschedules
		WHERE
			schedule_id = @scheduleID;

		SET @str = @str + CHAR (13) + 'GO';
		INSERT INTO #docjobs (cmd) VALUES (@str);
		PRINT @str;

		SELECT @scheduleID = MIN (schedule_id) FROM msdb..sysjobschedules WHERE job_id = @jobid AND schedule_id > @scheduleID;
	END

	SELECT @str = 'EXEC msdb..sp_add_jobserver
		@job_id = ' + CAST (@jobid AS VARCHAR (40)) + '
	,	@job_name = ''' + @jobname + '''
	,	@server_name = ''' + @@SERVERNAME + ''';'

	SET @str = @str + CHAR (13) + 'GO';
	INSERT INTO #docjobs (cmd) VALUES (@str);
	PRINT @str;

	SELECT @jobid = MIN (CAST (job_id AS VARCHAR (40))) FROM msdb..sysjobs WHERE CAST (job_id AS VARCHAR (40)) > @jobid;
END

--> GERA O ARQUIVO TEXTO
PRINT '--> 2. GERA ARQUIVO TEXTO';
SET @str = 'bcp #docjobs OUT ''' + @driver + '\document\Jobs_' + DATENAME (DW, GETDATE ()) + '';
SET @str = @str + '.sql'' -c -T -S ' + @@SERVERNAME + ' -e ''' + @driver + '\document\JOBS.err'';';
--EXEC xp_cmdshell @str, no_output;
PRINT @str;

DROP TABLE #docjobs;
GO