/*
 *	AUTHOR: BETO GIOY
 *	ACTION: DOCUMENTAR E CRIAR SCRIPT DOS LINKED SERVER EXISTENTES NO SERVIDOR.
 */

USE [master]

SET NOCOUNT ON;

DECLARE @driver NVARCHAR (256) = N'C:'	--> SETAR O DIRETORIO DESEJADO PARA CRIAR O SCRIPT

DECLARE @srvid INT
DECLARE @str VARCHAR (4000)

CREATE TABLE #docservers (cmd NVARCHAR (MAX));

--> INICIO DO PROCESSO
SET @str = '--> 1. INICIO DO PROCESSO' + CHAR (13) + '';
SET @str = @str + '--> SERVIDOR: ' + SUBSTRING (@@SERVERNAME, 1, 24) + CHAR (13) + '';
INSERT INTO #docservers (cmd) VALUES (@str);
PRINT @str;

SELECT @srvid = MIN (srvid) FROM sysservers WHERE srvname <> @@SERVERNAME;

WHILE @srvid IS NOT NULL
BEGIN
	SELECT @str = 'EXEC sp_addlinkedserver
		@server		= ''' + srvname + '''
	,	@srvproduct = ''' + srvproduct + '''
	,	@provider	= ''' + providername + '' + CASE WHEN datasource IS NOT NULL THEN '
	,	@datasrc	= ''' + datasource + '' ELSE '' END + '' + CASE WHEN location IS NOT NULL THEN '
	,	@location	= ''' + location + '' ELSE '' END + '' + CASE WHEN providerstring IS NOT NULL THEN '
	,	@provstr	= ''' + providerstring + '' ELSE '' END + '' + CASE WHEN [catalog] IS NOT NULL THEN '
	,	@catalog	= ''' + [catalog] + '' ELSE '''' END
	FROM
		dbo.sysservers 
	WHERE
		srvname <> @@SERVERNAME
		AND srvid = @srvid;

	SET @str = @str + CHAR (13) + 'GO' + CHAR (13);
	INSERT INTO #docservers (cmd) VALUES (@str);
	PRINT @str;

	SELECT @srvid = MIN (srvid) FROM sysservers WHERE srvname <> @@SERVERNAME AND srvid > @srvid;
END

--> GERA O ARQUIVO TEXTO
PRINT '--> 2. GERA ARQUIVO TEXTO';
SET @str = 'bcp #docservers OUT ''' + @driver + '\document\LinkedServers_' + DATENAME (DW, GETDATE ()) + '';
SET @str = @str + '.sql'' -c -T -S ' + @@SERVERNAME + ' -e ''' + @driver + '\document\LINKEDSERVERS.err'';';
--EXEC xp_cmdshell @str, no_output;
PRINT @str;

DROP TABLE #docservers;
GO