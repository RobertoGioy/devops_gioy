/*
 *	AUTHOR: BETO GIOY
 *	ACTION: DOCUMENTAR E CRIAR SCRIPT DOS DEVICES EXISTENTES NO SERVIDOR.
 */

USE [master]

SET NOCOUNT ON;

DECLARE @driver NVARCHAR (256) = N'C:'	--> SETAR O DIRETORIO DESEJADO PARA CRIAR O SCRIPT

DECLARE @devicename SYSNAME
DECLARE @phyname	NVARCHAR (256)
DECLARE @str		VARCHAR (4000)

CREATE TABLE #docdevices (cmd NVARCHAR (MAX));

--> INICIO DO PROCESSO
SET @str = '--> 1. INICIO DO PROCESSO' + CHAR (13) + '';
SET @str = @str + '--> SERVIDOR: ' + SUBSTRING (@@SERVERNAME, 1, 24) + CHAR (13) + '';
INSERT INTO #docdevices (cmd) VALUES (@str);
PRINT @str;

SELECT @devicename = MIN (name) FROM sysdevices WHERE [status] = 16;

WHILE @devicename IS NOT NULL
BEGIN
	SELECT @phyname = phyname FROM sysdevices WHERE name = @devicename;
	SET @str = 'IF EXISTS (SELECT name FROM sysdevices WHERE name = ''' + @devicename + ''')' + CHAR (13);
	SET @str = @str + CHAR (9) + 'EXEC sp_dropdevice @logicalname = N''' + @devicename + ''';' + CHAR (13);
	SET @str = @str + 'GO' + CHAR (13);
	SET @str = @str + 'PRINT ''CREATE DEVICE [' + @devicename + ']'';' + CHAR (13);
	SET @str = @str + 'EXEC sp_addumpdevice ''disk'', ''' +@devicename + ''', ''' + @phyname + ''';' + CHAR (13);
	SET @str = @str + 'GO'

	INSERT INTO #docdevices (cmd) VALUES (@str);
	PRINT @str;

	SELECT @devicename = MIN (name) FROM sysdevices WHERE [status] = 16 AND name > @devicename;
END

--> GERA O ARQUIVO TEXTO
PRINT '--> 2. GERA ARQUIVO TEXTO';
SET @str = 'bcp #docdevices OUT ''' + @driver + '\document\Devices_' + DATENAME (DW, GETDATE ()) + '';
SET @str = @str + '.sql'' -c -T -S ' + @@SERVERNAME + ' -e ''' + @driver + '\document\DEVICES.err'';';
--EXEC xp_cmdshell @str, no_output;
PRINT @str;

DROP TABLE #docdevices;
GO