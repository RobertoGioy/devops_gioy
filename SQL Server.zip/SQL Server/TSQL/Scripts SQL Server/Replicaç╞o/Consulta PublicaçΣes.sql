Select * From SysObjects Where Xtype='U' And Name Like'%MS%' 

Select Top 1 * From MSsubscriptions
Select Top 1 * From MSpublications
Select * From Sl2000Act.Dbo.sysarticles Where name='Itens_mod_balanco'


Select * From MSsubscriptions A
Inner Join MSpublications B On a.publication_id=b.publication_id


--Consulta erro servidor de fora
Sp_browsereplcmds '0x0001B5C0000001DA000400000000','0x0001B5C0000001DA000400000000'

--Consulta erro servidor local
Sp_Vr '0x0001B5C0000001DA000400000000'