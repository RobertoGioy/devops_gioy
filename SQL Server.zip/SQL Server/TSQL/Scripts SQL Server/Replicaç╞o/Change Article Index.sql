
SET QUOTED_IDENTIFIER OFF 

create table #temp (Servidor Varchar(max), Base Varchar(max), empresa Varchar(max))
create table #temp1 (Base1 Varchar(max))

DECLARE @base sysname, @reg int, @tot int, @CMD1 VARCHAR(MAX), @CMD2 VARCHAR(MAX), @CMD3 VARCHAR(MAX)
, @CMD4 VARCHAR(MAX), @CMD5 VARCHAR(MAX), @CMD6 VARCHAR(MAX), @CMD7 VARCHAR(MAX), @CMD8 VARCHAR(MAX)


SET @CMD1 = 
"

-- Corrige o Erro Envio de Index
declare	@artigos33	VARCHAR(MAX), @COMANDO33 VARCHAR(MAX)

DECLARE @var33 VARCHAR(MAX)

DECLARE CURSOR33 CURSOR FOR
SELECT COMANDO FROM (
SELECT	DISTINCT C.NAME,'H'AS ORDEM,'SP_CHANGEARTICLE @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''', @property = ''schema_option''  , @value = ''0x10'', @force_reinit_subscription = ''1'''AS COMANDO 
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE C.NAME = 'REPL_DC' AND B.DEST_DB <> 'VIRTUAL'
UNION 
SELECT	DISTINCT C.NAME,'H'AS ORDEM,'SP_CHANGEARTICLE @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''', @property = ''schema_option''  , @value = ''0x20'', @force_reinit_subscription = ''1'''AS COMANDO 
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE C.NAME = 'REPL_DC' AND B.DEST_DB <> 'VIRTUAL'

)TABELA	WHERE COMANDO <> ''	
ORDER BY ORDEM, NAME

OPEN CURSOR33
FETCH NEXT FROM CURSOR33 INTO @var33
WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC (@var33)
	FETCH NEXT FROM CURSOR33 INTO @var33
END
CLOSE CURSOR33
DEALLOCATE CURSOR33
"




set @tot = (select count(name) as Reg from sys.sysdatabases where not name in ('SL2000ASSP_E862','SL2000ASSP','SL2000ARQ','SL2000AND','SL2000ACT','CTR605_PRAIAMAR','ADM736_EMPRESARIALRJ','SL2000RCF','CTR555_EOURO','CTR952_PRM','SL2000_106','SL2000_112','SL2000_128','EMPDCGP','DCGP','FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') And Version <> 0 )

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where not name in ('SL2000ASSP_E862','SL2000ASSP','SL2000ARQ','SL2000AND','SL2000ACT','CTR605_PRAIAMAR','ADM736_EMPRESARIALRJ','SL2000RCF','CTR555_EOURO','CTR952_PRM','SL2000_106','SL2000_112','SL2000_128','EMPDCGP','DCGP','FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') And Version <> 0 ) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
	IF not (select OBJECT_ID ('sysarticles')) IS NULL
	if (select count(*) from sysobjects o inner join syscolumns c on o.id = c.id where o.name = 'Config' and c.name = 'Terc' ) > 0
	exec('if (select count(*) from config ) > 0
		INSERT into #temp1 SELECT ""[" + @base + "]"" ')
	")
	set @reg = @reg + 1
	end

update #temp1 set base1 = replace(replace(base1,'[',''),']','')


set @tot = (select count(name) as Reg from sys.sysdatabases where name in (select base1 from #Temp1) and not name in ('SL2000ASSP_E862','SL2000ASSP','SL2000ARQ','SL2000AND','SL2000ACT','CTR605_PRAIAMAR','ADM736_EMPRESARIALRJ','SL2000RCF','CTR555_EOURO','CTR952_PRM','SL2000_106','SL2000_112','SL2000_128','EMPDCGP','DCGP','FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') And Version <> 0 )

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where name in (select base1 from #Temp1) and not name in ('SL2000ASSP_E862','SL2000ASSP','SL2000ARQ','SL2000AND','SL2000ACT','CTR605_PRAIAMAR','ADM736_EMPRESARIALRJ','SL2000RCF','CTR555_EOURO','CTR952_PRM','SL2000_106','SL2000_112','SL2000_128','EMPDCGP','DCGP','FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') And Version <> 0 ) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
		IF not (select OBJECT_ID ('sysarticles')) IS NULL 
			begin
					if (select count(*) from sysarticles where name = 'Empresas') > 0
						begin
						begin try
							EXEC (""" + @CMD1 + """) 
      						INSERT into #temp SELECT distinct @@servername as Servidor, ""[" + @base + "]"" as Base, '' as empresa
						end try
						begin catch
		   					INSERT into #temp SELECT distinct '(' + ERROR_MESSAGE() +') ' + @@servername as Servidor, ""[" + @base + "]"" as Base, '' as empresa
						end catch
						end
				
			end	
		EXEC (""" + @CMD7 + """) 
	")
	
	set @reg = @reg + 1
	end

	

SELECT Servidor, Base, empresa FROM #temp
Drop Table #temp
Drop Table #temp1
