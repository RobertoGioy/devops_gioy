--distribution.dbo.sp_browsereplcmds
go
sp_dropsubscription	'EMPDCA','apuracao','all'
go
sp_droparticle	'EMPDCA','apuracao'

exec sp_addsubscription @publication = N'EMPDCA', 
						@subscriber = N'DCBSRVBDSQL02\SQL2', 
						@destination_db = N'DC', 
						@subscription_type = N'Push', 
						@sync_type = N'automatic', 
						@article = N'all', 
						@update_mode = N'read only', 
						@subscriber_type = 0
go
exec sp_addsubscription @publication = N'EMPDCA', 
						@subscriber = N'FRSRVBDSQL02\SQLSIC1', 
						@destination_db = N'FRDCA', 
						@subscription_type = N'Push', 
						@sync_type = N'automatic', 
						@article = N'all', 
						@update_mode = N'read only', 
						@subscriber_type = 0
						
						