SET NOCOUNT ON


CREATE TABLE #Transacoes_Paradas(Reg INT IDENTITY(1,1),Publicacao VARCHAR(100),Base_Publicada VARCHAR(100),Assinante VARCHAR(100),Transacoes NUMERIC(18,0))

INSERT INTO #Transacoes_Paradas (Publicacao,Base_Publicada,Assinante,Transacoes)
SELECT * 
FROM (SELECT b.publication,b.publisher_db,b.subscriber_db,sum(a.UndelivCmdsInDistDB)AS transacoes 
	  FROM distribution.dbo.MSdistribution_status  a
		INNER JOIN distribution.dbo.MSdistribution_agents b on a.agent_id = b.id
	  WHERE UndelivCmdsInDistDB <> 0 and b.subscriber_db <>'VIRTUAL'
      GROUP BY b.publication,b.publisher_db,b.subscriber_db
      ) AS transacoes 
WHERE Transacoes >3000
ORDER BY Transacoes DESC


DECLARE @Cont INT,@Tam1 INT,@Tam2 INT,@Tam3 INT, @Texto VARCHAR(8000), @Cabe�alho VARCHAR(8000)

SELECT @Tam1 = MAX(LEN(Publicacao))		+ 11, 
	   @Tam2 = MAX(LEN(Base_Publicada))	+ 15,
	   @Tam3 = MAX(LEN(Assinante))		+ 10
FROM #Transacoes_Paradas


SELECT @Cabe�alho	=  'TRANSA��ES PARADAS NO SERVIDOR ---------- >  '	+ @@SERVERNAME
SELECT @Texto		=  'SERVIDOR / INST�NCIA ------>  '					+ @@SERVERNAME + CHAR(13) + CHAR (13)
SELECT @Texto		=  @Texto + '-------------------------------------------------------------------------------------------------------' + CHAR(13)
SELECT @Texto		=  @Texto + 'PUBLICA��O'	 + REPLICATE(CHAR(32),@Tam1-10)	+	' | '+
								'BASE PUBLICADA' + REPLICATE(CHAR(32),@Tam2-14)	+	' | '+ 
								'ASSINANTE'		 + REPLICATE(CHAR(32),@Tam3-09)	+	' | '+ 
								'TRANSA��ES'	 + CHAR (13)
SELECT @Texto		=  @Texto + '-------------------------------------------------------------------------------------------------------' + CHAR(13)

               
SET @Cont = 1
WHILE (SELECT Reg FROM #Transacoes_Paradas WHERE Reg = @Cont) < = (SELECT COUNT(*)FROM #Transacoes_Paradas)
	BEGIN
		IF (SELECT COUNT(*) FROM #Transacoes_Paradas WHERE Reg = @Cont ) > 0
			BEGIN
				
				SET @Texto = @Texto + (SELECT  Publicacao		+REPLICATE(CHAR(32),@Tam1-LEN(Publicacao))		+	' | '	+
											   Base_Publicada	+REPLICATE(CHAR(32),@Tam2-LEN(Base_Publicada))	+	' | '	+
											   Assinante		+REPLICATE(CHAR(32),@Tam3-LEN(Assinante))		+	' | '	+
											   CONVERT(VARCHAR(50),Transacoes) 
									   FROM #Transacoes_Paradas WHERE Reg = @Cont)+CHAR(13)
		        
			END

				SET @Cont = @Cont + 1

	END
		
		IF (SELECT COUNT(*)FROM #Transacoes_Paradas)> = 1
		BEGIN
			EXEC [172.17.13.1].msdb.dbo.sp_send_dbmail  @profile_name = 'SQL Mail',
    													@recipients = 'pdsantos@grupoeouro.com.br',
														@subject = @Cabe�alho,
														@body = @Texto
		END
	
DROP TABLE #Transacoes_Paradas





