Error messages:
Message: Transaction (Process ID 91) was deadlocked on lock resources with another process and has been chosen as the deadlock victim. Rerun the transaction. 
Command Text: sp_articleview
Parameters: 	@publication = REPL_DC
	@article = Agencias
	@view_name = [dbo].[syncobj_0x540b244c7a1e47ed91b4fc22ec1baf17]
	@filter_clause = [Codemp] = '620'
	@force_invalidate_snapshot = 1
	@force_reinit_subscription = 1
	@refreshsynctranprocs = 0

Stack:    em Microsoft.SqlServer.Replication.AgentCore.ReMapSqlException(SqlException e, SqlCommand command)
   em Microsoft.SqlServer.Replication.AgentCore.AgentExecuteNonQuery(SqlCommand command, Int32 queryTimeout)
   em Microsoft.SqlServer.Replication.AgentCore.ExecuteDiscardResults(CommandSetupDelegate commandSetupDelegate, Int32 queryTimeout)
   em Microsoft.SqlServer.Replication.Snapshot.TransSynchronizationViewValidator.RegenerateSynchronizationView()
   em Microsoft.SqlServer.Replication.Snapshot.TransSynchronizationViewValidator.DoValidation()
   em Microsoft.SqlServer.Replication.Snapshot.TransSnapshotProvider.ValidateArticleSynchronizationView(BaseArticleWrapper article, SqlConnection connection)
   em Microsoft.SqlServer.Replication.Snapshot.SqlServer.BcpLoadHintAndPartitioningResolutionWorkerThreadProvider.DoWork(WorkItem workItem)
   em Microsoft.SqlServer.Replication.WorkerThread.NonExceptionBasedAgentThreadProc()
   em Microsoft.SqlServer.Replication.AgentCore.BaseAgentThread.AgentThreadProcWrapper() (Source: MSSQLServer, Error number: 1205)
Get help: http://help/1205
Server SRV620, Level 13, State 51, Procedure sp_MSrepl_reinitsubscription, Line 376
Transaction (Process ID 91) was deadlocked on lock resources with another process and has been chosen as the deadlock victim. Rerun the transaction. (Source: MSSQLServer, Error number: 1205)
Get help: http://help/1205




Para resolver esse problema, use um dos seguintes m�todos:

M�todo 1: Usar o comando DBCC UPDATEUSAGE

Para resolver esse problema, atualize o valor incorreto do n�mero de linhas. Para fazer isso, execute o seguinte comando:

DBCC UPDATEUSAGE (subscriber_database_name, 'MSreplication_subscriptions') com COUNT_ROWS

Observa��o O comando DBCC UPDATEUSAGE determina os valores corretos para linhas, p�ginas usadas, p�ginas reservadas, p�ginas de folha e contagens de p�gina de dados para cada parti��o em uma tabela. Se esses valores est�o corretos, o comando DBCC UPDATEUSAGE n�o retornar� nenhum dado. Se valores incorretos forem encontradas e corrigidas, DBCC UPDATEUSAGE retornar� as linhas e colunas que est�o atualizadas.

M�todo 2: Usar a instru��o ALTER INDEX

Para resolver esse problema, recrie os �ndices que est�o associados com a tabela MSreplication_subscriptions. Para fazer isso, use a instru��o a seguir:
ALTER INDEX todos ON [dbo].[MSreplication_subscriptions] RECONSTRU��O