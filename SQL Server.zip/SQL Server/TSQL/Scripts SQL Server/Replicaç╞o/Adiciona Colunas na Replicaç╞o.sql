sp_repladdcolumn  @source_object =  'Baixa_Cp2',  @column =  'Codban' 
     ,  @typetext =  'Int Default 0' 
     ,  @publication_to_add =  'all' 
     ,  @from_agent = 0
     ,  @schema_change_script = null
     ,  @force_invalidate_snapshot = 0
     ,  @force_reinit_subscription = 0
go


