/* DATABASE ID */
Select * From MSpublisher_databases Where Publisher_Db In (
Select Publisher_Db From MSpublications Where Publication In ('FRDCA','EMPDCA'))
/*Publication In*/
Select Publication_id,* From MSpublications Where Publication In ('FRDCA','EMPDCA')



Select * From MSarticles Where Publication_id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)
--Delete From MSarticles Where Publication_id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)
Select * From MSreplication_monitordata Where Publication_id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)
--Delete From MSreplication_monitordata Where Publication_id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)
Select * From MSsubscriptions Where Publication_id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)
--Delete From MSsubscriptions Where Publication_id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)
Select * From MSrepl_transactions Where Publisher_Database_Id In (42,106,118,74,119,75,120,89,47,123,10,121,11,12,103,99,15,57,126,125,94,76,16,96,98,93,86,17,66,69,63,23,39,24,68,67,28,38,85,105,87,97,92,124,61,35)
--Delete From MSrepl_transactions Where Publisher_Database_Id In (42,106,118,74,119,75,120,89,47,123,10,121,11,12,103,99,15,57,126,125,94,76,16,96,98,93,86,17,66,69,63,23,39,24,68,67,28,38,85,105,87,97,92,124,61,35)
Select * From MSrepl_commands Where Publisher_Database_Id In (42,106,118,74,119,75,120,89,47,123,10,121,11,12,103,99,15,57,126,125,94,76,16,96,98,93,86,17,66,69,63,23,39,24,68,67,28,38,85,105,87,97,92,124,61,35)
--Delete From MSrepl_commands Where Publisher_Database_Id In (42,106,118,74,119,75,120,89,47,123,10,121,11,12,103,99,15,57,126,125,94,76,16,96,98,93,86,17,66,69,63,23,39,24,68,67,28,38,85,105,87,97,92,124,61,35)
Select * From MSsnapshot_agents Where Id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)
--Delete From MSsnapshot_agents Where Id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)
Select * From MSlogreader_agents Where Id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)
--Delete From MSlogreader_agents Where Id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)
Select * From MSdistribution_agents Where Publisher_Database_Id In (42,106,118,74,119,75,120,89,47,123,10,121,11,12,103,99,15,57,126,125,94,76,16,96,98,93,86,17,66,69,63,23,39,24,68,67,28,38,85,105,87,97,92,124,61,35)
--Delete From MSdistribution_agents Where Publisher_Database_Id In (42,106,118,74,119,75,120,89,47,123,10,121,11,12,103,99,15,57,126,125,94,76,16,96,98,93,86,17,66,69,63,23,39,24,68,67,28,38,85,105,87,97,92,124,61,35)
Select * From MSrepl_backup_lsns Where Publisher_Database_Id In (42,106,118,74,119,75,120,89,47,123,10,121,11,12,103,99,15,57,126,125,94,76,16,96,98,93,86,17,66,69,63,23,39,24,68,67,28,38,85,105,87,97,92,124,61,35)
--Delete From MSrepl_backup_lsns Where Publisher_Database_Id In (42,106,118,74,119,75,120,89,47,123,10,121,11,12,103,99,15,57,126,125,94,76,16,96,98,93,86,17,66,69,63,23,39,24,68,67,28,38,85,105,87,97,92,124,61,35)
Select * From MSpublisher_databases Where Id In (42,106,118,74,119,75,120,89,47,123,10,121,11,12,103,99,15,57,126,125,94,76,16,96,98,93,86,17,66,69,63,23,39,24,68,67,28,38,85,105,87,97,92,124,61,35)
--Delete From MSpublisher_databases Where Id In (42,106,118,74,119,75,120,89,47,123,10,121,11,12,103,99,15,57,126,125,94,76,16,96,98,93,86,17,66,69,63,23,39,24,68,67,28,38,85,105,87,97,92,124,61,35)
Select * From MSpublications Where Publication_id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)
--Delete From MSpublications Where Publication_id In (11,13,15,18,20,21,27,29,33,43,51,52,54,59,76,80,82,85,86,87,88,93,94,95,104,105,106,109,114,115,116,118,121,123,124,128,130,131,143,144,145,146,147,149,150,151,152,154)

/*
use msdb
go
select * from sysjobs where name like '%adm531%'
*/
/*
Insert Into MSreplication_monitordata(lastrefresh, computetime, publication_id, publisher, publisher_srvid, publisher_db, publication, publication_type, agent_type, agent_id, agent_name, job_id, status, isagentrunningnow, warning, last_distsync, agentstoptime, distdb, retention, time_stamp, worst_latency, best_latency, avg_latency, cur_latency, worst_runspeedPerf, best_runspeedPerf, average_runspeedPerf, mergePerformance, mergelatestsessionrunduration, mergelatestsessionrunspeed, mergelatestsessionconnectiontype, retention_period_unit)
Select lastrefresh, computetime, publication_id, publisher, publisher_srvid, 
'ADM576_MAJESTIC'publisher_db, 
publication, 
publication_type, 
agent_type, 
'219' agent_id , 
'FRSRVBDSQL05-ADM576_MAJESTIC-219'agent_name, 
'9156EDBD-6744-4ABF-9A87-83A971242EBD'job_id, 
status, isagentrunningnow, warning, last_distsync, agentstoptime, distdb, retention, time_stamp, worst_latency, best_latency, avg_latency, cur_latency, worst_runspeedPerf, best_runspeedPerf, average_runspeedPerf, mergePerformance, mergelatestsessionrunduration, mergelatestsessionrunspeed, mergelatestsessionconnectiontype, retention_period_unit
From MSreplication_monitordata Where Publisher_db = 'CTR918_TRANSPORTE' And Agent_id = 191
*/
Go
/*
Insert Into MSreplication_monitordata(lastrefresh, computetime, publication_id, publisher, publisher_srvid, publisher_db, publication, publication_type, agent_type, agent_id, agent_name, job_id, status, isagentrunningnow, warning, last_distsync, agentstoptime, distdb, retention, time_stamp, worst_latency, best_latency, avg_latency, cur_latency, worst_runspeedPerf, best_runspeedPerf, average_runspeedPerf, mergePerformance, mergelatestsessionrunduration, mergelatestsessionrunspeed, mergelatestsessionconnectiontype, retention_period_unit)
Select lastrefresh, computetime, publication_id, publisher, publisher_srvid, 
'ADM576_MAJESTIC'publisher_db, 
publication, 
publication_type, 
agent_type, 
'251' agent_id , 
'FRSRVBDSQL05-ADM576_MAJESTIC-REPL_EMPDC-251'agent_name, 
'A1758EA9-399D-439A-B425-A7D034A6C84E'job_id, 
status, isagentrunningnow, warning, last_distsync, agentstoptime, distdb, retention, time_stamp, worst_latency, best_latency, avg_latency, cur_latency, worst_runspeedPerf, best_runspeedPerf, average_runspeedPerf, mergePerformance, mergelatestsessionrunduration, mergelatestsessionrunspeed, mergelatestsessionconnectiontype, retention_period_unit
From MSreplication_monitordata Where Publisher_db = 'CTR918_TRANSPORTE' And Agent_id = 224
*/
GO
/*
Insert Into MSreplication_monitordata(lastrefresh, computetime, publication_id, publisher, publisher_srvid, publisher_db, publication, publication_type, agent_type, agent_id, agent_name, job_id, status, isagentrunningnow, warning, last_distsync, agentstoptime, distdb, retention, time_stamp, worst_latency, best_latency, avg_latency, cur_latency, worst_runspeedPerf, best_runspeedPerf, average_runspeedPerf, mergePerformance, mergelatestsessionrunduration, mergelatestsessionrunspeed, mergelatestsessionconnectiontype, retention_period_unit)
Select lastrefresh, computetime, publication_id, publisher, publisher_srvid, 
'ADM576_MAJESTIC'publisher_db, 
publication, 
publication_type, 
agent_type, 
'354' agent_id , 
'FRSRVBDSQL05-ADM576_MAJESTIC-REPL_EMPDC-FRSRVBDSQL53\CON-354'agent_name, 
'67F094FA-2889-4B60-932A-049A1F901F11'job_id, 
status, isagentrunningnow, warning, last_distsync, agentstoptime, distdb, retention, time_stamp, worst_latency, best_latency, avg_latency, cur_latency, worst_runspeedPerf, best_runspeedPerf, average_runspeedPerf, mergePerformance, mergelatestsessionrunduration, mergelatestsessionrunspeed, mergelatestsessionconnectiontype, retention_period_unit
From MSreplication_monitordata Where Publisher_db = 'CTR918_TRANSPORTE' And Agent_id = 328
*/