declare @result table (Output varchar(8000))
declare @arquivo varchar(8000)
insert into @result
exec master..xp_cmdshell 'DIR D:\MSSQLW5K\MSSQL.1\MSSQL\repldata\unc\E925S2_SL2000_SL2000A\20081128094785 /b'
delete from @result where [output] is null
declare reg cursor for
select [output] from @result where output like ('%%') order by output
open reg
fetch next from reg into @arquivo
while @@fetch_status = 0
begin
exec ('master..xp_cmdshell ''del "D:\MSSQLW5K\MSSQL.1\MSSQL\repldata\unc\E925S2_SL2000_SL2000A\20081128094785\' + @arquivo + '''')
exec ('master..xp_cmdshell ''del  >> "D:\MSSQLW5K\MSSQL.1\MSSQL\repldata\unc\E925S2_SL2000_SL2000A\20081128094785\' + @arquivo + '''')
fetch next from reg into @arquivo
end
close reg
deallocate reg

