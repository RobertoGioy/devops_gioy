
-- Verifica se tem artigos pendentes no snapshot
select * from syssubscriptions s inner join sysarticles s2 on s.artid=s2.artid
where s.dest_db= 'FRDCA' and s.status<>2

-- Verifica se tem artigos sem assinantes
select s.name from sysarticles s inner join syspublications s2 on s.pubid = s2.pubid 
where s2.name = 'SL2000A' and not exists (select * from syssubscriptions s3 where s.artid =s3.artid and s3.dest_db= 'FRDCA')
order by s.name

Select Distinct Name From Sysarticles Where Name in ('Itens_Nota_Fiscal','Mov_faturas','LivroCaixa','Baixa_Dpl','Nota_Fiscal_Cpl','Mov_Bancaria','Nota_Fiscal')

/*
SET QUOTED_IDENTIFIER OFF
EXEC("SP_ADDSUBSCRIPTION @publication = N'SL2000A', @subscriber = N'FRSRVBDSQL02\SQLSIC1', @destination_db = N'FRDCA', @subscription_type = N'PUSH', @sync_type = N'AUTOMATIC', @article = N'ALL', @update_mode = N'READ ONLY', @subscriber_type = 0")
*/
select * from empresas
