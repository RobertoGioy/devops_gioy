alter procedure [sp_MSdel_dboOcorrencias_acu_Revendas]   
  @pkc1 char(3),@pkc2 int  
as   
begin 
IF (select count(*) from [dbo].[Ocorrencias_acu_Revendas] where [CodEmp] = @pkc1 and [Seq] = @pkc2 ) = 0
Insert into [dbo].[Ocorrencias_acu_Revendas] ([CodEmp],[Nomlog],[Data],[Ocorrencia],[Modulo],[Tipo],[Seq]) values (@pkc1,'',Getdate(),'','','',@pkc2)
delete [dbo].[Ocorrencias_acu_Revendas]  where [CodEmp] = @pkc1 and [Seq] = @pkc2  

if @@rowcount = 0  
    if @@microsoftversion>0x07320000  
        exec sp_MSreplraiserror 20598  
end 
go
alter procedure [sp_MSdel_dboOcorrencias_Revendas]   
  @pkc1 char(3),@pkc2 int  
as   
begin 
IF (select count(*) from [dbo].[Ocorrencias_Revendas] where [CodEmp] = @pkc1 and [Seq] = @pkc2 ) = 0
Insert into [dbo].[Ocorrencias_Revendas] ([CodEmp],[Nomlog],[Data],[Ocorrencia],[Modulo],[Tipo],[Seq]) values (@pkc1,'',Getdate(),'','','',@pkc2)
delete [dbo].[Ocorrencias_Revendas]  where [CodEmp] = @pkc1 and [Seq] = @pkc2  

if @@rowcount = 0  
    if @@microsoftversion>0x07320000  
        exec sp_MSreplraiserror 20598  
end 

select * from [Ocorrencias_Revendas]  