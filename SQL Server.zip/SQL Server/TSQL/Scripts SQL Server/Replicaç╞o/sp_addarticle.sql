DECLARE @TableName VARCHAR(25)
DECLARE @SchemaName VARCHAR(25)
DECLARE @PublisherName VARCHAR(25)

SET @TableName='TBU_CLIENT'
SET @SchemaName='dbo'
SET @PublisherName='DB_REPLICATION'

EXEC sp_addarticle
	@publication = @PublisherName,
	@article = @TableName,
	@source_owner = @SchemaName,
	@source_object = @TableName,
	@type = N'logbased',
	@description = null,
	@creation_script = null,
	@pre_creation_cmd = N'drop',
	@schema_option = 0x000000000803509F,
	@identityrangemanagementoption = N'manual',
	@destination_table = @TableName,
	@destination_owner = @SchemaName,
	@force_invalidate_snapshot=1
 GO
