
SET QUOTED_IDENTIFIER OFF 

create table #temp (Servidor Varchar(max), Base Varchar(max), empresa Varchar(max))
create table #temp1 (Base1 Varchar(max))

DECLARE @base sysname, @reg int, @tot int, @CMD1 VARCHAR(MAX), @CMD2 VARCHAR(MAX), @CMD3 VARCHAR(MAX)
, @CMD4 VARCHAR(MAX), @CMD5 VARCHAR(MAX), @CMD6 VARCHAR(MAX), @CMD7 VARCHAR(MAX), @CMD8 VARCHAR(MAX)


SET @CMD1 = 
"
DISABLE TRIGGER ALL ON DATABASE

"

SET @CMD2 = 
"
	declare @CODEMP  sysname
	declare reg2 cursor for
	Select Distinct Substring(Filter_Clause,13,3) From Sysarticles Where Name = 'Empresas'

	open reg2 
	fetch next  from reg2 into  @CODEMP 
	while @@fetch_status = 0 
	begin
			EXEC ('
					Update 
						Sysarticles 
					Set 
						Dest_Table=''OCORRENCIAS_REVENDAS'',
						Filter_Clause =''Codemp = '''''+@CODEMP+''''' AND ((Modulo = ''''Estoque'''' and Tipo <> ''''R'''') or (Modulo in(''''Logout de Usu�rio'''',''''Login de Usu�rio'''')) or (Modulo = ''''Fechamento'''') Or (modulo = ''''Atualiza_cadastros'''' And (Ocorrencia Like ''''%Inicio%'''' Or Ocorrencia Like ''''%Fim%'''' Or Ocorrencia Like ''''%erro%'''')))''
					Where 
						Name = ''Ocorrencias''
				   ')
        
        
	fetch next from reg2 into @CODEMP 
	end 
	close reg2
	deallocate reg2
"

SET @CMD3 = 
"
	declare @CODEMP  sysname
	declare reg2 cursor for
	Select Distinct Substring(Filter_Clause,13,3) From Sysarticles Where Name = 'Empresas'

	open reg2 
	fetch next  from reg2 into  @CODEMP 
	while @@fetch_status = 0 
	begin
			EXEC ('
					Update 
						Sysarticles 
					Set 
						Dest_Table=''OCORRENCIAS_ACU_REVENDAS'',
						Filter_Clause =''Codemp = '''''+@CODEMP+''''' AND ((Modulo = ''''Estoque'''' and Tipo <> ''''R'''') or (Modulo in(''''Logout de Usu�rio'''',''''Login de Usu�rio'''')) or (Modulo = ''''Fechamento'''') Or (modulo = ''''Atualiza_cadastros'''' And (Ocorrencia Like ''''%Inicio%'''' Or Ocorrencia Like ''''%Fim%'''' Or Ocorrencia Like ''''%erro%'''')))''
					Where 
						Name = ''Ocorrencias_Acu''
				   ')
        
        
	fetch next from reg2 into @CODEMP 
	end 
	close reg2
	deallocate reg2

"


SET @CMD4 = 
"


			DECLARE	@ARTIGOS	VARCHAR(MAX), @COMANDO	VARCHAR(MAX)
	
			DECLARE @VAR2 VARCHAR(MAX)

			SET @ARTIGOS = 'OCORRENCIAS'

			DECLARE CURSOR2 CURSOR FOR

			SELECT COMANDO FROM (
			SELECT	DISTINCT C.NAME,'A'AS ORDEM,
						'SP_DROPSUBSCRIPTION @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''',@SUBSCRIBER = N'''+B.SRVNAME +'''' AS COMANDO
			FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
			INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
			WHERE A.NAME = @ARTIGOS
			UNION
			SELECT	DISTINCT C.NAME,'B'AS ORDEM,'SP_DROPARTICLE @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME +'''' AS COMANDO
			FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
			INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
			WHERE A.NAME = @ARTIGOS

			
			UNION
			SELECT	DISTINCT C.NAME,'C'AS ORDEM,CASE WHEN A.FILTER <> 0 THEN 		
									'SP_ADDARTICLE @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''', @SOURCE_OWNER = N''DBO'', @SOURCE_OBJECT = N'''+A.NAME+
									''', @TYPE = N''LOGBASED'', @DESCRIPTION = N'''', @CREATION_SCRIPT = N'''', @PRE_CREATION_CMD = N''DELETE'', @IDENTITYRANGEMANAGEMENTOPTION = N''MANUAL'', @DESTINATION_TABLE = N'''+A.DEST_TABLE+
									''', @DESTINATION_OWNER= N''DBO'', @VERTICAL_PARTITION = N''FALSE'', @INS_CMD = N'''+A.INS_CMD+''', @DEL_CMD = N'''+A.DEL_CMD+
									''', @UPD_CMD = N'''+A.UPD_CMD+''', @FILTER_CLAUSE = N'''+REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+'''' 
									ELSE 
									'SP_ADDARTICLE @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''', @SOURCE_OWNER = N''DBO'', @SOURCE_OBJECT = N'''+A.NAME+
									''', @TYPE = N''LOGBASED'', @DESCRIPTION = N'''', @CREATION_SCRIPT = N'''', @PRE_CREATION_CMD = N''DELETE'', @IDENTITYRANGEMANAGEMENTOPTION = N''MANUAL'', @DESTINATION_TABLE = N'''+A.DEST_TABLE+
									''', @DESTINATION_OWNER= N''DBO'', @VERTICAL_PARTITION = N''FALSE'', @INS_CMD = N'''+A.INS_CMD+''', @DEL_CMD = N'''+A.DEL_CMD+
									''', @UPD_CMD = N'''+A.UPD_CMD+'''' END AS COMANDO
							FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
							INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
							WHERE A.NAME = @ARTIGOS
							UNION
							SELECT	DISTINCT C.NAME,'D'AS ORDEM,ISNULL('SP_ARTICLEFILTER @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''', @FILTER_NAME = N'''+E.NAME+ ''', @FILTER_CLAUSE = N'''+
									REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+''', @FORCE_INVALIDATE_SNAPSHOT = 1, @FORCE_REINIT_SUBSCRIPTION = 1','')AS COMANDO 
							FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
							INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
							WHERE A.NAME = @ARTIGOS
							UNION
							SELECT	DISTINCT C.NAME,'E'AS ORDEM,ISNULL('SP_ARTICLEVIEW @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''', @VIEW_NAME = N'''+D.NAME+ ''', @FILTER_CLAUSE = N'''+
									REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+''', @FORCE_INVALIDATE_SNAPSHOT = 1, @FORCE_REINIT_SUBSCRIPTION = 1','')AS COMANDO 
							FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
							INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
							WHERE A.NAME = @ARTIGOS
							UNION
							SELECT	DISTINCT C.NAME,'F'AS ORDEM,'SP_ADDSUBSCRIPTION @PUBLICATION = N'''+C.NAME+''', @SUBSCRIBER = N'''+B.SRVNAME+''', @DESTINATION_DB = N'''+B.DEST_DB+
									''', @SUBSCRIPTION_TYPE = N''PUSH'', @SYNC_TYPE = N''AUTOMATIC'', @ARTICLE = N''ALL'', @UPDATE_MODE = N''READ ONLY'', @SUBSCRIBER_TYPE = 0'AS COMANDO 
							FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
							INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
							WHERE A.NAME = @ARTIGOS

							)TABELA	WHERE COMANDO <> ''	
							ORDER BY ORDEM, NAME

							OPEN CURSOR2
							FETCH NEXT FROM CURSOR2 INTO @VAR2
							WHILE @@FETCH_STATUS = 0
							BEGIN
				
							  EXEC(@VAR2)
	
								FETCH NEXT FROM CURSOR2 INTO @VAR2
							END
							CLOSE CURSOR2
							DEALLOCATE CURSOR2
"


SET @CMD5 = 
"

		
			DECLARE	@ARTIGOS	VARCHAR(MAX), @COMANDO	VARCHAR(MAX)
	
			DECLARE @VAR2 VARCHAR(MAX)

			SET @ARTIGOS = 'OCORRENCIAS_ACU'

			DECLARE CURSOR2 CURSOR FOR

			SELECT COMANDO FROM (
			SELECT	DISTINCT C.NAME,'A'AS ORDEM,
						'SP_DROPSUBSCRIPTION @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''',@SUBSCRIBER = N'''+B.SRVNAME +'''' AS COMANDO
			FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
			INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
			WHERE A.NAME = @ARTIGOS
			UNION
			SELECT	DISTINCT C.NAME,'B'AS ORDEM,'SP_DROPARTICLE @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME +'''' AS COMANDO
			FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
			INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
			WHERE A.NAME = @ARTIGOS

			
			UNION
			SELECT	DISTINCT C.NAME,'C'AS ORDEM,CASE WHEN A.FILTER <> 0 THEN 		
									'SP_ADDARTICLE @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''', @SOURCE_OWNER = N''DBO'', @SOURCE_OBJECT = N'''+A.NAME+
									''', @TYPE = N''LOGBASED'', @DESCRIPTION = N'''', @CREATION_SCRIPT = N'''', @PRE_CREATION_CMD = N''DELETE'', @IDENTITYRANGEMANAGEMENTOPTION = N''MANUAL'', @DESTINATION_TABLE = N'''+A.DEST_TABLE+
									''', @DESTINATION_OWNER= N''DBO'', @VERTICAL_PARTITION = N''FALSE'', @INS_CMD = N'''+A.INS_CMD+''', @DEL_CMD = N'''+A.DEL_CMD+
									''', @UPD_CMD = N'''+A.UPD_CMD+''', @FILTER_CLAUSE = N'''+REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+'''' 
									ELSE 
									'SP_ADDARTICLE @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''', @SOURCE_OWNER = N''DBO'', @SOURCE_OBJECT = N'''+A.NAME+
									''', @TYPE = N''LOGBASED'', @DESCRIPTION = N'''', @CREATION_SCRIPT = N'''', @PRE_CREATION_CMD = N''DELETE'', @IDENTITYRANGEMANAGEMENTOPTION = N''MANUAL'', @DESTINATION_TABLE = N'''+A.DEST_TABLE+
									''', @DESTINATION_OWNER= N''DBO'', @VERTICAL_PARTITION = N''FALSE'', @INS_CMD = N'''+A.INS_CMD+''', @DEL_CMD = N'''+A.DEL_CMD+
									''', @UPD_CMD = N'''+A.UPD_CMD+'''' END AS COMANDO
							FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
							INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
							WHERE A.NAME = @ARTIGOS
							UNION
							SELECT	DISTINCT C.NAME,'D'AS ORDEM,ISNULL('SP_ARTICLEFILTER @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''', @FILTER_NAME = N'''+E.NAME+ ''', @FILTER_CLAUSE = N'''+
									REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+''', @FORCE_INVALIDATE_SNAPSHOT = 1, @FORCE_REINIT_SUBSCRIPTION = 1','')AS COMANDO 
							FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
							INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
							WHERE A.NAME = @ARTIGOS
							UNION
							SELECT	DISTINCT C.NAME,'E'AS ORDEM,ISNULL('SP_ARTICLEVIEW @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''', @VIEW_NAME = N'''+D.NAME+ ''', @FILTER_CLAUSE = N'''+
									REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+''', @FORCE_INVALIDATE_SNAPSHOT = 1, @FORCE_REINIT_SUBSCRIPTION = 1','')AS COMANDO 
							FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
							INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
							WHERE A.NAME = @ARTIGOS
							UNION
							SELECT	DISTINCT C.NAME,'F'AS ORDEM,'SP_ADDSUBSCRIPTION @PUBLICATION = N'''+C.NAME+''', @SUBSCRIBER = N'''+B.SRVNAME+''', @DESTINATION_DB = N'''+B.DEST_DB+
									''', @SUBSCRIPTION_TYPE = N''PUSH'', @SYNC_TYPE = N''AUTOMATIC'', @ARTICLE = N''ALL'', @UPDATE_MODE = N''READ ONLY'', @SUBSCRIBER_TYPE = 0'AS COMANDO 
							FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
							INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
							WHERE A.NAME = @ARTIGOS

							)TABELA	WHERE COMANDO <> ''	
							ORDER BY ORDEM, NAME

							OPEN CURSOR2
							FETCH NEXT FROM CURSOR2 INTO @VAR2
							WHILE @@FETCH_STATUS = 0
							BEGIN
				
							  EXEC(@VAR2)
	
								FETCH NEXT FROM CURSOR2 INTO @VAR2
							END
							CLOSE CURSOR2
							DEALLOCATE CURSOR2

"

SET @CMD6 = 
"
		DECLARE	@ARTIGOS33	VARCHAR(MAX), @COMANDO33 VARCHAR(MAX)
		DECLARE @VAR33 VARCHAR(MAX)
		DECLARE CURSOR33 CURSOR FOR
		SELECT COMANDO FROM (
		SELECT	DISTINCT C.NAME,'H'AS ORDEM,'SP_CHANGEARTICLE @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''', @PROPERTY = ''STATUS''  , @VALUE = ''PARAMETERS'''AS COMANDO 
		FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
		INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
		WHERE B.DEST_DB <> 'VIRTUAL' AND A.NAME IN ('OCORRENCIAS','OCORRENCIAS_ACU')

		)TABELA	WHERE COMANDO <> ''	
		ORDER BY ORDEM, NAME

		OPEN CURSOR33
		FETCH NEXT FROM CURSOR33 INTO @VAR33
		WHILE @@FETCH_STATUS = 0
		BEGIN
			EXEC (@VAR33)
			FETCH NEXT FROM CURSOR33 INTO @VAR33
		END
		CLOSE CURSOR33
		DEALLOCATE CURSOR33
"

SET @CMD7 = 
"
	ENABLE TRIGGER ALL ON DATABASE
"



set @tot = (select count(name) as Reg from sys.sysdatabases where not name in ('EMPDCGP','DCGP','FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') And Version <> 0 )

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where not name in ('EMPDCGP','DCGP','FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') And Version <> 0 ) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
	IF not (select OBJECT_ID ('Ocorrencias_Acu')) IS NULL
	if (select count(*) from sysobjects o inner join syscolumns c on o.id = c.id where o.name = 'Config' and c.name = 'Terc' ) > 0
	exec('if (select count(*) from config ) > 0
		INSERT into #temp1 SELECT ""[" + @base + "]"" ')
	")
	set @reg = @reg + 1
	end

update #temp1 set base1 = replace(replace(base1,'[',''),']','')


set @tot = (select count(name) as Reg from sys.sysdatabases where name in (select base1 from #Temp1) and not name in ('EMPDCGP','DCGP','FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') And Version <> 0 )

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where name in (select base1 from #Temp1) and not name in ('EMPDCGP','DCGP','FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') And Version <> 0 ) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
		EXEC (""" + @CMD1 + """) 
		IF not (select OBJECT_ID ('sysarticles')) IS NULL and not (select OBJECT_ID ('Ocorrencias_Acu')) IS NULL 
			begin
					if (select count(*) from sysarticles where name = 'Ocorrencias_Acu') > 0
						begin
						begin try
							EXEC (""" + @CMD2 + """) 
							EXEC (""" + @CMD3 + """) 
							EXEC (""" + @CMD4 + """) 
							EXEC (""" + @CMD5 + """) 
							EXEC (""" + @CMD6 + """) 
      						INSERT into #temp SELECT distinct @@servername as Servidor, ""[" + @base + "]"" as Base, '' as empresa
						end try
						begin catch
		   					INSERT into #temp SELECT distinct '(' + ERROR_MESSAGE() +') ' + @@servername as Servidor, ""[" + @base + "]"" as Base, '' as empresa
						end catch
						end
				
			end	
		EXEC (""" + @CMD7 + """) 
	")
	
	set @reg = @reg + 1
	end

	

SELECT Servidor, Base, empresa FROM #temp
Drop Table #temp
Drop Table #temp1
