select @@servername as Servidor, transacoes.name as Base, s.name, transacoes as Empresa 
from (select b.name,article_id, sum(a.UndelivCmdsInDistDB)as transacoes 
	  from distribution.dbo.MSdistribution_status  a
	  inner join distribution.dbo.MSdistribution_agents b on a.agent_id = b.id
	  where UndelivCmdsInDistDB <> 0 and b.subscriber_db <> 'virtual'
      group by b.name, article_id) as transacoes 
inner join sysarticles s on transacoes.article_id = s.artid
where transacoes > 3000 and transacoes.name like '%SL2000SMA%'
order by 3

--select * from sysarticles

