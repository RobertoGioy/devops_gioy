If (Select Count(*) From Syspublications Where Name Like '%GP%'  And Name Not Like '%NFE%') > 0
Begin
declare	@ARTIGOS	VARCHAR(MAX), @COMANDO	VARCHAR(MAX)
	
DECLARE @VAR2 VARCHAR(MAX)

set @artigos = 'Empresas'

DECLARE CURSOR2 CURSOR FOR

SELECT COMANDO FROM (
SELECT	DISTINCT C.NAME,'C'AS ORDEM,CASE WHEN A.FILTER <> 0 THEN 		
		'SP_ADDARTICLE @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''', @source_owner = N''DBO'', @source_object = N'''+A.NAME+
		''', @type = N''LOGBASED'', @description = N'''', @creation_script = N'''', @pre_creation_cmd = N''DELETE'', @identityrangemanagementoption = N''MANUAL'', @destination_table = N'''+A.DEST_TABLE+
        ''', @destination_owner= N''DBO'', @vertical_partition = N''FALSE'', @ins_cmd = N'''+A.INS_CMD+''', @del_cmd = N'''+A.DEL_CMD+
		''', @upd_cmd = N'''+A.UPD_CMD+''', @filter_clause = N'''+REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+'''' 
		ELSE 
		'SP_ADDARTICLE @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''', @source_owner = N''DBO'', @source_object = N'''+A.NAME+
		''', @type = N''LOGBASED'', @description = N'''', @creation_script = N'''', @pre_creation_cmd = N''DELETE'', @identityrangemanagementoption = N''MANUAL'', @destination_table = N'''+A.DEST_TABLE+
        ''', @destination_owner= N''DBO'', @vertical_partition = N''FALSE'', @ins_cmd = N'''+A.INS_CMD+''', @del_cmd = N'''+A.DEL_CMD+
		''', @upd_cmd = N'''+A.UPD_CMD+'''' END AS COMANDO
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE A.NAME = @ARTIGOS
UNION
SELECT	DISTINCT C.NAME,'D'AS ORDEM,ISNULL('SP_ARTICLEFILTER @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''', @filter_name = N'''+E.NAME+ ''', @filter_clause = N'''+
		REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+''', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1','')AS COMANDO 
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE A.NAME = @ARTIGOS
UNION
SELECT	DISTINCT C.NAME,'E'AS ORDEM,ISNULL('SP_ARTICLEVIEW @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''', @view_name = N'''+D.NAME+ ''', @filter_clause = N'''+
		REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+''', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1','')AS COMANDO 
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE A.NAME = @ARTIGOS
UNION
SELECT	DISTINCT C.NAME,'F'AS ORDEM,'SP_ADDSUBSCRIPTION @publication = N'''+C.NAME+''', @subscriber = N'''+B.SRVNAME+''', @destination_db = N'''+B.DEST_DB+
		''', @subscription_type = N''PUSH'', @sync_type = N''AUTOMATIC'', @article = N''ALL'', @update_mode = N''READ ONLY'', @subscriber_type = 0'AS COMANDO 
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE A.NAME = @ARTIGOS

)TABELA	WHERE COMANDO <> ''	
ORDER BY ORDEM, NAME

OPEN CURSOR2
FETCH NEXT FROM CURSOR2 INTO @VAR2
WHILE @@FETCH_STATUS = 0
BEGIN
    set @var2 = replace(@var2,@artigos,'GP_Produtos')
  EXEC(@VAR2)
	
	FETCH NEXT FROM CURSOR2 INTO @VAR2
END
CLOSE CURSOR2
DEALLOCATE CURSOR2
End

Go

DECLARE	@ARTIGOS33	VARCHAR(MAX), @COMANDO33 VARCHAR(MAX)
	
DECLARE @VAR33 VARCHAR(MAX)

DECLARE CURSOR33 CURSOR FOR
SELECT COMANDO FROM (
SELECT	DISTINCT C.NAME,'H'AS ORDEM,'SP_CHANGEARTICLE @PUBLICATION = N'''+C.NAME+''', @ARTICLE = N'''+A.NAME+''', @PROPERTY = ''STATUS''  , @VALUE = ''PARAMETERS'''AS COMANDO 
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE C.NAME LIKE '%GP%' AND C.NAME NOT LIKE '%NFE%' AND B.DEST_DB <> 'VIRTUAL'
)TABELA	WHERE COMANDO <> ''	
ORDER BY ORDEM, NAME

OPEN CURSOR33
FETCH NEXT FROM CURSOR33 INTO @VAR33
WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC (@VAR33)
	FETCH NEXT FROM CURSOR33 INTO @VAR33
END
CLOSE CURSOR33
DEALLOCATE CURSOR33