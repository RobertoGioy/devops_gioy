
--Remove Mov_Estoque2 da Replica��o
SET QUOTED_IDENTIFIER OFF
EXEC("SP_DROPSUBSCRIPTION @publication = N'SL2000A', @article = N'Mov_Estoque2',@subscriber = N'DCBSRVBDSQL02\SQL2'")
EXEC("SP_DROPSUBSCRIPTION @publication = N'SL2000A', @article = N'Mov_Estoque2',@subscriber = N'FRSRVBDSQL02\SQLSIC1'")
EXEC("SP_DROPARTICLE @publication = N'SL2000A', @article = N'Mov_Estoque2'")




--Cria Backup Mov_Estoque2 Revenda
Go
Select * Into Mov_Estoque2_Clodoaldo From Mov_Estoque2 Where Codemp = '115'


--Zera Mov_Estoque2 Revenda
Go
Truncate Table Mov_Estoque2



--Importa Mov_Estoque2 Dc Para Revenda
Go
Insert Into Mov_Estoque2
	(Codemp,Datmov,Codgru,subgru,Codpro,Tiplan,Desgru,dessgru,Despro,Tesinc,Qtdant,Valant,Qtdcom,Valcom,Qenbon,Qtdven,Valven,Qsabon,Qtdque,Valque,QTroca,Qtdatu,Valatu,Qtdcha,Valcha,Qtdvaa,Valvaa,Comqta,Comvaa,Qtdent,Valent,Qtdsai,Valsai,Qtdchf,Valchf,Qtdvaf,Valvaf,Comqtf,Comvaf,EntEmp,SaiBic,SaiEmp,SalTrA,SalPaA,SalPrA,SalTrF,SalPaF,SalPrF,TTGeral,TTValor,SalEmA,SalPoA,SalEmF,SalPoF,Tipo,Valfre,Valimp,SalMkA,SalMkF,QTDEMkt,QTDQueE,QTDQueM,QTDEmpM,QTDFatD,ValDes,ValQueEmp,ValQueMkt,EntRepEmp,EntRepMkt,Val_acre_compra,Val_desc_compra,Val_acre_venda,Val_desc_venda,Mao_obra,QtdInd,qtdTransInd,ValSaiIMp,ValInd,ValTransf)
Select 
	Codemp,Datmov,Codgru,subgru,Codpro,Tiplan,Desgru,dessgru,Despro,Tesinc,Qtdant,Valant,Qtdcom,Valcom,Qenbon,Qtdven,Valven,Qsabon,Qtdque,Valque,QTroca,Qtdatu,Valatu,Qtdcha,Valcha,Qtdvaa,Valvaa,Comqta,Comvaa,Qtdent,Valent,Qtdsai,Valsai,Qtdchf,Valchf,Qtdvaf,Valvaf,Comqtf,Comvaf,EntEmp,SaiBic,SaiEmp,SalTrA,SalPaA,SalPrA,SalTrF,SalPaF,SalPrF,TTGeral,TTValor,SalEmA,SalPoA,SalEmF,SalPoF,Tipo,Valfre,Valimp,SalMkA,SalMkF,QTDEMkt,QTDQueE,QTDQueM,QTDEmpM,QTDFatD,ValDes,ValQueEmp,ValQueMkt,EntRepEmp,EntRepMkt,Val_acre_compra,Val_desc_compra,Val_acre_venda,Val_desc_venda,Mao_obra,QtdInd,qtdTransInd,ValSaiIMp,ValInd,ValTransf
From [DCBSRVBDSQL02\SQL2].Dc.Dbo.Mov_Estoque2 With(Nolock)
	Where CodEmp = '115' And Tiplan = '99'


--Coloca Tabela Mov_Estoque na Replica��o
SET QUOTED_IDENTIFIER OFF
EXEC("SP_ADDARTICLE @publication = N'SL2000A', @article = N'Mov_Estoque2', @source_owner = N'DBO', @source_object = N'Mov_Estoque2', @type = N'LOGBASED', @description = N'', @creation_script = N'', @pre_creation_cmd = N'DELETE', @schema_option = 0X000000000A03008F, @identityrangemanagementoption = N'MANUAL', @destination_table = N'Mov_Estoque2', @destination_owner= N'DBO', @status = 8, @vertical_partition = N'FALSE', @ins_cmd = N'CALL [[[REPLA_sp_MSins_dboMov_Estoque2]', @del_cmd = N'CALL [[[REPLA_sp_MSdel_dboMov_Estoque2]', @upd_cmd = N'SCALL [[[REPLA_sp_MSupd_dboMov_Estoque2]', @filter_clause = N'[Codemp] = ''115''  And [Tiplan] In (''0'',''99'')'")
EXEC("SP_ARTICLEFILTER @publication = N'SL2000A', @article = N'Mov_Estoque2', @filter_name = N'SYNC_Mov_Estoque2_1__212', @filter_clause = N'[Codemp] = ''115''  And [Tiplan] In (''0'',''99'')', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1")
EXEC("SP_ARTICLEVIEW @publication = N'SL2000A', @article = N'Mov_Estoque2', @view_name = N'FLTR_Mov_Estoque2_1__212', @filter_clause = N'[Codemp] = ''115''  And [Tiplan] In (''0'',''99'')', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1")
EXEC("SP_ADDSUBSCRIPTION @publication = N'SL2000A', @subscriber = N'DCBSRVBDSQL02\SQL2', @destination_db = N'DC', @subscription_type = N'PUSH', @sync_type = N'AUTOMATIC', @article = N'ALL', @update_mode = N'READ ONLY', @subscriber_type = 0")
EXEC("SP_ADDSUBSCRIPTION @publication = N'SL2000A', @subscriber = N'FRSRVBDSQL02\SQLSIC1', @destination_db = N'FRDCA', @subscription_type = N'PUSH', @sync_type = N'AUTOMATIC', @article = N'ALL', @update_mode = N'READ ONLY', @subscriber_type = 0")


--Remove Balanco_Estoque Da Replica��o
SET QUOTED_IDENTIFIER OFF
EXEC("SP_DROPSUBSCRIPTION @publication = N'SL2000A', @article = N'Balanco_Estoque',@subscriber = N'DCBSRVBDSQL02\SQL2'")
EXEC("SP_DROPSUBSCRIPTION @publication = N'SL2000A', @article = N'Balanco_Estoque',@subscriber = N'FRSRVBDSQL02\SQLSIC1'")
EXEC("SP_DROPARTICLE @publication = N'SL2000A', @article = N'Balanco_Estoque'")


--Cria Backup Balanco_Estoque Revenda
Go
Select * Into Balanco_Estoque_Clodoaldo From Balanco_Estoque Where Tiplan = '99' And Codemp = '115'


--Deleta Balanco_Estoque 99 da Revenda
Go
Delete From Balanco_Estoque Where Codemp = '115' And Tiplan = '99'



--Importa Balanco_Estoque 99 Dc Para Revenda
Go
Insert Into Balanco_Estoque
	(CodEmp, Datmov, CodGru, SubGru, Tiplan, DesGru, Dessgru, QtdAnt, ValAnt, QtdCom, ValCom, QEnBon, QtdVen, ValVen, QSaBon, QtdQue, ValQue, QTroca, QtdAtu, ValAtu, Qtdcha, Valcha, Qtdvaa, Valvaa, Comqta, Comvaa, Qtdent, Valent, Qtdsai, Valsai, Qtdchf, Valchf, Qtdvaf, Valvaf, Comqtf, Comvaf, EntEmp, SaiBic, SaiEmp, SalTrA, SalPaA, SalPrA, SalTrF, SalPaF, SalPrF, SalEmA, SalPoA, SalEmF, SalPoF, TTGeral, TTValor, Val_acre_compra, Val_desc_compra, Val_acre_venda, Val_desc_venda, Mao_obra, QtdInd, qtdTransInd, ValSaiIMp, ValInd, ValTransf, ValFre, ValImp)
Select 
	CodEmp, Datmov, CodGru, SubGru, Tiplan, DesGru, Dessgru, QtdAnt, ValAnt, QtdCom, ValCom, QEnBon, QtdVen, ValVen, QSaBon, QtdQue, ValQue, QTroca, QtdAtu, ValAtu, Qtdcha, Valcha, Qtdvaa, Valvaa, Comqta, Comvaa, Qtdent, Valent, Qtdsai, Valsai, Qtdchf, Valchf, Qtdvaf, Valvaf, Comqtf, Comvaf, EntEmp, SaiBic, SaiEmp, SalTrA, SalPaA, SalPrA, SalTrF, SalPaF, SalPrF, SalEmA, SalPoA, SalEmF, SalPoF, TTGeral, TTValor, Val_acre_compra, Val_desc_compra, Val_acre_venda, Val_desc_venda, Mao_obra, QtdInd, qtdTransInd, ValSaiIMp, ValInd, ValTransf, ValFre, ValImp
From [DCBSRVBDSQL02\SQL2].Dc.Dbo.Balanco_Estoque
	Where Codemp = '115' And Tiplan = '99'
	


--Coloca Tabela Mov_Estoque na Replica��o
SET QUOTED_IDENTIFIER OFF
EXEC("SP_ADDARTICLE @publication = N'SL2000A', @article = N'Balanco_Estoque', @source_owner = N'DBO', @source_object = N'Balanco_Estoque', @type = N'LOGBASED', @description = N'', @creation_script = N'', @pre_creation_cmd = N'DELETE', @schema_option = 0X000000000A03008F, @identityrangemanagementoption = N'MANUAL', @destination_table = N'Balanco_Estoque', @destination_owner= N'DBO', @status = 8, @vertical_partition = N'FALSE', @ins_cmd = N'CALL [[[REPLA_sp_MSins_dboBalanco_Estoque]', @del_cmd = N'CALL [[[REPLA_sp_MSdel_dboBalanco_Estoque]', @upd_cmd = N'SCALL [[[REPLA_sp_MSupd_dboBalanco_Estoque]', @filter_clause = N'[CodEmp] = ''115'' And [Tiplan] In (''0'',''99'')'")
EXEC("SP_ARTICLEFILTER @publication = N'SL2000A', @article = N'Balanco_Estoque', @filter_name = N'SYNC_Balanco_Estoque_1__212', @filter_clause = N'[CodEmp] = ''115'' And [Tiplan] In (''0'',''99'')', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1")
EXEC("SP_ARTICLEVIEW @publication = N'SL2000A', @article = N'Balanco_Estoque', @view_name = N'FLTR_Balanco_Estoque_1__212', @filter_clause = N'[CodEmp] = ''115'' And [Tiplan] In (''0'',''99'')', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1")
EXEC("SP_ADDSUBSCRIPTION @publication = N'SL2000A', @subscriber = N'DCBSRVBDSQL02\SQL2', @destination_db = N'DC', @subscription_type = N'PUSH', @sync_type = N'AUTOMATIC', @article = N'ALL', @update_mode = N'READ ONLY', @subscriber_type = 0")
EXEC("SP_ADDSUBSCRIPTION @publication = N'SL2000A', @subscriber = N'FRSRVBDSQL02\SQLSIC1', @destination_db = N'FRDCA', @subscription_type = N'PUSH', @sync_type = N'AUTOMATIC', @article = N'ALL', @update_mode = N'READ ONLY', @subscriber_type = 0")
	
	
--Verifica Filtro Replica��o
Select * From SysArticles Where Dest_Table Like '%Mov_Estoque%'
Select * From SysArticles Where Dest_Table Like '%Balanco_Estoque%'


--Insere 99 Na Tabela Op��es //Executar Ap�s Colocar as Tabelas na Replica��o//
Go
Insert Into Opcoes (Codigo,Descricao,Contabil) Values('99','Mov_Estoque2 - Copia','N')

