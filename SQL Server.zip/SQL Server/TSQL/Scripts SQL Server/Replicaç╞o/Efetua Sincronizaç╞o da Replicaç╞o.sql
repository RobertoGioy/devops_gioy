sp_serveroption 'frsrvbdsql02\sqlsic1','data access','true'
/*
sp_dropsubscription 'SL2000A','fat_contab','all'
go
sp_droparticle 'SL2000A','fat_contab'
go
*/
--------------------------------------------------------------------

sp_changepublication 'SL2000A','allow_anonymous','false'
GO
sp_changepublication 'SL2000A','immediate_sync','false'
GO
update syssubscriptions set sync_type=1, nosync_type=0




