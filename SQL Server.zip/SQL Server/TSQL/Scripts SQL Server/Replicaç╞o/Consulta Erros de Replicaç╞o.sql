set identity_insert #repl on
Insert into #repl (datalog, id, publisher, publisher_db, publication, subscription_type, queue_id, update_mode, failover_mode, spid, login_time, allow_subscription_copy, attach_state, attach_version, last_sync_status, last_sync_summary, last_sync_time, queue_server)
select getdate() as datalog,id, publisher, publisher_db, publication, subscription_type, queue_id, update_mode, failover_mode, spid, login_time, allow_subscription_copy, attach_state, attach_version, last_sync_status, last_sync_summary, last_sync_time, queue_server from mssubscription_agents
where login_time >= '2011-03-24' and publication like '%A'
and last_sync_summary not like ('%N�o h�%')
and last_sync_summary not like ('%No Replicated%')
and last_sync_summary not like ('%andamento%')
and last_sync_summary not like ('%entregues%')
and last_sync_summary not like ('%total%')
and last_sync_summary not like ('%progre%')
and last_sync_summary not like ('%delivered%')


select getdate() as datalog,* from mssubscription_agents
where login_time >= '2011-03-24' and publication like '%A'
and last_sync_summary not like ('%N�o h�%')
and last_sync_summary not like ('%No Replicated%')
and last_sync_summary not like ('%andamento%')
and last_sync_summary not like ('%entregues%')
and last_sync_summary not like ('%total%')
and last_sync_summary not like ('%progre%')
and last_sync_summary not like ('%delivered%')


truncate table #repl