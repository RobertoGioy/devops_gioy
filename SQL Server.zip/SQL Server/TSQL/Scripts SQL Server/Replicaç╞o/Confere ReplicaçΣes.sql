SELECT	'FRSRVBDSQL02\SQLSIC1' AS 'Servidor DC',
		'FRDCA' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [FRSRVBDSQL02\SQLSIC1].[FRDCA].DBO.mssubscription_agents t (NOLOCK)  
		LEFT JOIN [FRSRVBDSQL02\SQLSIC1].[FRDCA].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [FRSRVBDSQL02\SQLSIC1].[FRDCA].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
      and not t.last_sync_summary like 'no replicated%' 
      and not t.last_sync_summary like 'a total%'  
      and not t.last_sync_summary like 'N�o h� transa��es%' 
      and not t.last_sync_summary like 'No total%' 
      and not t.last_sync_summary like 'the process%' 
      and not t.last_sync_summary like 'synchronization%' 
      and not t.last_sync_summary like 'Sincroniza��o%'       
      
UNION

SELECT	'FRSRVBDSQL02\SQLSIC1' AS 'Servidor DC',
		'SLDCA' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [FRSRVBDSQL02\SQLSIC1].[SLDCA].DBO.mssubscription_agents t (NOLOCK)  
		LEFT JOIN [FRSRVBDSQL02\SQLSIC1].[SLDCA].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [FRSRVBDSQL02\SQLSIC1].[SLDCA].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
      and not t.last_sync_summary like 'no replicated%' 
      and not t.last_sync_summary like 'a total%'  
      and not t.last_sync_summary like 'N�o h� transa��es%' 
      and not t.last_sync_summary like 'No total%' 
      and not t.last_sync_summary like 'the process%' 
      and not t.last_sync_summary like 'synchronization%' 
      and not t.last_sync_summary like 'Sincroniza��o%'
            
UNION

SELECT	'FRSRVBDSQL02\SQLSIC1' AS 'Servidor DC','EMPDCA' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [FRSRVBDSQL02\SQLSIC1].[EMPDCA].DBO.mssubscription_agents t (NOLOCK)  
		LEFT JOIN [FRSRVBDSQL02\SQLSIC1].[EMPDCA].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (SELECT MAX(last_sync_time) FROM [FRSRVBDSQL02\SQLSIC1].[EMPDCA].DBO.mssubscription_agents s (NOLOCK) WHERE s.publisher = t.publisher) 
	  and not t.last_sync_summary like 'no replicated%' 
      and not t.last_sync_summary like 'a total%'  
      and not t.last_sync_summary like 'N�o h� transa��es%' 
      and not t.last_sync_summary like 'No total%' 
      and not t.last_sync_summary like 'the process%' 
      and not t.last_sync_summary like 'synchronization%' 
      and not t.last_sync_summary like 'Sincroniza��o%'
            
UNION

SELECT	'FRSRVBDSQL04\SIS01' AS 'Servidor DC',
		'NFE_PRD' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidade, t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [FRSRVBDSQL04\SIS01].[NFE_PRD].DBO.mssubscription_agents t (NOLOCK)  
		LEFT JOIN [FRSRVBDSQL04\SIS01].[NFE_PRD].DBO.nfe03_filial e (NOLOCK) on e.id_filial = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [FRSRVBDSQL04\SIS01].[NFE_PRD].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
      and not t.last_sync_summary like 'no replicated%' 
      and not t.last_sync_summary like 'a total%'  
      and not t.last_sync_summary like 'N�o h� transa��es%' 
      and not t.last_sync_summary like 'No total%' 
      and not t.last_sync_summary like 'the process%' 
      and not t.last_sync_summary like 'synchronization%' 
      and not t.last_sync_summary like 'Sincroniza��o%'
            
UNION

SELECT	'DCBSRVBDSQL02\SQL2' AS 'Servidor DC',
		'SLDCB' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [DCBSRVBDSQL02\SQL2].[SLDCB].DBO.mssubscription_agents t (NOLOCK)  
		LEFT JOIN [DCBSRVBDSQL02\SQL2].[SLDCB].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [DCBSRVBDSQL02\SQL2].[SLDCB].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
      and not t.last_sync_summary like 'no replicated%' 
      and not t.last_sync_summary like 'a total%'  
      and not t.last_sync_summary like 'N�o h� transa��es%' 
      and not t.last_sync_summary like 'No total%' 
      and not t.last_sync_summary like 'the process%' 
      and not t.last_sync_summary like 'synchronization%' 
      and not t.last_sync_summary like 'Sincroniza��o%'
            
UNION

SELECT	'DCBSRVBDSQL02\SQL2' AS 'Servidor DC',
		'DC' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [DCBSRVBDSQL02\SQL2].[DC].DBO.mssubscription_agents t (NOLOCK)  
		LEFT JOIN [DCBSRVBDSQL02\SQL2].[DC].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [DCBSRVBDSQL02\SQL2].[DC].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
      and not t.last_sync_summary like 'no replicated%' 
      and not t.last_sync_summary like 'a total%'  
      and not t.last_sync_summary like 'N�o h� transa��es%' 
      and not t.last_sync_summary like 'No total%' 
      and not t.last_sync_summary like 'the process%' 
      and not t.last_sync_summary like 'synchronization%' 
      and not t.last_sync_summary like 'Sincroniza��o%'
            
UNION

SELECT	'DCBSRVBDSQL02\SQL2' AS 'Servidor DC',
		'EMPDCAB' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [DCBSRVBDSQL02\SQL2].[EMPDCAB].DBO.mssubscription_agents t (NOLOCK)  
		LEFT JOIN [DCBSRVBDSQL02\SQL2].[EMPDCAB].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [DCBSRVBDSQL02\SQL2].[EMPDCAB].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
      and not t.last_sync_summary like 'no replicated%' 
      and not t.last_sync_summary like 'a total%'  
      and not t.last_sync_summary like 'N�o h� transa��es%' 
      and not t.last_sync_summary like 'No total%' 
      and not t.last_sync_summary like 'the process%' 
      and not t.last_sync_summary like 'synchronization%' 
      and not t.last_sync_summary like 'Sincroniza��o%'      
      
UNION

SELECT	'FRSRVBDSQL02\SQLSIC1' AS 'Servidor DC',
		'FRDCA' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [FRSRVBDSQL02\SQLSIC1].[FRDCA].DBO.mssubscription_agents t (NOLOCK) 
		LEFT JOIN [FRSRVBDSQL02\SQLSIC1].[FRDCA].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [FRSRVBDSQL02\SQLSIC1].[FRDCA].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
	  and DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) > 10 and t.publisher not in ('')
	  
UNION

SELECT  'FRSRVBDSQL02\SQLSIC1' AS 'Servidor DC','SLDCA' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [FRSRVBDSQL02\SQLSIC1].[SLDCA].DBO.mssubscription_agents t (NOLOCK) 
	LEFT JOIN [FRSRVBDSQL02\SQLSIC1].[SLDCA].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [FRSRVBDSQL02\SQLSIC1].[SLDCA].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
	  and DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) > 10 and t.publisher not in ('')
	  
UNION

SELECT	'FRSRVBDSQL02\SQLSIC1' AS 'Servidor DC','EMPDCA' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [FRSRVBDSQL02\SQLSIC1].[EMPDCA].DBO.mssubscription_agents t (NOLOCK) 
	LEFT JOIN [FRSRVBDSQL02\SQLSIC1].[EMPDCA].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [FRSRVBDSQL02\SQLSIC1].[EMPDCA].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
	  and DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) > 10 and t.publisher not in ('')
	  
UNION

SELECT	'FRSRVBDSQL04\SIS01' AS 'Servidor DC',
		'NFE_PRD' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidade, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [FRSRVBDSQL04\SIS01].[NFE_PRD].DBO.mssubscription_agents t (NOLOCK)	
	LEFT JOIN [FRSRVBDSQL04\SIS01].[NFE_PRD].DBO.nfe03_filial e (NOLOCK) on convert(varchar(03),e.id_filial) = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [FRSRVBDSQL04\SIS01].[NFE_PRD].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
	  and DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) > 10 and t.publisher not in ('')
	  
UNION

SELECT	'DCBSRVBDSQL02\SQL2' AS 'Servidor DC',	
		'SLDCB' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,
		GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [DCBSRVBDSQL02\SQL2].[SLDCB].DBO.mssubscription_agents t (NOLOCK) 
	LEFT JOIN [DCBSRVBDSQL02\SQL2].[SLDCB].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [DCBSRVBDSQL02\SQL2].[SLDCB].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
	  and DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) > 10 and t.publisher not in ('')
	  
UNION

SELECT	'DCBSRVBDSQL02\SQL2' AS 'Servidor DC',
		'DC' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [DCBSRVBDSQL02\SQL2].[DC].DBO.mssubscription_agents t (NOLOCK) 
	LEFT JOIN [DCBSRVBDSQL02\SQL2].[DC].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [DCBSRVBDSQL02\SQL2].[DC].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
	  and DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) > 10 and t.publisher not in ('')
	  
UNION

SELECT	'DCBSRVBDSQL02\SQL2' AS 'Servidor DC',
		'EMPDCAB' AS 'Base DC',
		t.publisher AS 'Servidor REV', 
		t.publisher_db AS 'Base REV', 
		e.cidemp, 
		t.last_sync_summary, 
		t.last_sync_time, 
		DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) AS Minutos, 
		(DATEDIFF(MINUTE,t.last_sync_time, GETDATE())/60) as Horas, 
		(DATEDIFF(MINUTE, t.last_sync_time, GETDATE())/60/24) AS Dias 
FROM [DCBSRVBDSQL02\SQL2].[EMPDCAB].DBO.mssubscription_agents t (NOLOCK) 
	LEFT JOIN [DCBSRVBDSQL02\SQL2].[EMPDCAB].DBO.empresas e (NOLOCK) on e.codemp = SUBSTRING(t.publisher,2,3)
WHERE t.last_sync_time = (	SELECT MAX(last_sync_time) 
							FROM [DCBSRVBDSQL02\SQL2].[EMPDCAB].DBO.mssubscription_agents s (NOLOCK) 
							WHERE s.publisher = t.publisher) 
	  and DATEDIFF(MINUTE,t.last_sync_time,GETDATE()) > 10 and t.publisher not in ('')

ORDER BY Minutos DESC,'Servidor DC','Base DC' 

--select * from [DCBSRVBDSQL02\SQL2].DC.dbo.mssubscription_agents where publisher='E189S2'
--select * from [FRSRVBDSQL02\SQLSIC1].frdca.dbo.mssubscription_agents where publisher='E189S2'
