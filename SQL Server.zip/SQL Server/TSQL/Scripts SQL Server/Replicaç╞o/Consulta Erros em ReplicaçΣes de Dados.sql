IF not (select db_name(db_id ('distribution'))) IS NULL
	begin
		select top 1 
		@@servername as Servidor,
		error_code as Base, 
		cast(error_text as varchar(200)) +'='+ cast(publisher_db as varchar) +'='+ cast(publication as varchar) +'='+ cast(subscriber_db as varchar) as Empresa
		from distribution.dbo.MSdistribution_history 
		join distribution.dbo.msrepl_errors on msrepl_errors.id=MSdistribution_history.error_id
		join distribution.dbo.MSdistribution_agents on MSdistribution_history.agent_id = [MSdistribution_agents].id
		where msrepl_errors.time >= getdate()-'00:10' 
		and not msrepl_errors.error_code in ('20052','20203','9002','4060','64','18456','10061','10060','HYT00','0','','121','258','10051','08001','08S01','-1','10054','10065')  
		order by msrepl_errors.time desc
	end

IF not (select db_name(db_id ('distribution1'))) IS NULL
	begin
		select top 1 
		@@servername as Servidor,
		error_code as Base, 
		cast(error_text as varchar(200)) +'='+ cast(publisher_db as varchar) +'='+ cast(publication as varchar) +'='+ cast(subscriber_db as varchar) as Empresa
		from distribution1.dbo.MSdistribution_history 
		join distribution1.dbo.msrepl_errors on msrepl_errors.id=MSdistribution_history.error_id
		join distribution1.dbo.MSdistribution_agents on MSdistribution_history.agent_id = [MSdistribution_agents].id
		where msrepl_errors.time >= getdate()-'00:10' 
		and not msrepl_errors.error_code in ('20052','20203','9002','4060','64','18456','10061','10060','HYT00','0','','121','258','10051','08001','08S01','-1','10054','10065')  
		order by msrepl_errors.time desc
	end

IF not (select db_name(db_id ('frsql03'))) IS NULL
	begin
		select top 1 
		@@servername as Servidor,
		error_code as Base, 
		cast(error_text as varchar(200)) +'='+ cast(publisher_db as varchar) +'='+ cast(publication as varchar) +'='+ cast(subscriber_db as varchar) as Empresa
		from frsql03.dbo.MSdistribution_history 
		join frsql03.dbo.msrepl_errors on msrepl_errors.id=MSdistribution_history.error_id
		join frsql03.dbo.MSdistribution_agents on MSdistribution_history.agent_id = [MSdistribution_agents].id
		where msrepl_errors.time >= getdate()-'00:10' 
		and not msrepl_errors.error_code in ('20052','20203','9002','4060','64','18456','10061','10060','HYT00','0','','121','258','10051','08001','08S01','-1','10054','10065')  
		order by msrepl_errors.time desc
	end

IF not (select db_name(db_id ('frsql02'))) IS NULL
	begin
		select top 1 
		@@servername as Servidor,
		error_code as Base, 
		cast(error_text as varchar(200)) +'='+ cast(publisher_db as varchar) +'='+ cast(publication as varchar) +'='+ cast(subscriber_db as varchar) as Empresa
		from frsql02.dbo.MSdistribution_history 
		join frsql02.dbo.msrepl_errors on msrepl_errors.id=MSdistribution_history.error_id
		join frsql02.dbo.MSdistribution_agents on MSdistribution_history.agent_id = [MSdistribution_agents].id
		where msrepl_errors.time >= getdate()-'00:10' 
		and not msrepl_errors.error_code in ('20052','20203','9002','4060','64','18456','10061','10060','HYT00','0','','121','258','10051','08001','08S01','-1','10054','10065')  
		order by msrepl_errors.time desc
	end

IF not (select db_name(db_id ('frsql05'))) IS NULL
	begin
		select top 1 
		@@servername as Servidor,
		error_code as Base, 
		cast(error_text as varchar(200)) +'='+ cast(publisher_db as varchar) +'='+ cast(publication as varchar) +'='+ cast(subscriber_db as varchar) as Empresa
		from frsql05.dbo.MSdistribution_history 
		join frsql05.dbo.msrepl_errors on msrepl_errors.id=MSdistribution_history.error_id
		join frsql05.dbo.MSdistribution_agents on MSdistribution_history.agent_id = [MSdistribution_agents].id
		where msrepl_errors.time >= getdate()-'00:10' 
		and not msrepl_errors.error_code in ('20052','20203','9002','4060','64','18456','10061','10060','HYT00','0','','121','258','10051','08001','08S01','-1','10054','10065')  
		order by msrepl_errors.time desc
	end

IF not (select db_name(db_id ('DISTR34'))) IS NULL
	begin
		select top 1 
		@@servername as Servidor,
		error_code as Base, 
		cast(error_text as varchar(200)) +'='+ cast(publisher_db as varchar) +'='+ cast(publication as varchar) +'='+ cast(subscriber_db as varchar) as Empresa
		from DISTR34.dbo.MSdistribution_history 
		join DISTR34.dbo.msrepl_errors on msrepl_errors.id=MSdistribution_history.error_id
		join DISTR34.dbo.MSdistribution_agents on MSdistribution_history.agent_id = [MSdistribution_agents].id
		where msrepl_errors.time >= getdate()-'00:10' 
		and not msrepl_errors.error_code in ('20052','20203','9002','4060','64','18456','10061','10060','HYT00','0','','121','258','10051','08001','08S01','-1','10054','10065')  
		order by msrepl_errors.time desc
	end

IF not (select db_name(db_id ('DISTR35'))) IS NULL
	begin
		select top 1 
		@@servername as Servidor,
		error_code as Base, 
		cast(error_text as varchar(200)) +'='+ cast(publisher_db as varchar) +'='+ cast(publication as varchar) +'='+ cast(subscriber_db as varchar) as Empresa
		from DISTR35.dbo.MSdistribution_history 
		join DISTR35.dbo.msrepl_errors on msrepl_errors.id=MSdistribution_history.error_id
		join DISTR35.dbo.MSdistribution_agents on MSdistribution_history.agent_id = [MSdistribution_agents].id
		where msrepl_errors.time >= getdate()-'00:10' 
		and not msrepl_errors.error_code in ('20052','20203','9002','4060','64','18456','10061','10060','HYT00','0','','121','258','10051','08001','08S01','-1','10054','10065')  
		order by msrepl_errors.time desc
	end

IF not (select db_name(db_id ('DISTR41_PROD'))) IS NULL
	begin
		select top 1 
		@@servername as Servidor,
		error_code as Base, 
		cast(error_text as varchar(200)) +'='+ cast(publisher_db as varchar) +'='+ cast(publication as varchar) +'='+ cast(subscriber_db as varchar) as Empresa
		from DISTR35.dbo.MSdistribution_history 
		join DISTR35.dbo.msrepl_errors on msrepl_errors.id=MSdistribution_history.error_id
		join DISTR35.dbo.MSdistribution_agents on MSdistribution_history.agent_id = [MSdistribution_agents].id
		where msrepl_errors.time >= getdate()-'00:10' 
		and not msrepl_errors.error_code in ('20052','20203','9002','4060','64','18456','10061','10060','HYT00','0','','121','258','10051','08001','08S01','-1','10054','10065')  
		order by msrepl_errors.time desc
	end