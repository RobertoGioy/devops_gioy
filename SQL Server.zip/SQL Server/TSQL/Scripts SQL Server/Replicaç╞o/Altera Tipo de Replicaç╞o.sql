declare @totx int, @regx int, @publica sysname

set @totx = (select count(*) as reg from syspublications where not name like ('REVNFE%'))

set @regx = 1

while @regx <= @totx
	begin
		set @publica = (select name from (select row_number() over (order by name) as Reg, name from syspublications where not name like ('REVNFE%')) as t where t.reg  = @regx)

		DECLARE @reg int, @tot int, @artigo sysname

		set @tot = (select count(*) as reg from sysarticles a inner join syspublications p on a.pubid = p.pubid where p.name = @publica )

		set @reg = 1

		while @reg <= @tot
			begin
			set @artigo = (select name from (select row_number() over (order by a.name) as Reg, a.name from sysarticles a inner join syspublications p on a.pubid = p.pubid where p.name = @publica) as t where t.reg  = @reg)

			exec sp_changearticle @publication = @publica, @article = @artigo, @property = N'ins_cmd', @value = N'SQL', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
			exec sp_changearticle @publication = @publica, @article = @artigo, @property = N'del_cmd', @value = N'SQL', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
			exec sp_changearticle @publication = @publica, @article = @artigo, @property = N'upd_cmd', @value = N'SQL', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1

			Exec sp_changearticle @publication = @publica, @article = @artigo, @property = 'status'  , @value = 'parameters'
			
			set @reg = @reg + 1
			end
		set @regx = @regx + 1
	end
	
