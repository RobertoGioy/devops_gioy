select top 1 * from ocorrencias
select top 1 * from ocorrencias_acu


alter table ocorrencias add Seq int identity(1,1)
Go
alter table ocorrencias_acu add Seq int identity(1,1)
Go
alter table ocorrencias add constraint PK_Ocorrencias primary key (seq,codemp)
Go
alter table ocorrencias_acu add constraint PK_Ocorrencias_Acu primary key (seq,codemp)
Go
alter table ocorrencias alter column Ocorrencia varchar(800)
Go
alter table ocorrencias_acu alter column Ocorrencia varchar(800)


Exec sp_dropsubscription 'EMPDCA', 'carrega', 'FRSRVBDSQL02\SQLSIC1'
Go
Exec sp_dropsubscription 'EMPDCA', 'carrega', 'DCBSRVBDSQL02\SQL2'
Go
Exec sp_droparticle 'EMPDCA', 'carrega'


select filter_clause,* from sysarticles where name = 'empresas'
select *--'alter table '+b.name+' add constraint PK_'+b.name+' primary key (Codemp)'
from syscolumns a 
inner join sysobjects b on a.id = b.id
where a.name = 'codemp' and b.xtype = 'U' and b.name not like '%temp%' and b.name not in ('carrega', 'modelo3', 'transacoes') and b.name not like '%2008%' and b.name not like '%2%' and b.name not like '%BKP%' and b.name not like '%results%' and b.name not like '%00%'
and not exists (select * from sysarticles c where b.name = c.name)
order by 1


select case when b.name like '%ocorrencias%' 
then 
'if not exists (
SELECT * FROM SYSARTICLES a
inner join syspublications b 
on a.pubid = b.pubid 
where b.name = ''EMPDCA''
and a.name = '''+b.name +''')
Begin
exec sp_addarticle @publication = N''EMPDCA'', @article = N'''+b.name+''', @source_owner = N''dbo'', @source_object = N'''+b.name+''', @type = N''logbased'', @description = N'''', @creation_script = null, @pre_creation_cmd = N''delete'', @schema_option = 0x000000000A03008F, @force_invalidate_snapshot = 1, @identityrangemanagementoption = N''manual'', @destination_table = N'''+b.name+'_Revendas'', @destination_owner = N''dbo'', @status = 0, @vertical_partition = N''false'', @ins_cmd = N''CALL EMPDCA_sp_MSins_dbo'+b.name+'_Revendas'', @del_cmd = N''CALL EMPDCA_sp_MSdel_dbo'+b.name+'_Revendas'', @upd_cmd = N''SCALL EMPDCA_sp_MSupd_dbo'+b.name+'_Revendas''
exec sp_MSuniquename N''EMPDCA_FLTR_'+b.name+'_Revendas'', 1
exec sp_articlefilter @publication = N''EMPDCA'', @article = N'''+b.name+''', @filter_name = N''EMPDCA_FLTR_'+b.name+'_1__232'', @filter_clause = N''Codemp in (''''766'''') AND ((Modulo = ''''Estoque'''' and Tipo <> ''''R'''') or (Modulo in(''''Logout de Usu�rio'''',''''Login de Usu�rio'''')) or Modulo = ''''Fechamento'''')'', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articleview @publication = N''EMPDCA'', @article = N'''+b.name+''', @view_name = N''EMPDCA_SYNC_'+b.name+'_1__232'', @filter_clause = N''Codemp in (''''766'''') AND ((Modulo = ''''Estoque'''' and Tipo <> ''''R'''') or (Modulo in(''''Logout de Usu�rio'''',''''Login de Usu�rio'''')) or Modulo = ''''Fechamento'''')'', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_refreshsubscriptions @publication = N''EMPDCA''
end
'
else 
'if not exists (
SELECT * FROM SYSARTICLES a
inner join syspublications b 
on a.pubid = b.pubid 
where b.name = ''EMPDCA''
and a.name = '''+b.name +''')
Begin
exec sp_addarticle @publication = N''EMPDCA'', @article = N'''+b.name+''', @source_owner = N''dbo'', @source_object = N'''+b.name+''', @type = N''logbased'', @description = N'''', @creation_script = null, @pre_creation_cmd = N''delete'', @schema_option = 0x000000000A03008F, @force_invalidate_snapshot = 1, @identityrangemanagementoption = N''manual'', @destination_table = N'''+b.name+''', @destination_owner = N''dbo'', @status = 0, @vertical_partition = N''false'', @ins_cmd = N''CALL EMPDCA_sp_MSins_dbo'+b.name+''', @del_cmd = N''CALL EMPDCA_sp_MSdel_dbo'+b.name+''', @upd_cmd = N''SCALL EMPDCA_sp_MSupd_dbo'+b.name+'''
exec sp_MSuniquename N''EMPDCA_FLTR_'+b.name+'_'', 1
exec sp_articlefilter @publication = N''EMPDCA'', @article = N'''+b.name+''', @filter_name = N''EMPDCA_FLTR_'+b.name+'_1__232'', @filter_clause = N''Codemp in (''''766'''') '', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_articleview @publication = N''EMPDCA'', @article = N'''+b.name+''', @view_name = N''EMPDCA_SYNC_'+b.name+'_1__232'', @filter_clause = N''Codemp in (''''766'''')'', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1
exec sp_refreshsubscriptions @publication = N''EMPDCA''
end
'
end
from syscolumns a 
inner join sysobjects b on a.id = b.id
where a.name = 'codemp' and b.xtype = 'U' and b.name not like '%temp%' and b.name not in ('carrega', 'modelo3', 'transacoes') and b.name not like '%2008%' and b.name not like '%2%' and b.name not like '%BKP%' and b.name not like '%results%' and b.name not like '%00%'
and not exists (select * from sysarticles c where b.name = c.name)
order by 1


/*
alter table Baixa_Transitoria add constraint PK_Baixa_Transitoria primary key (Codemp, Numdoc, CodTran, TipLan, Datinc, Datbai, Reg)
go
alter table Transitorias add constraint PK_Transitorias primary key (Codemp, Numdoc, CodTran, TipLan, Datinc, Reg)
go
alter table Saldo_CaixaContabil add constraint PK_Saldo_CaixaContabil primary key (Codemp, Data, CodMod, TipLan)
go
alter table Saldo_BancoContabil add constraint PK_Saldo_BancoContabil primary key (Codemp, Data, Numcon, TipLan)
go
alter table Efetuarcont add constraint PK_Efetuarcont primary key (Codemp, Codigo, Cod)
go
alter table itdterr add constraint PK_itdterr primary key (Codemp, Numnot, Sernot, Tipnot)
go
alter table nfdterr add constraint PK_nfdterr primary key (Codemp, Numnot, Sernot, Tipnot, Codope, Pericm, Codcli, CodMod, Datent)
go
alter table Saldo_CaixaCont add constraint PK_Saldo_CaixaCont primary key (Codemp, Data, CodMod, TipLan)
go
alter table Balanco_Efetuarcont add constraint PK_Balanco_Efetuarcont primary key (Codemp, Codigo, Data, Tiplan)
go
alter table cfgnfe alter column codemp varchar(3) not null
go
alter table CfgNFe add constraint PK_CfgNFe primary key (Codemp)
go
alter table Ciap alter column codemp char(3) not null
go
alter table Ciap add constraint PK_Ciap primary key (Codemp)
go
alter table CIAP_Imob alter column codemp char(3) not null
go
alter table CIAP_Imob add constraint PK_CIAP_Imob primary key (Codemp)
go
alter table Ciap_Mes alter column codemp char(3) not null
go
alter table Ciap_Mes add constraint PK_Ciap_Mes primary key (Codemp)
go
alter table Ciap_Res alter column codemp char(3) not null
go
alter table Ciap_Res add constraint PK_Ciap_Res primary key (Codemp)
go
alter table DuplicataAlinea add constraint PK_DuplicataAlinea primary key (Codemp)
go
alter table ExportaPlanejamento alter column codemp char(3) not null
go
alter table ExportaPlanejamento add constraint PK_ExportaPlanejamento primary key (Codemp)
go
alter table FechaPlanejamento alter column codemp char(3) not null
go
alter table FechaPlanejamento add constraint PK_FechaPlanejamento primary key (Codemp)
go
alter table Historico_Estoque add constraint PK_Historico_Estoque primary key (Codemp, Seq, Numfat)
go
alter table indice add constraint PK_indice primary key (Codemp)
go
alter table Logs alter column codemp char(3) not null
go
alter table Logs add constraint PK_Logs primary key (Codemp)
go
alter table Piores alter column codemp char(3) not null
go
alter table Piores add constraint PK_Piores primary key (Codemp)
go
alter table Regras_itens_log alter column codemp char(3) not null
go
alter table Regras_itens_log add constraint PK_Regras_itens_log primary key (Codemp)
go
alter table Regras_Log alter column codemp char(3) not null
go
alter table Regras_Log add constraint PK_Regras_Log primary key (Codemp)
go
alter table TRef_Soma add constraint PK_TRef_Soma primary key (Codemp)
go
--alter table Proposta add constraint PK_Proposta primary key (CodEmp, NumPro, CodCli, Meses, DatIni)
--go
--alter table Proposta_config add constraint PK_Proposta_Config primary key (CodEmp)
--go
--alter table Proposta_Empresas add constraint PK_Proposta_Empresas primary key (CodEmp)
--go
--alter table Proposta_Investimentos add constraint PK_Proposta_Investimentos primary key (CodEmp,NumPro,CodCli,Meses,DatIni,CodVer,CodInv,CodItem,CodPro)
*/

/*
Sp_Help Nota_Fiscal_Cpl
Sp_Help Caixa

Select 'Alter Table Caixa Drop Constraint '+Name From SysObjects Where (
Name Like '%DF%Caixa%Cc2ant%' or Name Like '%DF%Caixa%Pgpro2a%' or 
Name Like '%DF%Caixa%Pgpro2e%'or Name Like '%DF%Caixa%Pgpro2s%' or
Name Like '%DF%Caixa%Pgpro2f%')

Alter Table Caixa Drop Constraint DF__Caixa__Pgpro2a__071D7872
Alter Table Caixa Drop Constraint DF__Caixa__Pgpro2e__08119CAB
Alter Table Caixa Drop Constraint DF__Caixa__Pgpro2s__0905C0E4
Alter Table Caixa Drop Constraint DF__Caixa__Pgpro2f__09F9E51D


Alter Table Caixa Drop Column Pgpro2a
Alter Table Caixa Drop Column Pgpro2e
Alter Table Caixa Drop Column Pgpro2f
Alter Table Caixa Drop Column Pgpro2s

Alter Table Caixa Add Pgpro2a Decimal(18,2)
Alter Table Caixa Add Pgpro2e Decimal(18,2)
Alter Table Caixa Add Pgpro2s Decimal(18,2)
Alter Table Caixa Add Pgpro2f Decimal(18,2)

Alter Table Caixa Add Constraint DF__Caixa__Pgpro2a__071D7872 Default((0)) For Pgpro2a
Alter Table Caixa Add Constraint DF__Caixa__Pgpro2e__08119CAB Default((0)) For Pgpro2e
Alter Table Caixa Add Constraint DF__Caixa__Pgpro2s__0905C0E4 Default((0)) For Pgpro2s
Alter Table Caixa Add Constraint DF__Caixa__Pgpro2f__09F9E51D Default((0)) For Pgpro2f

*/
