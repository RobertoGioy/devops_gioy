--Verifica se tem alguma tabela replicada com status 16

select status,* from sysarticles where status in (16)
select status,* from sysarticles where name in ('mov_estoque','mov_estoque2')


-- Corrige o status
declare	@artigos33	VARCHAR(MAX), @COMANDO33 VARCHAR(MAX)

DECLARE @var33 VARCHAR(MAX)

DECLARE CURSOR33 CURSOR FOR
SELECT COMANDO FROM (
SELECT	DISTINCT C.NAME,'H'AS ORDEM,'SP_CHANGEARTICLE @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''', @property = ''status''  , @value = ''parameters'''AS COMANDO 
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE C.NAME = 'REPL_DC' AND B.DEST_DB <> 'VIRTUAL'

)TABELA	WHERE COMANDO <> ''	
ORDER BY ORDEM, NAME

OPEN CURSOR33
FETCH NEXT FROM CURSOR33 INTO @var33
WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC (@var33)
	FETCH NEXT FROM CURSOR33 INTO @var33
END
CLOSE CURSOR33
DEALLOCATE CURSOR33