--Use Distribution

Select * From MSsubscriptions A
Inner Join MSpublications B On A.Publication_Id=B.Publication_Id And A.Publisher_Db=B.Publisher_Db
Inner Join Sl2000Act.Dbo.sysarticles C On A.Article_Id=C.ArtId
Where C.Name='OpcFat' And A.Publisher_Db='SL2000ACT'