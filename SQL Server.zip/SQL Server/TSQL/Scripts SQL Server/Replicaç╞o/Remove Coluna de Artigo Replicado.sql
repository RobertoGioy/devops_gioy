sp_repldropcolumn 
    [ @source_object = ] 'Lancont' ,    
        [ @column = ] 'Teste'
        
EXEC sp_repladdcolumn 'Mov_Faturas','CodNivel','Int'