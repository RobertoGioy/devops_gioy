-- SNAPHOT			- CATEGORIA 15
-- LOGREADER		- CATEGORIA 13
-- SINCRONIZATION	- CATEGORIA 10


-- DESABILITANDO TODOS OS JOBS DE SNAPSHOT
DECLARE @VAR1 SYSNAME
DECLARE CURSOR1 CURSOR FOR

select name from msdb.dbo.sysjobs where category_id = 15 order by name

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1
WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT 'Desabilitando Job  --> '+@VAR1
	EXEC ('MSDB.DBO.SP_UPDATE_JOB @job_name = ['+ @VAR1 +'] , @enabled = 0')
	FETCH NEXT FROM CURSOR1 INTO @VAR1
END
CLOSE CURSOR1
DEALLOCATE CURSOR1

-- CONFIGURANDO OS SCHEDULES DOS JOBS DE SNAPSHOT
DECLARE @VAR1 SYSNAME, @VAR2 SYSNAME
DECLARE CURSOR1 CURSOR FOR

select s2.name, s.schedule_id from msdb.dbo.sysjobschedules s inner join msdb.dbo.sysjobs s2 on s.job_id = s2.job_id where s2.category_id = 15 order by s2.name

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1,@VAR2
WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT 'Configurando Job  --> '+@VAR1
	EXEC ('msdb.dbo.sp_update_schedule @schedule_id			 = ['+ @VAR2 +'] , 
									   @enabled				 = 0,				-- Desabilitado
									   @freq_type			 = 4,				-- Diariamente
									   @freq_interval		 = 1,				-- Dias
									   @freq_subday_type	 = 4,				-- Minutos
									   @freq_subday_interval = 5,				-- Intervalos
									   @active_start_time	 = 0,				-- Hora Inicial
									   @active_end_time		 = 235959,			-- Hora Final
									   @active_start_date	 = 20090921			-- Data Inicial')
	FETCH NEXT FROM CURSOR1 INTO @VAR1,@VAR2
END
CLOSE CURSOR1
DEALLOCATE CURSOR1



-- HABILITANDO TODOS OS JOBS DE LOGREADER E SINCRONIZATION

DECLARE @VAR1 SYSNAME
DECLARE CURSOR1 CURSOR FOR

select name from msdb.dbo.sysjobs where category_id in (10,13) order by name

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1
WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT 'Habilitando Job  --> '+@VAR1
	EXEC ('MSDB.DBO.SP_UPDATE_JOB @job_name = ['+ @VAR1 +'] , @enabled = 1')
	FETCH NEXT FROM CURSOR1 INTO @VAR1
END
CLOSE CURSOR1
DEALLOCATE CURSOR1


-- CONFIGURANDO OS SCHEDULES DOS JOBS DE LOGREADER
DECLARE @VAR1 SYSNAME, @VAR2 SYSNAME
DECLARE CURSOR1 CURSOR FOR

select s2.name, s.schedule_id from msdb.dbo.sysjobschedules s inner join msdb.dbo.sysjobs s2 on s.job_id = s2.job_id where s2.category_id = 13 order by s2.name

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1,@VAR2
WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT 'Configurando Job  --> '+@VAR1
	EXEC ('msdb.dbo.sp_update_schedule @schedule_id			 = ['+ @VAR2 +'] , 
									   @enabled				 = 1,				-- Habilitado
									   @freq_type			 = 4,				-- Diariamente
									   @freq_interval		 = 1,				-- Dias
									   @freq_subday_type	 = 4,				-- Minutos
									   @freq_subday_interval = 2,				-- Intervalos
									   @active_start_time	 = 0,				-- Hora Inicial
									   @active_end_time		 = 235959,			-- Hora Final
									   @active_start_date	 = 20090921			-- Data Inicial')
	FETCH NEXT FROM CURSOR1 INTO @VAR1,@VAR2
END
CLOSE CURSOR1
DEALLOCATE CURSOR1


-- DC			- DCBSRVBDSQL02		-   02 Minutos
-- CONTIG�NCIA	-					-	02 Minutos
-- NFE			- FRSRVBDSQL04		-	02 Minutos
-- CADASTROS	- DCBSRVBDSQL01		-	10 Minutos
-- FRDCA		- FRSRVBDSQL02		-	30 Minutos


-- CONFIGURANDO OS SCHEDULES DOS JOBS DE SINCRONIZATION 
DECLARE @VAR1 SYSNAME, @VAR2 SYSNAME
DECLARE CURSOR1 CURSOR FOR

select s2.name, s.schedule_id from msdb.dbo.sysjobschedules s inner join msdb.dbo.sysjobs s2 on s.job_id = s2.job_id where s2.category_id = 10 order by s2.name

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1,@VAR2
WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT 'Configurando Job  --> '+@VAR1
	EXEC ('msdb.dbo.sp_update_schedule @schedule_id			 = ['+ @VAR2 +'] , 
									   @enabled				 = 1,				-- Habilitado
									   @freq_type			 = 4,				-- Diariamente
									   @freq_interval		 = 1,				-- Dias
									   @freq_subday_type	 = 4,				-- Minutos
									   @freq_subday_interval = 2,				-- Intervalos
									   @active_start_time	 = 0,				-- Hora Inicial
									   @active_end_time		 = 235959,			-- Hora Final
									   @active_start_date	 = 20090921			-- Data Inicial')
	FETCH NEXT FROM CURSOR1 INTO @VAR1,@VAR2
END
CLOSE CURSOR1
DEALLOCATE CURSOR1

-- CONFIGURANDO OS SCHEDULES DOS JOBS DE SINCRONIZATION DE CADASTROS
DECLARE @VAR1 SYSNAME, @VAR2 SYSNAME
DECLARE CURSOR1 CURSOR FOR

select s2.name, s.schedule_id from msdb.dbo.sysjobschedules s inner join msdb.dbo.sysjobs s2 on s.job_id = s2.job_id where s2.category_id = 10 and s2.name like ('%DCBSRVBDSQL01%')order by s2.name

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1,@VAR2
WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT 'Configurando Job  --> '+@VAR1
	EXEC ('msdb.dbo.sp_update_schedule @schedule_id			 = ['+ @VAR2 +'] , 
									   @enabled				 = 1,				-- Habilitado
									   @freq_type			 = 4,				-- Diariamente
									   @freq_interval		 = 1,				-- Dias
									   @freq_subday_type	 = 4,				-- Minutos
									   @freq_subday_interval = 10,				-- Intervalos
									   @active_start_time	 = 0,				-- Hora Inicial
									   @active_end_time		 = 235959,			-- Hora Final
									   @active_start_date	 = 20090921			-- Data Inicial')
	FETCH NEXT FROM CURSOR1 INTO @VAR1,@VAR2
END
CLOSE CURSOR1
DEALLOCATE CURSOR1

-- CONFIGURANDO OS SCHEDULES DOS JOBS DE SINCRONIZATION DE FRDCA
DECLARE @VAR1 SYSNAME, @VAR2 SYSNAME
DECLARE CURSOR1 CURSOR FOR

select s2.name, s.schedule_id from msdb.dbo.sysjobschedules s inner join msdb.dbo.sysjobs s2 on s.job_id = s2.job_id where s2.category_id = 10 and s2.name like ('%FRSRVBDSQL02%')order by s2.name

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1,@VAR2
WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT 'Configurando Job  --> '+@VAR1
	EXEC ('msdb.dbo.sp_update_schedule @schedule_id			 = ['+ @VAR2 +'] , 
									   @enabled				 = 1,				-- Habilitado
									   @freq_type			 = 4,				-- Diariamente
									   @freq_interval		 = 1,				-- Dias
									   @freq_subday_type	 = 4,				-- Minutos
									   @freq_subday_interval = 30,				-- Intervalos
									   @active_start_time	 = 0,				-- Hora Inicial
									   @active_end_time		 = 235959,			-- Hora Final
									   @active_start_date	 = 20090921			-- Data Inicial')
	FETCH NEXT FROM CURSOR1 INTO @VAR1,@VAR2
END
CLOSE CURSOR1
DEALLOCATE CURSOR1