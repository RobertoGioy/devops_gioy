
SET QUOTED_IDENTIFIER OFF 

create table #temp (Servidor Varchar(max), Base Varchar(max), empresa Varchar(max))
create table #temp1 (Base1 Varchar(max))

DECLARE @base sysname, @reg int, @tot int, @CMD1 VARCHAR(MAX), @CMD2 VARCHAR(MAX), @CMD3 VARCHAR(MAX)
, @CMD4 VARCHAR(MAX), @CMD5 VARCHAR(MAX), @CMD6 VARCHAR(MAX), @CMD7 VARCHAR(MAX), @CMD8 VARCHAR(MAX)


SET @CMD1 = 
"
disable trigger all on database
"

SET @CMD2 = 
"
declare	@ARTIGOS	VARCHAR(MAX), @COMANDO	VARCHAR(MAX)
	
DECLARE @VAR2 VARCHAR(MAX)

set @artigos = 'empresas'

DECLARE CURSOR2 CURSOR FOR

SELECT COMANDO FROM (
SELECT	DISTINCT C.NAME,'C'AS ORDEM,CASE WHEN A.FILTER <> 0 THEN 		
		'SP_ADDARTICLE @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''', @source_owner = N''DBO'', @source_object = N'''+A.NAME+
		''', @type = N''LOGBASED'', @description = N'''', @creation_script = N'''', @pre_creation_cmd = N''DELETE'', @identityrangemanagementoption = N''MANUAL'', @destination_table = N'''+A.DEST_TABLE+
        ''', @destination_owner= N''DBO'', @vertical_partition = N''FALSE'', @ins_cmd = N'''+A.INS_CMD+''', @del_cmd = N'''+A.DEL_CMD+
		''', @upd_cmd = N'''+A.UPD_CMD+''', @filter_clause = N'''+REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+'''' 
		ELSE 
		'SP_ADDARTICLE @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''', @source_owner = N''DBO'', @source_object = N'''+A.NAME+
		''', @type = N''LOGBASED'', @description = N'''', @creation_script = N'''', @pre_creation_cmd = N''DELETE'', @identityrangemanagementoption = N''MANUAL'', @destination_table = N'''+A.DEST_TABLE+
        ''', @destination_owner= N''DBO'', @vertical_partition = N''FALSE'', @ins_cmd = N'''+A.INS_CMD+''', @del_cmd = N'''+A.DEL_CMD+
		''', @upd_cmd = N'''+A.UPD_CMD+'''' END AS COMANDO
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE A.NAME = @ARTIGOS
UNION
SELECT	DISTINCT C.NAME,'D'AS ORDEM,ISNULL('SP_ARTICLEFILTER @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''', @filter_name = N'''+E.NAME+ ''', @filter_clause = N'''+
		REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+''', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1','')AS COMANDO 
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE A.NAME = @ARTIGOS
UNION
SELECT	DISTINCT C.NAME,'E'AS ORDEM,ISNULL('SP_ARTICLEVIEW @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''', @view_name = N'''+D.NAME+ ''', @filter_clause = N'''+
		REPLACE(CONVERT(VARCHAR(MAX),A.FILTER_CLAUSE),'''','''''')+''', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1','')AS COMANDO 
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE A.NAME = @ARTIGOS
UNION
SELECT	DISTINCT C.NAME,'F'AS ORDEM,'SP_ADDSUBSCRIPTION @publication = N'''+C.NAME+''', @subscriber = N'''+B.SRVNAME+''', @destination_db = N'''+B.DEST_DB+
		''', @subscription_type = N''PUSH'', @sync_type = N''AUTOMATIC'', @article = N''ALL'', @update_mode = N''READ ONLY'', @subscriber_type = 0'AS COMANDO 
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE A.NAME = @ARTIGOS

)TABELA	WHERE COMANDO <> ''	
ORDER BY ORDEM, NAME

OPEN CURSOR2
FETCH NEXT FROM CURSOR2 INTO @VAR2
WHILE @@FETCH_STATUS = 0
BEGIN
    set @var2 = replace(@var2,@artigos,'Form_PagtoClientes_Analise')
  EXEC(@VAR2)
	
	FETCH NEXT FROM CURSOR2 INTO @VAR2
END
CLOSE CURSOR2
DEALLOCATE CURSOR2
"


SET @CMD3 = 
"
enable trigger all on database
"

SET @CMD4 = 
"
DECLARE @VAR1 SYSNAME
DECLARE CURSOR1 CURSOR FOR

select name from msdb.dbo.sysjobs where category_id = 15 and not name like '%NFE%' and not name like '%cadastros%'

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1
WHILE @@FETCH_STATUS = 0
BEGIN
	EXEC ('MSDB.DBO.SP_start_JOB @job_name = ['+ @VAR1 +'] ')
	FETCH NEXT FROM CURSOR1 INTO @VAR1
END
CLOSE CURSOR1
DEALLOCATE CURSOR1
"


set @tot = (select count(name) as Reg from sys.sysdatabases where not name in ('FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%'))

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where not name in ('FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%')) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
	IF not (select OBJECT_ID ('Mov_Estoque2')) IS NULL
	if (select count(*) from sysobjects o inner join syscolumns c on o.id = c.id where o.name = 'Config' and c.name = 'Terc' ) > 0
	exec('if (select count(*) from config where terc <> ''C'') > 0
		INSERT into #temp1 SELECT ""[" + @base + "]"" ')
	")
	set @reg = @reg + 1
	end

update #temp1 set base1 = replace(replace(base1,'[',''),']','')


set @tot = (select count(name) as Reg from sys.sysdatabases where name in (select base1 from #Temp1) and not name in ('FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%'))

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where name in (select base1 from #Temp1) and not name in ('FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%')) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
		IF not (select OBJECT_ID ('sysarticles')) IS NULL and not (select OBJECT_ID ('mov_estoque2')) IS NULL 
			begin
			EXEC (""" + @CMD1 + """) 
			IF not (select OBJECT_ID ('Form_PagtoClientes_Analise')) IS NULL 
				begin
					if (select count(*) from sysarticles where name = 'Form_PagtoClientes_Analise') = 0
						begin
						begin try
							EXEC (""" + @CMD2 + """) 
      						INSERT into #temp SELECT distinct @@servername as Servidor, ""[" + @base + "]"" as Base, 'Form_PagtoClientes_Analise' as empresa
						end try
						begin catch
		   					INSERT into #temp SELECT distinct '(' + ERROR_MESSAGE() +') ' + @@servername as Servidor, ""[" + @base + "]"" as Base, 'Form_PagtoClientes_Analise' as empresa
						end catch
						end
				end	
			EXEC (""" + @CMD3 + """) 
			end	
	")
	
	set @reg = @reg + 1
	end

EXEC (@CMD4) 	

SELECT Servidor, Base, empresa FROM #temp
