select * 
from (select b.publication,b.publisher_db,b.subscriber_db,sum(a.UndelivCmdsInDistDB)as transacoes 
	  from distribution.dbo.MSdistribution_status  a
	  inner join distribution.dbo.MSdistribution_agents b on a.agent_id = b.id
	  where UndelivCmdsInDistDB <> 0 and b.subscriber_db <>'virtual'
      group by b.publication,b.publisher_db,b.subscriber_db) as transacoes 
where transacoes >3000
order by transacoes desc

/*
select * 
from (select b.publication,b.publisher_db,b.subscriber_db,sum(a.UndelivCmdsInDistDB)as transacoes 
	  from DCSQL01.dbo.MSdistribution_status  a
	  inner join DCSQL01.dbo.MSdistribution_agents b on a.agent_id = b.id
	  where UndelivCmdsInDistDB <> 0 and b.subscriber_db <>'virtual'
      group by b.publication,b.publisher_db,b.subscriber_db
      Union
	  select b.publication,b.publisher_db,b.subscriber_db,sum(a.UndelivCmdsInDistDB)as transacoes 
	  from DCSQL05.dbo.MSdistribution_status  a
	  inner join DCSQL05.dbo.MSdistribution_agents b on a.agent_id = b.id
	  where UndelivCmdsInDistDB <> 0 and b.subscriber_db <>'virtual'
      group by b.publication,b.publisher_db,b.subscriber_db) as transacoes 
where transacoes >3000
order by transacoes desc

select b.publication,d.article,c.publisher_db,sum(a.UndelivCmdsInDistDB)as transacoes from distribution.dbo.MSdistribution_status  a
inner join distribution.dbo.MSdistribution_agents b on a.agent_id = b.id
inner join distribution.dbo.MSpublications c on b.publication = c.publication
inner join distribution.dbo.MSarticles d on a.article_id = d.article_id and c.publication_id = d.publication_id
where UndelivCmdsInDistDB <> 0 and b.subscriber_db <>'virtual'
group by b.publication,d.article,c.publisher_db
order by b.publication,c.publisher_db
*/

--EXEC dbo.sp_MShistory_cleanup @history_retention = 48
--EXEC dbo.sp_MSdistribution_cleanup @min_distretention = 0, @max_distretention = 8760

