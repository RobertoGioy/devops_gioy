SET QUOTED_IDENTIFIER OFF 

create table #temp (Servidor Varchar(max), Base Varchar(max), empresa Varchar(max))

DECLARE @base sysname, @reg int, @tot int, @CMD1 VARCHAR(MAX), @CMD2 VARCHAR(MAX), @CMD3 VARCHAR(MAX)
, @CMD4 VARCHAR(MAX), @CMD5 VARCHAR(MAX), @CMD6 VARCHAR(MAX), @CMD7 VARCHAR(MAX), @CMD8 VARCHAR(MAX)


SET @CMD1 = 
"
declare	@ARTIGOS	VARCHAR(MAX), @COMANDO	VARCHAR(MAX)
	
DECLARE @VAR2 VARCHAR(MAX)

DECLARE CURSOR2 CURSOR FOR

SELECT COMANDO FROM (
SELECT	DISTINCT C.NAME,'B'AS ORDEM,'SP_DROPSUBSCRIPTION @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''',@subscriber = N'''+B.SRVNAME+''''+''AS COMANDO
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE A.NAME IN ('IMOB_ORIGEMBEM_','IMOB_PRIDENTBEM_','IMOB_PRNATBCCRED_','IMOB_STCOF_','IMOB_STPIS_','IMOB_TIPOBAIXA_','IMOB_USOBEM_')
UNION
SELECT	DISTINCT C.NAME,'C'AS ORDEM,'SP_DROPARTICLE @publication = N'''+C.NAME+''', @article = N'''+A.NAME+''''+''AS COMANDO
FROM SYSARTICLES A	LEFT JOIN SYSOBJECTS D ON A.FILTER = D.ID LEFT JOIN SYSOBJECTS E ON A.SYNC_OBJID = E.ID 
INNER JOIN SYSSUBSCRIPTIONS B ON A.ARTID = B.ARTID INNER JOIN SYSPUBLICATIONS C ON A.PUBID = C.PUBID 
WHERE A.NAME IN ('IMOB_ORIGEMBEM_','IMOB_PRIDENTBEM_','IMOB_PRNATBCCRED_','IMOB_STCOF_','IMOB_STPIS_','IMOB_TIPOBAIXA_','IMOB_USOBEM_')


)TABELA	WHERE COMANDO <> ''	
ORDER BY ORDEM, NAME

OPEN CURSOR2
FETCH NEXT FROM CURSOR2 INTO @VAR2
WHILE @@FETCH_STATUS = 0
BEGIN

  EXEC(@VAR2)
	
	FETCH NEXT FROM CURSOR2 INTO @VAR2
END
CLOSE CURSOR2
DEALLOCATE CURSOR2
"



set @tot = (select count(name) as Reg from sys.sysdatabases where not name in ('FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%')and not name like ('T[_]%'))

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where not name in ('FRDCA','DC','EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%')and not name like ('T[_]%')) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
		IF not (select OBJECT_ID ('sysarticles')) IS NULL  
			begin
			EXEC (""" + @CMD1 + """) 
			end	
	")
	
	set @reg = @reg + 1
	end
	

SELECT Servidor, Base, empresa FROM #temp
