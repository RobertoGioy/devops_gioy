SET QUOTED_IDENTIFIER OFF 
DECLARE @base SYSNAME, @Reg INT, @Tot INT
SET @Tot = (SELECT count(name) as Reg FROM Sys.Sysdatabases )
SET @Reg = 1
WHILE @Reg <= @Tot
BEGIN
		SET @base = (SELECT name FROM (SELECT ROW_NUMBER() OVER (ORDER BY name) AS Reg, name FROM Sys.Sysdatabases ) as t where t.reg  = @Reg)
		EXEC ("
				DBCC UPDATEUSAGE('"+ @base +"')
				")
		SET @Reg = @Reg + 1
END


GO


declare @table2  sysname
declare reg2 cursor for
SELECT RTRIM(B.NAME) + '.' + RTRIM(A.NAME) FROM SYSOBJECTS A
INNER JOIN SYS.SCHEMAS B ON A.UID=B.SCHEMA_ID
WHERE A.XTYPE = 'U'  AND NOT A.NAME LIKE '%TEMP%' 

open reg2 
fetch next  from reg2 into  @table2 
while @@fetch_status = 0 
begin
		--exec ('Alter Index All On ' +@table2 + ' Rebuild With (Online = On,Fillfactor = 90)')
        exec ('UPDATE STATISTICS ' +@table2 +'')
        exec ('DBCC dbreindex ([' +@table2 + '],'''',90)')
        print'Tabela Reindexada ---->  [' +@table2 +']' + char(10)
fetch next from reg2 into @table2 
end 
close reg2
deallocate reg2


