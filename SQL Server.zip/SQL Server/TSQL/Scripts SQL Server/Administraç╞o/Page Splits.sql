/******************************************************************************

	Autor: Luciano Caixeta Moreira
	Data: 11/08/2006
	Descri��o: Verifica o comportamento das tabelas e �ndices quando page splits acontecem.

	Hist�rico:
	-

******************************************************************************/

/*
	0) Cria o banco de dados Inside
*/
USE MASTER
GO

IF EXISTS (SELECT * FROM SYSDATABASES WHERE [Name] = 'Inside')
BEGIN
	DROP DATABASE Inside
END
GO

CREATE DATABASE Inside
ON
(
Name = 'Inside_data',
FileName = 'C:\Program Files\Microsoft SQL Server\MSSQL$INST2000_01\Data\Inside_data.mdf',
Size = 10MB,
FileGrowth = 5MB,
MaxSize = UNLIMITED
)
LOG ON
(
Name = 'Inside_log',
FileName = 'C:\Program Files\Microsoft SQL Server\MSSQL$INST2000_01\Data\Inside_log.mdf',
Size = 5MB,
FileGrowth = 3MB,
MaxSize = UNLIMITED
)
GO

/*
	1 - PRIMEIRA ETAPA
	==============================================================================

	Demonstrar que o �ndice clusterizado mant�m os registros ordenados de acordo com a sua chave e que 
dependendo da forma que os registros s�o inseridos, isto pode causar um alto n�mero de page splits, gerando
uma fragmenta��o desnecess�ria na tabela.

*/

/*
	1.1) Cria nova tabela para verificar page splits
*/

USE Inside
go

IF EXISTS (SELECT [Id] FROM SysObjects WHERE Name = 'PageSplit' and Xtype = 'U')
BEGIN
	DROP TABLE PageSplit
END

CREATE TABLE PageSplit (
	Code int NOT NULL,
	Column2 char(3950) NOT NULL)

CREATE UNIQUE CLUSTERED INDEX PageSplit_ind on PageSplit(Code)
GO

/*
	1.2) Os pr�ximos passos v�o mostrar a inser��o de 4 registros, onde veremos um page split e
		analisaremos o padr�o de aloca��o do SQL Server.
*/

INSERT INTO PageSplit VALUES(1, 'SQL Server')
GO

--	2 p�ginas, uma � a raiz do �ndice clusterizado e a outra � a primeira p�gina do n�vel folha.
DBCC ExtentInfo (Inside, 'PageSplit', 1)
GO

--	Inside database id = 7
SELECT * FROM Master..sysdatabases
GO

DBCC TRACEON (3604)

--	Index page (m_type = 2)
DBCC PAGE (7, 1, 15, 2)
--	Data page (m_type = 1)
DBCC PAGE (7, 1, 28, 3)

INSERT INTO PageSplit VALUES(99, 'SQL Server')
go

-- 2 p�ginas, uma � a raiz do �ndice clusterizado e a outra � a primeira p�gina do n�vel folha.
DBCC ExtentInfo (Inside, 'PageSplit', 1)
-- 2 registros (1 e 99)
DBCC PAGE (7, 1, 28, 3)
GO

-- At� o momento, nada de fragmenta��o l�gica
DBCC SHOWCONTIG ('PageSplit', 1)
GO

/*
	Esta inser��o causa um page split, pois a p�gina 28 n�o possui espa�o para conter os 3 registros.
	Como o �ndice clusterizado deve manter os registros no n�vel folha ordenados de acordo com suas chaves
(no nosso caso somente o campo Code), o registro 99 ser� colocado em uma nova p�gina (29) enquanto os
registros 1 e 2 ficar�o na p�gina original (28).
*/
INSERT INTO PageSplit VALUES(2, 'SQL Server')
GO

/*
	3 p�ginas, uma � a raiz do �ndice clusterizado. As outras duas pertencem ao n�vel folha.
	1 p�gina com registros 1 e 2
	1 p�gina com registro 99
*/
DBCC ExtentInfo (Inside, 'PageSplit', 1)
GO

-- Registros 1 e 2
DBCC PAGE (7, 1, 28, 3)
-- Registro 99
DBCC PAGE (7, 1, 29, 3)
GO

-- At� o momento, nada de fragmenta��o l�gica
DBCC SHOWCONTIG ('PageSplit', 1)
GO

/*
	Ao inv�s de colocar o registro na p�gina 29 (que continha espa�o para suportar uma inser��o), o
	SQL Server preferiu colocar o registro em uma nova p�gina.
*/
INSERT INTO PageSplit VALUES(98, 'SQL Server')
GO

/*
	3 p�ginas, uma � a raiz do �ndice clusterizado. As outras duas pertencem ao n�vel folha.
	1 p�gina com registros 1 e 2
	1 p�gina com registro 99
	1 p�gina com registro 98
*/
DBCC ExtentInfo (Inside, 'PageSplit', 1)
GO

/*
	Registros 1 e 2
	m_prevPage = (0:0) (Est� � a primeira p�gina do �ndice clusterizado, ent�o n�o existe prevPage)
	m_nextPage = (1:30)  (refere-se ao registro 98, que est� em uma p�gina fisicamente posterior que 
		a p�gina do registro 99)
*/
DBCC PAGE (7, 1, 28, 3)
GO

/*
	Registro 98

	m_prevPage = (1:28) (Refere-se a p�gina com os registros 1 e 2)
	m_nextPage = (1:29) (refere-se ao registro 99, que fisicamente est� em uma p�gina anterior)
*/
DBCC PAGE (7, 1, 30, 3)
GO

/*
	Registro 99

	m_prevPage = (1:30) (Refere-se a p�gina com o registro 98)
	m_nextPage = (0:0) (Esta � a �ltima p�gina do �ndice clusterizado, pois n�o existe nextPage)
*/
DBCC PAGE (7, 1, 29, 3)
GO

/*
	Como a ordena��o l�gica das p�ginas est� diferente da ordena��o f�sica, temos uma fragmenta��o l�gica. 
*/
DBCC SHOWCONTIG ('PageSplit', 1)
GO

TRUNCATE TABLE PageSplit
GO

/*
	1.3) Coloque no performance monitor o contador Page Splits/sec e execute o script abaixo.
	Como s�o feitas inser��es no in�cio e no fim da tabela, v�rios page splits s�o necess�rios para manter
o �ndice clusterizado ordenado.
*/

SET NOCOUNT ON

DECLARE @contador INT
SET @contador = 1
WHILE (@contador < 50)
BEGIN
	INSERT INTO PageSplit VALUES(@contador, 'SQL Server')
	INSERT INTO PageSplit VALUES(100 - @contador, 'SQL Server')
	SET @contador = @contador + 1
END

SET NOCOUNT OFF
GO

/*
	Muitos page splits por segundo podem degradar a performance das opera��es de inser��o e atualiza��o dos 
registros, portanto deve-se prestar aten��o em dois pontos:

	- Fillfactor do seus �ndices.
	- Ordena��o do �ndice clusterizado.

	Infelizmente n�o existe uma receita de bolo de como configurar suas tabelas, mas nada como conhecer
a forma como o SQL Server trabalha para conseguir uma melhor performance.
*/