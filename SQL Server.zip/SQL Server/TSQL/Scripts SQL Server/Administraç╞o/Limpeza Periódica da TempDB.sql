-- Lista as sess�es ativas na TEMPDB
select * from sys.dm_db_session_space_usage d inner join sys.dm_exec_sessions s on d.session_id = s.session_id left join sys.dm_exec_requests r on r.session_id = s.session_id left join sys.dm_tran_session_transactions t on d.session_id = t.session_id  where d.user_objects_alloc_page_count > 0 

-- Lista os arquivos 
use tempdb
go
select * from sys.sysfiles

-- Derruba as sess�es ativas na TEMPDB
declare @spid varchar(5)

DECLARE CURSOR1 CURSOR FOR

Select A.session_id
FROM sys.dm_db_session_space_usage A
JOIN sys.dm_exec_sessions B  ON A.session_id = B.session_id
JOIN sys.dm_exec_connections C ON C.session_id = B.session_id
CROSS APPLY sys.dm_exec_sql_text(C.most_recent_sql_handle) As D
WHERE A.session_id > 0
--and (user_objects_alloc_page_count + internal_objects_alloc_page_count)*1.0/128 > 100 -- Ocupam mais de 100 MB

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @spid
WHILE @@FETCH_STATUS = 0
	BEGIN
	exec ('kill ' + @spid)
	FETCH NEXT FROM CURSOR1 INTO @spid
	END
CLOSE CURSOR1
DEALLOCATE CURSOR1	


Go
DBCC SHRINKDATABASE(TEMPDB)
Go
DBCC FREEPROCCACHE 
Go
DBCC FREESYSTEMCACHE ('ALL')
GO
-- Limpa o Log
DBCC SHRINKFILE (templog, 0)
go
-- Limpa Data
DBCC SHRINKFILE (tempdev, 0)
go


