use master

CREATE DATABASE FNDBLogTest;
go
USE FNDBLogTest;
GO

CREATE TABLE ProdTable (c1 INT IDENTITY, c2 DATETIME DEFAULT GETDATE (), c3 CHAR (25) DEFAULT 'a');
GO 

INSERT INTO ProdTable DEFAULT VALUES;
GO 10000

BACKUP DATABASE FNDBLogTest TO DISK = 'c:\FNDBLogTest_Full.bak' WITH INIT;
GO
BACKUP LOG FNDBLogTest TO DISK = 'c:\FNDBLogTest_Log1.bak' WITH INIT;
GO 

-- 36900
select count(1) from FNDBLogTest.dbo.ProdTable

delete top (10) from FNDBLogTest.dbo.ProdTable

BACKUP LOG FNDBLogTest TO DISK = 'c:\FNDBLogTest_Log2.bak' WITH INIT;
GO 

--36890
select count(1) from FNDBLogTest.dbo.ProdTable

delete top (10) from FNDBLogTest.dbo.ProdTable

BACKUP LOG FNDBLogTest TO DISK = 'c:\FNDBLogTest_Log3.bak' WITH INIT;
GO 

-- 36880
select count(1) from FNDBLogTest.dbo.ProdTable

-- executa 1 vez
RESTORE DATABASE FNDBLogTest2
    FROM DISK = 'c:\FNDBLogTest_Full.bak'
    WITH MOVE 'FNDBLogTest' TO 'c:\FNDBLogTest2.mdf',
    MOVE 'FNDBLogTest_log' TO 'c:\FNDBLogTest2_log.ldf',
    REPLACE, RECOVERY;
GO 

-- restaura base em Standby
RESTORE DATABASE FNDBLogTest2  
FROM  DISK = N'c:\FNDBLogTest_Full.bak' 
WITH  FILE = 1, 
REPLACE, 
STANDBY = N'C:\ROLLBACK_UNDO_FNDBLogTest.BAK'

-- 36920
select count(1) from FNDBLogTest2.dbo.ProdTable


RESTORE LOG FNDBLogTest2
    FROM DISK = 'c:\FNDBLogTest_Log1.bak'
    WITH REPLACE, STOPBEFOREMARK  = 'lsn:99:761:1', 
STANDBY = N'C:\ROLLBACK_UNDO_FNDBLogTest.BAK'
GO 

-- 36920
select count(1) from FNDBLogTest2.dbo.ProdTable

RESTORE LOG FNDBLogTest2
    FROM DISK = 'c:\FNDBLogTest_Log2.bak'
    WITH REPLACE, STOPBEFOREMARK  = 'lsn:99:761:1', 
STANDBY = N'C:\ROLLBACK_UNDO_FNDBLogTest.BAK'
GO 

-- 36890
select count(1) from FNDBLogTest2.dbo.ProdTable


RESTORE LOG FNDBLogTest2
    FROM DISK = 'c:\FNDBLogTest_Log3.bak'
    WITH REPLACE, STOPBEFOREMARK  = 'lsn:99:761:1', 
STANDBY = N'C:\ROLLBACK_UNDO_FNDBLogTest.BAK'
GO 

-- 36880
select count(1) from FNDBLogTest2.dbo.ProdTable


RESTORE DATABASE FNDBLogTest2 WITH RECOVERY;


----------------------------------------------------
DECLARE @LSN NVARCHAR(46)
DECLARE @LSN_HEX NVARCHAR(25)
DECLARE @tbl TABLE (id INT identity(1,1), i VARCHAR(10))
DECLARE @stmt VARCHAR(256)

SET @LSN = '00000063:000002f9:0001'
PRINT @LSN

SET @stmt = 'SELECT CAST(0x' + SUBSTRING(@LSN, 1, 8) + ' AS INT)'
INSERT @tbl EXEC(@stmt)
SET @stmt = 'SELECT CAST(0x' + SUBSTRING(@LSN, 10, 8) + ' AS INT)'
INSERT @tbl EXEC(@stmt)
SET @stmt = 'SELECT CAST(0x' + SUBSTRING(@LSN, 19, 4) + ' AS INT)'
INSERT @tbl EXEC(@stmt)

SET @LSN_HEX =
(SELECT i FROM @tbl WHERE id = 1) + ':' + (SELECT i FROM @tbl WHERE id = 2) + ':' + (SELECT i FROM @tbl WHERE id = 3)
PRINT @LSN_HEX

-----------------------------------------------------

SELECT
    [Current LSN],
    [Operation],
    [Context],
    [Transaction ID],
    [Description]
FROM fn_dblog (NULL, NULL),
    (SELECT [Transaction ID] AS tid FROM fn_dblog (NULL, NULL) WHERE [Transaction Name] LIKE '%Delete%') fd
WHERE [Transaction ID] = fd.tid;
GO 

----------------------------------------------------

SELECT * FROM fn_dump_dblog (
    NULL, NULL, 'DISK', 1, 'c:\FNDBLogTest_Log2.bak',
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT) where [transaction name] like '%delete%';

----------------------------------------------------

SELECT
    [Current LSN],
    [Operation],
    [Context],
    [Transaction ID],
    [Description]
FROM fn_dump_dblog (
    NULL, NULL, 'DISK', 1, 'c:\FNDBLogTest_Log2.bak',
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
    DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT),
    (SELECT [Transaction ID] AS tid
     FROM fn_dump_dblog (
         NULL, NULL, 'DISK', 1, 'c:\FNDBLogTest_Log2.bak',
         DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
         DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
         DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
         DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
         DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
         DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
         DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
         DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT,
         DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT, DEFAULT)
     WHERE [Transaction Name] LIKE '%DROPOBJ%') fd
WHERE [Transaction ID] = fd.tid;
    
----------------------------------------------------
