/*
	EXEMPLO QUE MOSTRA COMO RESTAURAR BACKUP DE PRODU��O NO AMBIENTE DE DESENVOLVIMENTO
	CONSIDERA-SE QUE O BACKUP CONCATENA NO NOME A DATA E HORA.
*/

DECLARE @backup		NVARCHAR(800),
		@dateini	DATETIME,
		@datefim	DATETIME,
		@dbname		SYSNAME

-- definir range de datas e database a restaurar
SET @dateini = DATEADD(wk,DATEDIFF(wk,0,GETDATE()),0)
SET @datefim = DATEADD(wk,DATEDIFF(wk,0,GETDATE()),1)
SET @dbname = 'Alabama'

-- 1. O primeiro passo � saber o tamanho da base e efetuar o shrink da base de produ��o.

EXEC sp_spaceused 

-- O shrink leva em considera��o o tamanho incial do banco de dados
-- TRUNCATEONLY - reduz o arquivo de dados e de log at� a �ltima extens�o alocada.
-- NOTRUNCATE - compacta os arquivos mas n�o libera o espa�o ao SO.
DBCC SHRINKDATABASE (@dbname, TRUNCATEONLY)


SELECT	TOP 1 @backup = name + '.bak' 
FROM	msdb..backupset 
WHERE	database_name = @dbname
AND		backup_start_date BETWEEN @dateini AND @datefim
AND		[type] = 'D' -- D is for full backups, I is for diferencial backups and L for log backups
ORDER BY backup_start_date ASC


USE [master]

-- Put DB in Single_User Mode
ALTER DATABASE [Tide] SET SINGLE_USER WITH ROLLBACK IMMEDIATE 

-- Restore DB using query from @backup variable
RESTORE DATABASE [Tide] FROM DISK = @backup WITH FILE = 1, NOUNLOAD, REPLACE, STATS = 10 
GO