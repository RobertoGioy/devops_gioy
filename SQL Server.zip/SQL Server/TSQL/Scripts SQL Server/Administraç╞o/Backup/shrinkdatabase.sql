/****** Object:  DdlTrigger [BLOQUEIA_DDL]    Script Date: 07/04/2011 09:56:11 ******/
IF  EXISTS (SELECT * FROM sys.triggers WHERE name = N'BLOQUEIA_DDL' AND parent_class=0)
DROP TRIGGER [BLOQUEIA_DDL] ON DATABASE
GO
Delete From Comissao Where Comissao=0
GO

declare @table  sysname
declare reg cursor for
Select Name From SysObjects Where Xtype='Tr' And Name Like 'TRG%'
open reg 
fetch next  from reg into  @table 
while @@fetch_status = 0 
begin
	exec ('Drop Trigger '+ @table )

if @@error=0
	print'---------> Triggers Transa��es Apagadas <----------' + char(10)
else
        print'---------> Erro ao Truncar as Tabelas Tempor�rias <-------'  + char(10)

fetch next from reg into @table 
end 
close reg
deallocate reg 


GO
declare @table  sysname
declare reg cursor for
select name  from sysobjects where xtype = 'U' and (name  like '%temp%' or name  like '%Transacoes%' Or name Like '%Ocorrencias_Acu%' Or name Like '%Historico%' Or  name Like '%lancont%' )
open reg 
fetch next  from reg into  @table 
while @@fetch_status = 0 
begin
	exec ('truncate table '+ @table )

if @@error=0
	print'---------> Tabelas Tempor�rias Truncadas <----------' + char(10)
else
        print'---------> Erro ao Truncar as Tabelas Tempor�rias <-------'  + char(10)

fetch next from reg into @table 
end 
close reg
deallocate reg 



go
Declare @Base Varchar(Max)
Set @Base=(Select Db_NAme())
backup log @Base with truncate_only 
go
checkpoint
go
Declare @Base Varchar(Max)
Set @Base=(Select Db_NAme())
dbcc shrinkdatabase(@Base)
