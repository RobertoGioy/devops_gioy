declare @tabela table (campo varchar(100))
declare @tabela1 table (campo varchar(100))
declare @tab sysname, @command sysname
insert into @tabela exec xp_cmdshell 'dir D:\MSSQLW2K5\MSSQL.1\MSSQL\Backup\*.bak'
insert into @tabela1 select substring(campo,patindex('%sl2000fer_%',campo),40) from @tabela where campo like '%.bak'
insert into @tabela1 select substring(campo,patindex('%cupom_%',campo),40) from @tabela where campo like '%.bak'
insert into @tabela1 select substring(campo,patindex('%barril_%',campo),40) from @tabela where campo like '%.bak'
if (select COUNT(*) from @tabela1 where campo like '%barril%') >= 3
	begin
	set @tab = (select top 1 campo from @tabela1 where campo like '%barril%' order by campo)
	set @command = 'del D:\MSSQLW2K5\MSSQL.1\MSSQL\Backup\' + @tab
	exec xp_cmdshell @command
	end
if (select COUNT(*) from @tabela1 where campo like '%cupom%') >= 3
	begin
	set @tab = (select top 1 campo from @tabela1 where campo like '%cupom%' order by campo)
	set @command = 'del D:\MSSQLW2K5\MSSQL.1\MSSQL\Backup\' + @tab
	exec xp_cmdshell @command
	end
if (select COUNT(*) from @tabela1 where campo like '%sl2000fer%') >= 3
	begin
	set @tab = (select top 1 campo from @tabela1 where campo like '%sl2000fer%' order by campo)
	set @command = 'del D:\MSSQLW2K5\MSSQL.1\MSSQL\Backup\' + @tab
	exec xp_cmdshell @command
	end
declare @base sysname
set @base = 'D:\MSSQLW2K5\MSSQL.1\MSSQL\Backup\SL2000FER_' + replicate('0',4-LEN(year(getdate())))+ltrim(str(year(getdate())))+
replicate('0',2-LEN(month(getdate())))+ltrim(str(month(getdate())))+
replicate('0',2-LEN(day(getdate())))+ltrim(str(day(getdate()))) + '.bak' 
backup database SL2000FER to disk = @base with init
set @base = 'D:\MSSQLW2K5\MSSQL.1\MSSQL\Backup\cupom_' + replicate('0',4-LEN(year(getdate())))+ltrim(str(year(getdate())))+
replicate('0',2-LEN(month(getdate())))+ltrim(str(month(getdate())))+
replicate('0',2-LEN(day(getdate())))+ltrim(str(day(getdate()))) + '.bak' 
backup database cupom to disk = @base with init
set @base = 'D:\MSSQLW2K5\MSSQL.1\MSSQL\Backup\barril_' + replicate('0',4-LEN(year(getdate())))+ltrim(str(year(getdate())))+
replicate('0',2-LEN(month(getdate())))+ltrim(str(month(getdate())))+
replicate('0',2-LEN(day(getdate())))+ltrim(str(day(getdate()))) + '.bak' 
backup database barril to disk = @base with init
