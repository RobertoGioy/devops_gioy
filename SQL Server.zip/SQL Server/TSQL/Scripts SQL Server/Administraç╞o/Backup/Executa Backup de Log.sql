use master;

BACKUP LOG [UmailNG_Ipiranga] 
TO  DISK = N'\\unear-nas\unearnas\DDBS03\Log\Backup user databases\UmailNG_Ipiranga_backup_2014_06_30_103114_7149914.trn' 
WITH NOFORMAT, NOINIT,  NAME = N'UmailNG_Ipiranga_backup_2014_06_30_103114_7149914', SKIP, REWIND, NOUNLOAD, COMPRESSION,  STATS = 10
GO