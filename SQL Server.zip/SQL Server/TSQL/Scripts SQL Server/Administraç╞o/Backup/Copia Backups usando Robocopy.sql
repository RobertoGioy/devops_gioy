DECLARE @DbName			sysname
DECLARE @ORIGEM			nvarchar(400)
DECLARE @DESTINO		nvarchar(400)
DECLARE @Source			nvarchar(400)
DECLARE	@Destination	nvarchar(400)
DECLARE @File			nvarchar(100)
DECLARE @LOG			nvarchar(100)
DECLARE @CMD			varchar(4000)
DECLARE @OK				BIT
DECLARE @Day			INT

SET @ORIGEM = 'F:\Databases\Producao\'
SET @DESTINO = '\\192.168.210.197\bspodbs03\Databases\Producao\'
SET @File = ''

SELECT @Day = DATEPART(DW, GETDATE())

IF (@Day = 1)
BEGIN
	DECLARE COPYCURSOR CURSOR FOR
	SELECT [name]
	FROM sys.databases
	WHERE [name] LIKE 'DB%'
	ORDER BY 1

	OPEN COPYCURSOR
	FETCH NEXT FROM COPYCURSOR INTO @DbName

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Source = @ORIGEM + @DbName + '\'
		SET @Destination = @DESTINO + @DbName + '\'
		SET @LOG = @DbName + CONVERT(VARCHAR,GETDATE(),112) + '.txt'
		
		SET @CMD = 'robocopy ' + @Source + @File + ' ' + @Destination + @File + ' /COPY:DAT /LOG+:' + @Source + @LOG 
		
		EXEC @OK = xp_cmdshell @CMD
		
		FETCH NEXT FROM COPYCURSOR INTO @DbName
	END

	CLOSE COPYCURSOR
	DEALLOCATE COPYCURSOR
END