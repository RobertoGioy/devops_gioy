USE msdb

DROP TABLE #TEMPBACKUP

SELECT
  Row_number() OVER (Partition BY @@SERVERNAME ORDER BY Isnull(CONVERT(VARCHAR, Max(CASE WHEN TYPE = 'D' THEN backup_finish_date ELSE NULL END), 121), 'SEM BACKUP FULL')) ID,
  --@@ServerName as ServerName,
  a.name                                                                                                                                                                   AS DatabaseName,
  --isnull(convert(varchar,max(CASE WHEN TYPE = 'L' THEN backup_finish_date ELSE NULL END),121),'SEM BACKUP LOG') as LastBackupLog,
  --isnull(convert(varchar,max(CASE WHEN TYPE = 'I' THEN backup_finish_date ELSE NULL END),121),'SEM BACKUP DIF') as LastBackupDif,
  Cast(Isnull(CONVERT(VARCHAR, Max(CASE WHEN TYPE = 'D' THEN backup_finish_date ELSE NULL END), 121), 'SEM BACKUP FULL') AS DATETIME)                                      AS LastBackupFull
INTO      #TEMPBACKUP
FROM
  sys.databases a
LEFT JOIN backupset b
  ON a.name = b.database_name --and b.type = 'L'
WHERE
  Isnull(backup_finish_date, '2099-01-01') >= Getdate() - 10
  AND a.name NOT IN ( 'tempdb', 'Master', 'Model', 'msdb', 'UmailNG_ScriptClean' ) --And a.name = 'UmailNG_Netpoints'	
  AND NOT backup_finish_date IS NULL
GROUP     BY a.name
ORDER     BY
  LastBackupFull ASC

SELECT
  DatabaseName,
  Inicio,
  Termino,
  Cast(( Segundos / 3600 ) AS VARCHAR) + ' horas ' + Cast(( ( Segundos % 3600 ) / 60 ) AS VARCHAR) + ' minutos ' + Cast(( ( Segundos % 3600 ) % 60 ) AS VARCHAR) + ' segundos' [Tempo de execu��o Destalhado]
FROM
  (SELECT
     B.Id,
     B.databasename,
     CASE
       WHEN B.Id = 1 THEN '2014-06-20 21:00:00.000'
       ELSE A.lastbackupfull
     END              Inicio,
     B.lastbackupfull Termino,
     CASE
       WHEN B.id = 1 THEN Datediff(SECOND, '2014-06-20 21:00:00.000', B.lastbackupfull)
       ELSE Datediff(SECOND, A.lastbackupfull, B.lastbackupfull)
     END              Segundos
   FROM
     #TEMPBACKUP A
   INNER JOIN #TEMPBACKUP B
     ON ( A.id ) = CASE
                     WHEN ( B.Id - 1 ) = 0 THEN 1
                     ELSE ( B.Id - 1 )
                   END
   WHERE
    NOT A.lastbackupfull IS NULL
    AND NOT B.DatabaseName IN ( 'UmailNG_Lasa', 'UmailNG_B2Wbbc', 'PostSalesB2W', 'DBA_PerfMon',
                                'AcomCRTransactions', 'UmailNG_EbitShoptime', 'UmailNG_ShoptimeMX', 'UmailNG_Submarino',
                                'AcomTransactionsDB5', 'UchannelsShoptime', 'UmailNG_SubmarinoCR', 'UmailNG_ShoptimeAR',
                                'UmailNG_ShoptimeCL', 'UmailNG_Submarino2010', 'UmailNG_ShoptimeCR', 'UchannelsSubmarino',
                                'UmailNG_Americanas', 'UmailNG_SubmarinoViagens', 'UmailNG_EbitSubmarino', 'UmailNG_EbitAmericanas',
                                'AcomTransactions', 'SubmarinoTransactions', 'UmailNG_Shoptime2010', 'UmailNG_AcomCR', 'ShoptimeTransactions' ))A
--Order by Inicio ASC,  Segundos DESC
ORDER  BY
  Segundos DESC

--
SELECT
  Cast(( Segundos / 3600 ) AS VARCHAR) + ' horas ' + Cast(( ( Segundos % 3600 ) / 60 ) AS VARCHAR) + ' minutos ' + Cast(( ( Segundos % 3600 ) % 60 ) AS VARCHAR) + ' segundos' [Tempo de execu��o Destalhado SEM B2W]
FROM
  (SELECT
     Sum(Segundos)Segundos
   FROM
     (SELECT
        CASE
          WHEN B.id = 1 THEN Datediff(SECOND, '2014-06-20 21:00:00.000', B.lastbackupfull)
          ELSE Datediff(SECOND, A.lastbackupfull, B.lastbackupfull)
        END Segundos
      FROM
        #TEMPBACKUP A
      INNER JOIN #TEMPBACKUP B
        ON ( A.id ) = CASE
                        WHEN ( B.Id - 1 ) = 0 THEN 1
                        ELSE ( B.Id - 1 )
                      END
      WHERE
       NOT A.lastbackupfull IS NULL
       AND NOT B.DatabaseName IN ( 'UmailNG_Lasa', 'UmailNG_B2Wbbc', 'PostSalesB2W', 'DBA_PerfMon',
                                   'AcomCRTransactions', 'UmailNG_EbitShoptime', 'UmailNG_ShoptimeMX', 'UmailNG_Submarino',
                                   'AcomTransactionsDB5', 'UchannelsShoptime', 'UmailNG_SubmarinoCR', 'UmailNG_ShoptimeAR',
                                   'UmailNG_ShoptimeCL', 'UmailNG_Submarino2010', 'UmailNG_ShoptimeCR', 'UchannelsSubmarino',
                                   'UmailNG_Americanas', 'UmailNG_SubmarinoViagens', 'UmailNG_EbitSubmarino', 'UmailNG_EbitAmericanas',
                                   'AcomTransactions', 'SubmarinoTransactions', 'UmailNG_Shoptime2010', 'UmailNG_AcomCR', 'ShoptimeTransactions' ))A)B

SELECT
  Cast(( Segundos / 3600 ) AS VARCHAR) + ' horas ' + Cast(( ( Segundos % 3600 ) / 60 ) AS VARCHAR) + ' minutos ' + Cast(( ( Segundos % 3600 ) % 60 ) AS VARCHAR) + ' segundos' [Tempo de execu��o Destalhado SOMENTE B2W]
FROM
  (SELECT
     Sum(Segundos)Segundos
   FROM
     (SELECT
        CASE
          WHEN B.id = 1 THEN Datediff(SECOND, '2014-06-20 21:00:00.000', B.lastbackupfull)
          ELSE Datediff(SECOND, A.lastbackupfull, B.lastbackupfull)
        END Segundos
      FROM
        #TEMPBACKUP A
      INNER JOIN #TEMPBACKUP B
        ON ( A.id ) = CASE
                        WHEN ( B.Id - 1 ) = 0 THEN 1
                        ELSE ( B.Id - 1 )
                      END
      WHERE
       NOT A.lastbackupfull IS NULL
       AND B.DatabaseName IN ( 'UmailNG_Lasa', 'UmailNG_B2Wbbc', 'PostSalesB2W', 'DBA_PerfMon',
                               'AcomCRTransactions', 'UmailNG_EbitShoptime', 'UmailNG_ShoptimeMX', 'UmailNG_Submarino',
                               'AcomTransactionsDB5', 'UchannelsShoptime', 'UmailNG_SubmarinoCR', 'UmailNG_ShoptimeAR',
                               'UmailNG_ShoptimeCL', 'UmailNG_Submarino2010', 'UmailNG_ShoptimeCR', 'UchannelsSubmarino',
                               'UmailNG_Americanas', 'UmailNG_SubmarinoViagens', 'UmailNG_EbitSubmarino', 'UmailNG_EbitAmericanas',
                               'AcomTransactions', 'SubmarinoTransactions', 'UmailNG_Shoptime2010', 'UmailNG_AcomCR', 'ShoptimeTransactions' ))A)B 
