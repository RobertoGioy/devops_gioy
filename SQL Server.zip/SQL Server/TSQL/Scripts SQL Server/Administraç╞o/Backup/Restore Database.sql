RESTORE FILELISTONLY FROM DISK = 'E:\Roberto\Unear\DatabaseServerAuditDev20140309020023.bak'


RESTORE DATABASE [Audit_Server]
FROM DISK = 'E:\Roberto\Unear\DatabaseServerAuditDev20140309020023.bak'
WITH FILE = 1, NORECOVERY,
MOVE 'DatabaseServerAuditDev' TO 'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Audit_Server.mdf',
MOVE 'DatabaseServerAuditDev_log' TO 'C:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\Audit_Server.ldf',
STATS=10
