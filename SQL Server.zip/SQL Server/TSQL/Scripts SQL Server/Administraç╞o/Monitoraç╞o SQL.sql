/************************************************************
 PROCEDIMENTOS ARMAZENADOS DO SISTEMA PARA MONITORA��O DO SQL
*************************************************************/
sp_who		--> Usu�rios e processos atuais do SQL Server.
sp_who2	active	--> Usu�rios e processos ativos do SQL Server, mostra cputime e diskIO.
sp_lock		--> Locks ativos, bem como informa��es sobre bloqueio e deadlocks.

sp_blockcnt     --> Verifica n�mero de conexoes bloqueadas no momento
exec msdb.dbo.p_VerificaBloqueios  --> Lista todas as conexoes bloqueadas

sp_spaceused	--> Quantidade de espa�o em disco usada por uma tabela ou banco de dados.
sp_helpdb	--> Bancos de dados e seus objetos.
sp_monitor	--> Estat�sticas do SQL Server, como tempo de processamento total, n�mero de leituras e grava��es, e conex�es.
sp_helpindex tabela	--> �ndices de uma tabela.
sp_statistics tabela 	--> Todos os �ndices de uma tabela espec�fica.

DBCC inputbuffer(344)	--> Mostra o comando executado pela conexao (@@SPID)
kill 103		--> Finaliza uma conexao (@@SPID)


/************************************************************
VARI�VEIS GLOBAIS
*************************************************************/
select @@connections	--> Cont�m o n�mero de logins ou de tentativas de logins desde que o SQL Server foi iniciado pela �ltima vez.
select @@error		--> Cont�m o n�mero de erros da �ltima instru��o Transact-SQL executada.
select @@spid		--> Cont�m a identifica��o do processo atual do usu�rio do servidor - use essa identifica��o para identificar o processo atual do usu�rio na sa�da de sp_who.
select @@procid 	--> Cont�m a identifica��o do procedimento armazenado atual.

/************************************************************
INSTRU��O TRANSACT-SQL  - rodar antes da Query a ser executada
*************************************************************/
set statistics IO { on/off }	--> Exibe informa��es sobre a quantidade de atividade do disco gerada pelas intru��es Transact-SQL.
set statistics time { on/off }	--> Exibe o n�mero de milessegendos necess�rios para analisar, compilar e executar cada instru��o.
set statistics profile { on/off } --Exibe o plano de execu��o da query em forma textual.
set showplan_text { on/off }	--> Faz com que o SQL Server n�o execute a consulta e retorna informa��es detalhadas sobre como as instru��es s�o executadas.

/************************************************************
INSTRU��O DO DBCC
*************************************************************/
DBCC MEMUSAGE   --> Exibe informa��es sobre a quantidade de mem�ria utilizada pelos objetos no buffer e cache de procedimentos.

DBCC SQLPERF (logspace) --> Exibe informa��es sobre o uso do espa�o do log de transa��es em todos os bancos de dados.
DBCC SQLPERF (iostats)  --> Exibe informa��es sobre E/S de disco
DBCC SQLPERF (lrustats) --> Exibe informa��es sobre uso de mem�ria e do cache.
DBCC SQLPERF (netstats) --> Exibe informa��es sobre atividade da rede.

DBCC OPENTRAN				--> Exibe informa��es sobre as transa��es ativas
DBCC SHOW_STATISTICS (tabela,indice)  	--> Exibe informa��es sobre a seletividade de um �ndice, que serve de base para determinar se um �ndice � �til ao otimizador de consultas.
DBCC SHOWCONTIG('Usados','pk_usados')   --> Exibe informa��es sobre o n�vel de fragmenta��o do �ndice, o %Scan Density deve estar pr�ximo de 100%, caso contr�rio execute dbreindex para corrigir, recriando o �ndice.
DBCC DBREINDEX('Usados','CustomerId')   --> Recria o �ndice da tabela.

DBCC CHECKDB('DB_Promocoes',REPAIR_REBUILD) WITH NO_INFOMSGS
DBCC CHECKFILEGROUP
DBCC CHECKALLOC
DBCC CHECKTABLE

DBCC TRACEON
DBCC TRACEOFF



/************************************************************
 PROCEDIMENTOS ARMAZENADOS DO SISTEMA (N�o documentados) PARA MANUTEN��O DO SQL
*************************************************************/

--> Executa comandos de manuten�ao em todos os bancos de dados existentes 
exec sp_MSForEachDB @command1="print '?'" , 
		    @command2="DBCC CHECKDB ('?')"

/* Os par�metros da procedure s�o:
Par�metro Obrigat�rio ? Para que serve 
@command1 Sim Primeiro comando que se deseja executar.  
@command2 N�o Segundo comando que se deseja executar 
@command3 N�o Terceiro comando que se deseja executar 
@replacechar N�o Caractere que dever� ser substitu�do pelo nome do database nos par�metros @command1..3. Quando n�o especificado, o caractere default ser� o sinal de interroga��o �?�. 
@precommand N�o Comando que dever� ser executado ANTES de @command1..3 
@poscommand N�o Comando que dever� ser executado AP�S @command1..3 
*/


--> Executa comandos de manuten��o em todas as tabelas do banco de dados
use banco
/*
Executa um procedimento para todas as tabelas pertencentes a um database. 
Para reindexar todas as tabelas de um database:
*/
 EXEC sp_MSforeachTable @command1="print '>>>Tabela: ?'",
			@command2="DBCC dbreindex ('?')"



--Lista Todas as Tabelas do Banco-===============================================
create table #Tabelas(nome varchar(100), linhas int, reservado varchar(20), dados varchar(20),indices varchar(20), livre varchar(20))

EXEC sp_MSforeachTable @command1="print '>>>Tabela: ?'",
			@command2="Insert into #Tabelas Exec sp_spaceused '?'"

select * from #Tabelas order by linhas desc
--================================================================================


--PROCEDIMENTO PARA EXECUTAR CHECK DB===================================
USE master

EXEC  p_DesconectaUsuarios 'DB_Promocoes'

EXEC sp_dboption 'DB_Promocoes', 'single user', 'TRUE'

DBCC CHECKDB('DB_Promocoes',REPAIR_REBUILD) WITH NO_INFOMSGS  --mais r�pido, pq n�o lista detalhes
--DBCC CHECKDB('DB_Promocoes',REPAIR_REBUILD) WITH ALL_ERRORMSGS
            
EXEC sp_dboption 'DB_Promocoes', 'single user', 'FALSE'
--=====================================================================


--ALTERAR O COLLATION DEFAULT PARA UM CAMPO NA TABELA===============
ALTER TABLE TB_PessoaFisica ALTER COLUMN nm_vch_email
            varchar(60) COLLATE SQL_Latin1_General_CP1_CI_AI NOT NULL  --padr�o webmotors
--==================================================================


