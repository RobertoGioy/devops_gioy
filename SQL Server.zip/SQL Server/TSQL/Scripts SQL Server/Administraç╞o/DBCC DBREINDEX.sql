DBCC CHECKTABLE (Itens_nota_Fiscal);
Go
DBCC DBREINDEX (Itens_nota_Fiscal,'', 90)
 WITH NO_INFOMSGS;
Go 
DBCC SHOWCONTIG (Itens_Nota_Fiscal);
 
go 
 sp_helpindex Itens_Nota_Fiscal;
 go
 Alter Index PK_Itens_Nota_Fiscal on Itens_Nota_Fiscal reorganize;