CREATE PROC usp_limpa_log (@type int = null, @dbname sysname = null)
AS

--by Miller

declare @expr varchar(max)

if @type is null
begin
	SELECT '@type 1 = Precisa informar a vari�vel @dbname com o nome da base para que a limpeza seja para uma �nica base de dados.
@type 2 = N�o precisa informar a base de dados e ser� feita a limpeza para todas as bases de dados'
return(1)
end

if @type = 2 and not @dbname is null
begin
	SELECT '@type 1 = Precisa informar a vari�vel @dbname com o nome da base para que a limpeza seja para uma �nica base de dados.
@type 2 = N�o precisa informar a base de dados e ser� feita a limpeza para todas as bases de dados'
return(1)
end

if @type = 2
begin
		create table #dblogs 
		( id int identity(1,1) primary key,
		  dbname sysname,
		  dblog sysname)

		insert into #dblogs
		select db_name(dbid),name from sys.sysaltfiles
		where groupid = 0
		order by 1,2

		declare @cont int

		set @cont = (select max(id) from #dblogs)

		while @cont > 0
		begin
		SELECT TOP 1 @expr = ' USE [' + dbname + '] BACKUP LOG [' + dbname + '] WITH TRUNCATE_ONLY
		CHECKPOINT
		DBCC SHRINKFILE ([' + dblog + '])'
			FROM #dblogs

		delete top (1) from #dblogs
		set @cont = @cont - 1
		
		EXEC (@expr)
		
		end

	return(1)

end

if @type = 1 and @dbname is null
begin
	SELECT 'Voc� deve informar o @dbname com o nome da base para limpeza de log individual.
Caso queira para todas as bases do servidor, voc� dever� informar @type = 2'
return(1)
end

if @type = 1 and not @dbname is null
begin
	IF NOT EXISTS (SELECT db_id(@dbname))
		SELECT 'Base de dados inexistente!'
	ELSE
		begin
			SELECT	@expr = 'USE [' + @dbname + ']' + char(13) + 
					'BACKUP LOG [' + @dbname + '] WITH TRUNCATE_ONLY' + CHAR(13) +
					'CHECKPOINT' + CHAR(13) +
					'DBCC SHRINKFILE ([' + name + '])' 
						FROM
								sys.sysaltfiles
									where dbid = db_id(@dbname) and groupid = 0
			EXEC (@expr)
	
		end
	return(1)
end


