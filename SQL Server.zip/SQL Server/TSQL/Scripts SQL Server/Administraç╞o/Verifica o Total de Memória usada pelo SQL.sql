--the total memory used by the SQL Server executable. 
declare @Server nvarchar(40) 
set @Server = 'MSSQL$SQL1' 

SELECT cntr_value/1024 as 'MBs used' 
from master.dbo.sysperfinfo 
where object_name = @Server + ':Memory Manager' and 
counter_name = 'Total Server Memory (KB)' 


SELECT 'Procedure 
Cache Allocated', 
CONVERT(int,((CONVERT(numeric(10,2),cntr_value) 
* 8192)/1024)/1024) 
as 'MBs' 
from master.dbo.sysperfinfo 
where object_name = @Server + ':Buffer Manager' and 
counter_name = 'Procedure cache pages' 
UNION 
SELECT 'Buffer Cache database pages', 
CONVERT(int,((CONVERT(numeric(10,2),cntr_value) 
* 8192)/1024)/1024) 
as 'MBs' 
from master.dbo.sysperfinfo 
where object_name = @Server + ':Buffer Manager' and 
counter_name = 'Database pages' 
UNION 
SELECT 'Free pages', 
CONVERT(int,((CONVERT(numeric(10,2), cntr_value) 
* 8192)/1024)/1024) 
as 'MBs' 
from master.dbo.sysperfinfo 
where object_name = @Server + ':Buffer Manager' and 
counter_name = 'Free pages' 