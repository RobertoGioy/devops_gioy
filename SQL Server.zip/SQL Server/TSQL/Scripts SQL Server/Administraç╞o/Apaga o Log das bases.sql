Declare @var1 sysname, @var2 sysname
Declare cursor1 cursor for

select db_name(dbid)as dbname,name from sysaltfiles where groupid<>0  
and databasepropertyex(db_name(dbid),'status')='ONLINE' 
and databasepropertyex(db_name(dbid),'Updateability')='READ_WRITE' order by dbname

open cursor1
fetch next from cursor1 into @var1, @var2
while @@fetch_status = 0
begin
   print 'Truncando log da base --> '+@var1
   exec ('use [' + @var1 + '] 
		  backup log [' + @var1 + '] with truncate_only
		  checkpoint
		  dbcc shrinkfile ( ' + @var2 + ')')
   fetch next from cursor1 into @var1, @var2
end
close cursor1
deallocate cursor1

--dbcc sqlperf(logspace)
