Sp_Verifica_Processo 'programname Like''%E236s2%'''

sp_who '358'
sp_who '51'

DBCC Inputbuffer(51)