USE [master]
GO

/****** Object:  StoredProcedure [dbo].[spUseIODatabase]    Script Date: 07/18/2013 14:08:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[spUseIODatabase]
	@DatabaseID INT
AS
SELECT	DB_NAME(@DatabaseID) AS [Database Name], 
		fs.[file_id],
		MF.name,
		num_of_reads AS [NumeroLeituras],
		num_of_writes AS [NumeroGravacoes],
		(num_of_reads + num_of_writes) [total_io],
		fs.num_of_bytes_read / 1024 [MbLeitura],
		fs.num_of_bytes_written /1024 [MbEscrita],
		(num_of_bytes_read + num_of_bytes_written) / 1024 [total_mb_io],
		CAST((io_stall_read_ms + io_stall_write_ms)/(1.0 + num_of_reads + num_of_writes) AS NUMERIC(10,1)) AS [avg_io_stall_ms]
FROM	sys.dm_io_virtual_file_stats(@DatabaseID,null) AS fs
		INNER JOIN sys.master_files AS mf WITH (NOLOCK)
ON		fs.database_id = mf.database_id AND	fs.[file_id] = mf.[file_id]
ORDER BY (num_of_reads + num_of_writes) DESC OPTION (RECOMPILE);

GO


