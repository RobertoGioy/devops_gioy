/*Ativar change data capture*/

--Ativa CDC:
EXEC sys.sp_cdc_enable_db


--Verifica STATUS da base, se est� ativo o CDC ou n�o (1 = ativo):
select is_cdc_enabled,* from master.sys.databases
      where name = db_name()

--Tabelas de sistemas criadas ap�s habilitar CDC na base est�o no schema CDC da master.
/*
cdc.captured_columns
cdc.change_tables
cdc.ddl_history
cdc.index_columns
cdc.lsn_time_mapping
dbo.systranschemas
*/

--Ativa CDC em uma tabela espec�fica:
EXEC sys.sp_cdc_enable_table
      @source_schema = 'dbo',
      @source_name = 'dim_bases',
      @role_name = NULL

--change data capture
select * from cdc.change_tables
select * from cdc.ddl_history
select * from cdc.dbo_dim_bases_CT
select * from cdc.captured_columns
select * from cdc.index_columns
select * from cdc.lsn_time_mapping
