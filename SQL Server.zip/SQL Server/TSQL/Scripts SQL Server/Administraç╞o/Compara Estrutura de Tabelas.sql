select c.name, c.xtype, c.length, c.xprec, c.xscale, c.colid, c.colorder, c.prec, c.scale, c.type, c.offset from sysobjects o inner join syscolumns c on o.id = c.id where o.name = 'pedido'
except
select c.name, c.xtype, c.length, c.xprec, c.xscale, c.colid, c.colorder, c.prec, c.scale, c.type, c.offset from [frsrvbdsql02\sqlsic1].frdca.dbo.sysobjects o inner join [frsrvbdsql02\sqlsic1].frdca.dbo.syscolumns c on o.id = c.id where o.name = 'pedido'


