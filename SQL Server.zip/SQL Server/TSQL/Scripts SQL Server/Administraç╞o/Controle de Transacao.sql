SET TRANSACTION ISOLATION LEVEL REPEATABLE READ
BEGIN TRANSACTION

DECLARE @LockID INT
EXECUTE @LockID = sp_getapplock
        @Resource    = 'JAPA', 
        @LockMode    = 'Exclusive',
        @LockTimeout = 0

IF @LockID <> 0
   BEGIN
      ROLLBACK TRANSACTION
      RAISERROR ( 51001, 16, 1 )
      RETURN
   END

--WAITFOR DELAY '00:00:05'

DECLARE @ID INT 
SET @ID = (SELECT ISNULL(MAX(IDBEM), 0) + 1 FROM Imobilizado.Bem WHERE IDEmpresa = 1)
INSERT INTO Imobilizado.Bem 
VALUES (1, @ID, 'Bem 1', '2011-06-07', 1, 3.75)

EXECUTE sp_releaseapplock 
        @Resource = 'JAPA'

COMMIT TRANSACTION
