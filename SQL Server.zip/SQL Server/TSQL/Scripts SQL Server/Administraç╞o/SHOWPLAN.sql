USE [AdventureWorks2014]
GO

-- SHOWPLAN_XML s� � executado em blocos (lotes) e apresenta o plano de execu��o no formato XML

SET SHOWPLAN_XML ON;
GO

SELECT BusinessEntityID 
FROM HumanResources.Employee
WHERE NationalIDNumber = '509647174';
GO

SELECT BusinessEntityID, LoginID 
FROM HumanResources.Employee
WHERE JobTitle LIKE 'Production%';
GO

SET SHOWPLAN_XML OFF
GO

-- SHOWPLAN_TEXT retorna a instru��o e o plano de execu��o no formato texto.

SET SHOWPLAN_TEXT ON
GO

SELECT BusinessEntityID 
FROM HumanResources.Employee
WHERE NationalIDNumber = '509647174';
GO

SET SHOWPLAN_TEXT OFF
GO

-- SHOWPLAN_ALL retorna as instru��es igual a SHOWPLAN_TEXT com mais detalhes

SET SHOWPLAN_ALL ON
GO

SELECT BusinessEntityID 
FROM HumanResources.Employee
WHERE NationalIDNumber = '509647174';
GO

SET SHOWPLAN_ALL OFF
GO

-- STATISTICS XML retorna o resultado da consulta e o plano de execu��o no formato XML

SET STATISTICS XML ON
GO

SELECT BusinessEntityID 
FROM HumanResources.Employee
WHERE NationalIDNumber = '509647174';
GO

SET STATISTICS XML OFF
GO

-- STATISTICS PROFILE � executado em lote e apresenta informa��es detalhadas dos planos de execu��o

SET STATISTICS PROFILE ON
GO

SELECT BusinessEntityID 
FROM HumanResources.Employee
WHERE NationalIDNumber = '509647174';
GO

SELECT BusinessEntityID, LoginID 
FROM HumanResources.Employee
WHERE JobTitle LIKE 'Production%';
GO

SET STATISTICS PROFILE OFF
GO