
create table #tb_info
(dbname sysname null,
 name sysname,
 qtdlinhas bigint,
 reserved varchar(1000),
 data varchar(1000),
 index_size varchar(1000),
 unused varchar(1000)
)		

set quoted_identifier off

declare @db sysname
declare c_db cursor for
select name from master.dbo.sysdatabases
where dbid > 4
order by name
open c_db
fetch next from c_db into @db
while @@fetch_status = 0
begin

insert into #tb_info (name,qtdlinhas,reserved,data,index_size,unused)
exec ("
set nocount on

use [" + @db + "];

declare @tb sysname

declare c_tb cursor for
select b.name + '.' + a.name from sys.all_objects a
		inner join sys.schemas b on a.schema_id = b.schema_id
	where type_desc = 'USER_TABLE'
order by 1
open c_tb
fetch next from c_tb into @tb
while @@FETCH_STATUS = 0
begin

EXEC sp_spaceused @tb

fetch next from c_tb into @tb
end
close c_tb
deallocate c_tb")

update #tb_info set dbname = @db where dbname is null

fetch next from c_db into @db
end
close c_db
deallocate c_db



select dbname,name,row_number() over (partition by dbname order by (convert(bigint,replace(reserved,' KB',''))/1024.00)/1024.00 desc) as row,
          (convert(bigint,replace(reserved,' KB',''))/1024.00)/1024.00 as tamanho
       from #tb_info

--drop table #tb_info
--select * from #tb_info

/* Para estimativa de compacta��o de dados:
select 'EXEC ' + rtrim(dbname) + '.dbo.sp_estimate_data_compression_savings ''dbo'',''CampaignObjects'',NULL,NULL,''PAGE''',
		sum((convert(bigint,replace(reserved,' KB',''))/1024.00)/1024.00)
	from #tb_info a
		where a.qtdlinhas > 0
	group by dbname

--Estimativa de compacta��o de apenas uma parti��o:
EXEC sp_estimate_data_compression_savings 
	@schema_name = 'dbo'
	, @object_name = 'CampaignObjects'
	, @index_id = NULL
	, @partition_number = $PARTITION.PF_Data (20020301) --> Partition Function DATA
	, @data_compression ='PAGE' 

*/


/*
--Top 4 maiores tabelas

select * from (
select dbname,name,row_number() over (partition by dbname order by (convert(bigint,replace(reserved,' KB',''))/1024.00)/1024.00 desc) as row,
	   (convert(bigint,replace(reserved,' KB',''))/1024.00)/1024.00 as tamanho
	from #tb_info) a where row < 5

*/





/*

--Consulta R�pida

select db_name(database_id), sum(size*8/1024.)/1024. from sys.master_files
group by db_name(database_id)
order by 2 desc

select db_name(database_id), sum(size*8/1024.)/1024. from sys.master_files
group by db_name(database_id)
order by 2 desc
*/