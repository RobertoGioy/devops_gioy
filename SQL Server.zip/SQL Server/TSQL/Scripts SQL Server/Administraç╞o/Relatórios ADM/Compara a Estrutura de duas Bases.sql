SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE SP_COMPARA_BASES (@SERVIDOR1 VARCHAR(50), @BASE1 VARCHAR(30), @SERVIDOR2 VARCHAR(50), @BASE2 VARCHAR(30))AS 
SET NOCOUNT ON
SET QUOTED_IDENTIFIER OFF


EXEC("
------- Insere dados na #Tabelas_Base1
SELECT [Schema],Tabela,Campo,CodTypeUser,TypeUser,CodType,s.Name as [Type],Tamanho,[Precis�o],Escala,[Identity],Seed,Incremental,Replicado,Nulo,
	   ROW_NUMBER() OVER (PARTITION BY Tabela ORDER BY Ordem) as Ordem
INTO #Tabelas_Base1 
FROM ( SELECT  s4.Name as 'Schema',s.Name as 'Tabela',s2.Name as 'Campo',s3.Xusertype as 'CodTypeUser',s3.Name 'TypeUser',s3.Xtype as 'CodType', 
               s2.Length as 'Tamanho',s2.Xprec as 'Precis�o',s2.Xscale as 'Escala',s5.Is_Identity as 'Identity',s5.Seed_Value as 'Seed', 
               s5.Increment_Value as 'Incremental',s5.Is_Replicated as 'Replicado',s5.Is_Nullable as 'Nulo',s2.Colorder as 'Ordem'  
	   FROM ["+@SERVIDOR1+"].["+@BASE1+"].[dbo].[Sysobjects] s 
	   INNER JOIN ["+@SERVIDOR1+"].["+@BASE1+"].[dbo].[Syscolumns] s2 ON s.Id = s2.Id
	   INNER JOIN ["+@SERVIDOR1+"].["+@BASE1+"].[dbo].[Systypes] s3 ON s2.Xtype = s3.Xtype AND s2.Xusertype = s3.Xusertype 
	   INNER JOIN ["+@SERVIDOR1+"].["+@BASE1+"].[sys].[Schemas] s4 ON s.Uid = s4.Schema_Id
	   LEFT  JOIN ["+@SERVIDOR1+"].["+@BASE1+"].[sys].[Identity_Columns] s5 ON s2.Id = s5.Object_Id AND s2.Colid = s5.Column_Id
	   WHERE s.Xtype IN ('U') 
	 ) AS Tabelas_Base1 
INNER JOIN ["+@SERVIDOR1+"].["+@BASE1+"].[dbo].[Systypes] s ON s.xusertype = Tabelas_Base1.CodType
WHERE Tabela NOT IN ('MSpeer_Lsns','MSpeer_Request','MSpeer_Response','MSpub_Identity_range','Sysarticlecolumns','Systranschemas',
                     'Sysarticles','Sysarticleupdates','Syspublications','Sysreplservers','Sysschemaarticles','Syssubscriptions',
                     'MSreplication_objects','MSreplication_subscriptions','MSsnapshotdeliveryprogress','MSsubscription_agents',
                     'MSsavedforeignkeycolumns','MSsavedforeignkeyextendedproperties','MSsavedforeignkeys')
ORDER BY Tabela, Ordem


------- Insere dados na #Tabelas_Base2
SELECT [Schema],Tabela,Campo,CodTypeUser,TypeUser,CodType,s.Name as [Type],Tamanho,[Precis�o],Escala,[Identity],Seed,Incremental,Replicado,Nulo,
	   ROW_NUMBER() OVER (PARTITION BY Tabela ORDER BY Ordem) as Ordem
INTO #Tabelas_Base2 
FROM ( SELECT  s4.Name as 'Schema',s.Name as 'Tabela',s2.Name as 'Campo',s3.Xusertype as 'CodTypeUser',s3.Name 'TypeUser',s3.Xtype as 'CodType', 
               s2.Length as 'Tamanho',s2.Xprec as 'Precis�o',s2.Xscale as 'Escala',s5.Is_Identity as 'Identity',s5.Seed_Value as 'Seed', 
               s5.Increment_Value as 'Incremental',s5.Is_Replicated as 'Replicado',s5.Is_Nullable as 'Nulo',s2.Colorder as 'Ordem'  
	   FROM ["+@SERVIDOR2+"].["+@BASE2+"].[dbo].[Sysobjects] s 
	   INNER JOIN ["+@SERVIDOR2+"].["+@BASE2+"].[dbo].[Syscolumns] s2 ON s.Id = s2.Id
	   INNER JOIN ["+@SERVIDOR2+"].["+@BASE2+"].[dbo].[Systypes] s3 ON s2.Xtype = s3.Xtype AND s2.Xusertype = s3.Xusertype 
	   INNER JOIN ["+@SERVIDOR2+"].["+@BASE2+"].[sys].[Schemas] s4 ON s.Uid = s4.Schema_Id
	   LEFT  JOIN ["+@SERVIDOR2+"].["+@BASE2+"].[sys].[Identity_Columns] s5 ON s2.Id = s5.Object_Id AND s2.Colid = s5.Column_Id
	   WHERE s.Xtype IN ('U') 
	 ) AS Tabelas_Base2 
INNER JOIN ["+@SERVIDOR2+"].["+@BASE2+"].[dbo].[Systypes] s ON s.xusertype = Tabelas_Base2.CodType
WHERE Tabela NOT IN ('MSpeer_Lsns','MSpeer_Request','MSpeer_Response','MSpub_Identity_range','Sysarticlecolumns','Systranschemas',
                     'Sysarticles','Sysarticleupdates','Syspublications','Sysreplservers','Sysschemaarticles','Syssubscriptions',
                     'MSreplication_objects','MSreplication_subscriptions','MSsnapshotdeliveryprogress','MSsubscription_agents',
                     'MSsavedforeignkeycolumns','MSsavedforeignkeyextendedproperties','MSsavedforeignkeys')
ORDER BY Tabela, Ordem



------- Tabelas que n�o existem na base BASE1
SELECT DISTINCT [Schema] +'.'+ Tabela AS 'Tabelas que n�o existem na base "+@BASE1+"'
FROM #Tabelas_Base2 t
WHERE NOT EXISTS (SELECT * 
				  FROM #Tabelas_Base1 t2 
				  WHERE T.[Schema] = t2.[Schema] AND t.Tabela = t2.Tabela)
ORDER BY 1

------- Tabelas que n�o existem na base BASE2
SELECT DISTINCT [Schema] +'.'+ Tabela AS 'Tabelas que n�o existem na base "+@BASE2+"'
FROM #Tabelas_Base1 t
WHERE NOT EXISTS (SELECT * 
				  FROM #Tabelas_Base2 t2 
				  WHERE T.[Schema] = t2.[Schema] AND t.Tabela = t2.Tabela)
ORDER BY 1


------- Campos que n�o existem na base BASE1
SELECT DISTINCT CONVERT(VARCHAR(50),LTRIM(RTRIM(T.[Schema])) +'.'+ LTRIM(RTRIM(t.tabela))) as 'Tabela', T.Ordem as 'Ordem do Campo', 
       CONVERT(varchar(50),T.Campo) as 'Campos que n�o existem na base "+@BASE1+"', CONVERT(varchar(15),T.TypeUser)as 'Tipo', 
       T.Tamanho, T.[Precis�o], T.Escala, case when T.Nulo = 0 then 'N�o' 
                                                               Else 'Sim'end as 'Aceita Nulo' 
FROM #Tabelas_Base2 T 
INNER JOIN #Tabelas_Base1 T2 on T.[Schema] = T2.[Schema] and T.tabela = T2.Tabela 
WHERE not exists (SELECT * 
				  FROM #Tabelas_Base1 T3 
				  WHERE T.[Schema] = T3.[Schema] and T.tabela = T3.tabela and T.campo = T3.campo)
order by 1,2,3

------- Campos que n�o existem na base BASE2
SELECT DISTINCT CONVERT(VARCHAR(50),LTRIM(RTRIM(T.[Schema])) +'.'+ LTRIM(RTRIM(t.tabela))) as 'Tabela', T.Ordem as 'Ordem do Campo', 
	   CONVERT(varchar(50),T.Campo) as 'Campos que n�o existem na base "+@BASE2+"', CONVERT(varchar(15),T.TypeUser)as 'Tipo', T.Tamanho, 
	   T.[Precis�o], T.Escala, case when T.Nulo = 0 then 'N�o' 
													Else 'Sim'end as 'Aceita Nulo' 
FROM #Tabelas_Base1 T 
INNER JOIN #Tabelas_Base2 t2 on T.[Schema] = T2.[Schema] and T.tabela = T2.Tabela 
WHERE not exists (SELECT * 
				  FROM #Tabelas_Base2 T3 
				  WHERE T.[Schema] = T3.[Schema] and T.tabela = T3.tabela and T.campo = T3.campo)
order by 1,2,3

----- Cria os campos que faltam na base BASE1         
SELECT DISTINCT 'ALTER TABLE ["+@SERVIDOR1+"].["+@BASE1+"].'+CONVERT(VARCHAR(50),LTRIM(RTRIM(T.[Schema])) +'.'+ LTRIM(RTRIM(t.tabela)))+' ADD '
	   +CONVERT(varchar(50),T.Campo) +' '+ CONVERT(varchar(15),T.TypeUser) + case when t.TypeUser in ('Varchar','Char')    then ' ('+ CONVERT(VARCHAR(4),LTRIM(RTRIM(T.Tamanho)))+')'
																				  when t.TypeUser in ('Numeric','Decimal') then ' ('+CONVERT(VARCHAR(4),LTRIM(RTRIM(T.[Precis�o])))+','+CONVERT(VARCHAR(4),LTRIM(RTRIM(T.Escala)))+')'
																														   else  ''    end 
	   +case when T.Nulo = 0 then ' NOT NULL DEFAULT(0) WITH VALUES' 
							 Else ' NULL'end as 'Comando' ,T.Tabela, T.Ordem 
FROM #Tabelas_Base2 T 
INNER JOIN #Tabelas_Base1 T2 on T.[Schema] = T2.[Schema] and T.tabela = T2.Tabela 
WHERE not exists (SELECT * 
                  FROM #Tabelas_Base1 T3 
                  WHERE T.[Schema] = T3.[Schema] and T.tabela = T3.tabela and T.campo = T3.campo)
order by 2,3

----- Cria os campos que faltam na base BASE2         
SELECT DISTINCT 'ALTER TABLE ["+@SERVIDOR2+"].["+@BASE2+"].'+CONVERT(VARCHAR(50),LTRIM(RTRIM(T.[Schema])) +'.'+ LTRIM(RTRIM(t.tabela)))+' ADD '
	   +CONVERT(varchar(50),T.Campo) +' '+ CONVERT(varchar(15),T.TypeUser) + case when t.TypeUser in ('Varchar','Char')    then '('+ CONVERT(VARCHAR(4),LTRIM(RTRIM(T.Tamanho)))+')'
																				  when t.TypeUser in ('Numeric','Decimal') then '('+CONVERT(VARCHAR(4),LTRIM(RTRIM(T.[Precis�o])))+','+CONVERT(VARCHAR(4),LTRIM(RTRIM(T.Escala)))+')'
																													       else  ''    end 
	   +case when T.Nulo = 0 then ' NOT NULL DEFAULT(0) WITH VALUES' 
							 Else ' NULL'end as 'Comando' ,T.Tabela, T.Ordem 
FROM #Tabelas_Base1 T 
INNER JOIN #Tabelas_Base2 t2 on T.[Schema] = T2.[Schema] and T.tabela = T2.Tabela 
WHERE not exists (SELECT * 
				  FROM #Tabelas_Base2 T3 
				  WHERE T.[Schema] = T3.[Schema] and T.tabela = T3.tabela and T.campo = T3.campo)
				  
order by 2,3

----- Compara todos os campos das duas bases
SELECT t.[Schema],t.Tabela,t.Campo,t.Ordem,CASE WHEN t.Ordem <> t2.Ordem THEN '<>'
                                                                         ELSE '=' END AS Sinal, 
       t2.Ordem,UPPER(t.Typeuser) + CASE WHEN t.Typeuser in ('Varchar','Char')    THEN '('+ CONVERT(VARCHAR(4),LTRIM(RTRIM(t.Tamanho)))+')'
			                             WHEN t.Typeuser in ('Numeric','Decimal') THEN '('+CONVERT(VARCHAR(4),LTRIM(RTRIM(t.[Precis�o])))+','+CONVERT(VARCHAR(4),LTRIM(RTRIM(t.Escala)))+')'
                                                                                  ELSE  ''    END  + CASE WHEN t.Nulo = 0 THEN '   NOT NULL' 
                                                                                                                          ELSE '   NULL'     END  
			  +CASE WHEN t.[Identity] <> 0 THEN ' Identity ('+ CONVERT(varchar(10),t.Seed)+','+CONVERT(varchar(8000),t.Incremental)+')' 
										   ELSE '' END AS 'Campos na base "+@BASE1+"',
							       
	   CASE WHEN (
	               UPPER(t.Typeuser) + CASE WHEN t.Typeuser in ('Varchar','Char')    THEN '('+ CONVERT(VARCHAR(4),LTRIM(RTRIM(t.tamanho)))+')'
			                                WHEN t.Typeuser in ('Numeric','Decimal') THEN '('+CONVERT(VARCHAR(4),LTRIM(RTRIM(t.[Precis�o])))+','+CONVERT(VARCHAR(4),LTRIM(RTRIM(t.Escala)))+')'
                                                                                     ELSE  ''    END + CASE WHEN t.Nulo = 0 THEN '   NOT NULL' 
														                                                                    ELSE '   NULL'     END 
				   +CASE WHEN t.[Identity] <> 0 THEN ' Identity ('+ CONVERT(varchar(10),t.seed)+','+CONVERT(varchar(8000),t.Incremental)+')' 
							                    ELSE '' END 
	             ) 
				  <> 
				 ( 
				   UPPER(t2.Typeuser) + CASE WHEN t2.Typeuser in ('Varchar','Char')    THEN '('+ CONVERT(VARCHAR(4),LTRIM(RTRIM(t2.tamanho)))+')'
			                                 WHEN t2.Typeuser in ('Numeric','Decimal') THEN '('+CONVERT(VARCHAR(4),LTRIM(RTRIM(t2.[Precis�o])))+','+CONVERT(VARCHAR(4),LTRIM(RTRIM(t2.Escala)))+')'
                                                                                       ELSE  ''    END + CASE WHEN t2.Nulo = 0 THEN '   NOT NULL' 
														                                                                       ELSE '   NULL'     END 
				   +CASE WHEN t2.[Identity] <> 0 THEN ' Identity ('+ CONVERT(varchar(10),t2.seed)+','+CONVERT(varchar(8000),t2.Incremental)+')' 
							                     ELSE '' END 
				  ) 
			THEN '<>'
            ELSE '=' END AS Sinal2,
							                                      
	  UPPER(t2.Typeuser) + CASE WHEN t2.Typeuser in ('Varchar','Char')    THEN '('+ CONVERT(VARCHAR(4),LTRIM(RTRIM(t2.tamanho)))+')'
			                    WHEN t2.Typeuser in ('Numeric','Decimal') THEN '('+CONVERT(VARCHAR(4),LTRIM(RTRIM(t2.[Precis�o])))+','+CONVERT(VARCHAR(4),LTRIM(RTRIM(t2.Escala)))+')'
                                                                          ELSE  ''    END + CASE WHEN t2.Nulo = 0 THEN '   NOT NULL' 
																												  ELSE '   NULL'     END 
	  +CASE WHEN t2.[Identity] <> 0 THEN ' Identity ('+ CONVERT(varchar(10),t2.seed)+','+CONVERT(varchar(8000),t2.Incremental)+')' 
							        ELSE '' END as 'Campos na base "+@BASE2+"', CASE WHEN t.Replicado = 1 THEN 'S'
							                                                                             ELSE 'N' END as Replicado1, 
      CASE WHEN t.Replicado <> t2.Replicado THEN '<>'
											ELSE '=' END as Sinal3, CASE WHEN t2.Replicado = 1 THEN 'S'
																							   ELSE 'N' END as Replicado2 
                                      
FROM #Tabelas_Base1 t 
INNER JOIN #Tabelas_Base2 t2 on t.[Schema] = t2.[Schema] AND t.Tabela = t2.Tabela AND t.Campo = t2.Campo
WHERE (t.Codtypeuser <> t2.Codtypeuser) OR (t.Typeuser <> t2.Typeuser) OR (t.Codtype <> t2.Codtype) OR (t.[Type] <> t2.[Type]) OR 
      (t.Tamanho <> t2.Tamanho) OR (t.[Precis�o] <> t2.[Precis�o]) OR  (t.Escala <> t2.Escala) OR (t.[Identity] <> t2.[Identity]) OR 
      (t.Seed <> t2.Seed) OR (t.Replicado <> t2.Replicado) OR (t.Nulo <> t2.Nulo) OR (t.Ordem <> t2.Ordem)
order by t.tabela, t.Ordem


drop table #Tabelas_Base1
drop table #Tabelas_Base2
")



SET NOCOUNT OFF
SET QUOTED_IDENTIFIER ON
