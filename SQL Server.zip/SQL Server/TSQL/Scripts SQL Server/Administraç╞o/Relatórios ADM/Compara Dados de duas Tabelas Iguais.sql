ALTER PROCEDURE COMPARA_DADOS (@SERVIDOR1 VARCHAR(50), @BASE1 VARCHAR(30), @SERVIDOR2 VARCHAR(50), @BASE2 VARCHAR(30))AS   
SET NOCOUNT ON  
SET QUOTED_IDENTIFIER OFF  
  
EXEC ("declare @tb sysname, @col sysname, @cmd varchar(max),@tbant sysname  
       declare @tbsys table (Tabela sysname,CmdCampos varchar(max))  
/*  
set @serv1 = '[@SERVIDOR1]'  
set @base1 = '[@BASE1]'  
set @serv2 = '[@SERVIDOR2]'  
set @base2 = '[@BASE2]'  
*/  
set @cmd = ''  
  
declare reg cursor for select s3.name, s4.name from ["+@SERVIDOR1+"].["+@BASE1+"].dbo.sysindexkeys s1  
        inner join ["+@SERVIDOR1+"].["+@BASE1+"].dbo.sysindexes s2 on s1.id = s2.id and s1.indid =s2.indid          
        inner join ["+@SERVIDOR1+"].["+@BASE1+"].dbo.sysobjects s3 on s1.id = s3.id   
        inner join ["+@SERVIDOR1+"].["+@BASE1+"].dbo.syscolumns s4 on s4.id = s3.id and s1.colid = s4.colid   
             where s2.status <> 0  
        order by s3.name, s1.colid   
  
           
open reg  
fetch next from reg into @tb,@col  
set @tbant = @tb  
while @@fetch_status = 0  
 begin  
  if @tbant <> @tb  
   begin  
    set @cmd = ''  
    set @tbant = @tb  
   end  
     
  set @cmd = @cmd + 'a.' + @col + ' = b.' + @col+ ''+' AND '  
  
  insert into @tbsys select @tb,@cmd  
  
  fetch next from reg into @tb,@col  
  
 end  
  
close reg  
deallocate reg  
  
select 'select * from ["+@SERVIDOR1+"].["+@BASE1+"].dbo.'+tabela+' a where not exists (select * from ["+@SERVIDOR2+"].["+@BASE2+"].dbo.'+tabela+' b   
where '+substring (max(cmdcampos),1,len(max(cmdcampos))-3)+')'   
from @tbsys group by tabela order by tabela")  
  
  
SET NOCOUNT OFF  
SET QUOTED_IDENTIFIER ON


-- COMPARA_DADOS 'FRSRVDTC01','FIN_PIRACICABA_AV','FRSRVBDSQL02\SQLSIC1','EMPDCA'