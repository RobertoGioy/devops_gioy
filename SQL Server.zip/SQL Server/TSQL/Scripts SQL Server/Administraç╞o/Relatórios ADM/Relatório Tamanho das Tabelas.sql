declare @schemaname varchar(100), @tablename varchar(100), @table varchar(200)
create table #tabletemp (name varchar(100), nrows int, reserved varchar(30), data varchar(30), index_size varchar(30), unused varchar(30))

DECLARE TableCursor CURSOR LOCAL STATIC FOR	
select s.name, t.name from sys.tables t inner join sys.schemas s on t.schema_id = s.schema_id order by s.schema_id

OPEN TableCursor
FETCH NEXT FROM TableCursor INTO @schemaname, @tablename

WHILE @@FETCH_STATUS >= 0
BEGIN
	SET @table = @schemaname + '.' + @tablename
	
	insert #tabletemp
	EXEC sp_spaceused @table

	FETCH NEXT FROM TableCursor INTO @schemaname, @tablename
END
	
CLOSE TableCursor
DEALLOCATE TableCursor

select * from #tabletemp

drop table #tabletemp