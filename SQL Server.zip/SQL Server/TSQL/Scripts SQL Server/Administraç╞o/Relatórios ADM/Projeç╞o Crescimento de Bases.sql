SELECT 
	   [BASE]				  = A.BASE
	  ,[ANO]				  = A.ANO
	  ,[MES]				  = A.MES
	  ,[VOLUMETRIA_GB]		  = ROUND(A.TAMANHO/1024,2) 
	  ,[TAXA_CRESCIMENTO_GB]  =  
								CASE WHEN (A.TAMANHO - ISNULL(B.TAMANHO,0)) < 0 THEN 0 
								ELSE ROUND(((A.TAMANHO - ISNULL(B.TAMANHO,0))/1024),2) END
FROM (
SELECT 
	ROW_NUMBER() OVER(Partition By 0 Order by YEAR(Data), MONTH(Data)) LINHA,
	[Base],
	YEAR(Data) Ano
   ,MONTH(Data) Mes
   ,COUNT(DISTINCT DATA) Registros
   ,MAX(Total_MB) Tamanho
FROM [DBA_PerfMon].[dbo].[dbsizes]
WHERE Base Like  '%Sky%'
GROUP BY [Base],YEAR(Data), MONTH(Data)
) A
LEFT JOIN
(
SELECT 
	ROW_NUMBER() OVER(Partition By 0 Order by YEAR(Data), MONTH(Data))+ 1 LINHA,
	[Base],
	YEAR(Data) Ano
   ,MONTH(Data) Mes
   ,COUNT(DISTINCT DATA) Registros
   ,MAX(Total_MB) Tamanho
FROM [DBA_PerfMon].[dbo].[dbsizes]
WHERE Base Like  '%Sky%'
GROUP BY [Base],YEAR(Data), MONTH(Data)
) B ON A.LINHA=B.LINHA