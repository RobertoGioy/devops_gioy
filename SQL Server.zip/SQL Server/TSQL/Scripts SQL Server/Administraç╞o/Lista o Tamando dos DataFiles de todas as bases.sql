declare @database varchar(50)

create table #db_files (dbname varchar(50), fgname sysname, nrows bigint, datasize decimal(19,2), spaceused decimal(19,2), spacefree decimal(19,2), freepercent decimal(19,2))

declare dbcursor cursor local static for
select name from sys.databases where database_id > 6 and name not like 'Sky%' order by database_id

open dbcursor
fetch next from dbcursor into @database

while @@FETCH_STATUS = 0
begin
declare @sql nvarchar(max)

set @sql = '
use ' + @database + ';'

set @sql = @sql + '
with cte as (
select			filegroupName	= case when fg.name IS NULL then ds.name else fg.name end,
				nRows			= p.row_count
from			sys.dm_db_partition_stats p 
inner join		sys.indexes i on	p.index_id = i.index_id and p.object_id = i.object_id and i.index_id in (0,1)
inner join		sys.data_spaces ds on i.data_space_id = ds.data_space_id
left outer join sys.partition_schemes ps on	ps.data_space_id = i.data_space_id and ps.data_space_id = ds.data_space_id
left outer join	sys.destination_data_spaces dds on dds.partition_scheme_id = ps.data_space_id AND dds.destination_id = p.partition_number
left outer join sys.filegroups fg on fg.data_space_id = dds.data_space_id
),
cte2 as (
select		fg.name,
			dataSize	= CONVERT (Decimal(15,2),ROUND(sf.Size/128.000,2)),
			spaceUsed	= CONVERT (Decimal(15,2),ROUND(FILEPROPERTY(sf.Name,''SpaceUsed'')/128.000,2)),
			spaceFree	= CONVERT (Decimal(15,2),ROUND((sf.Size-FILEPROPERTY(sf.Name,''SpaceUsed''))/128.000,2))
from		sys.tables t 
inner join	sys.indexes i on t.object_id= i.object_id and i.index_id in (0,1)
inner join	sys.dm_db_partition_stats p on p.index_id = i.index_id and p.object_id = i.object_id and p.object_id = t.object_id
inner join	sys.partition_schemes ps on i.data_space_id = ps.data_space_id
inner join	sys.destination_data_spaces dds on ps.data_space_id = dds.partition_scheme_id
right join	sys.filegroups fg on fg.data_space_id = dds.data_space_id
left join	dbo.sysfiles sf on fg.data_space_id = sf.groupid
group by	sf.name,fg.name,
			CONVERT (Decimal(15,2),ROUND(sf.Size/128.000,2)),
			CONVERT (Decimal(15,2),ROUND(FILEPROPERTY(sf.Name,''SpaceUsed'')/128.000,2)),
			CONVERT (Decimal(15,2),ROUND((sf.Size-FILEPROPERTY(sf.Name,''SpaceUsed''))/128.000,2))
)
insert into #db_files
select	''' + convert(varchar,@database) + ''', filegroupName,
		sum(nRows),
		max(cte2.dataSize),
		max(cte2.spaceUsed),
		max(cte2.spaceFree),
		cast(max(cte2.spaceFree / cte2.dataSize) as decimal(19,2))
from	cte inner join cte2 on cte.filegroupName = cte2.name
group by cte2.name, filegroupName
order by filegroupName'

exec sp_executesql @sql

fetch next from dbcursor into @database

end

close dbcursor
deallocate dbcursor

select * from #db_files

drop table #db_files