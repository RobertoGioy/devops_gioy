Alter Table Insumos Disable Trigger All
Insert Into Insumos(Codemp, Codpro, Descricao, Tipo, Unid, Volven, Pvenda, Ppadrao, Ultpre, Ultcom, Codigo, Ativo, Pesliq, Pesbru, Mod3, Clafis, Incentivado, ClassProdutoDIEF, CodGeneroItem, CodEX, TipoItem, CodServico, CodEnquadramentoIPI, CodCombustivelANP, CodCat, CodEAN, MetCub)
Select '128', Codpro, Descricao, Tipo, Unid, Volven, Pvenda, Ppadrao, Ultpre, Ultcom, Codigo, Ativo, Pesliq, Pesbru, Mod3, Clafis, Incentivado, ClassProdutoDIEF, CodGeneroItem, CodEX, TipoItem, CodServico, CodEnquadramentoIPI, CodCombustivelANP, CodCat, CodEAN, MetCub
From [FRSRVBDSQL02\SQLSIC1].Atualiza_Cadastros.dbo.Insumos Where Codpro not In (Select Codpro From Insumos)
Alter Table Insumos Enable Trigger All

Alter Table Categoria Disable Trigger All
Insert Into Categoria(Codemp, Codcat, Descat, Ativo, Datinc, Marca, Seleciona, Codtip, Valoriza, Codpal)
Select '128', Codcat, Descat, Ativo, Datinc, Marca, Seleciona, Codtip, Valoriza, Codpal From [FRSRVBDSQL02\SQLSIC1].Atualiza_Cadastros.dbo.Categoria
Where Codcat Not In (Select Codcat From Categoria)
Alter Table Categoria Enable Trigger All


Select * From Insumos Where Codpro Like '96%'