/*Habilita Consulta Ad-Hoc*/
sp_configure 'show advanced options',1 --0
GO
reconfigure with override
GO
sp_configure 'Ad Hoc Distributed Queries',1 --0
GO
reconfigure with override


/*Cria o Link*/

EXEC master.dbo.sp_dropserver @server=N'ADSI', @droplogins='droplogins'

exec sp_addlinkedserver 'ADSI', 'Active Directory Services 2.5', 'ADsDSOObject', 'adsdatasource'

EXEC master.dbo.sp_addlinkedserver @server = N'ADSI', 
@srvproduct=N'Active Directory Services', @provider=N'ADsDSOObject',
@datasrc=N'E125S2.CATANDUVA.COM.BR'  --AKA the full computer name of the AD server

EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname=N'ADSI',
                                     @useself=N'False',
                                     @locallogin=NULL,
                                     @rmtuser=N'CATANDUVA\auditor',
                                     @rmtpassword='***'

/*Consulta*/                                     

select * from openquery
(
ADSI,'SELECT name, sn, street, l, st
FROM ''LDAP://CATANDUVA.COM.BR''
')                                     
---------
SELECT sAMAccountName as LoginName,givenName AS FirstName, sn AS LastName, name AS FullName, LastLogon AS LastLogin
FROM OPENQUERY( ADSI, 
     'SELECT sAMAccountName,givenname,sn, name,LastLogon
      FROM ''LDAP://DC=CATANDUVA,DC=COM,DC=BR''
      WHERE objectClass = ''user''')
GO



/*-----Lista os Grupos que o usuario � membro ------*/
DROP PROCEDURE dbo.GetLdapUserGroups 
CREATE PROCEDURE dbo.GetLdapUserGroups (@LdapUsername NVARCHAR(256)) AS 
BEGIN     
 DECLARE @Query NVARCHAR(1024), @Path NVARCHAR(1024)      
 SET @Query = 'SELECT @Path = distinguishedName 
                FROM OPENQUERY(ADSI, ''SELECT distinguishedName              
                                         FROM ''''LDAP://DC=fernandopolis,DC=com,DC=br''''             
                                        WHERE objectClass = ''''user'''' 
                                          AND sAMAccountName = ''''' + @LdapUsername + ''''''')'     
 EXEC SP_EXECUTESQL @Query, N'@Path NVARCHAR(1024) OUTPUT', @Path = @Path OUTPUT       
        SET @Query = 'SELECT name AS LdapGroup          
                        FROM OPENQUERY(ADSI,''SELECT name
                                                FROM ''''LDAP://DC=fernandopolis,DC=com,DC=br''''             
                                               WHERE objectClass=''''group'''' 
                                                 AND member=''''' + @Path + ''''''')         
                                               ORDER BY name'     
 EXEC SP_EXECUTESQL @Query  
END 

EXEC dbo.GetLdapUserGroups 'auditor'
/*-----------*/