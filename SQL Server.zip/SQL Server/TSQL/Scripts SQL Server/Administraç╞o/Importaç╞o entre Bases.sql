-- sp_msforeachtable ' alter table ? nocheck constraint all alter table ? disable trigger all'
-- sp_msforeachtable ' alter table ? check constraint all alter table ? enable trigger all'

-- RODAR NA [BASE_DESTINO] 
USE [BASE_DESTINO]
GO
set nocount on
declare @tb sysname, @col sysname, @cmd varchar(max),@tbant sysname
declare @tbsys table (Tabela sysname,CmdCampos varchar(max))

set @cmd = ''
declare reg cursor for

	select a.name,b.name from sysobjects a inner join syscolumns b on a.id = b.id 
			             where a.xtype = 'u' --and a.name in('Ativo','Empresas')
			                   and exists (select * from [BASE_ORIGEM].dbo.sysobjects c inner join [BASE_ORIGEM].dbo.sysindexes d on c.id=d.id 
			                                        where a.name = c.name and c.xtype = 'u' and d.rows>0)
							                                                         
							
			             order by a.name,b.colid
			             
open reg
fetch next from reg into @tb,@col
set @tbant = @tb
while @@fetch_status = 0
	begin
		if @tbant <> @tb
			begin
				set @cmd = ''
				set @tbant = @tb
			end
			
		set @cmd = @cmd + '' + @col + '' + ','

		insert into @tbsys select @tb,@cmd

		fetch next from reg into @tb,@col

	end

close reg
deallocate reg

select CASE WHEN objectpropertyex(object_id(Tabela),'TableHasIdentity') = 1 
			THEN 'SET IDENTITY_INSERT ' + Tabela + ' ON ' + char(13)
		    ELSE '' END + 'INSERT INTO [BASE_DESTINO].dbo.' + Tabela + '(' + left(max(CmdCampos),len(max(CmdCampos))-1) + ')' + char(13) + 
	             'SELECT ' +left(max(CmdCampos),len(max(CmdCampos))-1) + ' FROM [BASE_ORIGEM].dbo.' + Tabela + char(13) +  
	   CASE WHEN objectpropertyex(object_id(Tabela),'TableHasIdentity') = 1 
			THEN 'SET IDENTITY_INSERT ' + Tabela + ' OFF ' + char(13)
		    ELSE '' END + char(13) + 'GO' from @tbsys
group by Tabela-- having len(CmdCampos) = max(len(CmdCampos))

/*

sp_msforeachtable
'
alter table ? disable trigger all
alter table ? nocheck constraint all
'

update mov_faturas set tiplan = 0
update duplicata set tiplan = 0
update sobrafalta set tiplan = 0
update livrocaixa set tiplan = 0
GO

update a set a.datinc = m.datinc from apropria a inner join mov_faturas m on
a.codemp=m.codemp and a.numfat=m.numfat and a.numpar=m.numpar and a.codfor=m.codfor and a.tiplan=m.tiplan
GO

update b set b.datinc = a.datinc from baixa_cp b inner join apropria a on
a.codemp=b.codemp and a.numfat=b.numfat and a.numpar=b.numpar and a.codfor=b.codfor  and a.codred=b.codred and a.tiplan=b.tiplan
GO

update b set b.datinc = d.datinc from baixa_dpl b inner join duplicata d on 
b.codemp=d.codemp and b.numdup=d.numdup and b.codcli=d.codcli and b.numpar=d.nparc and b.tiplan=d.tiplan
GO

update b set b.datinc = d.datinc from ChequesTransf b inner join duplicata d on 
b.codemp=d.codemp and b.numdup=d.numdup and b.codcli=d.codcli and b.npar=d.nparc 
GO

update b set b.datinc = s.datinc from baixa_sobf b inner join sobrafalta s on
b.codemp=s.codemp and b.numdoc=s.numdoc
GO

update b set b.datlan = l.datlan from baixa_livcai b inner join livrocaixa l on
b.codemp=l.codemp and b.codcon=l.codcon and b.numdoc=l.numdoc
GO


sp_msforeachtable
'
alter table ? enable trigger all
alter table ? check constraint all
'
*/
