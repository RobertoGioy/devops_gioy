/*
	RESTAURAR UMA BASE SEM O LOG DE TRANSA��O
*/

EXEC sp_attach_single_file_db @dbname='UnearBeiContacts',
@physname='D:\MSSQLSERVER\Databases\UnearBeiContacts.mdf'
GO