


USE [master]
GO

SELECT 
DB_NAME(dbid) BASE,
fileid IDBASE,
[filename] ARQORI,
CASE WHEN filename LIke 'e:%' THEN
REPLACE(REVERSE(SUBSTRING(Reverse([filename]),CHARINDEX('\',Reverse([filename])),LEN([filename]))),REVERSE(SUBSTRING(Reverse([filename]),CHARINDEX('\',Reverse([filename])),LEN([filename]))),'D:\SQL2K8R2\MSSQL10_50.MSSQLSERVER\MSSQL\DBLOG\')
ELSE [filename] END DIRDEST,
CASE WHEN filename LIke 'e:%' THEN
REPLACE([filename],REVERSE(SUBSTRING(Reverse([filename]),CHARINDEX('\',Reverse([filename])),LEN([filename]))),'D:\SQL2K8R2\MSSQL10_50.MSSQLSERVER\MSSQL\DBLOG\')
ELSE [filename] END DIRNEW
INTO MOVFILES
FROM sys.sysaltfiles 
WHERE NOT DB_NAME(dbid) IS NULL
AND NOT DB_NAME(dbid) IN ('master','msdb','tempdb','msdb')
ORDER BY DB_NAME(dbid),fileid

GO
SELECT * FROM MOVFILES

GO

declare @BASE  sysname
declare reg2 cursor for

SELECT Distinct BASE FROM MOVFILES --WHERE BASE = 'AbrilPublicidadeUweb'
WHERE BASE IN (SELECT NAME FROM SYS.sysdatabases) 
open reg2 
fetch next  from reg2 into  @BASE 
while @@fetch_status = 0 
begin

EXEC
('
ALTER DATABASE ['+@BASE+'] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
EXEC master.dbo.sp_detach_db @dbname = N'''+@BASE+''', @keepfulltextindexfile=N''true''
')
        
fetch next from reg2 into @BASE 
end 
close reg2
deallocate reg2



GO


declare @ARQORI sysname, @DIRDEST sysname
declare reg2 cursor for

SELECT ARQORI, DIRDEST FROM MOVFILES WHERE ARQORI Like 'E:%' 
--AND BASE = 'AbrilPublicidadeUweb'

open reg2 
fetch next  from reg2 into  @ARQORI, @DIRDEST 
while @@fetch_status = 0 
begin

--PRINT(''+@ARQORI+'')

PRINT
('
Exec Master.dbo.Xp_cmdshell ''Copy '+@ARQORI + ' '+ @DIRDEST +' /n''
')
        
fetch next from reg2 into @ARQORI, @DIRDEST 
end 
close reg2
deallocate reg2







declare @ATTACH VARCHAR(MAX)
declare reg2 cursor for

SELECT 
'CREATE DATABASE [' + RTRIM(BASE) + '] ON ' + RTRIM(CAMPO) + ' FOR ATTACH;'
FROM (
SELECT 
	BASE, 
	CAMPO  = STUFF((SELECT ', (FILENAME = ''' + C.DIRNEW + ''')'  FROM (SELECT BASE, DIRNEW FROM MOVFILES)C WHERE A.BASE=C.BASE FOR XML PATH('')
					), 1, 2, '' )
	FROM (
SELECT BASE BASE  FROM MOVFILES 
--WHERE BASE = 'AbrilPublicidadeUweb'
)A
GROUP BY BASE
) TABELA



open reg2 
fetch next  from reg2 into  @ATTACH
while @@fetch_status = 0 
begin

PRINT
(''+@ATTACH +'')
        
fetch next from reg2 into @ATTACH
end 
close reg2
deallocate reg2


