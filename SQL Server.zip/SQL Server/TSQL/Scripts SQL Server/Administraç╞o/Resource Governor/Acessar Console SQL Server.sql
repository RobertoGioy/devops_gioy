1 - Pare o servi�o do mecanismo do SQL Server usando o gerenciador de configura��o.

2 - Abra um prompt de comando e navegue at� a pasta Binn da inst�ncia do SQL Server.
	EX: C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\Binn

3 - Inicie o SQL Server no modo de usu�rio �nico: para uma inst�ncia padr�o:
	PARA INSTANCIA PADR�O:
		*Sqlservr.exe -m -sMSSQLSERVER
	PARA INSTANCIA NOMEADA:
		*Sqlservr.exe -m -sCEBTV1491\SQL

4 - Abra outra janela de comando e se conectar � inst�ncia com sqlcmd. 
	Para uma inst�ncia padr�o:
		*sqlcmd-E
	Para uma inst�ncia nomeada:
		*sqlcmd -E -S 'machine name\instance name'

5 - Criar um SQL Login:
	CREATE LOGIN INVASOR WITH PASSWORD = 'P@$$w0rd1';
	GO

6 - Adicione o login para o grupo sysadmin:
	EXEC sp_addsrvrolemember [INVASOR], [sysadmin];
	GO

7 - Volte para a primeira janela de comando e parar a �nica inst�ncia do SQL modo de usu�rio, pressionando <ctrl> + <Break>


8 - Inicie o servi�o SQL Server como normal usando o gerenciador de configura��o, e fa�a login com sua conta de administrador de sistemas rec�m-criado.


No Query digite sp_helpsrvrolemember sysadmin

