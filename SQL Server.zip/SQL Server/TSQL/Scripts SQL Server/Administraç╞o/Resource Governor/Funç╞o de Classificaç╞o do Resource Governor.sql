USE [master]
GO

/****** Object:  UserDefinedFunction [dbo].[rgClassifier]    Script Date: 08/03/2012 14:59:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[rgClassifier]() RETURNS SYSNAME 
WITH SCHEMABINDING 
AS 
BEGIN 
	DECLARE @grp_name AS SYSNAME 
	
	IF (SUSER_NAME() = 'sa' OR SUSER_NAME() = 'BSPODBS02\Administrators') 
		SET @grp_name = 'GroupAdmin' 
	ELSE IF ((APP_NAME() LIKE '%MANAGEMENT STUDIO%') OR (APP_NAME() LIKE '%QUERY ANALYZER%') OR (APP_NAME() LIKE '%REPORT SERVER%')) AND (SUSER_NAME() <> 'sa')
		SET @grp_name = 'GroupDevelopers' 
	ELSE IF (SUSER_NAME() = 'ae') OR (SUSER_NAME() = 'userdb')
		SET @grp_name = 'GroupAppTests'
		
    RETURN @grp_name 
END 

GO
