
CREATE RESOURCE POOL [AdmServer] WITH (
	min_cpu_percent=0, 
	max_cpu_percent=30, 
	min_memory_percent=0, 
	max_memory_percent=30
)
GO

CREATE RESOURCE POOL [AppTests] WITH (
	min_cpu_percent=0, 
	max_cpu_percent=50, 
	min_memory_percent=0, 
	max_memory_percent=50
)
GO

CREATE RESOURCE POOL [Developers] WITH (
	min_cpu_percent=0, 
	max_cpu_percent=20, 
	min_memory_percent=0, 
	max_memory_percent=20
)
GO

CREATE WORKLOAD GROUP [GroupAdmin] WITH (
	group_max_requests=0, 
	importance=Medium, 
	request_max_cpu_time_sec=0, 
	request_max_memory_grant_percent=25, 
	request_memory_grant_timeout_sec=0, 
	max_dop=0
) USING [AdmServer]
GO

CREATE WORKLOAD GROUP [GroupAppTests] WITH (
	group_max_requests=0, 
	importance=High, 
	request_max_cpu_time_sec=0, 
	request_max_memory_grant_percent=25, 
	request_memory_grant_timeout_sec=0, 
	max_dop=0
) USING [AppTests]
GO

CREATE WORKLOAD GROUP [GroupDevelopers] WITH(
	group_max_requests=0, 
	importance=Low, 
	request_max_cpu_time_sec=0, 
	request_max_memory_grant_percent=25, 
	request_memory_grant_timeout_sec=0, 
	max_dop=0
) USING [Developers]
GO