
DROP TABLE #TB
GO
CREATE TABLE #TB (TABLE_QUALIFIER sysname,
  TABLE_OWNER sysname, 
  TABLE_NAME sysname, 
  COLUMN_NAME sysname, 
  KEY_SEQ int, 
  PK_NAME sysname)
GO
declare @tb sysname
declare reg cursor for
select name from sysobjects where xtype = 'U' order by name
open reg
fetch next from reg into @tb
while @@fetch_status = 0
begin
insert into #tb
exec sp_pkeys @tb
fetch next from reg into @tb
end
close reg
deallocate reg
select * from sysobjects a where not exists (select * from #TB b where
a.name = b.TABLE_NAME) and xtype = 'U'
order by name
