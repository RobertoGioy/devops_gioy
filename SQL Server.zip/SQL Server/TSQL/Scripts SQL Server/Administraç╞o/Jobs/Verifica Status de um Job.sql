
SELECT	j.name AS JobName,
		h.step_name AS StepName,
		CONVERT(CHAR(10), CAST(STR(h.run_date,8, 0) AS DATETIME), 120) + ' ' + 
		STUFF(STUFF(RIGHT('000000' + CAST (h.run_time AS VARCHAR(6)),6),5,0,':'),3,0,':') AS ExecutionTime,
		REPLICATE('0', 2 - LEN(run_duration / 3600)) + CAST((run_duration / 3600) AS VARCHAR) + ':' + 
		REPLICATE('0', 2 - LEN((run_duration % 3600) / 60)) + CAST(((run_duration % 3600) / 60) AS VARCHAR) + ':' + 
		REPLICATE('0', 2 - LEN((run_duration % 3600) % 60)) + CAST(((run_duration % 3600) % 60) AS VARCHAR) AS DurationTime,
		case h.run_status 
			when 0 then 'Falha'
			when 1 then 'Sucesso'
			when 2 then 'Retry'
			when 3 then 'Cancelado pelo usu�rio'
			when 4 then 'Em execu��o'
		end AS ExecutionStatus
FROM	msdb..sysjobhistory h inner join  msdb..sysjobs j 
ON		j.job_id = h.job_id
Where	j.Name = 'UMAILNG - MultiplusUnica - Integracao Unica'
AND		h.step_name <> '(Job outcome)'
AND		j.enabled = 1 
AND		H.run_date = '20140625'
ORDER BY j.name, h.run_date, h.run_time
      