SET QUOTED_IDENTIFIER OFF 

create table #tempx (Servidor Varchar(150), Base Varchar(150), empresa Varchar(150))

DECLARE @base sysname, @reg int, @tot int



set @tot = (select count(name) as Reg from sys.sysdatabases where not name in ('DC','DCGP','EMPDC','EMPDCGP','SPED','SIM','SIM_GP','Megasul','XMLINK','SL2000_ANTIGA2','SL2000_ANTIGA','SL2000_30','SL2000BTV_BK_K','SL2000PPR_BK','SL2000SLT_K_RESTORE','SL2000SMA_BK','SL2000SMA_CL_EG','FIS264_CL_JDIAS_09','JUNCAO289_816','FIS264_POLIBEER_BKP','SL2000_E369_NFE','HISTORICO_EMP647','SL2000_BKP_20100120','SL2000_NFE','SL2000_BKP2','SL2000_JUNCAO','SL2000_FISCAL','SL2000_1','SL2000_2','SL2000SCB_K_SCB','SL2000MGU_K_MGU','SL2000BTC_2009','SL2000BTC_2008','SL2000BAU_APOIO','SL2000_E267_M_2009A2011','FIS264_POLIBEER_BK','EMPDCA_RESTORE_OFFLINE','FRDCA_HISTORICO','T_SIC10_FISCAL','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') and not name like ('T_%') and not name like ('KAV%') and not version is null and not version = '0')

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where not name in ('DC','DCGP','EMPDC','EMPDCGP','SPED','SIM','SIM_GP','Megasul','XMLINK','SL2000_ANTIGA2','SL2000_ANTIGA','SL2000_30','SL2000BTV_BK_K','SL2000PPR_BK','SL2000SLT_K_RESTORE','SL2000SMA_BK','SL2000SMA_CL_EG','FIS264_CL_JDIAS_09','JUNCAO289_816','FIS264_POLIBEER_BKP','SL2000_E369_NFE','HISTORICO_EMP647','SL2000_BKP_20100120','SL2000_NFE','SL2000_BKP2','SL2000_JUNCAO','SL2000_FISCAL','SL2000_1','SL2000_2','SL2000SCB_K_SCB','SL2000MGU_K_MGU','SL2000BTC_2009','SL2000BTC_2008','SL2000BAU_APOIO','SL2000_E267_M_2009A2011','FIS264_POLIBEER_BK','EMPDCA_RESTORE_OFFLINE','FRDCA_HISTORICO','T_SIC10_FISCAL','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') and not name like ('T_%') and not name like ('KAV%') and not version is null and not version = '0') as t where t.reg  = @reg)
	EXEC ("use [" + @base + "]
	IF not (select OBJECT_ID ('sp_Duplicata_Marca_Inad')) IS NULL
		begin
			begin try
			
					DECLARE @jobId BINARY(16)
					select @jobId = job_id from msdb.dbo.sysjobs where (name = N'Atualiza SITINAD')
					if (@jobId is NULL)
						   BEGIN
							   EXEC ("" 
										DECLARE @jobId BINARY(16)
										select @jobId = job_id from msdb.dbo.sysjobs where (name = N'Atualiza SITINAD')
										
										DECLARE @ReturnCode INT
										SELECT @ReturnCode = 0
										
										EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Atualiza SITINAD', 
												@enabled=1, 
												@notify_level_eventlog=0, 
												@notify_level_email=0, 
												@notify_level_netsend=0, 
												@notify_level_page=0, 
												@delete_level=0, 
												@category_name=N'[Uncategorized (Local)]', 
												@owner_login_name=N'sa', @job_id = @jobId OUTPUT
										

										
										EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Agendamento', 
												@enabled=1, 
												@freq_type=4, 
												@freq_interval=1, 
												@freq_subday_type=1, 
												@freq_subday_interval=0, 
												@freq_relative_interval=0, 
												@freq_recurrence_factor=0, 
												@active_start_date=20140407, 
												@active_end_date=99991231, 
												@active_start_time=10000, 
												@active_end_time=235959
										
										EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
										
										

										EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'exec sp_Duplicata_Marca_Inad', 
												@step_id=1, 
												@cmdexec_success_code=0, 
												@on_success_action=1, 
												@on_success_step_id=0, 
												@on_fail_action=2, 
												@on_fail_step_id=0, 
												@retry_attempts=0, 
												@retry_interval=0, 
												@os_run_priority=0, @subsystem=N'TSQL', 
												@command=N'EXEC " + @base + ".dbo.sp_Duplicata_Marca_Inad', 
												@database_name=N'master', 
												@flags=0
										
										EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
										
								"") 
						   END	       
     					ELSE 
						BEGIN
							EXEC ("" 
									DECLARE @jobId2 BINARY(16)
										select @jobId2 = job_id from msdb.dbo.sysjobs where (name = N'Atualiza SITINAD')
									Declare @commandJobStep NVarchar(max)
											Set @commandJobStep = (Select ISNULL(Command,'') From msdb.dbo.sysjobsteps Where Job_id = @jobId2)

											Set @commandJobStep = (@commandJobStep  + Char(13) + Char(10) + 'EXEC ' + Db_name() + '.dbo.sp_Duplicata_Marca_Inad')
							
											EXEC msdb.dbo.sp_update_jobstep @job_id=@jobId2, @step_id=1 ,@command=@commandJobStep
									"")
						END
			
			
			INSERT into #tempx SELECT distinct @@servername as Servidor, ""[" + @base + "]"" as Base, '' as empresa 
			end try
	        begin catch
	       	    INSERT into #tempx SELECT distinct '(' + ERROR_MESSAGE() +') ' + @@servername as Servidor, ""[" + @base + "]"" as Base, '' as empresa
	        end catch
		END
	")
	set @reg = @reg + 1
	end

SELECT Servidor, Base, empresa FROM #tempx

Drop Table #tempx