DECLARE @MENSAGEM VARCHAR(MAX)
set @MENSAGEM = 
(
('Usuario Que Acessaram A Base T_SL2000_CL_CONT em ' + convert(varchar(10),Getdate(),20)+ ': ')
+
(Select Distinct Usuario From 
(Select Codemp Empresa, Nomlog Usuario, convert(varchar(10),Data,20) DataAcesso, Modulo From Ocorrencias Where Data>='2010-01-01'
	 Group By Codemp, Nomlog, Data, Modulo
	 Union All
	 Select Codemp Empresa, Nomlog Usuario, convert(varchar(10),Data,20) DataAcesso, Modulo From Ocorrencias_Acu Where Data>='2010-01-01'
	 Group By Codemp, Nomlog, Data, Modulo)A Where DataAcesso = '2010-10-07')
)
EXEC [172.17.7.3\SQL2008].msdb.dbo.sp_send_dbmail  
  @profile_name = 'SQL Mail',            
  @recipients = 'dba@grupoeouro.com.br',            
  @subject = 'Acesso � Base T_SL2000_CL_CONT',
  @body = @MENSAGEM
