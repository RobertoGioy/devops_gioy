SET QUOTED_IDENTIFIER OFF 

CREATE TABLE #tempx (Servidor Varchar(MAX), Base Varchar(MAX), empresa Varchar(MAX))

DECLARE @base sysname, @reg int, @tot int, @CMD1 VARCHAR(MAX), @CMD2 VARCHAR(MAX), @CMD3 VARCHAR(MAX), @CMD4 VARCHAR(MAX), 
@CMD5 VARCHAR(MAX), @CMD6 VARCHAR(MAX), @CMD7 VARCHAR(MAX), @CMD8 VARCHAR(MAX), @CMD9 VARCHAR(MAX), @CMD10 VARCHAR(MAX), 
@CMD11 VARCHAR(MAX), @CMD12 VARCHAR(MAX), @CMD13 VARCHAR(MAX), @CMD14 VARCHAR(MAX), @CMD15 VARCHAR(MAX), @CMD16 VARCHAR(MAX), 
@CMD17 VARCHAR(MAX), @CMD18 VARCHAR(MAX), @CMD19 VARCHAR(MAX), @CMD20 VARCHAR(MAX)



set @tot = (select count(name) as Reg from sys.sysdatabases where name in ('msdb'))

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where name in ('msdb')) as t where t.reg  = @reg)
	EXEC ("use [" + @base + "] 
     		INSERT into #tempx 
     		SELECT 
				 Servidor = @@SERVERNAME + ' - ' + RTRIM(Name)
				,Base = Convert(Date,Date_created)
				,empresa = 
						CASE WHEN DATEDIFF(YEAR,Convert(Date,Date_modified),Convert(Date,GETDATE())) >0 
									THEN RTRIM(DATEDIFF(YEAR,Convert(Date,Date_modified),Convert(Date,GETDATE()))) + RTRIM(' ANO(S)')
							 WHEN DATEDIFF(MONTH,Convert(Date,Date_modified),Convert(Date,GETDATE())) >0 
									THEN RTRIM(DATEDIFF(MONTH,Convert(Date,Date_modified),Convert(Date,GETDATE()))) + RTRIM(' M�S(S)')
							 WHEN DATEDIFF(DAY,Convert(Date,Date_modified),Convert(Date,GETDATE())) >0 
									THEN RTRIM(DATEDIFF(DAY,Convert(Date,Date_modified),Convert(Date,GETDATE()))) + RTRIM(' DIA(S)')
						END
			FROM 
			sysjobs 
			WHERE 
			[enabled] = 0
			Order by DATEDIFF(DAY,Convert(Date,Date_modified),Convert(Date,GETDATE())) Desc
	")
	set @reg = @reg + 1
	end
	
SELECT Servidor, Base, empresa FROM #tempx
Drop table #tempx




