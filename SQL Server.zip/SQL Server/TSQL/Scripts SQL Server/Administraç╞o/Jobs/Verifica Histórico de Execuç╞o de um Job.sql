
SELECT
      j.name as [Nome do Job],
      h.step_name [Nome do Passo],--um job pode ter diversos passos
      CONVERT(CHAR(10), CAST(STR(h.run_date,8, 0) AS dateTIME), 111) as [Data da Execu��o],
      STUFF(STUFF(RIGHT('000000' + CAST ( h.run_time AS VARCHAR(6 ) ) ,6),5,0,':'),3,0,':') as [Hora Execu��o],
      h.run_duration [Tempo de execu��o em segundos],
      cast((run_duration / 3600) as varchar) + ' horas ' + cast(((run_duration % 3600) / 60) as varchar) + ' minutos ' + cast(((run_duration % 3600) % 60) as varchar) + ' segundos'  [Tempo de execu��o Destalhado],
      case h.run_status when 0 then 'Falha'
            when 1 then 'Sucesso'
            when 2 then 'Retry'
            when 3 then 'Cancelado pelo usu�rio'
            when 4 then 'Em execu��o'
      end as [Status final da execu��o],
      h.message as [Mensagem da execu��o]
FROM
      msdb..sysjobhistory h
inner join  msdb..sysjobs j ON j.job_id = h.job_id
Where j.Name = 'UmailNG - PortoSeguro - Enviar Campanhas Gen�ricas'
AND h.step_name <> '(Job outcome)'
--J.enabled = 1 And H.run_date = '20140412'
ORDER BY
      j.name,
      h.run_date,
      h.run_time
      