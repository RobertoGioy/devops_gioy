SET NOCOUNT ON

CREATE TABLE #Espaco_Disco(Reg INT IDENTITY(1,1),Disco CHAR(01),Espa�o_Livre NUMERIC(18,2))

INSERT INTO #Espaco_Disco (Disco, Espa�o_Livre) EXEC XP_FIXEDDRIVES

DECLARE @Cont INT, @Texto VARCHAR(8000)
SET @Cont = 1
SELECT @Texto = 'SERVIDOR / INST�NCIA ------>  '+ @@SERVERNAME + CHAR(13) + CHAR (13)



WHILE (SELECT Reg FROM #Espaco_Disco WHERE Reg = @Cont) < (SELECT COUNT(*)FROM #Espaco_Disco)
	BEGIN
		IF (SELECT COUNT(*) FROM #Espaco_Disco WHERE Reg = @Cont AND Espa�o_Livre < 10240 AND Disco IN('P', 'Q')) > 0
			BEGIN
				
				SET @Texto = @Texto + (SELECT  'Espa�o Cr�tico no Disco '+Disco +'   Espa�o Livre =  '+ convert(varchar(10),convert(numeric(18,2),(Espa�o_Livre/1024)))+' GB 'from #Espaco_disco WHERE Reg = @Cont)+CHAR(13)
		        
			END

				SET @Cont = @Cont + 1

	END

IF (SELECT COUNT(*) FROM #Espaco_Disco WHERE Espa�o_Livre < 10240 AND Disco IN('P','Q')) > 0
	BEGIN

		EXEC [172.17.13.1].msdb.dbo.sp_send_dbmail  @profile_name = 'SQL Mail',
													@recipients = 'pdsantos@grupoeouro.com.br',
													@subject = 'Falta de Espa�o em Disco ',
													@body = @Texto
	END
	
DROP TABLE #Espaco_Disco


