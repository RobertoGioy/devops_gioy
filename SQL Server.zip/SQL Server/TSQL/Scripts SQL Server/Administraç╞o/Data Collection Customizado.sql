USE MSDB;

BEGIN TRY;

BEGIN TRANSACTION;

    DECLARE @collection_set_id INT
    EXEC [dbo].[sp_syscollector_create_collection_set]
        @name = N'Coletor de Desempenho',
        @collection_mode = 1,
        @description = N'Coletar dados para mensurar o desempenho',
        @days_until_expiration = 7,
        @collection_set_id = @collection_set_id OUTPUT

DECLARE @collector_type_uid UNIQUEIDENTIFIER
    = (SELECT TOP 1 collector_type_uid
        FROM [dbo].[syscollector_collector_types]
        WHERE name = N'Generic T-SQL Query Collector Type')

DECLARE @CollItemID INT

EXEC [dbo].[sp_syscollector_create_collection_item]
    @Name = N'Conex�es',
    @parameters = N'<ns:TSQLQueryCollector xmlns:ns="DataCollectorType">
            <Query>
                <Value>
                SELECT COUNT(*) As TotConexoes
                FROM sys.dm_exec_connections
                </Value>
                <OutputTable>Conexoes</OutputTable>
            </Query>
            <Databases UseSystemDatabases="false" UseUserDatabases="true"/>
        </ns:TSQLQueryCollector>',
    @collection_item_id = @CollItemID OUTPUT,
    @frequency = 15,
    @collection_set_id = @collection_set_id,
    @collector_type_uid = @collector_type_uid

SET @collector_type_uid = 
    (SELECT TOP 1 collector_type_uid
        FROM [dbo].[syscollector_collector_types]
        WHERE name = N'Generic SQL Trace Collector Type')

EXEC [dbo].[sp_syscollector_create_collection_item]
    @name = N'Eventos do Profiler',
    @parameters = N'<ns:SqlTraceCollector xmlns:ns="DataCollectorType" use_default="0">
        <Events>
            <EventType name="Stored Procedures">
                <Event id="10" name="RPC:Completed" columnslist="1,3,11,35,12,28,13" />
            </EventType>
            <EventType name="TSQL">
                <Event id="12" name="SQL:BatchCompleted" columnslist="1,3,11,35,12,28,13" />
                <Event id="13" name="SQL:BatchStarting" columnslist="1,3,11,35,12,28,13" />
            </EventType>
    </Events>
            <Filters>
                <Filter columnid="35" columnname="DatabaseName"
                    logical_operator="AND" comparison_operator="LIKE"
                    value="AdventureWorks"/>
            </Filters>
        </ns:SqlTraceCollector>',
    @collection_item_id = @CollItemID OUTPUT,
    @frequency = 15,
    @collection_set_id = @collection_set_id,
    @collector_type_uid = @collector_type_uid

SET @collector_type_uid = 
    (SELECT TOP 1 collector_type_uid
        FROM [dbo].[syscollector_collector_types]
        WHERE name = N'Performance Counters Collector Type')

EXEC [dbo].[sp_syscollector_create_collection_item]
    @name = N'Contadores do Perfmon',
    @parameters = N'
        <ns:PerformanceCountersCollector xmlns:ns="DataCollectorType">
            <PerformanceCounters Objects="Processor" Counters="% Processor Time" Instances="*"/>
            <PerformanceCounters Objects="$(INSTANCE):General Statistics" Counters="User Connections"/>
            <PerformanceCounters Objects="$(INSTANCE):SQL Statistics" Counters="Batch Requests/sec"/>
        </ns:PerformanceCountersCollector>',
    @collection_item_id = @CollItemID OUTPUT,
    @frequency = 15,
    @collection_set_id = @collection_set_id,
    @collector_type_uid = @collector_type_uid

COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE(),
        @ErrorSeverity INT = ERROR_SEVERITY(),
        @ErrorState INT = ERROR_STATE(),
        @ErrorNumber INT = ERROR_NUMBER(),
        @ErrorLine INT = ERROR_LINE(),
        @ErrorProcedure NVARCHAR(200) = ISNULL(ERROR_PROCEDURE(),'-')

    RAISERROR(14684,@ErrorSeverity,1,@ErrorNumber,@ErrorSeverity,@ErrorState,
            @ErrorProcedure, @ErrorLine, @ErrorMessage)

END CATCH
GO