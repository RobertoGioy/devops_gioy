Use SkyAnalysis

GO


Create Table Dir
(
Directory Varchar(200),
Expr1 int,
Expr2 Int
)
GO
Insert Into Dir
exec master.dbo.xp_dirtree 'C:\Temp\SRVTBUNE03\SkyAnalysis',2,1


GO

declare @Dir  sysname
declare reg2 cursor for

Select Directory  From Dir Where Directory Like '%.sql%'

open reg2 
fetch next  from reg2 into  @Dir 
while @@fetch_status = 0 
begin
		EXEC
		(
			'Exec Master.dbo.Xp_cmdshell ''sqlcmd -SBSPODBS02\QA -i C:\Temp\SRVTBUNE03\SkyAnalysis\'+ @Dir +''',''NO_OUTPUT'''
		)

fetch next from reg2 into @Dir 
end 
close reg2
deallocate reg2

GO

Drop table Dir