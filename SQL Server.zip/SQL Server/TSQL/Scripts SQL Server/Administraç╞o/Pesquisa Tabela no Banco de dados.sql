SET QUOTED_IDENTIFIER OFF
GO
SP_MSFOREACHDB 
"
USE [#]
--EXEC SP_MSFOREACHTABLE ' IF (SELECT ''?'') = ''[dbo].[a_bancocont]''
EXEC SP_MSFOREACHTABLE ' IF (SELECT ''?'') LIKE ''%a[_]bancocont%''
PRINT ''DROP TABLE [#].''+''?'''


"  , '#'







