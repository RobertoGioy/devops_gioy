SELECT
    SERVERPROPERTY('IsClustered') as _1_Eh_Clusterizada,
    SERVERPROPERTY('ComputerNamePhysicalNetBIOS') as NoAtual,
    SERVERPROPERTY('Edition') as Edicao,
    SERVERPROPERTY('MachineName') as VirtualName,
    SERVERPROPERTY('InstanceName') as NomeInstancia,
    SERVERPROPERTY('ServerName') as Virtual_e_InstanceNames,
    SERVERPROPERTY('ProductVersion') as Versao,
    SERVERPROPERTY('ProductLevel') as NomeVersaoSemHotfixes