create table #temp (Servidor Varchar(50), Base Varchar(50), empresa Varchar(50))


INSERT into #temp SELECT @@servername as Servidor, (select max(local_net_address) from sys.dm_exec_connections) as Base, '' as empresa

SELECT Servidor, Base, empresa FROM #temp
