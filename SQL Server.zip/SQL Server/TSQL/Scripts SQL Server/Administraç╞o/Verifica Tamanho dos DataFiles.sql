select	ds.name as filegroup, file_id, driver_letter=left(df.physical_name,1), df.physical_name, df.name as logical_name, df.type_desc, state_desc,
		max_size/128 as [maxsize (mb)],
		growth/128 as [growth (mb)],
		size/128 as [size (mb)],
		cast(FILEPROPERTY(df.name,'SpaceUsed') as int)/128 as [usedspace (mb)],
		(size/128)-cast(FILEPROPERTY(df.name,'SpaceUsed') as int)/128 as [freespace (mb)]
from	sys.database_files df left join sys.data_spaces ds
on		df.data_space_id = ds.data_space_id