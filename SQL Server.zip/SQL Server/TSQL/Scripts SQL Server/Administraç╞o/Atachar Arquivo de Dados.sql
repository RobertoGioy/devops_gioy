USE [master]   
GO 
CREATE DATABASE [T_EMP660] ON    
( FILENAME = N'C:\Arquivos de programas\Microsoft SQL Server\MSSQL10.MSSQLSERVER\MSSQL\DATA\T_EMP660.MDF' )
--( FILENAME = N'C:\Arquivos de programas\Microsoft SQL Server\MSSQL10.MSSQLSERVER\MSSQL\DATA\T_EMP660.LDF' )    
FOR ATTACH ;   


exec sp_attach_db database_name , 'd:\database_name.mdf' 

use master
Alter database T_EMP249 SET Recovery Full

Backup Log T_EMP249

DBCC SHRINKFILE (N'SL204_AVISTA_Log', 1)