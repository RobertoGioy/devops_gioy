use AdventureWorks
GO

--CRIA UM TRACE EM FORMATO TRC  - SEM AFETAR PERFORMANCE DO SERVIDOR
declare @traceid int, @tam bigint
set @tam = 20

exec sp_trace_create @traceid = @traceid  OUTPUT
				, @options = 2
                , @tracefile = N'c:\temp\TraceAdventureWorks'
			     ,@maxfilesize = @tam

select @traceid
GO

--VERIFICA OS TRACES EXISTENTES
Select * From fn_trace_getinfo(0)
GO

--ADICIONA EVENTOS AO TRACE
declare @chave bit
set @chave = 1 --ativa evento

--12,-- SQL:BatchCompleted
exec sp_trace_setevent @traceid = 2, @eventid =  12, @columnid = 1, @on= @chave  --textdata
exec sp_trace_setevent @traceid = 2, @eventid =  12, @columnid = 8, @on= @chave  --hostname
exec sp_trace_setevent @traceid = 2, @eventid =  12, @columnid = 11, @on= @chave --loginname
exec sp_trace_setevent @traceid = 2, @eventid =  12, @columnid = 12, @on= @chave --spid
exec sp_trace_setevent @traceid = 2, @eventid =  12, @columnid = 13, @on= @chave --duration
exec sp_trace_setevent @traceid = 2, @eventid =  12, @columnid = 14, @on= @chave --starttime
exec sp_trace_setevent @traceid = 2, @eventid =  12, @columnid = 15, @on= @chave --endtime
exec sp_trace_setevent @traceid = 2, @eventid =  12, @columnid = 16, @on= @chave --reads
exec sp_trace_setevent @traceid = 2, @eventid =  12, @columnid = 17, @on= @chave --writes
exec sp_trace_setevent @traceid = 2, @eventid =  12, @columnid = 18, @on= @chave --cpu
exec sp_trace_setevent @traceid = 2, @eventid =  12, @columnid = 48, @on= @chave --rowcount


--10,-- RPC:Completed
--exec sp_trace_setevent @traceid = 2, @eventid =  10, @columnid = 1, @on = @chave --textdata
exec sp_trace_setevent @traceid = 2, @eventid =  10, @columnid = 8, @on= @chave  --hostname
exec sp_trace_setevent @traceid = 2, @eventid =  10, @columnid = 11, @on= @chave --loginname
exec sp_trace_setevent @traceid = 2, @eventid =  10, @columnid = 12, @on= @chave --spid
exec sp_trace_setevent @traceid = 2, @eventid =  10, @columnid = 13, @on= @chave --duration
exec sp_trace_setevent @traceid = 2, @eventid =  10, @columnid = 14, @on= @chave --starttime
exec sp_trace_setevent @traceid = 2, @eventid =  10, @columnid = 15, @on= @chave --endtime
exec sp_trace_setevent @traceid = 2, @eventid =  10, @columnid = 16, @on= @chave --reads
exec sp_trace_setevent @traceid = 2, @eventid =  10, @columnid = 17, @on= @chave --writes
exec sp_trace_setevent @traceid = 2, @eventid =  10, @columnid = 18, @on= @chave --cpu
exec sp_trace_setevent @traceid = 2, @eventid =  10, @columnid = 48, @on= @chave --rowcount

--33,-- Exception
exec sp_trace_setevent @traceid = 2, @eventid =  33, @columnid = 1, @on= @chave  --textdata
exec sp_trace_setevent @traceid = 2, @eventid =  33, @columnid = 8, @on= @chave  --hostname
exec sp_trace_setevent @traceid = 2, @eventid =  33, @columnid = 11, @on= @chave --loginname
exec sp_trace_setevent @traceid = 2, @eventid =  33, @columnid = 12, @on= @chave --spid
exec sp_trace_setevent @traceid = 2, @eventid =  33, @columnid = 13, @on= @chave --duration
exec sp_trace_setevent @traceid = 2, @eventid =  33, @columnid = 14, @on= @chave --starttime
exec sp_trace_setevent @traceid = 2, @eventid =  33, @columnid = 15, @on= @chave --endtime
exec sp_trace_setevent @traceid = 2, @eventid =  33, @columnid = 16, @on= @chave --reads
exec sp_trace_setevent @traceid = 2, @eventid =  33, @columnid = 17, @on= @chave --writes
exec sp_trace_setevent @traceid = 2, @eventid =  33, @columnid = 18, @on= @chave --cpu
exec sp_trace_setevent @traceid = 2, @eventid =  33, @columnid = 48, @on= @chave --rowcount
GO
 
--EXECUTAR O TRACE
EXEC sp_trace_setstatus  @traceid = 2 ,    @status = 1  --Liga o Trace
--EXEC sp_trace_setstatus  @traceid = 2 ,    @status = 0  --Desliga o Trace
--EXEC sp_trace_setstatus  @traceid = 2 ,    @status = 1  --Desliga e Desativa o Trace

GO


USE AdventureWorks;
GO

SELECT spid,hostname, loginname, EventClass, textdata,  reads, writes, cpu, rowcounts, duration, starttime, endtime
	INTO t_Trace
FROM fn_trace_gettable('c:\temp\TraceAdventureWorks.trc', default);
where eventclass in (10,12,33)
GO

select * from t_Trace
GO

