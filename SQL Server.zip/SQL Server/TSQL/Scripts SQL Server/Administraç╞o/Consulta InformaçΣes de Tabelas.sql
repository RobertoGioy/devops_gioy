Select
'Insert Into #Inf_Limpeza Select Db_Name() As Base,
@@ServerName As Servidor, '
+ ''''+Rtrim(A.Name)+''''+' As Tabela, '
+'Min('+Rtrim(B.Name)+') As Data_Minima,
Max('+Rtrim(B.Name)+') As Data_Maxima From '
+USER_NAME(C.Principal_id)+'.'+Rtrim(A.Name) 
From SysObjects A
Inner Join Syscolumns B On A.Id=B.Id
Inner Join Sys.Schemas C On A.Uid=C.Principal_Id
Where A.Xtype = 'U' And B.Xtype = '61'
And A.Name ='INTER_TRAF'


Drop Table #Inf_Limpeza

Create Table #Inf_Limpeza(
       Base Char(100),
       Servidor Char(100),
       Tabela Char(100),
       Data_Minima Datetime,
       Data_Maxima Datetime)


Select 
Base, Servidor, Tabela, Min(Data_MInima) Data_MInima, Max(Data_Maxima) Data_Maxima
From #Inf_Limpeza
Where Not Data_Minima Is Null
Group By Base, Servidor, Tabela
Order By Data_Minima



Select Db_Name() As Base,  @@ServerName As Servidor, 'INTER_TRAF' As Tabela, Min(INT_DTMOD) As Data_Minima,  Max(INT_DTMOD) As Data_Maxima From dbo.INTER_TRAF