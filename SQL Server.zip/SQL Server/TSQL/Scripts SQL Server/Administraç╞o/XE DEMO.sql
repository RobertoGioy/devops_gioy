--PACKAGES
SELECT
	name,
	[description]
FROM
	sys.dm_xe_packages


--EVENTS
SELECT
	name,
	[description]
FROM 
	sys.dm_xe_objects 
WHERE 
	object_type = 'event'
order by 
	name


--EVENT FIELDS
SELECT
	c.name, 
	c.[description]
FROM
	sys.dm_xe_object_columns c
INNER JOIN
	sys.dm_xe_objects o 
ON
	o.name= c.object_name
WHERE
	o.name = 'sql_statement_starting'


--ACTIONS
SELECT 
	name, 
	[description] 
FROM 
	sys.dm_xe_objects 
WHERE 
	object_type = 'action' 
AND
	capabilities_desc IS NULL
ORDER BY 
	name

--Cria��o de uma session para processos bloqueados
CREATE EVENT SESSION [BlockedProcess] ON SERVER 
ADD EVENT 
	sqlserver.blocked_process_report(
	ACTION(
			sqlserver.client_app_name,
			sqlserver.client_hostname,
			sqlserver.database_name)),
ADD EVENT 
	sqlserver.xml_deadlock_report(
    ACTION(
			sqlserver.client_app_name,
			sqlserver.client_hostname,
			sqlserver.database_name)) 
ADD TARGET 
	package0.event_file(SET filename=N'C:\XE\BlockedProcess.xel')
GO

--Diminuindo tempo de timeout
EXEC sys.sp_configure N'show advanced options', N'1'  RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'blocked process threshold (s)', N'5'
GO
RECONFIGURE WITH OVERRIDE


--Extraindo informa��o do arquivo XEL
WITH events_cte AS (
  SELECT
    xevents.event_data,
    DATEADD(mi,
    DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP),
    xevents.event_data.value(
      '(event/@timestamp)[1]', 'datetime2')) AS [event time] ,
    xevents.event_data.value(
      '(event/action[@name="client_app_name"]/value)[1]', 'nvarchar(128)')
      AS [client app name],
    xevents.event_data.value(
      '(event/action[@name="client_hostname"]/value)[1]', 'nvarchar(max)')
      AS [client host name],
    xevents.event_data.value(
      '(event[@name="blocked_process_report"]/data[@name="database_name"]/value)[1]', 'nvarchar(max)')
      AS [database name],
    xevents.event_data.value(
      '(event[@name="blocked_process_report"]/data[@name="database_id"]/value)[1]', 'int')
      AS [database_id],
    xevents.event_data.value(
      '(event[@name="blocked_process_report"]/data[@name="object_id"]/value)[1]', 'int')
      AS [object_id],
    xevents.event_data.value(
      '(event[@name="blocked_process_report"]/data[@name="index_id"]/value)[1]', 'int')
      AS [index_id],
    xevents.event_data.value(
      '(event[@name="blocked_process_report"]/data[@name="duration"]/value)[1]', 'bigint') / 1000
      AS [duration (ms)],
    xevents.event_data.value(
      '(event[@name="blocked_process_report"]/data[@name="lock_mode"]/text)[1]', 'varchar')
      AS [lock_mode],
    xevents.event_data.value(
      '(event[@name="blocked_process_report"]/data[@name="login_sid"]/value)[1]', 'int')
      AS [login_sid],
    xevents.event_data.query(
      '(event[@name="blocked_process_report"]/data[@name="blocked_process"]/value/blocked-process-report)[1]')
      AS blocked_process_report,
    xevents.event_data.query(
      '(event/data[@name="xml_report"]/value/deadlock)[1]')
      AS deadlock_graph
  FROM    sys.fn_xe_file_target_read_file
    ('C:\TRACE\BlockedProcess*.xel',
     'C:\TRACE\BlockedProcess*.xem',
     null, null)
    CROSS APPLY (SELECT CAST(event_data AS XML) AS event_data) as xevents
)
SELECT
  CASE WHEN blocked_process_report.value('(blocked-process-report[@monitorLoop])[1]', 'nvarchar(max)') IS NULL
       THEN 'Deadlock'
       ELSE 'Blocked Process'
       END AS ReportType,
  [event time],
  CASE [client app name] WHEN '' THEN ' -- N/A -- '
                         ELSE [client app name]
                         END AS [client app _name],
  CASE [client host name] WHEN '' THEN ' -- N/A -- '
                          ELSE [client host name]
                          END AS [client host name],
  [database name],
  COALESCE(OBJECT_SCHEMA_NAME(object_id, database_id), ' -- N/A -- ') AS [schema],
  COALESCE(OBJECT_NAME(object_id, database_id), ' -- N/A -- ') AS [table],
  index_id,
  [duration (ms)],
  lock_mode,
  COALESCE(SUSER_NAME(login_sid), ' -- N/A -- ') AS username,
  CASE WHEN blocked_process_report.value('(blocked-process-report[@monitorLoop])[1]', 'nvarchar(max)') IS NULL
       THEN deadlock_graph
       ELSE blocked_process_report
       END AS Report
FROM events_cte
ORDER BY [event time] DESC ;


----Criando uma sess�o para erros 
CREATE EVENT SESSION
   QueryErrors
ON SERVER
ADD EVENT sqlserver.error_reported
(
    ACTION (sqlserver.sql_text, sqlserver.tsql_stack, sqlserver.database_id, sqlserver.username)
    WHERE ([severity]> 10)
)
ADD TARGET package0.asynchronous_file_target
(set filename = 'C:\XE\QueryErrors.xel' ,
    metadatafile = 'C:\XE\QueryErrors.xem',
    max_file_size = 5,
    max_rollover_files = 5)
WITH (MAX_DISPATCH_LATENCY = 5SECONDS)
GO
 
-- Iniciando a sess�o
ALTER EVENT SESSION QueryErrors
    ON SERVER STATE = START
GO

--For�ando um erro
USE AdventureWorks2012;
GO
SELECT * FROM Person.Person WHERE ModifiedDate='20aaa';
GO


--Visualizando a lista de erros
;with events_cte as(
    select
        DATEADD(mi,
        DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP),
        xevents.event_data.value('(event/@timestamp)[1]', 'datetime2')) AS [err_timestamp],
        xevents.event_data.value('(event/data[@name="severity"]/value)[1]', 'bigint') AS [err_severity],
        xevents.event_data.value('(event/data[@name="error_number"]/value)[1]', 'bigint') AS [err_number],
        xevents.event_data.value('(event/data[@name="message"]/value)[1]', 'nvarchar(512)') AS [err_message],
       xevents.event_data.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(max)') AS [sql_text],
        xevents.event_data
    from sys.fn_xe_file_target_read_file
    ('C:\XE\QueryErrors*.xel',
    'C:\XE\QueryErrors*.xem',
    null, null)
    cross apply (select CAST(event_data as XML) as event_data) as xevents
)
SELECT *
from events_cte
order by err_timestamp;


--Criando uma session para detalhes de performance
CREATE EVENT SESSION [QueryPerformance] ON SERVER 
ADD EVENT sqlos.wait_info(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_id,sqlserver.database_name,
	sqlserver.plan_handle,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id,sqlserver.sql_text)
    WHERE ([package0].[greater_than_uint64]([sqlserver].[database_id],(7)) AND [package0].[equal_boolean]([sqlserver].[is_system],(0)))),
ADD EVENT sqlserver.sp_statement_completed(SET collect_object_name=(1),collect_statement=(1)
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_id,sqlserver.database_name,
	sqlserver.plan_handle,sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id)
    WHERE ([package0].[greater_than_uint64]([sqlserver].[database_id],(7)) AND [package0].[equal_boolean]([sqlserver].[is_system],(0)))),
ADD EVENT sqlserver.sql_statement_completed(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_id,sqlserver.database_name,sqlserver.plan_handle,
	sqlserver.query_hash,sqlserver.query_plan_hash,sqlserver.session_id)
    WHERE ([package0].[greater_than_uint64]([sqlserver].[database_id],(7)) AND [package0].[equal_boolean]([sqlserver].[is_system],(0)))) 
ADD TARGET package0.event_file(SET filename=N'C:\XE\queryperformance.xel',max_file_size=(64),max_rollover_files=(5),
metadatafile=N'C:\XE\queryperformance.xem')
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=5 SECONDS,MAX_EVENT_SIZE=0 KB,
MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO
ALTER EVENT SESSION query_performance ON SERVER 
STATE = START;
GO

--Visualizando os dados coletados
CREATE TABLE xevents (
       event_time DATETIME2,
       event_type NVARCHAR(128),
       query_hash decimal(38,0),
       event_data XML
);
GO
INSERT INTO xevents (event_time, event_type, query_hash, event_data)
SELECT  DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), x.event_data.value('(event/@timestamp)[1]', 'datetime2')) AS event_time,
       x.event_data.value('(/event/@name)[1]', 'nvarchar(max)'),
       x.event_data.value('(event/action[@name="query_hash"])[1]', 'decimal(38,0)'),
       x.event_data
FROM    sys.fn_xe_file_target_read_file ('C:\XE\queryperformance*.xel', 'C:\XE\queryperformance*.xem', null, null)
           CROSS APPLY (SELECT CAST(event_data AS XML) AS event_data) as x ;
GO
SELECT  DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), x.event_data.value('(event/@timestamp)[1]', 'datetime2')) AS event_time,
       DATEADD(MINUTE, DATEDIFF(MINUTE, 0, event_time), 0) AS event_interval,
       x.event_data.value('(event/action[@name="query_hash"])[1]', 'decimal(38,0)') AS query_hash,
       x.event_data.value('(event/action[@name="query_plan_hash"])[1]', 'decimal(38,0)') AS query_plan_hash,
       x.event_data.value('(event/action[@name="session_id"])[1]', 'int') AS session_id,
       x.event_data.value('(event/action[@name="client_hostname"])[1]', 'nvarchar(max)') AS client_hostname,
       x.event_data.value('(event/action[@name="database_name"])[1]', 'nvarchar(max)') AS database_name,
       x.event_data.value('(event/action[@name="sql_text"])[1]', 'nvarchar(max)') AS statement,
       x.event_data.value('(event/data[@name="wait_type"]/text)[1]', 'nvarchar(max)') AS wait_type,
       x.event_data.value('(event/data[@name="duration"])[1]', 'int') AS duration_ms,
       x.event_data.value('(event/data[@name="signal_duration"])[1]', 'int') AS signal_duration_ms
FROM    xevents AS x 
WHERE   x.query_hash > 0
       AND x.event_type = 'wait_info';
GO 
SELECT  
       DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), x.event_data.value('(event/@timestamp)[1]', 'datetime2')) AS event_time,
       DATEADD(MINUTE, DATEDIFF(MINUTE, 0, event_time), 0) AS event_interval,
       x.event_data.value('(event/action[@name="query_hash"])[1]', 'decimal(38,0)') AS query_hash,
       x.event_data.value('(event/action[@name="query_plan_hash"])[1]', 'decimal(38,0)') AS query_plan_hash,
       x.event_data.value('(event/action[@name="session_id"])[1]', 'int') AS session_id,
       x.event_data.value('(event/action[@name="client_hostname"])[1]', 'nvarchar(max)') AS client_hostname,
       x.event_data.value('(event/action[@name="database_name"])[1]', 'nvarchar(max)') AS database_name,
       x.event_data.value('(event/data[@name="statement"])[1]', 'nvarchar(max)') AS statement,
       x.event_data.value('(event/data[@name="duration"])[1]', 'int') AS duration_ms,
       x.event_data.value('(event/data[@name="cpu_time"])[1]', 'int') AS cpu_time_ms,
       x.event_data.value('(event/data[@name="physical_reads"])[1]', 'int') AS physical_reads,
       x.event_data.value('(event/data[@name="logical_reads"])[1]', 'int') AS logical_reads,
       x.event_data.value('(event/data[@name="writes"])[1]', 'int') AS writes,
       x.event_data.value('(event/data[@name="row_count"])[1]', 'int') AS row_count
FROM   xevents AS x
WHERE  x.query_hash > 0
       AND (x.event_type = 'sp_statement_completed' OR x.event_type = 'sql_statement_completed') ;