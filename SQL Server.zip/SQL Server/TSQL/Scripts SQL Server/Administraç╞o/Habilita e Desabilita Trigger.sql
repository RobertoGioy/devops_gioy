SET QUOTED_IDENTIFIER OFF 

DECLARE @CMD1 VARCHAR(MAX), @CMD2 VARCHAR(MAX), @CMD3 VARCHAR(MAX), @CMD4 VARCHAR(MAX)

DECLARE @base sysname, @reg int, @tot int

create table #temp (Servidor Varchar(max), Base Varchar(max), empresa Varchar(max))
create table #temp1 (Base1 Varchar(max))


SET @CMD1 = 
"
ALTER TABLE PRODUTOS DISABLE TRIGGER ALL
"

SET @CMD2 = 
"

IF (Select Count(*) From Sys.Indexes Where Name = 'IDX_PRODUTOS')>0
begin
Drop Index IDX_PRODUTOS On Produtos 
CREATE CLUSTERED  INDEX IDX_PRODUTOS
    ON Produtos ( Codemp,CodPro )
    WITH (PAD_INDEX = ON,  FILLFACTOR = 90)
End
Else
Begin
CREATE CLUSTERED  INDEX IDX_PRODUTOS
    ON Produtos ( Codemp,CodPro )
    WITH (PAD_INDEX = ON,  FILLFACTOR = 90)
End
"

SET @CMD3 = 
"
ALTER TABLE PRODUTOS ENABLE TRIGGER ALL
"


set @tot = (select count(name) as Reg from sys.sysdatabases where not name in ('EMPDCA','EMPDCAB','FRDCA','DC','ATUALIZA_CADASTROS','SL2000_ANTIGA2','SL2000_ANTIGA','SL2000_30','SL2000BTV_BK_K','SL2000PPR_BK','SL2000SLT_K_RESTORE','SL2000SMA_BK','SL2000SMA_CL_EG','FIS264_CL_JDIAS_09','SL2000BRU_ASSP','JUNCAO289_816','FIS264_POLIBEER_BKP','SL2000_E369_NFE','HISTORICO_EMP647','SL2000_BKP_20100120','SL2000_NFE','SL2000_BKP2','SL2000_JUNCAO','SL2000_FISCAL','SL2000_1','SL2000_2','SL2000SCB_K_SCB','SL2000MGU_K_MGU','SL2000BTC_2009','SL2000BTC_2008','SL2000BAU_APOIO','SL2000_E267_M_2009A2011','FIS264_POLIBEER_BK','EMPDCA_RESTORE_OFFLINE','FRDCA_HISTORICO','ATUALIZA_CADASTROS','T_SIC10_FISCAL','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','EMPDCA','EMPDCAB','DC','FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') and not name like ('T_%'))

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where not name in ('EMPDCA','EMPDCAB','FRDCA','DC','ATUALIZA_CADASTROS','SL2000_ANTIGA2','SL2000_ANTIGA','SL2000_30','SL2000BTV_BK_K','SL2000PPR_BK','SL2000SLT_K_RESTORE','SL2000SMA_BK','SL2000SMA_CL_EG','FIS264_CL_JDIAS_09','SL2000BRU_ASSP','JUNCAO289_816','FIS264_POLIBEER_BKP','SL2000_E369_NFE','HISTORICO_EMP647','SL2000_BKP_20100120','SL2000_NFE','SL2000_BKP2','SL2000_JUNCAO','SL2000_FISCAL','SL2000_1','SL2000_2','SL2000SCB_K_SCB','SL2000MGU_K_MGU','SL2000BTC_2009','SL2000BTC_2008','SL2000BAU_APOIO','SL2000_E267_M_2009A2011','FIS264_POLIBEER_BK','EMPDCA_RESTORE_OFFLINE','FRDCA_HISTORICO','ATUALIZA_CADASTROS','T_SIC10_FISCAL','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','EMPDCA','EMPDCAB','DC','FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') and not name like ('T_%')) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
	IF not (select OBJECT_ID ('Mov_Estoque2')) IS NULL and not (select OBJECT_ID ('Produtos')) IS NULL and not (select OBJECT_ID ('empresas')) IS NULL
	if (select count(*) from sysobjects o inner join syscolumns c on o.id = c.id where o.name = 'Config' and c.name = 'Terc' ) > 0
	exec('if (select count(*) from config where terc <> ''C'') > 0
		INSERT into #temp1 SELECT ""[" + @base + "]"" ')
	")
	set @reg = @reg + 1
	end

update #temp1 set base1 = replace(replace(base1,'[',''),']','')


set @tot = (select count(name) as Reg from sys.sysdatabases
		where name in (select base1 from #Temp1) and not name in ('EMPDCA','EMPDCAB','FRDCA','DC','ATUALIZA_CADASTROS','SL2000_ANTIGA2','SL2000_ANTIGA','SL2000_30','SL2000BTV_BK_K','SL2000PPR_BK','SL2000SLT_K_RESTORE','SL2000SMA_BK','SL2000SMA_CL_EG','FIS264_CL_JDIAS_09','SL2000BRU_ASSP','JUNCAO289_816','FIS264_POLIBEER_BKP','SL2000_E369_NFE','HISTORICO_EMP647','SL2000_BKP_20100120','SL2000_NFE','SL2000_BKP2','SL2000_JUNCAO','SL2000_FISCAL','SL2000_1','SL2000_2','SL2000SCB_K_SCB','SL2000MGU_K_MGU','SL2000BTC_2009','SL2000BTC_2008','SL2000BAU_APOIO','SL2000_E267_M_2009A2011','FIS264_POLIBEER_BK','EMPDCA_RESTORE_OFFLINE','FRDCA_HISTORICO','ATUALIZA_CADASTROS','T_SIC10_FISCAL','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','EMPDCA','EMPDCAB','DC','FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') and not name like ('T_%'))
				
set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where name in (select base1 from #Temp1) and  not name in ('SL2000_ANTIGA2','SL2000_ANTIGA','SL2000_30','SL2000BTV_BK_K','SL2000PPR_BK','SL2000SLT_K_RESTORE','SL2000SMA_BK','SL2000SMA_CL_EG','FIS264_CL_JDIAS_09','SL2000BRU_ASSP','JUNCAO289_816','FIS264_POLIBEER_BKP','SL2000_E369_NFE','HISTORICO_EMP647','SL2000_BKP_20100120','SL2000_NFE','SL2000_BKP2','SL2000_JUNCAO','SL2000_FISCAL','SL2000_1','SL2000_2','SL2000SCB_K_SCB','SL2000MGU_K_MGU','SL2000BTC_2009','SL2000BTC_2008','SL2000BAU_APOIO','SL2000_E267_M_2009A2011','FIS264_POLIBEER_BK','EMPDCA_RESTORE_OFFLINE','FRDCA_HISTORICO','ATUALIZA_CADASTROS','T_SIC10_FISCAL','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','EMPDCA','EMPDCAB', 'DC', 'FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%') and not name like ('T_%')) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
		IF not (select OBJECT_ID ('mov_estoque2')) IS NULL and not (select OBJECT_ID ('Produtos')) IS NULL and not (select OBJECT_ID ('empresas')) IS NULL 
			begin
				begin try
						EXEC (""" + @CMD1 + """) 
						EXEC (""" + @CMD2 + """) 
						EXEC (""" + @CMD3 + """)
      					INSERT into #temp SELECT distinct @@servername as Servidor, ""[" + @base + "]"" as Base, '' as empresa
				end try
				begin catch
       				INSERT into #temp SELECT distinct '(' + ERROR_MESSAGE() +') ' + @@servername as Servidor, ""[" + @base + "]"" as Base, '' as empresa
				end catch
			end	
	")
	
	set @reg = @reg + 1
	end
	

SELECT Servidor, Base, empresa FROM #temp

            


/*
Select * from Importa_Metas_Novas


Alter Table  CLUSTERED

CREATE PRIMARY KEY CLUSTERED  PK_Importa_Metas_Novas
    ON Importa_Metas_Novas ( Codemp,Codcat, Datmov )
    WITH (PAD_INDEX = ON,  FILLFACTOR = 90)

Sp_help Importa_Metas_Novas

Alter Table Importa_Metas_Novas Alter Column Codcat Int Not Null
Alter Table Importa_Metas_Novas Alter Column Datmov Datetime Not Null
    
Alter Table Importa_Metas_Novas Add Constraint PK_Importa_Metas_Novas Primary Key Clustered (Codemp,Codcat, Datmov) 

Select * From Importa_Metas_Novas Where datmov Is Null
*/