SET NOCOUNT ON;

WITH DB_CPU_Stats
AS (
	SELECT	DatabaseID, DB_Name(DatabaseID) AS [DatabaseName], SUM(total_worker_time) AS [CPU_Time_Ms]
	FROM	sys.dm_exec_query_stats AS qs
	CROSS APPLY (SELECT CONVERT(int, value) AS [DatabaseID] FROM sys.dm_exec_plan_attributes(qs.plan_handle) WHERE attribute = N'dbid') AS F_DB
	GROUP BY DatabaseID
)
SELECT	ROW_NUMBER() OVER(ORDER BY [CPU_Time_Ms] DESC) AS [Ordem],
		DatabaseName AS dbname,
		[CPU_Time_Ms] / 1000 as CPU_Time_Sec,
		CAST([CPU_Time_Ms] * 1.0 / SUM([CPU_Time_Ms]) OVER() * 100.0 AS DECIMAL(5, 2)) AS [CPU_Perc],
		CONVERT(VARCHAR(16),GETDATE(), 121) as DataHora
INTO	#Table
FROM	DB_CPU_Stats
WHERE	DatabaseID > 4 -- system databases 
AND		DatabaseID <> 32767 -- ResourceDB
ORDER BY Ordem OPTION (RECOMPILE);

SELECT	Ordem, dbname, SUM(CPU_Time_Sec) AS CPU_Time_Sec, SUM(CPU_Perc) AS CPU_Perc, MAX(DataHora) AS DataHora
FROM	(
	SELECT	Ordem, dbname, CPU_Time_Sec, CPU_Perc, DataHora
	FROM	#Table
	WHERE	dbname IN (SELECT TOP 10 dbname FROM #Table ORDER BY Ordem)
UNION
	SELECT	'11', 'Outras', SUM(CPU_Time_Sec) AS CPU_Time_Sec, SUM(CPU_Perc) AS CPU_Perc, MAX(DataHora) AS DataHora
	FROM	#Table
	WHERE	dbname NOT IN (SELECT TOP 10 dbname FROM #Table ORDER BY Ordem)
) AS T
GROUP BY Ordem, dbname
ORDER BY Ordem

DROP TABLE #Table