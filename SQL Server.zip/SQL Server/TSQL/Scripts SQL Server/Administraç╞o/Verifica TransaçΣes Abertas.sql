select session_id, a.transaction_id,open_transaction_count, b.transaction_begin_time, b.transaction_status
from sys.dm_exec_requests a inner join sys.dm_tran_active_transactions b on a.transaction_id=b.transaction_id


SELECT BancoDados, HoraLogin, sum(TransacoesAbertas) as TransacoesAbertas, Comando, Status, Usuario, Aplicacao, EstacaoTrabalho, DATEDIFF(ss, HoraLogin, getdate()) as Tempo
FROM (
Select db_name(dbid) as BancoDados, login_time as HoraLogin,
Open_tran as TransacoesAbertas, nt_username as Usuario, Hostname as EstacaoTrabalho,
program_name as Aplicacao, Status, cmd as Comando
From master..sysProcesses
)Tb
where TransacoesAbertas > 0
group by BancoDados,HoraLogin, Usuario,Aplicacao,EstacaoTrabalho,Comando,Status