Sp_Msforeachdb '

use [?]

if object_id(''Mov_Estoque2_Clodoaldo'') is not null

print ''drop table [?].dbo.Mov_Estoque2_Clodoaldo''


'