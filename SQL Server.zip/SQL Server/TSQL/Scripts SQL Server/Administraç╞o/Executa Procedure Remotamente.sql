Sp_Verifica_Processo 'ProgramName Like ''%E273s2%'''
Set quoted_identifier off
EXEC ("Sp_Verifica_Processo 'ProgramName Like ''%E273s2%'''" ) AT [172.17.6.102\SQLSIC1]



While 1=1
begin
exec
Usp_Libera_Processos '106'
End

Set quoted_identifier off
While 1=1
Begin
EXEC 
("Usp_Libera_Processos '212'" ) AT [172.17.6.102\SQLSIC1]
End