/*
	AUTHOR:			ROBERTO GIOY
	PROJECT:		ITAU 30 HORAS
	DESCRIPTION:	CRIA MENSAGEM PADRONIZADA PARA TRATAR ERROS DE BANCO DE DADOS
	DATE CREATED:	07/05/2013
*/

SET LANGUAGE us_english;
GO

EXEC sp_addmessage 51000, 16, 'Procedure %s failed with error number %d at line %d because %s.'
GO