Segue:

DBCC FREEPROCCACHE - Remove tudo que est� no cache (Plano de execu��o).
DBCC FREESYSTEMCACHE ('ALL') - O SQL j� faz isso autom�tico para liberar mem�ria para os itens atuais, mas esse pode ser executado manualmente.

Depois disso divirtam-se com o DBCC SHRINKDATABASE na tempdb.
O legal � deixar agendado num plano de manuten��o do SQL para fazer isso diariamente ou semanalmente.
Peguem um caso a� que a tempdb n�o reduz nem a pau, da� executem os caras acima e depois testem o shrinkdatabase.

A tempdb n�o reduz por que tem planos de execu��es em cache, ap�s limpar executando os comandos acima, voc�s ver�o que ela reduz.
