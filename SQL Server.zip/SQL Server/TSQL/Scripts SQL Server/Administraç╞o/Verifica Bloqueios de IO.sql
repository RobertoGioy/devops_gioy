EXEC sp_who

DBCC SQLPERF (WAITSTATS)

-- VERIFICAR OS WAIT TYPES DE I/O OFENSORES
SELECT * FROM sys.dm_os_wait_stats
WHERE
wait_type like 'PAGEIO%' or
wait_type like '%IO_COMPLETION' or
wait_type like 'DISKIO%' or
wait_type like 'BACKUPIO%'or
wait_type like 'WRITE%'
ORDER BY wait_time_ms DESC

-- VERIFICAR PEDIDOS DE E/S PENDENTES
SELECT * FROM sys.dm_io_pending_io_requests

	
SELECT vfs.database_id, df.name, df.physical_name,vfs.file_id, ior.io_pending,ior.io_handle, vfs.file_handle
FROM sys.dm_io_pending_io_requests ior
INNER JOIN sys.dm_io_virtual_file_stats (DB_ID(), NULL) vfs on (vfs.file_handle = ior.io_handle)
INNER JOIN sys.database_files df on (df.file_id = vfs.file_id)
WHERE df.name = '[Logical Log File Name]'


select	DB_NAME(database_id) DB_NAME, file_id
		,io_stall_read_ms ,num_of_reads
		,cast(io_stall_read_ms/(1.0+num_of_reads) as numeric(10,1)) as 'avg_read_stall_ms'
		,io_stall_write_ms,num_of_writes
		,cast(io_stall_write_ms/(1.0+num_of_writes) as numeric(10,1)) as 'avg_write_stall_ms'
		,io_stall_read_ms + io_stall_write_ms as io_stalls
		,num_of_reads + num_of_writes as total_io
		,cast((io_stall_read_ms+io_stall_write_ms)/(1.0+num_of_reads + num_of_writes) as numeric(10,1)) as 'avg_io_stall_ms'
from sys.dm_io_virtual_file_stats(null,null)
order by avg_io_stall_ms desc


select * from sys.dm_tran_locks
