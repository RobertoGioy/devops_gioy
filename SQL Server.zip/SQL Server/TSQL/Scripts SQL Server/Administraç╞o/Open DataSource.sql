SELECT   *
FROM      OPENDATASOURCE(
         'SQLNCLI',
         'Data Source=172.21.8.2;User ID=consulta;Password=consulta'
         ).SL2000ARq.dbo.Empresas