exec sp_msforeachdb 'use ? if not (select object_id(''Empresas'')) is null 

begin 

if exists (select ''?'', Codemp, Nomemp from Empresas where codemp = ''905'') 

select ''?'' as Base,Codemp, Nomemp from Empresas where codemp = ''905''

end

'

exec sp_msforeachdb 'use ? if not (select object_id(''Empresas'')) is null 

begin 

if exists (select ''?'', Codemp, Nomemp from Empresas where nomemp like ''%NITRAS%'') 

select ''?'' as Base,Codemp, Nomemp from Empresas where nomemp like ''%NITRAS%''

end

'