CREATE SCHEMA [monitoring]
GO

CREATE TABLE [monitoring].[operations](
	[idoperation]	tinyint identity(1,1) NOT NULL,
	[operationname] varchar(100) NULL,
	CONSTRAINT [pk_operations] PRIMARY KEY CLUSTERED ([idoperation] ASC)
	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

INSERT INTO monitoring.operations VALUES ('Monitoramento de CPU')
GO

CREATE TABLE [monitoring].[itenstomonitor](
	[iditem]			int				identity(1,1) NOT NULL,
	[idoperation]		tinyint			NOT NULL,
	[servername]		varchar(100)	NOT NULL,
	[itemname]			varchar(100)	NOT NULL,
	[targetvalue]		decimal(18, 2)	NULL,
	[targetvaluetime]	decimal(18, 2)	NULL,
	CONSTRAINT [pk_itenstomonitor] PRIMARY KEY CLUSTERED ([idoperation] ASC,[servername] ASC)
	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

INSERT INTO [monitoring].[itenstomonitor] VALUES (1,'BSPODBS02','CPU',65,240)
GO

CREATE TABLE [monitoring].[operators](
	[idoperator]	tinyint			identity(1,1) NOT NULL,
	[operatorname]	varchar(100)	NULL,
	[email]			varchar(100)	NULL,
	[active]		bit				NULL,
	CONSTRAINT [pk_operators] PRIMARY KEY CLUSTERED ([idoperator] ASC)
	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

INSERT INTO[monitoring].[operators] VALUES ('Jos� Roberto','jose.roberto@unear.net',1), ('Adriana Abud', 'adriana.abud@unear.net',1)
GO

CREATE TABLE [monitoring].[operationsoperators](
	[idoperator]	tinyint NOT NULL,
	[idoperation]	tinyint NOT NULL,
	CONSTRAINT [pk_operationsoperators] PRIMARY KEY CLUSTERED ([idoperator] ASC,[idoperation] ASC)
	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

INSERT INTO monitoring.operationsoperators VALUES (1,1),(2,1)
GO

CREATE TABLE [monitoring].[statusitenstomonitor](
	[iditem]				[int] NOT NULL,
	[idoperation]			[tinyint] NOT NULL,
	[currentvalue]			[decimal](18, 2) NULL,
	[starteventtarget]		[datetime] NULL,
	[currenteventtarget]	[datetime] NULL,
	[endeventtarget]		[datetime] NULL,
	[emailsent]				[bit] NULL,
	CONSTRAINT [pk_statusitenstomonitor] PRIMARY KEY CLUSTERED ([iditem] ASC,[idoperation] ASC)
	WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

CREATE PROCEDURE monitoring.spvcpu
AS
BEGIN
	SET NOCOUNT ON
	--Verifica se a m�dia de CPU excedeu o par�metro configurado na "monitoring.itenstomonitor"
	--Se houver resultado na query abaixo, ent�o ele entrar� no bloco de acompanhamento
	SELECT  c.iditem,
			c.idoperation,
			replace(b.machinename,'\\','') as machinename,
			min(convert(datetime,left(counterdatetime,23))) as Data,
			convert(decimal(18,2),avg(countervalue)) as '%CPU M�dia',
			c.targetvalue
	INTO	#statuscpu
	FROM	counterdata a
			INNER JOIN counterdetails b 
	ON		a.counterid = b.counterid
			INNER JOIN monitoring.itenstomonitor c 
	ON		replace(b.machinename,'\\','') = c.servername
	WHERE	c.idoperation = 2 
	AND		convert(datetime,left(counterdatetime,23)) >= convert(datetime,dateadd(ss,c.targetvaluetime*-1,getdate())) 
	AND		b.objectname = 'Processor' 
	AND		b.countername = '% Processor Time'
	GROUP BY 
			c.iditem,
			c.idoperation,
			c.targetvalue,
			replace(b.machinename,'\\',''),
			a.counterid
	HAVING  c.targetvalue < avg(countervalue) OR EXISTS (
			SELECT 1 FROM monitoring.statusitenstomonitor sim WHERE c.iditem = sim.iditem AND c.idoperation = sim.idoperation)
	
	--Bloco de acompanhamento
	INSERT INTO monitoring.statusitenstomonitor (iditem,idoperation,currentvalue,starteventtarget,currenteventtarget,endeventtarget,emailsent)
	SELECT	iditem,idoperation,[%CPU M�dia],getdate(),getdate(),NULL,0
	FROM	#statuscpu a
	WHERE	NOT EXISTS(SELECT 1 FROM monitoring.statusitenstomonitor b WHERE a.iditem = b.iditem AND a.idoperation = b.idoperation)

	UPDATE	a 
	SET		a.currentvalue = b.[%CPU M�dia],
			a.currenteventtarget = getdate(),
			a.endeventtarget = case when b.targetvalue > b.[%CPU M�dia] then getdate() else NULL end
	FROM	monitoring.statusitenstomonitor a
			INNER JOIN #statuscpu b 
	ON		a.iditem = b.iditem and a.idoperation = b.idoperation
	WHERE	a.emailsent = 1
	
	--Processo abaixo padr�o para envio de alertas:
	--Constr�i lista dos operadores
	declare @emails varchar(max)
	set @emails = (
			SELECT	email + ';' 
			FROM	monitoring.operationsoperators a
					INNER JOIN monitoring.operators b 
			ON		a.idoperator = b.idoperator
					INNER JOIN monitoring.operations c 
			ON		a.idoperation = c.idoperation
			WHERE	c.idoperation = 2 and active = 1 for xml path (''))
			
	set @emails = left(@emails,len(@emails)-1)

	--Envia mensagens de Warning ou se est� est�vel:
	declare @server sysname, @subjecttext varchar(100), @alertmsgtext varchar(3000), @starteventtarget datetime,
			@currentvalue decimal(5,2), @targetvalue decimal(5,2), @emailsent bit, @endeventtarget datetime
		
	DECLARE C_MON2 CURSOR FOR
	SELECT	b.servername,a.currentvalue,b.targetvalue,starteventtarget,a.emailsent,a.endeventtarget
	FROM	monitoring.statusitenstomonitor a
			INNER JOIN monitoring.itenstomonitor b 
	ON		a.iditem = b.iditem and a.idoperation = b.idoperation
	WHERE	b.idoperation = 2
	
	OPEN c_mon2
	FETCH NEXT FROM c_mon2 INTO @server, @currentvalue, @targetvalue, @starteventtarget, @emailsent, @endeventtarget
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		--Envia mensagens:

		--Envia e-mail pela primeira vez:
		IF @emailsent = 0
		BEGIN
			set @subjecttext = '%CPU Warning: Servidor ' + @server + ' com m�dia acima de %CPU (' + rtrim(@currentvalue) + ')'
			set @alertmsgtext = 'O Servidor ' + @server + ' est� com a m�dia de %CPU (' + rtrim(@currentvalue) + ') acima do configurado (' + rtrim(@targetvalue) + ')' + char(13) + 
								'In�cio da instabilidade no dia: ' + convert(varchar,@starteventtarget,103) + ' as ' + convert(varchar,@starteventtarget,114)

			EXEC msdb.dbo.sp_send_dbmail
			 @recipients=@emails,
			 @body=@alertmsgtext,
			 @importance='High',
			 @subject=@subjecttext,
			 @profile_name='DBA Notification'
				
			UPDATE	a 
			SET		a.emailsent = 1
			FROM	monitoring.statusitenstomonitor a
					INNER JOIN monitoring.itenstomonitor b 
			ON		a.iditem = b.iditem and a.idoperation = b.idoperation
			WHERE	b.idoperation = 2 and b.servername = @server
		END

		--Envia e-mail caso o contador esteja est�vel:
		IF @emailsent = 1 and @endeventtarget is not null
		BEGIN
			set @subjecttext = '%CPU OK: Servidor ' + @server + ' com m�dia de %CPU estabilizada (' + rtrim(@currentvalue) + ')'
			set @alertmsgtext = 'O Servidor ' + @server + ' est� com a m�dia de %CPU (' + rtrim(@currentvalue) + ') abaixo do configurado (' + rtrim(@targetvalue) + ')' + char(13) + 
								'In�cio da instabilidade no dia: ' + convert(varchar,@starteventtarget,103) + ' as ' + convert(varchar,@starteventtarget,114) + char(13) + 
								'Estabilizado em: ' + convert(varchar,@endeventtarget,103) + ' as ' + convert(varchar,@endeventtarget,114) + char(13) + 
								'Dura��o da instabilidade (em Minutos): ' + convert(varchar,datediff(mi,@starteventtarget,@endeventtarget),103) 
								
			EXEC msdb.dbo.sp_send_dbmail
			 @recipients=@emails,
			 @body=@alertmsgtext,
			 @importance='High',
			 @subject=@subjecttext,
			 @profile_name='DBA Notification'
				
			DELETE	a
			FROM	monitoring.statusitenstomonitor a
					inner join monitoring.itenstomonitor b 
			ON		a.iditem = b.iditem and a.idoperation = b.idoperation
			WHERE	b.idoperation = 2 and b.servername = @server
		END

		FETCH NEXT FROM c_mon2 INTO @server, @currentvalue, @targetvalue, @starteventtarget, @emailsent, @endeventtarget
	END
	
	CLOSE c_mon2
	DEALLOCATE c_mon2
END
GO