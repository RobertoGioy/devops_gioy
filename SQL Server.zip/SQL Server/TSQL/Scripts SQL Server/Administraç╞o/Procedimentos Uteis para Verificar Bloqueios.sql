--PROCEDIMENTO PARA VERIFICAR BLOQUEIOS

sp_who2

dbcc inputbuffer(230)

declare @bloqueios int, @users int	
	
select @users= cntr_value from master.dbo.sysperfinfo (nolock)  where counter_name ='User Connections'	
select @bloqueios= count(*)  from master.dbo.sysprocesses  where blocked <> 0  	
	
if @bloqueios > 0 	
begin 	
  select  @bloqueios as bloqueios, @users as users,   	
	  spid, status,   
          	  loginame= substring(loginame,1,12), hostname=substring(hostname,1,12),   
                blk=convert(char(3),blocked),   	
	  dbname= substring(db_name(dbid),1,10),   
	  cmd, lastwaittype, cpu, physical_io, last_batch  
  from master.dbo.sysprocesses(nolock)  	
  where ecid= 0 and ((spid in (select blocked from master.dbo.sysprocesses (nolock) )  and blocked = 0)  or blocked <> 0)  	
  order by blocked	
end	
else	
  select  @bloqueios as bloqueios, @users as users	
  
      
  
  --==============================================================================


--================
--planilha 1  -  TamanhoTabelas_BBA_BEL
USE BBA_BEL
GO

drop table #Tabelas

create table #Tabelas(nome varchar(100), linhas int, reservado varchar(20), dados varchar(20),indices varchar(20), livre varchar(20))

EXEC sp_MSforeachTable @command1="print '>>>Tabela: ?'",
			@command2="Insert into #Tabelas Exec sp_spaceused '?'"

select * from #Tabelas order by linhas desc


GO
--==================================================================================================================================================





sp_who2
go


/*tamanho das tabelas*/
use bba_bel
go

SELECT  OBJECT_NAME(ps.[object_id]) AS [TableName] ,
        i.name AS [IndexName] ,
        i.type_desc,
        SUM(ps.row_count) AS [RowCount]
FROM    sys.dm_db_partition_stats AS ps
        INNER JOIN sys.indexes AS i ON i.[object_id] = ps.[object_id]
                                       AND i.index_id = ps.index_id
WHERE   i.type_desc IN ( 'CLUSTERED', 'HEAP' )
        AND i.[object_id] > 100
        AND OBJECT_SCHEMA_NAME(ps.[object_id]) <> 'sys'
GROUP BY ps.[object_id] ,
        i.name,
        i.type_desc
ORDER BY SUM(ps.row_count) DESC ;


--####################################################################################################

/*Procedures que mais consomem CPU Uso Processador/numero execu��es*/
use tempdb
go
SELECT TOP 50
        total_worker_time ,
        execution_count ,
        deqs.plan_generation_num ,
        total_worker_time / execution_count AS [Avg CPU Time] ,
		execText.text,
        CASE WHEN deqs.statement_start_offset = 0
                  AND deqs.statement_end_offset = -1
             THEN '-- see objectText column--'
             ELSE '-- query --' + CHAR(13) + CHAR(10)
                  + SUBSTRING(execText.text, deqs.statement_start_offset / 2,
                              ( ( CASE WHEN deqs.statement_end_offset = -1
                                       THEN DATALENGTH(execText.text)
                                       ELSE deqs.statement_end_offset
                                  END ) - deqs.statement_start_offset ) / 2)
        END AS queryText
FROM    sys.dm_exec_query_stats deqs
        CROSS APPLY sys.dm_exec_sql_text(deqs.plan_handle) AS execText
ORDER BY deqs.total_worker_time DESC ;


--####################################################################################################

/*Procedures que mais consomem CPU por numero execu��es*/
use tempdb
go
SELECT TOP 50
        total_worker_time ,
        execution_count ,
        deqs.plan_generation_num ,
        total_worker_time as [CPU Time] ,
        execText.text,
        CASE WHEN deqs.statement_start_offset = 0
                  AND deqs.statement_end_offset = -1
             THEN '-- see objectText column--'
             ELSE '-- query --' + CHAR(13) + CHAR(10)
                  + SUBSTRING(execText.text, deqs.statement_start_offset / 2,
                              ( ( CASE WHEN deqs.statement_end_offset = -1
                                       THEN DATALENGTH(execText.text)
                                       ELSE deqs.statement_end_offset
                                  END ) - deqs.statement_start_offset ) / 2)
        END AS queryText
FROM    sys.dm_exec_query_stats deqs
        CROSS APPLY sys.dm_exec_sql_text(deqs.plan_handle) AS execText
ORDER BY deqs.execution_count DESC ;


--####################################################################################################

/*Indices que est�o faltando*/
use bba_bel
go
SELECT  user_seeks * avg_total_user_cost * ( avg_user_impact * 0.01 )
                                                       AS [index_advantage] ,
        migs.last_user_seek ,
        mid.[statement] AS [Database.Schema.Table] ,
        mid.equality_columns ,
        mid.inequality_columns ,
        mid.included_columns ,
        migs.unique_compiles ,
        migs.user_seeks ,
        migs.avg_total_user_cost ,
        migs.avg_user_impact
FROM    sys.dm_db_missing_index_group_stats AS migs WITH ( NOLOCK )
        INNER JOIN sys.dm_db_missing_index_groups AS mig WITH ( NOLOCK )
           ON migs.group_handle = mig.index_group_handle
        INNER JOIN sys.dm_db_missing_index_details AS mid WITH ( NOLOCK )
           ON mig.index_handle = mid.index_handle
WHERE   mid.database_id = DB_ID()
ORDER BY index_advantage DESC ;


--####################################################################################################


/*Indices n�o usados*/
use bba_bel
go
SELECT  OBJECT_NAME(i.[object_id]) AS [Table Name] ,
        i.name,
        i.type_desc
FROM    sys.indexes AS i
        INNER JOIN sys.objects AS o ON i.[object_id] = o.[object_id]
WHERE   i.index_id NOT IN ( SELECT  s.index_id
                            FROM    sys.dm_db_index_usage_stats AS s
                            WHERE   s.[object_id] = i.[object_id]
                                    AND i.index_id = s.index_id
                                    AND database_id = DB_ID() )
        AND o.[type] = 'U'
ORDER BY OBJECT_NAME(i.[object_id]) ASC ;

--####################################################################################################


/*Como est�o as leituras e escritas nos indices*/
use bba_bel
go
SELECT  OBJECT_NAME(s.[object_id]) AS [ObjectName] ,
        i.name AS [IndexName] ,
        i.index_id ,
        user_seeks,
        user_scans,
        user_lookups ,
        user_seeks + user_scans + user_lookups AS [Reads] ,
        user_updates AS [Writes] ,
        i.type_desc AS [IndexType] ,
        i.fill_factor AS [FillFactor]
FROM    sys.dm_db_index_usage_stats AS s
        INNER JOIN sys.indexes AS i ON s.[object_id] = i.[object_id]
WHERE   OBJECTPROPERTY(s.[object_id], 'IsUserTable') = 1
        AND i.index_id = s.index_id
        AND s.database_id = DB_ID()
ORDER BY OBJECT_NAME(s.[object_id]) ,
        writes DESC ,
        reads DESC ;



--minhas procs




CREATE PROCEDURE [dbo].[p_RelatDatabases] 

AS

Create table #FreeSpace (banco varchar(100), valor decimal(24,0))
exec sp_MSForEachDB  @command1="Insert into #FreeSpace exec msdb.dbo.p_verificafreespace '?'"


Select  case when b.dbid <= 4 then 'Sistema' else 'Usuarios' end as tipodb,  b.dbid, b.name,
	SUM(convert(float,case when fileid=1 then size end))*(8192.0/1024.0)/1024 as DBsize, 
	SUM(convert(float,case when fileid=2 then size end))*(8192.0/1024.0)/1024 as LGsize, 
	sum(convert(float,size))*(8192.0/1024.0)/1024 as Tam, 
	max(case when fileid=1 then a.filename end) as DBfile, 
	max(case when fileid=2 then a.filename end) as LGfile,
	replace(str((sum(size) - (max(c.valor))) / 128,15,2),'.',',') as Livre
from master.dbo.sysaltfiles a inner join master.dbo.sysdatabases b on a.dbid = b.dbid 
  left join  #FreeSpace c on b.name = c.banco	
group by b.dbid, b.name
order by tipodb desc, b.name

Drop table #FreeSpace

GO


--================
--planilha 1  -  TamanhoTabelas_BBA_BEL
USE BBA_BEL
GO

drop table #Tabelas

create table #Tabelas(nome varchar(100), linhas int, reservado varchar(20), dados varchar(20),indices varchar(20), livre varchar(20))

EXEC sp_MSforeachTable @command1="print '>>>Tabela: ?'",
			@command2="Insert into #Tabelas Exec sp_spaceused '?'"

select * from #Tabelas order by linhas desc


GO
--==================================================================================================================================================


--=============
CREATE PROCEDURE [dbo].[p_VerificaBloqueios] 	
	
AS	
declare @bloqueios int, @users int	
	
select @users= cntr_value from master.dbo.sysperfinfo (nolock)  where counter_name ='User Connections'	
select @bloqueios= count(*)  from master.dbo.sysprocesses  where blocked <> 0  	
	
if @bloqueios > 0 	
begin 	
  select  @bloqueios as bloqueios, @users as users,   	
	  spid, status,   
          	  loginame= substring(loginame,1,12), hostname=substring(hostname,1,12),   
                blk=convert(char(3),blocked),   	
	  dbname= substring(db_name(dbid),1,10),   
	  cmd, lastwaittype, cpu, physical_io, last_batch  
  from master.dbo.sysprocesses(nolock)  	
  where ecid= 0 and ((spid in (select blocked from master.dbo.sysprocesses (nolock) )  and blocked = 0)  or blocked <> 0)  	
  order by blocked	
end	
else	
  select  @bloqueios as bloqueios, @users as users	
GO
--===============





