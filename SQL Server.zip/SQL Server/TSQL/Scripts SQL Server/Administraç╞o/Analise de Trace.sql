user msdb

CREATE TABLE dbo.t_TraceSQL (
	RowNumber int IDENTITY (1, 1) NOT NULL ,
	EventClass int NULL ,
	TextData ntext COLLATE SQL_Latin1_General_CP1_CI_AI NULL ,
	ApplicationName nvarchar (128) COLLATE SQL_Latin1_General_CP1_CI_AI NULL ,
	LoginName nvarchar (128) COLLATE SQL_Latin1_General_CP1_CI_AI NULL ,
	SPID int NULL ,
	Duration bigint NULL ,
	StartTime datetime NULL ,
	Reads bigint NULL ,
	Writes bigint NULL ,
	CPU int NULL 
) ON PRIMARY TEXTIMAGE_ON PRIMARY
GO


CREATE TABLE t_TRACESQL_Hist
(textdata varchar(50), qtde int, cpu_media numeric(10,2), 
 duration_media numeric(10,2), qtdeponderada numeric(10,2),
 percrepresentacao numeric(10,2), percimportancia numeric(10,2), 
 periodo varchar(50), dataref datetime)
GO


CREATE proc p_TraceSQLCalc
as

Delete from  t_TraceSQL
where substring(textdata,1,30) in ('Some trace events have not bee','exec sp_reset_connection','COMMIT TRANSACTION','SET TRANSACTION ISOLATION LEVE')

declare @periodo varchar(50), @QtdeTotal varchar(20), @PondTotal varchar(20)
select 	@QtdeTotal= count(*),	
	@PondTotal= count(*) * avg(cpu),	
	@periodo= convert(char(10),min(starttime),103) + ' '+ convert(char(5),min(starttime),108) + ' �s '+convert(char(5),max(starttime),108)
from t_TraceSQL
where eventclass in (10,12)

Insert into TRACESQL_Hist
select  textdata= substring(textdata,1,30),
	qtde= count(*),  	
	cpu_media=avg(cpu) , 
	duration_media =avg(duration) ,	
	qtdeponderada= count(*) * avg(cpu),
	percRepresentacao= str(count(*) *100/convert(numeric,@qtdeTotal),10,2),
	percImportancia= str((count(*)*avg(cpu)) * 100/convert(numeric,@pondTotal),10,2),
	periodo= @periodo,
	dataref= convert(varchar(10),getdate(),101)
from t_TraceSQL
where eventclass in (10,12)
group by substring(textdata,1,30)
order by percImportancia desc

GO


CREATE proc p_TraceSQLRelat    --relat�rio para excell din�mico
 @data datetime	= null
as

	--pega o �ltimo trace gerado
	if @data is null
		select @data = max(dataref) from t_TRACESQL_Hist

	select * 
	from t_TRACESQL_Hist 
	where dataref = @data
GO



