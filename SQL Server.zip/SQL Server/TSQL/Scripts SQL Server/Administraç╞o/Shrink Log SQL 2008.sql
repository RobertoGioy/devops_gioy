Backup log SL2000 To Disk = 'C:\Teste.bak'
Checkpoint 
Dbcc Shrinkfile (2,1)