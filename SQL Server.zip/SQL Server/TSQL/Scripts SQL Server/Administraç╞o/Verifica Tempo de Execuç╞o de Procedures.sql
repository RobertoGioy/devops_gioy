USE [master]
GO

/****** Object:  StoredProcedure [dbo].[spTimeExecutionProcedure]    Script Date: 07/18/2013 14:08:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[spTimeExecutionProcedure]
	@DatabaseID INT
AS
-- COLOCAR ESTA PROCEDURE NA BASE A SER MONITORADA
SELECT	p.name AS [procedureName],
		qs.execution_count,
		ISNULL(qs.execution_count/DATEDIFF(Second, qs.cached_time, GETDATE()), 0) AS [Calls/Second],
		((qs.total_worker_time / 1000000)/qs.execution_count) AS [AvgWorkerTime(seg)], 
		(qs.total_worker_time / 1000000) AS [TotalWorkerTime(seg)],  
		(qs.total_elapsed_time / 1000000) as [TotalElapseTime(seg)], 
		((qs.total_elapsed_time)/qs.execution_count) AS [avg_elapsed_time(mcs)],
		qs.last_execution_time
FROM	sys.dm_exec_procedure_stats AS qs WITH (NOLOCK) JOIN sys.procedures p
ON		qs.object_id = p.object_id
WHERE	qs.database_id = @DatabaseID
ORDER BY qs.execution_count DESC OPTION (RECOMPILE);


GO


