select    @@SERVERNAME as Servidor,
                               db_name(a.dbid) as DB, 
                               sum(convert(decimal(18,2),round(((a.size/0.125)/1024.00)/1024.00,2,1))) as DataSizeGB,
                               DATABASEPROPERTYEX (db_name(a.dbid),'UserAccess') as TipoAcesso                                            
                                               from sysaltfiles a
          where a.groupid >= 1
group by a.dbid 
order by DB



select    @@SERVERNAME as Servidor,
                               db_name(a.dbid) as DB, 
                               sum(convert(decimal(18,2),round(((b.size/0.125)/1024.00)/1024.00,2,1))) as DataSizeGB,
                               sum(convert(decimal(18,5),((a.size/0.125)/1024.00)/1024.00)) as LogSizeGB,
                               min(b.filename) as '1o DataFileName',min(a.filename) as '1o LogFileName',DATABASEPROPERTYEX (db_name(a.dbid),'status') as Status,
                               DATABASEPROPERTYEX (db_name(a.dbid),'UserAccess') as TipoAcesso                                            
                                               from sysaltfiles a,sysaltfiles b
                                                                              where a.groupid = 0 and b.groupid >= 1 and a.dbid = b.dbid
group by a.dbid 
order by DB

