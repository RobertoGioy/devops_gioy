DECLARE @chvDomainName NVARCHAR(100) 
EXEC master.dbo.xp_regread 'HKEY_LOCAL_MACHINE', 
'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon', 
N'DefaultDomainName',@chvDomainName OUTPUT 
SELECT @chvDomainName AS DomainName