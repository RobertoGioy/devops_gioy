USE master;
GO

-- verifica o nome dos arquivos f�sicos
SELECT name, physical_name AS CurrentLocation
FROM sys.master_files
WHERE database_id = DB_ID(N'dbname');
GO

-- altera o local dos arquivos f�sicos
ALTER DATABASE dbname 
MODIFY FILE (NAME = dbname, FILENAME = 'D:\Databases\dbname.mdf');
GO
ALTER DATABASE tempdb 
MODIFY FILE (NAME = dbname, FILENAME = 'E:\TransactionLogs\dbname.ldf');
GO

-- coloca a base offline para copiar os arquivos para o novo local
ALTER DATABASE dbname
SET offline
GO

-- ap�s copiar os arquivos f�sicos para o novo local, coloca a base online novamente
ALTER DATABASE dbname
SET online
GO

-- verifica o nome dos arquivos f�sicos
SELECT name, physical_name AS CurrentLocation, state_desc
FROM sys.master_files
WHERE database_id = DB_ID(N'dbname');