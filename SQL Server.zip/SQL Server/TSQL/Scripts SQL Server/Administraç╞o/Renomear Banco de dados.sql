/*
	Exemplo de como renomear tabelas e colunas ou adicionar colunas na tabela
*/

USE master;
GO
ALTER DATABASE AdventureWorks2012
Modify Name = Northwind ;
GO

sp_renamedb @dbname = 'old_name' , @newname = 'new_name'
GO