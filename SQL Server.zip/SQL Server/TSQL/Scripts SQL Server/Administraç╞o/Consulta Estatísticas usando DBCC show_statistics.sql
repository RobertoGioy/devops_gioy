Sp_spaceused 'EmailsGenerated_8' sp_helpindex EmailsGenerated_8

DBCC show_statistics(EmailsGenerated_8, IX_EmailsGenerated_8)

DBCC show_statistics(EmailsGenerated_8, IX_EmailsGenerated_8_TGUID)

DBCC show_statistics(EmailsGenerated_8, PK_EmailsGenerated_8)

Select * From Sysobjects where xtype = 'P' And name Like '%per%'


exec spNGZCampaignGeneratedStatusPercent 

exec spNGZCampaignGeneratedStatusPercent 571758


select groupid, count(1) from emailsgenerated_8 where campid =571758
Group By groupid

Select GroupId, Count(1) From EmailsGenerated_8 Where Campid = 571758 And GeneratedStatus = 0
Group By GroupId
Order By GroupId

Select * From Umail_master.dbo.HostGroups
Where GroupId IN (
Select Distinct GroupId From EmailsGenerated_8 Where Campid = 571758 And GeneratedStatus = 0
)
select groupid, count(1) from emailsgenerated_8 where campid =571758
Group By groupid



select Top 1 * from emailsgenerated_8 where campid =571758
select Top 1 * from Umail_master.dbo.HostGroups where Groupid = 62

select count(1) from emailsgenerated_8 where campid =571758

Select A.HostName, COUNT(distinct A.GroupId) From 
Umail_master.dbo.HostGroups A
Inner Join EmailsGenerated_8 B On A.GroupId=B.GroupId
Where B.Campid = 571758 
Group By A.HostName
Order By A.HostName


Select A.HostName, COUNT(distinct A.GroupId) From 
Umail_master.dbo.HostGroups A
Inner Join EmailsGenerated_8 B On A.GroupId=B.GroupId
Where B.Campid = 571758 
Group By A.HostName
Order By A.HostName

Select * From Umail_master.dbo.HostGroups Where Hostname = 'DGNT14V'

Select * From Umail_master.dbo.HostGroups Where Hostname = 'DGNT14V'


Select * From campaign Where Campid = 594679


select campid, COUNT(*) from emailsgenerated_9 where GeneratedStatus = 0
Group By campid
Order By campid


Select * From umail_master.dbo.Client Where Name like '%mult%'
Select * From umail_master.dbo.campaign where clientid = 1059 And Status Not in ('ENCERRADA', 'PAUSADA','RECORRENTE')