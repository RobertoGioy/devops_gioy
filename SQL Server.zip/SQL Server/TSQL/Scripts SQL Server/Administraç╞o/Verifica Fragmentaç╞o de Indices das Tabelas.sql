
set nocount on
print '--RELATORIO INDEXES DE TABELAS SQL2005'
print ''

use DB_WebMotors
go

declare @tb varchar(100), @id varchar(50)

declare tb_cursor cursor for 
select  name, object_id
from sys.tables
where name like 'TB_%'
order by name


   open tb_cursor
   fetch next from tb_cursor into @tb,@id

   while @@fetch_status = 0
   begin
	
	 SELECT Tabela= @tb, indexname=name, percfragment= str(avg_fragmentation_in_percent,5,2)
	 FROM sys.dm_db_index_physical_stats (5,@id,null,null,null) a 
	    JOIN sys.indexes AS b ON a.object_id = b.object_id AND a.index_id = b.index_id
	 order by percfragment desc;

     fetch next from tb_cursor into @tb,@id
   end

   close tb_cursor
   deallocate tb_cursor
set nocount off

--ALTER INDEX ALL ON tb_anuncio --4 m
--REBUILD WITH (ONLINE = ON);
