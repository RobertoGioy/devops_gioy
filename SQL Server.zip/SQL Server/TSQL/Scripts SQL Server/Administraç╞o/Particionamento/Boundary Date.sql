DECLARE @DateFunction VARCHAR(10)
DECLARE @RunDate DATETIME
DECLARE @RetainedDate DATETIME
DECLARE @SQL NVARCHAR(400)
DECLARE @Retention INT

SET @RunDate = GETDATE()
SET @DateFunction = 'DAY'
SET @Retention = 7

SET @SQL = 'SELECT DATEADD(' + @DateFunction + ', 1, ''' + CONVERT(VARCHAR(10),GETDATE(), 120) + ' 23:59:59.997'')'

EXEC sp_executesql @SQL, N'@RunDate DATETIME OUTPUT', @RunDate OUTPUT

PRINT @SQL

SELECT @RunDate = CONVERT(VARCHAR(25),CONVERT(VARCHAR(10),@RunDate,120) + ' 23:59:59.997',120)

SET	@SQL = 'SELECT DATEADD(DD, -1, DATEADD(' + @DateFunction + ', ' + CONVERT(VARCHAR,@Retention) + ' * -1, ''' + CONVERT(VARCHAR(10),@RunDate, 120) + '''))'

EXEC sp_executesql @SQL, N'@RetainedDate DATETIME OUTPUT', @RetainedDate OUTPUT	
		
PRINT @SQL