Select * from sys.FileGroups
SELECT * FROM sys.partition_schemes
SELECT * FROM SYS.PARTITION_RANGE_VALUES Where function_id = 65541

Use UchannelsSubmarino

Dbcc showcontig (UwebTrans)



--Para determinar se uma tabela � particionada
SELECT * FROM sys.partitions AS p
JOIN sys.tables AS t
    ON  p.object_id = t.object_id
WHERE p.partition_id IS NOT NULL
    AND t.name = 'UwebTrans';
    
--Para determinar os valores de limite para uma tabela particionada    
SELECT t.name AS TableName, i.name AS IndexName, p.partition_number, p.partition_id, i.data_space_id, f.function_id, f.type_desc, r.boundary_id, r.value AS BoundaryValue 
FROM sys.tables AS t
JOIN sys.indexes AS i
    ON t.object_id = i.object_id
JOIN sys.partitions AS p
    ON i.object_id = p.object_id AND i.index_id = p.index_id 
JOIN  sys.partition_schemes AS s 
    ON i.data_space_id = s.data_space_id
JOIN sys.partition_functions AS f 
    ON s.function_id = f.function_id
LEFT JOIN sys.partition_range_values AS r 
    ON f.function_id = r.function_id and r.boundary_id = p.partition_number
WHERE t.name = 'EmailDeliveryLog' AND i.type <= 1
ORDER BY p.partition_number;

--Para determinar a coluna de parti��o para uma tabela particionada
SELECT Distinct t.object_id AS Object_ID, t.name AS TableName, ic.column_id as PartitioningColumnID, col.COLUMN_NAME AS PartitioningColumnName 
FROM sys.tables AS t
JOIN sys.indexes AS i
    ON t.object_id = i.object_id
JOIN sys.columns AS c
    ON t.object_id = c.object_id
JOIN sys.partition_schemes AS ps
    ON ps.data_space_id = i.data_space_id
JOIN sys.index_columns AS ic
    ON ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.partition_ordinal > 0
JOIN INFORMATION_SCHEMA.COLUMNS col
    ON col.TABLE_NAME = t.name
      AND col.ORDINAL_POSITION = ic.column_id
WHERE t.name = 'EmailDeliveryLog'
AND i.type <= 1;


--Quantidade de Linhas Por Parti��o
SELECT OBJECT_NAME(p.object_id) as obj_name, p.index_id, p.partition_number,d.name, p.rows, a.type, a.filegroup_id 
FROM sys.system_internals_allocation_units a
JOIN sys.partitions p
ON p.partition_id = a.container_id
left join sys.data_spaces d
ON d.data_space_id= a.filegroup_id
WHERE p.object_id = (OBJECT_ID(N'EmailDeliveryLog'))
and p.index_id = 1
ORDER BY obj_name, p.index_id, p.partition_number;


ALTER INDEX ALL ON EmailDeliveryLog REBUILD PARTITION = 8 WITH (DATA_COMPRESSION = PAGE) 

dbcc shrinkfile (EmailDeliveryLog_0008,1)