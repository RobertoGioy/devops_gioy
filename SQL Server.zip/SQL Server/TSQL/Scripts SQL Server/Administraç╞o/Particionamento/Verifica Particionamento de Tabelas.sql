-- DESCOBRIR MENOR DATA E MAIOR DATA E A QUANTIDADE DE REGISTROS DA TABELA EM CADA PARTI��O
SELECT	$partition.WeekDateRangePFN(LogDate) AS [Partition Number],
		min(LogDate) AS [Min LogDate],
		max(LogDate) AS [Max LogDate],
		count(*) AS [Rows In Partition]
FROM	Udial.CommandLog
GROUP BY $partition.WeekDateRangePFN(LogDate)
ORDER BY [Partition Number]
GO

-- DESCOBRIR RANGE DE DATA DE CADA PARTI��O
SELECT * FROM sys.partition_range_values WHERE function_id = 65536
GO

-- DESCOBRIR NOME DO FILEGROUP DO RANGE DESEJADO
SELECT	ps.name AS PSName, dds.destination_id AS PartitionNumber, fg.name AS FileGroupName
FROM	(((sys.tables AS t INNER JOIN sys.indexes AS i 
ON		(t.object_id = i.object_id)) INNER JOIN sys.partition_schemes AS ps 
ON		(i.data_space_id = ps.data_space_id)) INNER JOIN sys.destination_data_spaces AS dds 
ON		(ps.data_space_id = dds.partition_scheme_id)) INNER JOIN sys.filegroups AS fg
ON		dds.data_space_id = fg.data_space_id
WHERE	(t.name = 'CommandLog') and (i.index_id IN (0,1))
AND		dds.destination_id = $partition.WeekDateRangePFN('2011-05-26')
GO

-- DESCOBRIR APENAS A QUANTIDADE DE REGISTROS DE UMA TABELA EM UMA PARTI��O
SELECT	ps.row_count
FROM	sys.dm_db_partition_stats ps INNER JOIN sys.partitions p
ON		ps.partition_id = p.partition_id
WHERE	p.[object_id] IN (OBJECT_ID('Udial.CommandLog')) AND p.partition_number = 1 -- SUBSTITUIR PELA PARTI��O DESEJADA
GO

-- DESCOBRIR A QUANTIDADE DE REGISTROS DE UMA TABELA EM CADA PARTI��O
SELECT	OBJECT_NAME(ps.[object_id]) as tablename, ps.partition_number, ps.row_count
FROM	sys.dm_db_partition_stats ps INNER JOIN sys.partitions p
ON		ps.partition_id = p.partition_id AND p.[object_id] IN (OBJECT_ID('Udial.CommandLog'))
GO

-- DESCOBRIR SE EXISTE VALOR COM UM RANGE DE DATA ESPEC�FICO
SELECT	prv.value
FROM	sys.partition_functions AS pf JOIN sys.partition_range_values AS prv 
ON		prv.function_id = pf.function_id
WHERE	pf.name = 'WeekDateRangePFN' AND CAST(prv.value AS datetime) = '2011-05-31 23:59:59.997'