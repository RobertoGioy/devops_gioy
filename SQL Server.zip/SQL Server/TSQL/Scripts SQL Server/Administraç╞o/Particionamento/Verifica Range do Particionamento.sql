declare @pfname sysname

set @pfname = 'MonthDateRangePFN'

select	Tabela		= t.name, 
		ParticaoNro	= dds.destination_id,
		Filegroup	= fg.name,
		RangeDate	= convert(char(10),max(prv.value),120), 
		nrLinhas	= sum(pt.rows)
FROM	sys.tables t 
		inner join sys.indexes i on t.object_id= i.object_id and i.index_id in (0,1)
		inner join sys.dm_db_partition_stats p on p.index_id = i.index_id and p.object_id = i.object_id
		inner join sys.partition_schemes ps on i.data_space_id = ps.data_space_id
		inner join sys.destination_data_spaces dds on ps.data_space_id = dds.partition_scheme_id
		inner join sys.filegroups fg on fg.data_space_id = dds.data_space_id
		inner join sys.partitions pt on t.object_id= pt.object_id and pt.partition_number = dds.destination_id
		inner join sys.partition_functions pf on pf.function_id = ps.function_id
		left join sys.partition_range_values prv on prv.function_id = pf.function_id and prv.boundary_id = dds.destination_id and prv.boundary_id = p.partition_number
where	pf.name = @pfname
group by	t.name, dds.destination_id, fg.name
order by	t.name, dds.destination_id, fg.name

