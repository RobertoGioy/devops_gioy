/*
USE [master]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [A_Menor_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [B_Janeiro_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [C_Fevereiro_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [D_Marco_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [E_Abril_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [F_Maio_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [G_Junho_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [H_Julho_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [I_Agosto_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [J_Setembro_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [K_Outubro_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [L_Novembro_2014]
GO
ALTER DATABASE [DCGP] ADD FILEGROUP [M_Dezembro_2014]
GO


USE [master]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'A_Menor_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\A_Menor_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [A_Menor_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'B_Janeiro_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\B_Janeiro_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [B_Janeiro_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'C_Fevereiro_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\C_Fevereiro_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [C_Fevereiro_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'D_Marco_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\D_Marco_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [D_Marco_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'E_Abril_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\E_Abril_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [E_Abril_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'F_Maio_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\F_Maio_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [F_Maio_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'G_Junho_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\G_Junho_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [G_Junho_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'H_Julho_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\H_Julho_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [H_Julho_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'I_Agosto_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\I_Agosto_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [I_Agosto_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'J_Setembro_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\J_Setembro_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [J_Setembro_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'K_Outubro_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\K_Outubro_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [K_Outubro_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'L_Novembro_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\L_Novembro_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [L_Novembro_2014]
GO
ALTER DATABASE [DCGP] ADD FILE ( NAME = N'M_Dezembro_2014', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\M_Dezembro_2014.ndf' , SIZE = 3072KB , FILEGROWTH = 1024KB ) TO FILEGROUP [M_Dezembro_2014]
GO
*/
GO

--Drop Partition FUNCTION PF_Month_2014
GO
USE DCGP
CREATE PARTITION FUNCTION PF_Month_2014 (DateTime)
AS RANGE RIGHT
FOR VALUES ('2014-01-01','2014-02-01','2014-03-01','2014-04-01','2014-05-01','2014-06-01','2014-07-01','2014-08-01','2014-09-01','2014-10-01','2014-11-01','2014-12-01')

GO

SELECT * FROM SYS.PARTITION_RANGE_VALUES

GO

USE DCGP

GO
--Drop Partition Scheme PS_Month_2014

CREATE PARTITION SCHEME PS_Month_2014 AS PARTITION PF_Month_2014 TO (A_Menor_2014, B_Janeiro_2014, C_Fevereiro_2014, D_Marco_2014, E_Abril_2014, F_Maio_2014, G_Junho_2014, H_Julho_2014, I_Agosto_2014, J_Setembro_2014, K_Outubro_2014, L_Novembro_2014, M_Dezembro_2014)


GO

--Select * From sys.partition_schemes


GO
ALTER TABLE dbo.Itens_Pedido	DROP CONSTRAINT PK_Itens_Pedido /* E TODOS OS DEMAIS INDICES*/
GO
CREATE CLUSTERED INDEX [IDXCL_Itens_Pedido] ON [dbo].[Itens_Pedido]([Datcai])	WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF) ON [PS_Month_2014]([Datcai])
GO
ALTER TABLE dbo.Itens_Pedido ADD CONSTRAINT PK_Itens_Pedido PRIMARY KEY NONCLUSTERED (Codemp, nummap, numped, Seq, pecodi, tippro, tipped) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


SELECT OBJECT_NAME(p.object_id) as obj_name, p.index_id, p.partition_number,d.name, p.rows, a.type, a.filegroup_id 
FROM sys.system_internals_allocation_units a
JOIN sys.partitions p
ON p.partition_id = a.container_id
left join sys.data_spaces d
ON d.data_space_id= a.filegroup_id
WHERE p.object_id = (OBJECT_ID(N'Itens_Pedido'))
and p.index_id = 1
ORDER BY obj_name, p.index_id, p.partition_number;

GO

USE [DCGP]
GO
DBCC SHRINKFILE (N'SL204_AVISTA_Data' , EMPTYFILE)
GO


/*
USE [DCGP]
DBCC SHRINKFILE (N'SL204_AVISTA_Data' , EMPTYFILE)
*/
/*
CREATE NONCLUSTERED INDEX Idx_Itens_Pedido_Par_PRIMARY On Itens_Pedido(Codemp, Datped,Datcai, nummap, numped, pecodi, tippro) On [PRIMARY]
CREATE NONCLUSTERED INDEX Idx_Itens_Pedido_Par_FG2010 On Itens_Pedido(Codemp, Datped,Datcai, nummap, numped, pecodi, tippro) On FG2010
CREATE NONCLUSTERED INDEX Idx_Itens_Pedido_Par_FG2011 On Itens_Pedido(Codemp, Datped,Datcai, nummap, numped, pecodi, tippro) On FG2011
CREATE NONCLUSTERED INDEX Idx_Itens_Pedido_Par_FG2012 On Itens_Pedido(Codemp, Datped,Datcai, nummap, numped, pecodi, tippro) On FG2012

EXEC Dbcc showContig(Itens_Pedido,Idx_Itens_Pedido_Par_PRIMARY)
EXEC Dbcc showContig(Itens_Pedido,Idx_Itens_Pedido_Par_FG2010)
EXEC Dbcc showContig(Itens_Pedido,Idx_Itens_Pedido_Par_FG2011)
EXEC Dbcc showContig(Itens_Pedido,Idx_Itens_Pedido_Par_FG2012)





DECLARE @TABLE2  SYSNAME
DECLARE @TABLE3  SYSNAME
DECLARE REG2 CURSOR FOR

SELECT OBJECT_NAME(p.object_id) as obj_name, p.partition_number
FROM sys.system_internals_allocation_units a
JOIN sys.partitions p
ON p.partition_id = a.container_id
left join sys.data_spaces d
ON d.data_space_id= a.filegroup_id
WHERE 
--p.object_id = (OBJECT_ID(N'Nota_Fiscal'))and 
p.index_id = 1
And OBJECT_NAME(p.object_id) IN 
				(Select Name From (
				Select Name, Count(*) Qtd From (
				SELECT OBJECT_NAME(object_id) as Name, partition_number
				From 
				sys.partitions
				--Where OBJECT_NAME(object_id) IN ('Nota_Fiscal','Comissao')
				Group By OBJECT_NAME(object_id) , partition_number)A
				Group By Name
				)B
				Where Qtd>1)
And d.name= N'PRIMARY'
ORDER BY obj_name, p.index_id, p.partition_number;

open reg2 
fetch next  from reg2 into  @table2,@table3 
while @@fetch_status = 0 
begin
        print'Reindexando Tabela ---->  ' +@table2 
		PRINT ('Alter Index All On ' +@table2 + ' REORGANIZE Partition = ' +@table3 + '')+ char(10)
		fetch next from reg2 into @table2,@table3 
end 
close reg2
deallocate reg2


DECLARE @TABLE2  SYSNAME
DECLARE REG2 CURSOR FOR

SELECT OBJECT_NAME(p.object_id) as obj_name
FROM sys.system_internals_allocation_units a
JOIN sys.partitions p
ON p.partition_id = a.container_id
left join sys.data_spaces d
ON d.data_space_id= a.filegroup_id
WHERE 
--p.object_id = (OBJECT_ID(N'Nota_Fiscal'))and 
p.index_id = 1
And NOT OBJECT_NAME(p.object_id) IN 
				(Select Name From (
				Select Name, Count(*) Qtd From (
				SELECT OBJECT_NAME(object_id) as Name, partition_number
				From 
				sys.partitions
				--Where OBJECT_NAME(object_id) IN ('Nota_Fiscal','Comissao')
				Group By OBJECT_NAME(object_id) , partition_number)A
				Group By Name
				)B
				Where Qtd>1)
And d.name= N'PRIMARY'
ORDER BY obj_name

open reg2 
fetch next  from reg2 into  @table2 
while @@fetch_status = 0 
begin
        print'Reindexando Tabela ---->  ' +@table2 + char(10)
		exec ('DBCC dbreindex (' +@table2 + ','''',90)')
		fetch next from reg2 into @table2 
end 
close reg2
deallocate reg2

/*Linhas Por Parti��o*/
 Select $partition.PF_Month_2014(Datent), Count(*) From Nota_Fiscal
 Group By $partition.PF_Month_2014(Datent)
 Order By $partition.PF_Month_2014(Datent)


/*VERIFICA TABELA X FILE GROUP*/
select name=left(o.name,100),filegroup = s.groupname
from sysfilegroups s, sysindexes i,sysobjects o
where s.groupname <>'PRIMARY'
and i.groupid = s.groupid and i.id=o.id

*/