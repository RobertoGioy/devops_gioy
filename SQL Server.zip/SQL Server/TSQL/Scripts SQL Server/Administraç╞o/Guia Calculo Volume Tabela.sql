set nocount on

DECLARE @RowSize 	int
	,@TamTabela 	numeric(18)
	,@NrPaginas	numeric(18)
	,@LinhasPag	numeric(18)
	,@NrLinhas	int

SELECT  @RowSize = (40 + 20) -- 2 colunas varchar
	+ (3 * 4) -- 3 int
	+ (3 * 2) -- 2 smallint
	+ (1 * 8) -- 1 money

SET @NrLinhas = 5000

SELECT Tamanha_da_Linha = @RowSize, Nr_de_Linhas = @NrLinhas

SET @LinhasPag = 8060 / (@RowSize + 2)

SELECT Linhas_por_Pagina = @LinhasPag

SET @NrPaginas = @NrLinhas / @LinhasPag

SELECT Nr_de_Paginas = @NrPaginas 

SET @TamTabela = 8192 * @NrPaginas

SELECT  Tamanho_da_Tabela_Bytes = @TamTabela
	,Tamanho_da_Tabela_KB = @TamTabela / 1024
	,Tamanho_da_Tabela_MB = (@TamTabela / 1024) / 1024
	