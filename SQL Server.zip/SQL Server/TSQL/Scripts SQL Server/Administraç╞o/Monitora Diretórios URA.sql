Use SkyAnalysis

GO

CREATE TABLE REGISTROS
(
DIRETORIO    VARCHAR(200),
ARQUIVO      VARCHAR(500),
TAMANHO		 FLOAT,
DATACRIACAO  DATETIME,
AMPM		 CHAR(2),
QUANTIDADE   VARCHAR(500)
)

EXEC MASTER.dbo.Xp_cmdshell 'net use \\177.53.210.16\c$\inetpub\wwwroot\WorkProcess\Sky /user:administrator 1Qaz2Wsx'

GO

--Arquivos Disponiveis no STCP
Create Table [Monitoramento].[DirList]
( 
Line Varchar(MAX)
)
GO

Insert Into Dir_Entrada
exec master.dbo.xp_dirtree '\\177.53.210.16\c$\STCPCLT-SKY\O0055SKY\ENTRADA',1,1

INSERT INTO REGISTROS
SELECT 
'\\177.53.210.16\c$\STCPCLT-SKY\O0055SKY\ENTRADA' DIRETORIO,
''												  ARQUIVO,
0												  TAMANHO,
CAST(CONVERT(VARCHAR,GETDATE(),101)+' ' + RTRIM(REPLACE(REPLACE(Right(IsNull(Convert(Varchar,GetDate(),100),''),7),'PM',''),'AM','')) AS DATETIME)
		                                          DATACRIACAO,
REVERSE(SUBSTRING(REVERSE(CONVERT(VARCHAR(30),GETDATE(),131)),1,2)) AMPM,
COUNT(1)										  QUANTIDADE
From Dir_Entrada Where Directory Like '%SKY_IVR_%'



--Arquivos Disponiveis no WorkProcess
Create Table Dir_Imported
(
Directory Varchar(200),
Expr1 int,
Expr2 Int
)
GO

Insert Into Dir_Imported
exec master.dbo.xp_dirtree '\\177.53.210.16\c$\inetpub\wwwroot\WorkProcess\Sky\Ura\Imported',1,1

Select COUNT(1) From Dir_Imported Where Directory Like '%SKY_IVR_%'

SELECT 
	'\\177.53.210.16\c$\STCPCLT-SKY\O0055SKY\ENTRADA' DIRETORIO,
	''												  ARQUIVO,
	0												  TAMANHO,
	CAST(CONVERT(VARCHAR,GETDATE(),101)+' ' + RTRIM(REPLACE(REPLACE(Right(IsNull(Convert(Varchar,GetDate(),100),''),7),'PM',''),'AM','')) AS DATETIME)
													  DATACRIACAO,
	REVERSE(SUBSTRING(REVERSE(CONVERT(VARCHAR(30),GETDATE(),131)),1,2)) AMPM,
	COUNT(1)										  QUANTIDADE
	FROM Dir_Imported 
	WHERE Directory Like '%SKY_IVR_%'



Create Table Dir_Processed
(
Directory Varchar(200),
Expr1 int,
Expr2 Int
)
GO

Insert Into Dir_Processed
exec master.dbo.xp_dirtree '\\177.53.210.16\c$\inetpub\wwwroot\WorkProcess\Sky\Ura\Processed',1,1

Select * From Dir_Processed Where Directory Like '%SKY_IVR_%'


CREATE TABLE dirError (
 id int identity(1,1),
 line nvarchar(1000)
)
GO

INSERT INTO dirList (line) 
EXEC xp_cmdshell 'dir \\177.53.210.16\c$\inetpub\wwwroot\WorkProcess\Sky\Ura\Processed'

 SELECT 
		 CAST(SUBSTRING(line,1,17)AS DATETIME) [DATA_CRIACAO],
		 SUBSTRING(line,18,3) AMPM,
		 CAST(REPLACE(LTRIM(RTRIM(SUBSTRING(line,21,19))),',','') AS INT) TAMANHO,
		 SUBSTRING(line,39,100) ARQUIVO
 INTO #PROCESSED
 FROM dirList
 WHERE NOT SUBSTRING(line,18,19) LIKE '%<DIR>%'
	   AND SUBSTRING(line,37,100) LIKE '%IVR%'


Select Top 1 * From #PROCESSED
Order by Data_criacao Desc

--dir *.txt /a

