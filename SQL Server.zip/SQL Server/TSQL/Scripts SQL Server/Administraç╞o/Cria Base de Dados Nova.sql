--select * from empresas

/*************************DESATIVA TRIGGERS E CONSTRAINTS**********************************/
sp_msforeachtable ' alter table ? nocheck constraint all alter table ? disable trigger all'
/******************************************************************************************/


/*************************EXCLUI TABELAS COM SCHEMA MAPINFO********************************/
Select 'Drop Table ' +Rtrim(B.Name) +'.'+Rtrim(A.Name) From SysObjects A
Inner Join  Sys.Schemas B On A.Uid=B.Schema_id
Where B.Name Like '%mapinfo%' And A.Xtype = 'U'
/******************************************************************************************/


/**********************************TRUNCATE************************************************/
DECLARE @VAR1 SYSNAME
DECLARE CURSOR1 CURSOR FOR

select name from sysobjects where xtype='U' and name not in(
'AbrevPed','Bancos','Balanco_Geral','Bloqueio','Cadastro_Caixa','C_Custo','C_CustoCon','C_CustoCont','C_custocontabil','CCusto_Imob','Calendario','Canais','Categoria','Cidades',
'Cod_Tributario','Combustivel','Config','CP_Departamento','CP_Regiao','CP_RegiaoXSetor','CP_Setor','CP_SetorXDepartamento','Cupom','Dados','Efetuar','Empresas','Empresas_Historico',
'Embalagens','Equipe_Venda','Estados','Fab_veiculos','Fat_contab','Forma_Pagto','Grupo_canais','Grupo_comissao','Grupo_Imob','Grupo_Mod3','Grupo_Pecas','GruposSistema','H_Padrao',
'Historico','HPadrao_CP','Imob_Grupo','Imob_Local','Imob_SubGrupo','Insumos','Itens_Grupo_Mod3','Itens_Mod_Balanco','Itens_Mod_Nota','Locais_Imob','Logins','Marcas',
'Marcas_Pneus','Mensagem','Mod_Balanco','Mod_Nota','Mod_Veiculos','Modulos','Montagem','Mot_saida','Motivos','Nat_Oper','Nivel','Opcfat','Opcoes','Orcamentos','PagarC',
'Pagar_cont','Paises','Pis_Cofins','Plano_Contas','Produtos','Relcaixa','Relcaixa_Itens','Regiao','Sabor','SubGrupo','Tip_veiculos','Tipo','Tipo_Controle','TipoAuxiliar',
'Tipos_Manutencao','TiposBloqueios','Transacao','UF_UF','Usuarios','Valida','Vasilhames','MetaLitro','Parametros','Fec_Geral', 'Fec_Modelo', 'Fec_Modelo_Itens',
'CFGNFE','GrupoBonificacaoXProduto',
-- Tabelas n�o padr�es mas que as vezes s�o pedidas para copiar 
'Fornecedores','Clientes','Clixvend','Vendedores','Motorista','Agencias','Ajudantes','Pastas','Subordinacao','Comissao','Forma_Pagto','Form_PagtoClientes',
'Tabela_Preco','Itens_Tabela','Tabela_ICMS','Veiculos',

-- Tabelas que possuem Foreign Key - Precisam serem deletadas depois
'Fornecedores','ItensImob','Mov_Faturas','Imob_Item','dados','empresas','apropria','imob_item','hpadrao_cp','c_custo','bancos','imob_grupo','imob_local',
'Imob_SubGrupo','VW50_NFE','VW60_DET','VW61_DET_DI',
'Ajuste_Contribuicao','Apuracao_Contribuicao_Cofins','Apuracao_Contribuicao_Pis',
'Apuracao_Credito_Cofins','Apuracao_Credito_Pis','Apuracao_Pis_Cofins','Arquivo',
'baixa_estado','baixa_forma_pagto','baixa_ocorrencia','Contribuicao_Pis_Cofins',
'cst_pis_cofins','Destinos','Duplicata','Frota_PerfilCarga','GrupoBonificacao',
'IMOB_CCUSTO_','IMOB_DESCRBEM_','IMOB_DESCRSUC_','IMOB_GRUPO_','IMOB_ITEM_',
'IMOB_LOCAL_','IMOB_PRNATBCCRED_','LivroCaixa','Tipo_Contribuicao','Tipo_creditos'

)order by name

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1
WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT 'APAGANDO TABELA --> '+@VAR1
	EXEC ('TRUNCATE TABLE '+@VAR1)
	--EXEC ('DELETE FROM '+@VAR1)
	FETCH NEXT FROM CURSOR1 INTO @VAR1
END
CLOSE CURSOR1
DEALLOCATE CURSOR1

/******************************************************************************************/


/**********************************APAGA TUDO**********************************************/

Select 'DELETE FROM ' + RTRIM(NAME) + CHAR(10) + 'GO' From SysObjects where Name In (
'Fornecedores','ItensImob','Mov_Faturas','Imob_Item','dados','apropria','imob_item','hpadrao_cp','imob_grupo','imob_local',
'Imob_SubGrupo','VW50_NFE','VW60_DET','VW61_DET_DI',
'Ajuste_Contribuicao','Apuracao_Contribuicao_Cofins','Apuracao_Contribuicao_Pis',
'Apuracao_Credito_Cofins','Apuracao_Credito_Pis','Apuracao_Pis_Cofins','Arquivo',
'baixa_estado','baixa_forma_pagto','baixa_ocorrencia','Contribuicao_Pis_Cofins',
'cst_pis_cofins','Destinos','Duplicata','Frota_PerfilCarga','GrupoBonificacao',
'IMOB_PRBX_','IMOB_PRAQ_','IMOB_CCUSTO_','IMOB_DESCRBEM_','IMOB_DESCRSUC_','IMOB_GRUPO_','IMOB_ITEM_',
'IMOB_LOCAL_','IMOB_PRNATBCCRED_','LivroCaixa','Tipo_Contribuicao','Tipo_creditos')
-- Tabelas n�o padr�es mas que as vezes s�o pedidas para copiar 
'Fornecedores','Clientes','Clixvend','Vendedores','Motorista','Agencias','Ajudantes','Pastas','Subordinacao','Comissao',
'Forma_Pagto','Form_PagtoClientes','Tabela_Preco','Itens_Tabela','Tabela_ICMS','Veiculos',
-- Tabelas que possuem Foreign Key - Precisam serem deletadas depois
'ItensImob','Mov_Faturas','Imob_Item','dados','empresas','apropria','imob_item','hpadrao_cp','c_custo','bancos','imob_grupo','imob_local',
'Imob_SubGrupo','VW50_NFE','VW60_DET','VW61_DET_DI',
'Ajuste_Contribuicao','Apuracao_Contribuicao_Cofins','Apuracao_Contribuicao_Pis',
'Apuracao_Credito_Cofins','Apuracao_Credito_Pis','Apuracao_Pis_Cofins','Arquivo',
'baixa_estado','baixa_forma_pagto','baixa_ocorrencia','Contribuicao_Pis_Cofins',
'cst_pis_cofins','Destinos','Duplicata','Frota_PerfilCarga','GrupoBonificacao',
'IMOB_CCUSTO_','IMOB_DESCRBEM_','IMOB_DESCRSUC_','IMOB_GRUPO_','IMOB_ITEM_',
'IMOB_LOCAL_','IMOB_PRNATBCCRED_','LivroCaixa','Tipo_Contribuicao','Tipo_creditos'
/******************************************************************************************/


/**********************************APAGA PARCIAL*******************************************/

Select 'DELETE FROM ' + RTRIM(NAME) + CHAR(10) + 'GO' From SysObjects where Name In (
'Mov_Faturas','Dados','Apropria','Duplicata','Baixa_Dpl','Apropria_CP','Baixa_CP2'
'VW50_NFE','VW60_DET','VW61_DET_DI',
'Apuracao_Contribuicao_Cofins','Apuracao_Contribuicao_Pis',
'Apuracao_Credito_Cofins','Apuracao_Credito_Pis','Apuracao_Pis_Cofins','Arquivo',
'baixa_estado','baixa_forma_pagto','Contribuicao_Pis_Cofins',
'Destinos','Duplicata','Frota_PerfilCarga',
'LivroCaixa')
/******************************************************************************************/


/**********************************MUDAR O CODIGO DA EMPRESA********************************/


DECLARE @VAR1 SYSNAME
DECLARE CURSOR1 CURSOR FOR

select s1.name from sysobjects s1 inner join syscolumns s2 on s1.id=s2.id 
where s1.xtype='U' and s2.name='Codemp' order by s1.name

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1
WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT 'ALTERANDO TABELA --> '+@VAR1
	EXEC ('UPDATE '+@VAR1+ ' SET CODEMP=''554''')
	FETCH NEXT FROM CURSOR1 INTO @VAR1
END
CLOSE CURSOR1
DEALLOCATE CURSOR1
/******************************************************************************************/


/**********************************ACERTA TABELAS CADASTROS *******************************/

--Produ��o
UPDATE CFGNFE SET NUMNFE = 0, PORTA_IMPR = 'SANSUNG_XXX', IDENT_IMPR='NFE_XXX', BASE='NFEPRD_BXX'
--Homologa��o
--UPDATE CFGNFE SET NUMNFE = 0, PORTA_IMPR = 'SANSUNG_XXX', IDENT_IMPR='NFE_XXX', BASE='NFEPRD_HOMOLOG', AMBIENTE = 2

UPDATE CONFIG SET NUMNOT = 0, NUMPLA = 1, NUMMAP = 0, NUMPED = 0

UPDATE EMPRESAS SET NOMEMP = '', ENDEMP = '', NUMEMP = 0,
					BAIEMP = '', CIDEMP = '', ESTEMP = '', TELEMP = '',
					FAXEMP = '', CGCEMP = '', INSEMP = '', CEPEMP = '', DATINC = GETDATE(),
					ATIVO = 'S', ABREVE = '', INSSUB = '', CODDIS = 0 , NROJUN = '',
					DATJUN = NULL, INSMUN = '', PROCESSADO = '', MATFIL = 'M',
					CODMAT = 0, SEQBAN = 0, NUMBAN = 0, NOVNOTA = '', LOGMARCA = '' 

INSERT INTO EMPRESAS_HISTORICO(CODEMP,DATINC,DATFIM,NOMEMP,ENDEMP,NUMEMP,BAIEMP,CIDEMP,ESTEMP,TELEMP,FAXEMP,CGCEMP,INSEMP,CEPEMP,INSSUB,CODDIS,NROJUN,DATJUN,INSMUN,PROCESSADO,MATFIL,SEQBAN,NUMBAN,NOVNOTA,LOGMARCA)
SELECT CODEMP,DATINC,NULL,NOMEMP,ENDEMP,NUMEMP,BAIEMP,CIDEMP,ESTEMP,TELEMP,FAXEMP,CGCEMP,INSEMP,CEPEMP,INSSUB,CODDIS,NROJUN,DATJUN,INSMUN,PROCESSADO,MATFIL,SEQBAN,NUMBAN,NOVNOTA,LOGMARCA FROM EMPRESAS

DELETE FROM USUARIOS WHERE NOME <>'SUPORTE'
DELETE FROM LOGINS WHERE LOGIN  <>'SUPORTE'
DELETE FROM VALIDA WHERE LOGIN  <>'SUPORTE'

INSERT INTO VALIDA
SELECT 'USUARIO',TABELA,ALTERA,INCLUI,EXCLUI,CONSULTA,SINTAXE FROM VALIDA WHERE LOGIN = 'SUPORTE'

INSERT INTO LOGINS
SELECT 'USUARIO',STATUS,USUARIO,FECHA,'' FROM LOGINS WHERE LOGIN = 'SUPORTE'

INSERT INTO USUARIOS
SELECT 'USUARIO',MODULO,'*',ITEM FROM USUARIOS WHERE NOME= 'SUPORTE'
/******************************************************************************************/


/**********************************EXCLUI CONSTRAINTS**************************************/

SELECT 'ALTER TABLE '+S2.NAME+' DROP CONSTRAINT '+S.NAME FROM SYSOBJECTS S INNER JOIN SYSOBJECTS S2 ON S.PARENT_OBJ = S2.ID WHERE S.XTYPE='F'
/******************************************************************************************/


/**********************************ACERTA PARAMETROS***************************************/
If (Select Count(*) From Parametros Where Nome in ('AcertaSaldoEspelho'))>0
	Begin
		Update Parametros Set Valor = 'True' Where Nome in ('AcertaSaldoEspelho')
	End
Else 
	Begin
		Insert Into Parametros
		Select Codemp, 'AcertaSaldoEspelho', 'Disponibiliza��o do saldo fiscal para faturamento', 'True','Boolean'
		From Empresas
	 End


If (Select Count(*) From Parametros Where Nome in ('Termo_Comodato'))>0
	Begin
		Update Parametros Set Valor = 'True' Where Nome in ('Termo_Comodato')
	End
Else 
	Begin
		Insert Into Parametros
		Select Codemp, 'Termo_Comodato', 'Permite a utiliza��o do novo Termo de Comodato', 'True','Boolean'
		From Empresas
	 End


If (Select Count(*) From Parametros Where Nome in ('PadraoDataProc'))>0
	Begin
		Update Parametros Set Valor = 'True' Where Nome in ('PadraoDataProc')
	End
Else 
	Begin
		Insert Into Parametros
		Select Codemp, 'PadraoDataProc', 'Controle de horario de Fechamento', 'True','Boolean'
		From Empresas
	 End


If (Select Count(*) From Parametros Where Nome in ('AutomatizaEstoque'))>0
	Begin
		Update Parametros Set Valor = 'True' Where Nome in ('AutomatizaEstoque')
	End
Else 
	Begin
		Insert Into Parametros
		Select Codemp, 'AutomatizaEstoque', 'Controle de Automatizacao de Estoque', 'True','Boolean'
		From Empresas
	 End
/******************************************************************************************/


/**********************************ACERTA USER BD******************************************/
SP_CHANGE_USERS_LOGIN 'AUTO_FIX','PROGRAMADOR'
GO
SP_CHANGE_USERS_LOGIN 'AUTO_FIX','CONSULTA'
GO
SP_CHANGE_USERS_LOGIN 'AUTO_FIX','SUPORTE'
GO
SP_CHANGE_USERS_LOGIN 'AUTO_FIX','REGIONAL'
GO



/*
Para bases GPs

CREATE LOGIN [AuditoriaGP] WITH PASSWORD=N'fef73jf888', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
CREATE USER [AuditoriaGP] FOR LOGIN [AuditoriaGP] WITH DEFAULT_SCHEMA=[dbo]
exec sp_addrolemember N'db_owner', N'AuditoriaGP'

*/
/******************************************************************************************/


/**********************************ATIVA TRIGGERS E CONSTRAINTS****************************/

sp_msforeachtable ' alter table ? check constraint all alter table ? enable trigger all'

/******************************************************************************************/