SELECT Distinct 
 Object_name(Referenced_Major_id)
 FROM SYS.SQL_DEPENDENCIES 
 Where Object_id In (Select Object_id From Sys.Views Where Name = 'VS_Venda')