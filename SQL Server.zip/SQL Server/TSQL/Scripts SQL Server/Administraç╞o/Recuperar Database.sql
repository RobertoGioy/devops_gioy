--  muitas das vezes pode ser que o comando sp_attachdb n�o funcione, neste caso vc pode tentar recuperar usando um DBCC n�o documentado.
-- 
-- Inicialemte, crie um banco com o mesmo nome do banco corrompido ( Isto criar� uma entrada na sysdatabase).
-- 
-- Efetue um stop no SQL e substitua os arquivo .mdf que foi craido com o novo banco pelo arquivo .mdf que vc possui ( Oque deve ser recuperado) e exclua o .ldf.
-- 
-- Start o SQL. Desta forma o banco voltar� em SUSPECT pois ele n�o encontrar� um .ldf
-- 
-- A partir deste ponto siga os passos abaixo:

EXEC sp_configure 'allow updates', 1
RECONFIGURE WITH OVERRIDE
GO

--Altera o status do banco para emergency mode
BEGIN TRAN
UPDATE master..sysdatabases
SET status = status | 32768
WHERE name = 'SeuBanco'

IF @@ROWCOUNT = 1
BEGIN
COMMIT TRAN
RAISERROR('emergency mode set', 0, 1)
END
ELSE
BEGIN
ROLLBACK
RAISERROR('unable to set emergency mode', 16, 1)
END

GO

EXEC sp_configure 'allow updates', 0
RECONFIGURE WITH OVERRIDE
GO

-- Cria um novo log para o banco no caminho especificado
-- 
DBCC REBUILD_LOG('Seubanco','C:Seubanco.ldf')
-- 
-- 
-- Passe um DBCC CHECKDB para verificar a integridade do banco. Se houver problemas de integridade, fa�a um BCP out dos dados de depois um BCP IN em uma nova base.
-- 
-- ALTER DATABASE SeuBanco SET MULTI_USER
-- GO
-- 
-- Pronto, o banco estar� pronto para uso.
-- 
-- Obs: Como vc s� possuia o .mdf, pode ser que vc tenha perdido alguns dados- que provavelmente estavam o .ldf que foi perdido.