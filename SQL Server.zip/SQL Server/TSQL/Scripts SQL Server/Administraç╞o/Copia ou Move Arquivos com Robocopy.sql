exec sp_configure 'show advanced options',1
reconfigure
go

exec sp_configure 'xp_cmdshell',1
exec sp_configure 'show advanced options',0
reconfigure
go

declare @origem nvarchar(4000)
declare @destino nvarchar(4000)
declare @arq nvarchar(200)
declare @copiar bit
declare @pasta bit
declare @ok bit
declare @cmd nvarchar(4000)
declare @log nvarchar(50)

set @ok = 0 -- Erro
set @log = 'log_' + CONVERT(varchar,GETDATE(),112) + '.txt'
set @origem = 'F:\Databases\AuditServerDev\'
set @destino = '\\192.168.210.197\bspodbs03\Databases\AuditServerDev\'
set @arq = ''
set @copiar = 1
set @pasta = 1

----------------------------------------------------------------------------------------
-- Move ou copia arquivos
----------------------------------------------------------------------------------------
if @pasta = 0
begin
if @copiar = 1 -- Copiar
set @cmd = 'robocopy ' + @origem + ' ' + @destino + ' ' + @arq + ' /COPY:DAT /LOG+:' + @origem + @log -- Copia
else -- Mover
set @cmd = 'robocopy ' + @origem + ' ' + @destino + ' ' + @arq + ' /MOVE /LOG+:' + @origem + @log -- Move arquivo
end


----------------------------------------------------------------------------------------
-- Move ou copia pastas
----------------------------------------------------------------------------------------
if @pasta = 1
begin
if @copiar = 1 -- Copiar
set @cmd = 'robocopy ' + @origem + @arq + ' ' + @destino + @arq + ' /COPY:DAT /LOG+:' + @origem + @log -- Copia
else -- Mover
set @cmd = 'robocopy ' + @origem + @arq + ' ' + @destino + @arq + ' /MOVE /LOG+:' + @origem + @log -- Move arquivo
end


----------------------------------------------------------------------------------------
-- Executa
----------------------------------------------------------------------------------------
exec @ok = master..xp_cmdshell @cmd--, no_output 

print @ok
