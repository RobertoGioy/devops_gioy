executar dentro da pasta que est� os arquivos
copy *.rar \\tscliente\c\pasta