
declare @rc int
declare @TraceID int
declare @maxfilesize bigint
declare @DateTime datetime

--SELECT CONVERT(VARCHAR(10), GETDATE(), 112)

set @DateTime = Dateadd(dd,4,Convert(Datetime,(CONVERT(VARCHAR(10), GETDATE(), 112))))--define o hor�rio que termina o monitoramento
set @maxfilesize = 50 --define o tamanho maximo do arquivo de log

--lembre-se de criar uma pasta com o nome Report_NPLK no disco local C.
DECLARE @vFile NVARCHAR(255)
SET @vFile = 'A:\PLKSQLTrc'+CONVERT(VARCHAR(10), GETDATE(), 112)
exec @rc = sp_trace_create @TraceID output, 2, @vFile, @maxfilesize, @Datetime

if (@rc != 0) 
  goto error

-- Client side File and Table cannot be scripted

-- Set the events
declare @on bit
set @on = 1
exec sp_trace_setevent @TraceID, 10, 31, @on
exec sp_trace_setevent @TraceID, 10, 16, @on
exec sp_trace_setevent @TraceID, 10, 1, @on
exec sp_trace_setevent @TraceID, 10, 17, @on
exec sp_trace_setevent @TraceID, 10, 18, @on
exec sp_trace_setevent @TraceID, 10, 34, @on
exec sp_trace_setevent @TraceID, 10, 3, @on
exec sp_trace_setevent @TraceID, 10, 11, @on
exec sp_trace_setevent @TraceID, 10, 35, @on
exec sp_trace_setevent @TraceID, 10, 12, @on
exec sp_trace_setevent @TraceID, 10, 13, @on
exec sp_trace_setevent @TraceID, 10, 14, @on
exec sp_trace_setevent @TraceID, 45, 16, @on
exec sp_trace_setevent @TraceID, 45, 1, @on
exec sp_trace_setevent @TraceID, 45, 17, @on
exec sp_trace_setevent @TraceID, 45, 18, @on
exec sp_trace_setevent @TraceID, 45, 34, @on
exec sp_trace_setevent @TraceID, 45, 3, @on
exec sp_trace_setevent @TraceID, 45, 11, @on
exec sp_trace_setevent @TraceID, 45, 35, @on
exec sp_trace_setevent @TraceID, 45, 12, @on
exec sp_trace_setevent @TraceID, 45, 13, @on
exec sp_trace_setevent @TraceID, 45, 14, @on
exec sp_trace_setevent @TraceID, 12, 31, @on
exec sp_trace_setevent @TraceID, 12, 16, @on
exec sp_trace_setevent @TraceID, 12, 1, @on
exec sp_trace_setevent @TraceID, 12, 17, @on
exec sp_trace_setevent @TraceID, 12, 14, @on
exec sp_trace_setevent @TraceID, 12, 18, @on
exec sp_trace_setevent @TraceID, 12, 3, @on
exec sp_trace_setevent @TraceID, 12, 11, @on
exec sp_trace_setevent @TraceID, 12, 35, @on
exec sp_trace_setevent @TraceID, 12, 12, @on
exec sp_trace_setevent @TraceID, 12, 13, @on
exec sp_trace_setevent @TraceID, 14, 35, @on
exec sp_trace_setevent @TraceID, 15, 35, @on
exec sp_trace_setevent @TraceID, 17, 35, @on
exec sp_trace_setevent @TraceID, 10, 35, @on
exec sp_trace_setevent @TraceID, 12, 35, @on
exec sp_trace_setevent @TraceID, 13, 35, @on


-- Set the Filters
declare @intfilter int
declare @bigintfilter bigint

set @bigintfilter = 250000
exec sp_trace_setfilter @TraceID, 13, 0, 4, @bigintfilter
exec sp_trace_setfilter @TraceID, 35, 0, 6, N'cppro'

-- Set the trace status to start
exec sp_trace_setstatus @TraceID, 1

-- display trace id for future references
select  TraceID = @TraceID
goto finish

error: 
select  ErrorCode = @rc

finish: 
go

/*
SELECT traceid,property,value
FROM ::fn_trace_getinfo(0)
WHERE property = 5

EXEC sp_trace_setstatus 1, 1 --reinicia trace
EXEC  sp_trace_setstatus 2,0 --reinicia para execu��o Trace
EXEC sp_trace_setstatus 2,2 --Deleta para execu��o Trace
*/