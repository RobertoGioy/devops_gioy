USE [master]
GO

/****** Object:  StoredProcedure [dbo].[spQueryIndex]    Script Date: 07/18/2013 14:08:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spQueryIndex]
	@DatabaseID INT
AS
SELECT	equality_columns as 'CamposUtilizadosWhereComIndex', 
		inequality_columns as 'CanposUtilizadosWhereSemIndex', 
		[statement] as 'Banco.Schema.Tabela',
		count(*) As 'Qtde Exec'
FROM	sys.dm_db_missing_index_details
WHERE	database_id = @DatabaseID
AND		inequality_columns IS NOT NULL
GROUP BY equality_columns, inequality_columns, statement
ORDER BY statement
GO


