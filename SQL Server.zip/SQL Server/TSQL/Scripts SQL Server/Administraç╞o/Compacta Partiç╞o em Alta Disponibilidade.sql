--Quando est� com problema
alter database umailng_ipiranga add file (name = 'UmailNG_Ipiranga_EDL17_Ext', filename = 'G:\MSSQLSERVER\DATA\UmailNG_Ipiranga_EDL17_EXT.ndf', size = 100MB, filegrowth = 100MB)
TO FILEGROUP UmailNG_Ipiranga_EDL17
ALTER DATABASE UmailNG_Ipiranga modify file (name = 'UmailNG_Ipiranga_EDL17', maxsize = '17003520 KB')

--Quando normalizar (precisar remover o arquivo "sujo")
ALTER DATABASE UmailNG_Ipiranga modify file (name = 'UmailNG_Ipiranga_EDL17', maxsize = unlimited)
dbcc shrinkfile (UmailNG_Ipiranga_EDL17_Ext, emptyfile)
alter database umailng_ipiranga remove file UmailNG_Ipiranga_EDL17_Ext