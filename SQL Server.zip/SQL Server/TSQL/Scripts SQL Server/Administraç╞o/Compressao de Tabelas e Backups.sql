-- COMPRESS�O DE TABELAS E BACKUP

USE [AdventureWorks2008R2]
GO

-- EXEMPLO DE COMPRESS�O DE TABELAS (POR LINHA)

EXEC sp_spaceused 'Sales.CreditCard'
GO

-- Neste caso, o SQL Server transforma internamente, todas as colunas em tipo de dados vari�vel.

/*
	Sem compress�o : 1496 (Data) + 776 (Index) = 2272
	Com compress�o : 0984 (Data) + 528 (Index) = 1512 => ganho de aprox. 33%
*/

EXEC sp_estimate_data_compression_savings
	@schema_name = 'Sales',
	@object_name = 'CreditCard',
	@index_id = NULL,
	@partition_number = NULL,
	@data_compression = 'ROW'
GO

-- EXEMPLO DE COMPRESS�O DE TABELAS (POR P�GINA)

EXEC sp_spaceused 'Sales.CreditCard'
GO

-- Neste caso, o SQL Server al�m de comprimir registros, comprime tamb�m as p�ginas de dados
-- Por exemplo, em colunas com grande n�mero de dados de mesmo valor.

/*
	Sem compress�o : 1496 (Data) + 776 (Index) = 2272
	Com compress�o : 0736 (Data) + 456 (Index) = 1192 => ganho de aprox. 48%
*/

EXEC sp_estimate_data_compression_savings
	@schema_name = 'Sales',
	@object_name = 'CreditCard',
	@index_id = NULL,
	@partition_number = NULL,
	@data_compression = 'PAGE'
GO

-- COMPRIMINDO POR LINHA
ALTER TABLE Sales.CreditCard
	REBUILD WITH (DATA_COMPRESSION = ROW)

-- COMPRIMINDO POR P�GINA
ALTER TABLE Sales.CreditCard
	REBUILD WITH (DATA_COMPRESSION = PAGE)
	
-- DESCOMPRIMINDO TABELA
ALTER TABLE Sales.CreditCard
	REBUILD WITH (DATA_COMPRESSION = NONE)
	
-- CRIANDO TABELA COM COMPRESS�O
CREATE TABLE EXEMPLO
(
	ID INT IDENTITY(1,1) NOT NULL,
	NAME NVARCHAR(255) NOT NULL
) WITH (DATA_COMPRESSION = PAGE)
GO

-- COMPRESS�O DE BACKUP

-- EXEMPLO SEM COMPRESS�O
BACKUP DATABASE AdventureWorks2008R2
TO DISK = 'C:\BACKUP\AdventureWorks2008R2.BAK'
WITH FORMAT

-- EXEMPLO COM COMPRESS�O

-- Neste caso, o SQL Server l� mais p�ginas em menor tempo, portanto, efetua o backup em menos tempo.
-- Por�m, tem maior consumo de CPU.

BACKUP DATABASE AdventureWorks2008R2
TO DISK = 'C:\BACKUP\AdventureWorks2008R2.BAK'
WITH FORMAT, COMPRESSION
