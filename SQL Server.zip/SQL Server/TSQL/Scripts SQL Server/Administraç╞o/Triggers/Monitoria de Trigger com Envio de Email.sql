
IF EXISTS(
  SELECT *
    FROM sys.triggers
   WHERE name = '%BLOQUEIA_DDL%'
     AND parent_class_desc = N'DATABASE'
)
	DROP TRIGGER BLOQUEIA_DDL ON DATABASE
GO


CREATE TRIGGER [BLOQUEIA_DDL] ON DATABASE 
	FOR DDL_DATABASE_LEVEL_EVENTS
AS 

SET ARITHABORT ON
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

BEGIN
IF  SUSER_SNAME() <> 'SA'
BEGIN
   IF (
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)'))  LIKE ('%ENABLE%TRIGGER%')) OR
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)'))  LIKE ('%DISABLE%TRIGGER%')) OR
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)'))  LIKE ('%ALTER%TRIGGER%')) OR
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)'))  LIKE ('%CREATE%TRIGGER%')) OR
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)'))  LIKE ('%DROP%TRIGGER%'))
	   --OR ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)'))  LIKE ('%DROP%TABLE%')) 
	   --OR ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)'))  LIKE ('%ADD%')) 
	   --OR  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)'))  LIKE ('%ALTER%COLUMN%')) 
	   --OR  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)'))  LIKE ('%DROP%COLUMN%')) 
	   )
   BEGIN
	    
        DECLARE @HOSTNAME VArchar(Max)
	    Set @HOSTNAME = (SELECT Rtrim(EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')))
		Set @HOSTNAME = (Select  (Rtrim(@@SERVERNAME)) + ' - ' + Rtrim(DB_NAME()) + ' - ' + Rtrim(SUSER_NAME()) + ' - ' + Rtrim(HOST_NAME()) + ' - ' + Rtrim(ISNULL(@HOSTNAME,''))) + ''
		
		
		ROLLBACK TRANSACTION
		EXEC 	[172.17.7.3\SQL2008].msdb.dbo.sp_send_dbmail 
				@profile_name = 'SQL Mail', 
				@recipients = 'dba@grupoeouro.com.br;josantos@grupoeouro.com.br',
				@subject = 'DISPAROU A TRIGGER DE BLOQUEIO ',
				@body = @HOSTNAME
		PRINT 'OPERA��O IMPOSS�VEL DE SER EXECUTADA! '
		
   END
 END
END


GO

DENY ALTER ANY DATABASE DDL TRIGGER TO Suporte,Programador


GO


Sp_ADD_Linked_Server [172.17.7.3\SQL2008]