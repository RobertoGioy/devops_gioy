
IF EXISTS(
  SELECT *
    FROM sys.triggers
   WHERE name = '%BLOQUEIO_TRIGGER%'
     AND parent_class_desc = N'DATABASE'
)
	DROP TRIGGER BLOQUEIO_TRIGGER ON DATABASE
GO

CREATE TRIGGER BLOQUEIO_TRIGGER
 ON DATABASE 
	FOR ALTER_TABLE
AS 
IF  SUSER_SNAME() <> 'SA'
BEGIN
   PRINT 'Permiss�o Negada Para Desabilitar Triggers' 
   ROLLBACK TRANSACTION
END

GO

DENY ALTER ANY DATABASE DDL TRIGGER TO Suporte,Programador


GO







