USE msdb
GO
CREATE TABLE t_LogDDL (PostTime datetime, DBName nvarchar(100),LoginName nvarchar(100),UserName nvarchar(100), Event nvarchar(100), Objecttype sysname,Object sysname, TSQL nvarchar(2000));
GO

use db_webmotors
GO
CREATE TRIGGER tg_DDLlog 
ON DATABASE 
FOR DDL_DATABASE_LEVEL_EVENTS 
AS
DECLARE @data XML
SET @data = EVENTDATA()

INSERT msdb.dbo.t_LogDDL 
   (PostTime, DBName,LoginName,UserName, Event, Objecttype,Object, TSQL) 
   VALUES 
   (@data.value('(/EVENT_INSTANCE/PostTime)[1]', 'nvarchar(100)'), 
	@data.value('(/EVENT_INSTANCE/DatabaseName)[1]', 'nvarchar(100)'), 
	@data.value('(/EVENT_INSTANCE/LoginName)[1]', 'nvarchar(100)'), 	
	@data.value('(/EVENT_INSTANCE/UserName)[1]', 'nvarchar(100)'), 
    @data.value('(/EVENT_INSTANCE/EventType)[1]', 'nvarchar(100)'), 
	@data.value('(/EVENT_INSTANCE/ObjectType)[1]','sysname'),
    @data.value('(/EVENT_INSTANCE/ObjectName)[1]','sysname'),
    @data.value('(/EVENT_INSTANCE/TSQLCommand)[1]', 'nvarchar(2000)')) ;
GO

--Test the trigger.

CREATE TABLE TestTable (a int)

select * from  TestTable 

alter table testtable add b varchar(100)

DROP TABLE TestTable ;
GO


SELECT * FROM msdb.dbo.t_LogDDL ;
GO

--Drop the trigger.
DROP TRIGGER log
ON DATABASE
GO
--Drop table ddl_log.
DROP TABLE ddl_log
GO
