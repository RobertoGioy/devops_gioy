
IF  EXISTS (SELECT * FROM sys.triggers WHERE parent_class_desc = 'DATABASE' AND name = N'BLOQUEIA_DDL')
DISABLE TRIGGER [BLOQUEIA_DDL] ON DATABASE

GO


/****** Object:  DdlTrigger [BLOQUEIA_DDL]    Script Date: 01/21/2010 15:33:19 ******/
IF  EXISTS (SELECT * FROM sys.triggers WHERE parent_class_desc = 'DATABASE' AND name = N'BLOQUEIA_DDL')DROP TRIGGER [BLOQUEIA_DDL] ON DATABASE
GO


/****** Object:  DdlTrigger [BLOQUEIA_DDL]    Script Date: 01/21/2010 15:33:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO	
CREATE TRIGGER [BLOQUEIA_DDL] ON DATABASE 
	FOR DDL_DATABASE_LEVEL_EVENTS 
AS 

SET ARITHABORT ON
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

BEGIN
   IF ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%TEMP[_]COMIS%'))	  AND 
      ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%TEMP[_]FORMAS%'))	  AND
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%RES[_]TEMP%'))		  AND
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%TEMPZ%'))		  AND
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%T[_]ST%'))			  AND
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%PEDIDO[_]%'))		  AND
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%ITENS_PEDIDO[_]%')) AND
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%HIST_BLOQPED[_]%')) AND
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%VisaoPosicaoSupervisor%')) AND
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%CHECK%')) AND
	--  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%ALTER TABLE Clientes ENABLE TRIGGER%')) AND
	--  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%ALTER TABLE Clientes DISABLE TRIGGER %')) AND
	  ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) NOT LIKE ('%v[_]piscofins%')) AND
	  (SUSER_NAME() NOT IN ('SA','REPREV') OR ((SELECT EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)')) like ('%DROP TABLE%')))
   BEGIN
		PRINT 'Opera��o imposs�vel de ser executada! Favor consultar um DBA!' 
		ROLLBACK TRANSACTION
   END
END

GO

SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO

DISABLE TRIGGER [BLOQUEIA_DDL] ON DATABASE
GO

ENABLE TRIGGER [BLOQUEIA_DDL] ON DATABASE
GO

IF (SELECT USER_ID('Programador')) IS NOT NULL
DENY ALTER ANY DATABASE DDL TRIGGER TO [Programador]
ELSE
PRINT 'PROGRAMADOR n�o existe'
GO
IF (SELECT USER_ID('Suporte')) IS NOT NULL
DENY ALTER ANY DATABASE DDL TRIGGER TO [Suporte]
ELSE
PRINT 'SUPORTE n�o existe'
GO

