DECLARE @VAR1 SYSNAME
DECLARE CURSOR1 CURSOR FOR

Select NAME From Sys.Databases

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1
WHILE @@FETCH_STATUS = 0
BEGIN
EXEC ('
    USE ['+ @VAR1 + ']
		IF EXISTS (SELECT * FROM SYS.SYSOBJECTS WHERE NAME = N''MOV_ESTOQUE'')
		BEGIN
			IF EXISTS (SELECT * FROM SYS.TRIGGERS WHERE PARENT_CLASS_DESC = ''DATABASE'' AND NAME = N''BLOQUEIA_DDL'')
			BEGIN
				DROP TRIGGER [BLOQUEIA_DDL] ON DATABASE
			END
			IF EXISTS (SELECT * FROM SYS.TRIGGERS WHERE PARENT_CLASS_DESC = ''DATABASE'' AND NAME = N''BLOQUEIA_DDL_SUPORTE'')
			BEGIN
				DROP TRIGGER [BLOQUEIA_DDL_SUPORTE] ON DATABASE
			END
			IF NOT EXISTS (SELECT * FROM SYS.TRIGGERS WHERE PARENT_CLASS_DESC = ''DATABASE'' AND NAME = N''BLOQUEIA_DDL_SUPORTE'')
			BEGIN	
				 EXEC (''  --ALTERADO 25/03/2014
				             CREATE TRIGGER [BLOQUEIA_DDL_SUPORTE] ON DATABASE 
									FOR DDL_DATABASE_LEVEL_EVENTS
								AS 

								SET ARITHABORT ON
								SET ANSI_NULLS ON
								SET QUOTED_IDENTIFIER ON

								BEGIN
								IF  ( (SUSER_SNAME() <> ''''SA'''') AND 
									  (SUSER_SNAME() <> ''''FRS\Cluster'''') AND 
									  (SUSER_SNAME() <> ''''CP\Cluster.Dist'''') AND 
									  (SUSER_SNAME() <> ''''RepRev'''') AND
									  (SUSER_SNAME() <> ''''RepRev_CP'''') AND
									  (SUSER_SNAME() <> ''''Programador''''))
								BEGIN
								   IF (
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%ENABLE%TRIGGER%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%DISABLE%TRIGGER%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%ALTER%TRIGGER%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%CREATE%TRIGGER%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%DROP%TRIGGER%'''')) OR


									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%CREATE%VIEW%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%ALTER%VIEW%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%DROP%VIEW%'''')) OR

									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%CREATE%TABLE%'''') AND 
									  (SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  NOT LIKE (''''%[_]%BACKUP%''''+Rtrim(HOST_NAME())+''''%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%DROP%TABLE%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%TRUNCATE%TABLE%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%ALTER%COLUMN%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%DROP%COLUMN%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%ADD%COLUMN%'''')) OR
						  						   

									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%ALTER%FUNCTION%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%DROP%FUNCTION%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%CREATE%FUNCTION%'''')) OR

									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%CREATE%PROC%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%ALTER%PROC%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%DROP%PROC%'''')) OR

									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%CREATE%INDEX%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%DROP%INDEX%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%ALTER%INDEX%'''')) OR
						  
						  
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%ADD%CONSTRAINT%'''')) OR
									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%DROP%CONSTRAINT%'''')) OR

									  ((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  LIKE (''''%SELECT%INTO%'''') AND 
									  (SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)''''))  NOT LIKE (''''%[_]%BACKUP%''''+Rtrim(HOST_NAME())+''''%''''))
									   )
								   BEGIN
	    
										DECLARE @HOSTNAME VArchar(Max)
										Set @HOSTNAME = (SELECT Rtrim(EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)'''')))
										Set @HOSTNAME = (Select  (Rtrim(@@SERVERNAME)) + '''' - '''' + Rtrim(DB_NAME()) + '''' - '''' + Rtrim(SUSER_NAME()) + '''' - '''' + Rtrim(HOST_NAME()) + '''' - '''' + Rtrim(ISNULL(@HOSTNAME,''''''''))) + ''''''''
		
		
										ROLLBACK TRANSACTION
										EXEC 	SQLMAIL.msdb.dbo.sp_send_dbmail 
												@profile_name = ''''SQLMAIL_CP'''', 
												@recipients = ''''dba@grupopetropolis.com.br'''',
												@subject = ''''DISPAROU A TRIGGER DE BLOQUEIO '''',
												@body = @HOSTNAME
										PRINT ''''OPERA��O IMPOSS�VEL DE SER EXECUTADA! ''''
		
								   END
								 END
								--((SELECT EVENTDATA().value(''''(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]'''',''''nvarchar(max)'''')))
								END
					'')
				END
	END
	')
	FETCH NEXT FROM CURSOR1 INTO @VAR1
END
CLOSE CURSOR1
DEALLOCATE CURSOR1

