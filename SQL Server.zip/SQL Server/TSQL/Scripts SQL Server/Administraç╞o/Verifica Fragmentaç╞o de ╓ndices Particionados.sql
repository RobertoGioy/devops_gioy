SELECT  OBJECT_NAME(i.OBJECT_ID) AS TableName,
		i.name AS IndexName,
		indexstats.avg_fragmentation_in_percent ,
		indexstats.partition_number,
		ISNULL(fg.name,'PRIMARY') AS FileGroupName,
		value AS BoundaryDate,
		fragment_count,
		page_count    
FROM	sys.dm_db_index_physical_stats(NULL, NULL, NULL, NULL , 'DETAILED') indexstats
		INNER JOIN sys.indexes i 
ON		i.OBJECT_ID = indexstats.OBJECT_ID AND i.index_id = indexstats.index_id
		LEFT JOIN sys.partition_schemes ps
ON		(ps.data_space_id = i.data_space_id)
		LEFT JOIN sys.partition_functions f
ON		(f.function_id = ps.function_id)
		LEFT JOIN sys.partition_range_values rv   
ON		(f.function_id = rv.function_id AND indexstats.partition_number = rv.boundary_id)
		LEFT JOIN sys.destination_data_spaces dds
ON		(dds.partition_scheme_id = ps.data_space_id AND dds.destination_id = indexstats.partition_number)
		LEFT JOIN sys.filegroups fg
ON		(dds.data_space_id = fg.data_space_id)
WHERE indexstats.avg_fragmentation_in_percent > 30


SELECT	OBJECT_NAME(si.OBJECT_ID) AS TableName, si.name, stat.[avg_fragmentation_in_percent], stat.[avg_fragment_size_in_pages], stat.[fragment_count], stat.[page_count]
FROM	sys.dm_db_index_physical_stats(NULL, NULL, NULL, NULL, 'DETAILED') stat 
		INNER JOIN sys.indexes si 
ON		si.[object_id] = stat.[object_id] AND si.[index_id] = stat.[index_id] 
ORDER BY si.[name]