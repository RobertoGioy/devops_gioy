USE [master]
GO

/*

Author:			Roberto Gioy
Description:	Consulta para obter informa��es sobre Bloqueios.

*/

SELECT		tr1.resource_type,
			tr1.resource_subtype,
			tr1.resource_database_id,
			tr1.resource_associated_entity_id,
			tr1.request_mode,
			tr1.request_type,
			tr1.request_status,
			tr1.request_session_id,
			tr1.request_owner_type,
			tr2.blocking_session_id
FROM		sys.dm_tran_locks tr1
INNER JOIN	sys.dm_os_waiting_tasks tr2
ON			tr1.lock_owner_address = tr2.resource_address
GO