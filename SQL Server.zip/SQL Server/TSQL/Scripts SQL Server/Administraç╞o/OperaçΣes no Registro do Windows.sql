EXEC master.dbo.sp_configure 'show advanced options','1'
Reconfigure
EXEC master.dbo.sp_configure 'xp_cmdshell','1'
Reconfigure

--BIO
Exec master..xp_regdeletevalue
'HKEY_LOCAL_MACHINE',
'SOFTWARE\Microsoft\MSSQLServer\Client\ConnectTo',
'BIO'

Exec master..Xp_regwrite
'HKEY_LOCAL_MACHINE',
'SOFTWARE\Microsoft\MSSQLServer\Client\ConnectTo',
'BIO' ,
'REG_SZ' ,
'DBMSSOCN,10.65.6.124,0304'

--BIO
Exec master..xp_regdeletevalue
'HKEY_LOCAL_MACHINE',
'SOFTWARE\Wow6432Node\Microsoft\MSSQLServer\Client\ConnectTo',
'BIO'

Exec master..Xp_regwrite
'HKEY_LOCAL_MACHINE',
'SOFTWARE\Wow6432Node\Microsoft\MSSQLServer\Client\ConnectTo',
'BIO' ,
'REG_SZ' ,
'DBMSSOCN,10.65.6.124,0304'

GO

IF NOT EXISTS (SELECT srv.name FROM sys.servers srv WHERE srv.server_id != 0 AND srv.name = N'BIO')
BEGIN
	EXEC master.dbo.sp_addlinkedserver @server = N'BIO', @srvproduct=N'SQL Server'
	EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname = N'BIO', @locallogin = NULL , @useself = N'False', @rmtuser = N'BIO', @rmtpassword = N'5q1M@i1'
	EXEC master.dbo.sp_serveroption @server=N'BIO', @optname=N'data access', @optvalue=N'true'
END