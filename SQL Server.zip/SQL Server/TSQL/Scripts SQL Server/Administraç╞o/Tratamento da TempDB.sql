USE MASTER
declare @spid varchar(5)

DECLARE CURSOR1 CURSOR FOR

Select A.session_id
FROM sys.dm_db_session_space_usage A
JOIN sys.dm_exec_sessions B  ON A.session_id = B.session_id
JOIN sys.dm_exec_connections C ON C.session_id = B.session_id
CROSS APPLY sys.dm_exec_sql_text(C.most_recent_sql_handle) As D
WHERE A.session_id > 0 And A.session_id <> @@SPID



OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @spid
WHILE @@FETCH_STATUS = 0
	BEGIN
	exec ('kill ' + @spid)
	FETCH NEXT FROM CURSOR1 INTO @spid
	END
CLOSE CURSOR1
DEALLOCATE CURSOR1	

USE [TEMPDB]

Go
DBCC SHRINKDATABASE(TEMPDB)
Go
DBCC FREEPROCCACHE 
Go
DBCC FREESYSTEMCACHE ('ALL')
GO

-- LIMPA O DATA
DBCC SHRINKFILE (1, 0)
GO
-- LIMPA LOG
DBCC SHRINKFILE (2, 0)

/*
declare @spid varchar(5)

DECLARE CURSOR1 CURSOR FOR

Select A.session_id
FROM sys.dm_db_session_space_usage A
JOIN sys.dm_exec_sessions B  ON A.session_id = B.session_id
JOIN sys.dm_exec_connections C ON C.session_id = B.session_id
CROSS APPLY sys.dm_exec_sql_text(C.most_recent_sql_handle) As D
WHERE A.session_id > 0
--and (user_objects_alloc_page_count + internal_objects_alloc_page_count)*1.0/128 > 100 -- Ocupam mais de 100 MB


OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @spid
WHILE @@FETCH_STATUS = 0
	BEGIN
	exec ('kill ' + @spid)
	FETCH NEXT FROM CURSOR1 INTO @spid
	END
CLOSE CURSOR1
DEALLOCATE CURSOR1	


Go
DBCC SHRINKDATABASE(TEMPDB)
Go
DBCC FREEPROCCACHE 
Go
DBCC FREESYSTEMCACHE ('ALL')
GO
-- Limpa o Log
DBCC SHRINKFILE (templog, 0)
go
-- Limpa Data
DBCC SHRINKFILE (tempdev, 0)
go
-- Limpa o Data
DBCC SHRINKFILE (1, 0)
go
-- Limpa LOG
DBCC SHRINKFILE (2, 0)
go
*/