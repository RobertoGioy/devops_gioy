Select B.name From sys.database_mirroring A
Inner Join sys.sysdatabases B On A.database_id=B.dbid
where NOT b.NAME IN ('tempdb', 'master', 'model', 'msdb', 'ReportServer', 'ReportServerTempDB')
AND COALESCE(A.mirroring_role,1) = 2


