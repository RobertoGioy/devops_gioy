use master

--muda para sincrono
ALTER DATABASE UmailNG_Netpoints SET SAFETY FULL

--faz o failover 
--A L T E R DATABASE UmailNG_Netpoints SET PARTNER FAILOVER

--muda para assincrono
ALTER DATABASE UmailNG_Netpoints SET SAFETY FULL

--DESLIGA O MIRROR (RODAR EM ULTIMO CASO!!!
------A L T E R DATABASE UmailNG_Netpoints SET PARTNER OFF