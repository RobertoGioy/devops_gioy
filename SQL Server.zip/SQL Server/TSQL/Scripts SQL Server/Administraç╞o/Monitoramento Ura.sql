USE SkyUra
GO


ALTER PROC [Monitoramento].[Usp_MonitoraImportacaoUra]
AS
SET NOCOUNT ON
DECLARE @HORABASE DATETIME, @MSG NVARCHAR(MAX), @DTINI VARCHAR(30), @DTFIM VARCHAR(30)


SET @HORABASE = CAST(CONVERT(VARCHAR(30),DATEADD(MINUTE,20,DATEADD(HOUR,9,CAST(CAST(GETDATE()AS DATE)AS DATETIME))),120) AS DATETIME)

IF (GETDATE()<=@HORABASE  ) 
BEGIN 
	SET @DTINI = CONVERT(VARCHAR(30),CAST(CAST(GETDATE()AS DATE)AS DATETIME),120)
	SET @DTFIM = CONVERT(VARCHAR(30),GETDATE(),120)
END
ELSE
BEGIN
	SET @DTINI = CONVERT(VARCHAR(30),DATEADD(MINUTE,21,DATEADD(HOUR,9,CAST(CAST(GETDATE()AS DATE)AS DATETIME))),120)
	SET @DTFIM = CONVERT(VARCHAR(30),GETDATE(),120)
END

--SELECT @HORABASE,@DTINI,@DTFIM

IF (SELECT  COUNT(1) FROM  SkyUra.FileImportRowLog WHERE  logdate Between @DTINI And @DTFIM) = 0
--IF (SELECT  COUNT(1) FROM  SkyUra.FileImportRowLog WHERE  logdate Between '20140810' And '20140810') = /*Linha para Teste*/
BEGIN
	SET @MSG = (SELECT 'N�O IMPORTADOS ARQUIVOS DE URA DA SKY ENTRE '''+ RTRIM(@DTINI) +''' E '''+ RTRIM(@DTFIM) +'''')
	
	INSERT INTO [Monitoramento].[RegistrosHistory]
	SELECT * FROM [Monitoramento].[Registros]
	
	TRUNCATE TABLE [Monitoramento].[Registros]

	EXEC MASTER.dbo.Xp_cmdshell 'net use \\177.53.210.16\c$\inetpub\wwwroot\WorkProcess\Sky /user:administrator 1Qaz2Wsx','NO_OUTPUT'
		
	--ENTRADA INICIO
	IF NOT (SELECT OBJECT_ID('Tempdb.dbo.#ENTRADA')) IS NULL
	BEGIN
		DROP TABLE #ENTRADA
	END

	TRUNCATE TABLE [Monitoramento].[DirList]

	INSERT INTO [Monitoramento].[DirList] (line) 
	EXEC xp_cmdshell 'dir \\177.53.210.16\c$\STCPCLT-SKY\O0055SKY\ENTRADA'


	SELECT 
		 CAST(SUBSTRING(line,1,17)AS DATETIME)							  DATA_CRIACAO,
		 SUBSTRING(line,18,3)											  AMPM,
		 CAST(REPLACE(LTRIM(RTRIM(SUBSTRING(line,21,19))),',','') AS INT) TAMANHO,
		 SUBSTRING(line,39,100)											  ARQUIVO
	INTO 
		#ENTRADA
	FROM 
		[Monitoramento].[DirList]
	WHERE NOT SUBSTRING(line,18,19) LIKE '%<DIR>%'
		  AND SUBSTRING(line,37,100) LIKE '%IVR%'

	IF (
		SELECT 
			COUNT(1)
		FROM 
			#ENTRADA 
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #ENTRADA ) 
				AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
		) = 0
	BEGIN
		INSERT INTO [Monitoramento].[Registros]
		SELECT
		'\\177.53.210.16\C$\STCPCLT-SKY\O0055SKY\ENTRADA'					DIRETORIO,
		'VAZIO'			      											    ARQUIVO,
		0																	TAMANHO,
		NULL        														DATA_CRIACAO,
		REVERSE(SUBSTRING(REVERSE(CONVERT(VARCHAR(30),GETDATE(),131)),1,2)) AMPM,
--		CAST(CONVERT(VARCHAR,GETDATE(),101)+' ' + RTRIM(REPLACE(REPLACE(Right(IsNull(Convert(Varchar,GetDate(),100),''),7),'PM',''),'AM','')) AS DATETIME)
		GETDATE()															DATAGERACAO,
		COUNT(1)															QUANTIDADE
		FROM #ENTRADA
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #ENTRADA )
		AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
	END
	ELSE
	BEGIN
		INSERT INTO [Monitoramento].[Registros]
		SELECT 
			'\\177.53.210.16\C$\STCPCLT-SKY\O0055SKY\ENTRADA'				   DIRETORIO,
			ARQUIVO                                                            ARQUIVO,
			RTRIM(((TAMANHO/1024)/1024)) + 'MB'                                TAMANHO,
			DATA_CRIACAO                                                       DATA_CRIACAO,
			LTRIM(RTRIM(AMPM))                                                 AMPM,
			GETDATE()														   DATAGERACAO,			
			1                                                                  QUANTIDADE
		FROM 
			#ENTRADA 
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #ENTRADA )
				AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
		ORDER BY DATA_CRIACAO DESC
	END	
	--ENTRADA FIM

	--IMPORTED INICIO
	IF NOT (SELECT OBJECT_ID('Tempdb.dbo.#IMPORTED')) IS NULL
	BEGIN
		DROP TABLE #IMPORTED
	END

	TRUNCATE TABLE [Monitoramento].[DirList]

	INSERT INTO [Monitoramento].[DirList] (line) 
	EXEC xp_cmdshell 'dir \\177.53.210.16\c$\inetpub\wwwroot\WorkProcess\Sky\Ura\Imported'


	SELECT 
		 CAST(SUBSTRING(line,1,17)AS DATETIME)							  DATA_CRIACAO,
		 SUBSTRING(line,18,3)											  AMPM,
		 CAST(REPLACE(LTRIM(RTRIM(SUBSTRING(line,21,19))),',','') AS INT) TAMANHO,
		 SUBSTRING(line,39,100)											  ARQUIVO
	INTO 
		#IMPORTED
	FROM 
		[Monitoramento].[DirList]
	WHERE NOT SUBSTRING(line,18,19) LIKE '%<DIR>%'
		  AND SUBSTRING(line,37,100) LIKE '%IVR%'

	IF (
		SELECT 
			COUNT(1)
		FROM 
			#IMPORTED 
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #IMPORTED ) 
				AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
		) = 0
	BEGIN
		INSERT INTO [Monitoramento].[Registros]
		SELECT
		'\\177.53.210.16\C$\INETPUB\WWWROOT\WORKPROCESS\SKY\URA\IMPORTED'   DIRETORIO,
		'VAZIO'			      											    ARQUIVO,
		0																	TAMANHO,
		NULL        														DATA_CRIACAO,
		REVERSE(SUBSTRING(REVERSE(CONVERT(VARCHAR(30),GETDATE(),131)),1,2)) AMPM,
--		CAST(CONVERT(VARCHAR,GETDATE(),101)+' ' + RTRIM(REPLACE(REPLACE(Right(IsNull(Convert(Varchar,GetDate(),100),''),7),'PM',''),'AM','')) AS DATETIME)
		GETDATE()															DATAGERACAO,
		COUNT(1)															QUANTIDADE
		FROM 
			#IMPORTED 
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #IMPORTED )
		AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
		
	END
	ELSE
	BEGIN
		INSERT INTO [Monitoramento].[Registros]
		SELECT 
			'\\177.53.210.16\C$\INETPUB\WWWROOT\WORKPROCESS\SKY\URA\IMPORTED' DIRETORIO,
			ARQUIVO                                                            ARQUIVO,
			RTRIM(((TAMANHO/1024)/1024)) + 'MB'                                TAMANHO,
			DATA_CRIACAO                                                       DATA_CRIACAO,
			LTRIM(RTRIM(AMPM))                                                 AMPM,
			GETDATE()														   DATAGERACAO,			
			1                                                                  QUANTIDADE
		FROM 
			#IMPORTED 
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #IMPORTED )
				AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
		ORDER BY DATA_CRIACAO DESC
	END	
	--IMPORTED FIM
		

	--DUPLICATED INICIO
	IF NOT (SELECT OBJECT_ID('Tempdb.dbo.#DUPLICATED')) IS NULL
	BEGIN
		DROP TABLE #DUPLICATED
	END

	TRUNCATE TABLE [Monitoramento].[DirList]

	INSERT INTO [Monitoramento].[DirList] (line) 
	EXEC xp_cmdshell 'dir \\177.53.210.16\c$\inetpub\wwwroot\WorkProcess\Sky\Ura\Duplicated'


	SELECT 
		 CAST(SUBSTRING(line,1,17)AS DATETIME)							  DATA_CRIACAO,
		 SUBSTRING(line,18,3)											  AMPM,
		 CAST(REPLACE(LTRIM(RTRIM(SUBSTRING(line,21,19))),',','') AS INT) TAMANHO,
		 SUBSTRING(line,39,100)											  ARQUIVO
	INTO 
		#DUPLICATED
	FROM 
		[Monitoramento].[DirList]
	WHERE NOT SUBSTRING(line,18,19) LIKE '%<DIR>%'
		  AND SUBSTRING(line,37,100) LIKE '%IVR%'

	IF (
		SELECT 
			COUNT(1)
		FROM 
			#DUPLICATED 
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #DUPLICATED ) 
				AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
		) = 0
	BEGIN
		INSERT INTO [Monitoramento].[Registros]
		SELECT
		'\\177.53.210.16\C$\INETPUB\WWWROOT\WORKPROCESS\SKY\URA\DUPLICATED' DIRETORIO,
		'VAZIO'			      											    ARQUIVO,
		0																	TAMANHO,
		NULL        														DATA_CRIACAO,
		REVERSE(SUBSTRING(REVERSE(CONVERT(VARCHAR(30),GETDATE(),131)),1,2)) AMPM,
--		CAST(CONVERT(VARCHAR,GETDATE(),101)+' ' + RTRIM(REPLACE(REPLACE(Right(IsNull(Convert(Varchar,GetDate(),100),''),7),'PM',''),'AM','')) AS DATETIME)
		GETDATE()															DATAGERACAO,
		COUNT(1)															QUANTIDADE
		FROM 
			#DUPLICATED 
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #DUPLICATED )
		AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
		
	END
	ELSE
	BEGIN
		INSERT INTO [Monitoramento].[Registros]
		SELECT 
			'\\177.53.210.16\C$\INETPUB\WWWROOT\WORKPROCESS\SKY\URA\DUPLICATED' DIRETORIO,
			ARQUIVO                                                             ARQUIVO,
			RTRIM(((TAMANHO/1024)/1024)) + 'MB'                                 TAMANHO,
			DATA_CRIACAO                                                        DATA_CRIACAO,
			LTRIM(RTRIM(AMPM))                                                  AMPM,
			GETDATE()														   DATAGERACAO,			
			1                                                                   QUANTIDADE
		FROM 
			#DUPLICATED 
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #DUPLICATED )
				AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
		ORDER BY DATA_CRIACAO DESC
	END	
	--DUPLICATED FIM

	--ERROR INICIO
	IF NOT (SELECT OBJECT_ID('Tempdb.dbo.#ERROR')) IS NULL
	BEGIN
		DROP TABLE #ERROR
	END

	TRUNCATE TABLE [Monitoramento].[DirList]

	INSERT INTO [Monitoramento].[DirList] (line) 
	EXEC xp_cmdshell 'dir \\177.53.210.16\c$\inetpub\wwwroot\WorkProcess\Sky\Ura\Error'


	SELECT 
		 CAST(SUBSTRING(line,1,17)AS DATETIME)							  DATA_CRIACAO,
		 SUBSTRING(line,18,3)											  AMPM,
		 CAST(REPLACE(LTRIM(RTRIM(SUBSTRING(line,21,19))),',','') AS INT) TAMANHO,
		 SUBSTRING(line,39,100)											  ARQUIVO
	INTO 
		#ERROR
	FROM 
		[Monitoramento].[DirList]
	WHERE NOT SUBSTRING(line,18,19) LIKE '%<DIR>%'
		  AND SUBSTRING(line,37,100) LIKE '%IVR%'

	IF (
		SELECT 
			COUNT(1)
		FROM 
			#ERROR 
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #ERROR ) 
				AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
		) = 0
	BEGIN
		INSERT INTO [Monitoramento].[Registros]
		SELECT
		'\\177.53.210.16\C$\INETPUB\WWWROOT\WORKPROCESS\SKY\URA\ERROR'		DIRETORIO,
		'VAZIO'			      											    ARQUIVO,
		0																	TAMANHO,
		NULL        														DATA_CRIACAO,
		REVERSE(SUBSTRING(REVERSE(CONVERT(VARCHAR(30),GETDATE(),131)),1,2)) AMPM,
--		CAST(CONVERT(VARCHAR,GETDATE(),101)+' ' + RTRIM(REPLACE(REPLACE(Right(IsNull(Convert(Varchar,GetDate(),100),''),7),'PM',''),'AM','')) AS DATETIME)
		GETDATE()															DATAGERACAO,
		COUNT(1)															QUANTIDADE
		FROM 
			#ERROR 
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #ERROR )
		AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
		
	END
	ELSE
	BEGIN
		INSERT INTO [Monitoramento].[Registros]
		SELECT 
			'\\177.53.210.16\C$\INETPUB\WWWROOT\WORKPROCESS\SKY\URA\ERROR'     DIRETORIO,
			ARQUIVO                                                            ARQUIVO,
			RTRIM(((TAMANHO/1024)/1024)) + 'MB'                                TAMANHO,
			DATA_CRIACAO                                                       DATA_CRIACAO,
			LTRIM(RTRIM(AMPM))                                                 AMPM,
			GETDATE()														   DATAGERACAO,			
			1                                                                  QUANTIDADE
		FROM 
			#ERROR 
		WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #ERROR )
				AND CAST(DATA_CRIACAO AS DATE) = CAST(GETDATE() AS DATE)
		ORDER BY DATA_CRIACAO DESC
	END	
	--ERROR FIM


	--PROCESSED INICIO	
	IF NOT (SELECT OBJECT_ID('Tempdb.dbo.#PROCESSED')) IS NULL
	BEGIN
		DROP TABLE #PROCESSED
	END

	TRUNCATE TABLE [Monitoramento].[DirList]

	INSERT INTO [Monitoramento].[DirList] (line) 
	EXEC xp_cmdshell 'dir \\177.53.210.16\c$\inetpub\wwwroot\WorkProcess\Sky\Ura\Processed'


	SELECT 
		 CAST(SUBSTRING(line,1,17)AS DATETIME)                            DATA_CRIACAO,
		 SUBSTRING(line,18,3)                                             AMPM,
		 CAST(REPLACE(LTRIM(RTRIM(SUBSTRING(line,21,19))),',','') AS INT) TAMANHO,
		 SUBSTRING(line,39,100)											  ARQUIVO
	INTO #PROCESSED
	FROM [Monitoramento].[DirList]
	WHERE NOT SUBSTRING(line,18,19) LIKE '%<DIR>%'
		  AND SUBSTRING(line,37,100) LIKE '%IVR%'



	INSERT INTO [Monitoramento].[Registros]
	SELECT 
		'\\177.53.210.16\C$\INETPUB\WWWROOT\WORKPROCESS\SKY\URA\PROCESSED' DIRETORIO,
		ARQUIVO                                                            ARQUIVO,
		RTRIM(((TAMANHO/1024)/1024)) + 'MB'                                TAMANHO,
		DATA_CRIACAO                                                       DATA_CRIACAO,
		LTRIM(RTRIM(AMPM))                                                 AMPM,
			GETDATE()														   DATAGERACAO,			
		1                                                                  QUANTIDADE
	FROM #PROCESSED 
	WHERE CAST(DATA_CRIACAO AS DATE) IN (SELECT MAX(CAST(DATA_CRIACAO AS DATE)) FROM #PROCESSED )
	ORDER BY DATA_CRIACAO DESC

	--PROCESSED FIM


		
	DECLARE @tableHTML  NVARCHAR(MAX) ;
	SET @tableHTML =
		N'<H1><center><small><font size="2px">'+@MSG+'</font></center></H1>' +
		N'<small>' +
		N'<table border="1">' +
		N'<tr><th><center>DIRETORIO</center></th>' +
		N'<th><center>ARQUIVO</center></th>' +
		N'<th><center>TAMANHO</center></th>' +
		N'<th><center>DATACRIACAO</center></th>' +
		N'<th><center>AMPM</center></th>'+
		N'<th><center>DATAGERACAO</center></th>'+
		N'<th><center>QUANTIDADE</center></th>'+
		CAST ( 
			( Select td = [DIRETORIO], '',
					 td = [ARQUIVO], '',
					 td = [TAMANHO], '',
					 td = ISNULL(CONVERT(VARCHAR(20),[DATACRIACAO],120),'NULL'), '', 
					 td = [AMPM], '',
					 td = [DATAGERACAO], '', 
					 td = ISNULL([QUANTIDADE],'0')
					 From SkyUra.[Monitoramento].[Registros]
				  FOR XML PATH('tr'), TYPE 
		) AS NVARCHAR(MAX) ) +
		N'</table>' ;



	EXEC msdb.dbo.sp_send_dbmail 
		@profile_name =  'DBA Notification',
		@recipients =  'dba@unear.net;infraestrutura@unear.net;monitoria@unear.net',
		--@recipients =  'clodoaldo.santos@unear.net',
		@subject = 'Resumo De Importa��o Sky Ura',
		@body = @tableHTML,
		@body_format = 'HTML' 
	
END