create procedure [CORP\marcelo.campos].[spAuditEventsLoad]
 as 
select 
	convert(datetime,convert(varchar(11), TimeGenerated, 120) + '00:00:00') as [Date], 
	convert(varchar(40),case when message like 'Erro ao processar informa��o computada:%' then 'Erro ao processar a informa��o computada:' when message like 'Erro ao processar a informa��o computada:%' then 'Erro ao processar a informa��o computada:' else message end) as [Browser], 
	count(1) as [Count]
INTO #temp
from 
	dbo.[AuditEventViewerLog] 
where 
	message not like '%BusinessObjectID: % Chamada do m�todo CriarREGID%' and  
	message not like '%venda tudo%' and 
	message not like '%Total de % erros nos par�metros%'  and
	message not like '%Erro ao chamar o WebService do MiddlewareOI%' and
	message not like '%ConsultarAvaliacaoCliente%' and
	message not like '%.NET Runtime Optimization Service (clr_optimization_v2.0.50727_64%'
group by 
	convert(datetime,convert(varchar(11), TimeGenerated, 120) + '00:00:00'),
	convert(varchar(40),case when message like 'Erro ao processar informa��o computada:%' then 'Erro ao processar a informa��o computada:' when message like 'Erro ao processar a informa��o computada:%' then 'Erro ao processar a informa��o computada:' else message end)
order by 1 asc

DECLARE @Filters VARCHAR(8000);
DECLARE @FiltersIsNull VARCHAR(8000);
DECLARE @SqlQuery VARCHAR(8000);

SELECT @Filters = COALESCE(@Filters + ', ', '') + '[' + Browser + ']' FROM #Temp group by Browser;
SELECT @FiltersIsNull = COALESCE(@FiltersIsNull + ', ', '') + 'isnull([' + Browser + '],0) as [' + Browser + ']' FROM #Temp group by Browser;

print @Filters

select @sqlQuery = 'SELECT date, ' + @FiltersIsNull + ' FROM (select date as [Date], Browser, sum([count]) as [Count] from #Temp ' + 
	'group by date, browser) up ' + 
	'PIVOT (sum([count]) FOR BROWSER IN (' + @Filters + ')) AS pvt'

EXEC (@SqlQuery);

drop table #Temp

GO


---------------------------------------------------------------------------------


create procedure [dbo].[spAuditEventsErrorLoad]
 as 
select 
	convert(datetime,convert(varchar(15), TimeGenerated, 120) + '0:00') as [Date], 
	convert(varchar(40),case when message like 'Erro ao processar informa��o computada:%' then 'Erro ao processar a informa��o computada:' when message like 'Erro ao processar a informa��o computada:%' then 'Erro ao processar a informa��o computada:' else message end) as [Browser], 
	count(1) as [Count]
INTO #temp
from 
	dbo.[AuditEventViewerLog] 
where 
	message not like '%BusinessObjectID: % Chamada do m�todo CriarREGID%' and  
	message not like '%venda tudo%' and 
	message not like '%Total de % erros nos par�metros%'  and
	message not like '%Erro ao chamar o WebService do MiddlewareOI%' and
	message not like '%ConsultarAvaliacaoCliente%' and
	message not like '%.NET Runtime Optimization Service (clr_optimization_v2.0.50727_64%' and
	EventType = 1
group by 
	convert(datetime,convert(varchar(15), TimeGenerated, 120) + '0:00'),
	convert(varchar(40),case when message like 'Erro ao processar informa��o computada:%' then 'Erro ao processar a informa��o computada:' when message like 'Erro ao processar a informa��o computada:%' then 'Erro ao processar a informa��o computada:' else message end)
order by 1 asc

DECLARE @Filters VARCHAR(8000);
DECLARE @FiltersIsNull VARCHAR(8000);
DECLARE @SqlQuery VARCHAR(8000);

SELECT @Filters = COALESCE(@Filters + ', ', '') + '[' + Browser + ']' FROM #Temp group by Browser;
SELECT @FiltersIsNull = COALESCE(@FiltersIsNull + ', ', '') + 'isnull([' + Browser + '],0) as [' + Browser + ']' FROM #Temp group by Browser;

print @Filters

select @sqlQuery = 'SELECT date, ' + @FiltersIsNull + ' FROM (select date as [Date], Browser, sum([count]) as [Count] from #Temp ' + 
	'group by date, browser) up ' + 
	'PIVOT (sum([count]) FOR BROWSER IN (' + @Filters + ')) AS pvt'

EXEC (@SqlQuery);

drop table #Temp


GO


--------------------------------------------------------------------------------------

create procedure [dbo].[spAuditEventsLoad]
 as 
select 
	convert(datetime,convert(varchar(15), TimeGenerated, 120) + '0:00') as [Date], 
	convert(varchar(40),case when message like 'Erro ao processar informa��o computada:%' then 'Erro ao processar a informa��o computada:' when message like 'Erro ao processar a informa��o computada:%' then 'Erro ao processar a informa��o computada:' else message end) as [Browser], 
	count(1) as [Count]
INTO #temp
from 
	dbo.[AuditEventViewerLog] 
where 
	message not like '%BusinessObjectID: % Chamada do m�todo CriarREGID%' and  
	message not like '%venda tudo%' and 
	message not like '%Total de % erros nos par�metros%'  and
	message not like '%Erro ao chamar o WebService do MiddlewareOI%' and
	message not like '%ConsultarAvaliacaoCliente%' and
	message not like '%.NET Runtime Optimization Service (clr_optimization_v2.0.50727_64%'
group by 
	convert(datetime,convert(varchar(15), TimeGenerated, 120) + '0:00'),
	convert(varchar(40),case when message like 'Erro ao processar informa��o computada:%' then 'Erro ao processar a informa��o computada:' when message like 'Erro ao processar a informa��o computada:%' then 'Erro ao processar a informa��o computada:' else message end)
order by 1 asc

DECLARE @Filters VARCHAR(8000);
DECLARE @FiltersIsNull VARCHAR(8000);
DECLARE @SqlQuery VARCHAR(8000);

SELECT @Filters = COALESCE(@Filters + ', ', '') + '[' + Browser + ']' FROM #Temp group by Browser;
SELECT @FiltersIsNull = COALESCE(@FiltersIsNull + ', ', '') + 'isnull([' + Browser + '],0) as [' + Browser + ']' FROM #Temp group by Browser;

print @Filters

select @sqlQuery = 'SELECT date, ' + @FiltersIsNull + ' FROM (select date as [Date], Browser, sum([count]) as [Count] from #Temp ' + 
	'group by date, browser) up ' + 
	'PIVOT (sum([count]) FOR BROWSER IN (' + @Filters + ')) AS pvt'

EXEC (@SqlQuery);

drop table #Temp

GO


------------------------------------------------------------------------------------------

create procedure [dbo].[spAuditEventsLoadDaily]
 as 
select 
	convert(datetime,convert(varchar(11), TimeGenerated, 120) + '00:00:00') as [Date], 
	convert(varchar(40),case when message like 'Erro ao processar informa��o computada:%' then 'Erro ao processar a informa��o computada:' when message like 'Erro ao processar a informa��o computada:%' then 'Erro ao processar a informa��o computada:' else message end) as [Browser], 
	count(1) as [Count]
INTO #temp
from 
	dbo.[AuditEventViewerLog] 
where 
	message not like '%BusinessObjectID: % Chamada do m�todo CriarREGID%' and  
	message not like '%venda tudo%' and 
	message not like '%Total de % erros nos par�metros%'  and
	message not like '%Erro ao chamar o WebService do MiddlewareOI%' and
	message not like '%ConsultarAvaliacaoCliente%' and
	message not like '%.NET Runtime Optimization Service (clr_optimization_v2.0.50727_64%' and
	EventType = 1
group by 
	convert(datetime,convert(varchar(11), TimeGenerated, 120) + '00:00:00'),
	convert(varchar(40),case when message like 'Erro ao processar informa��o computada:%' then 'Erro ao processar a informa��o computada:' when message like 'Erro ao processar a informa��o computada:%' then 'Erro ao processar a informa��o computada:' else message end)
order by 1 asc

DECLARE @Filters VARCHAR(8000);
DECLARE @FiltersIsNull VARCHAR(8000);
DECLARE @SqlQuery VARCHAR(8000);

SELECT @Filters = COALESCE(@Filters + ', ', '') + '[' + Browser + ']' FROM #Temp group by Browser;
SELECT @FiltersIsNull = COALESCE(@FiltersIsNull + ', ', '') + 'isnull([' + Browser + '],0) as [' + Browser + ']' FROM #Temp group by Browser;

print @Filters

select @sqlQuery = 'SELECT date, ' + @FiltersIsNull + ' FROM (select date as [Date], Browser, sum([count]) as [Count] from #Temp ' + 
	'group by date, browser) up ' + 
	'PIVOT (sum([count]) FOR BROWSER IN (' + @Filters + ')) AS pvt'

EXEC (@SqlQuery);

drop table #Temp


GO

------------------------------------------------------------------------------------------


CREATE PROCEDURE [dbo].[spAuditEventsTimeoutByHour] AS
SELECT	CONVERT(VARCHAR(13),[TimeGenerated], 120) + ':00' DataHora,
		[SourceName],
		COUNT(1) AS Total
FROM	[AuditEvents].[dbo].[AuditEventViewerLog]
WHERE	Message like '%sqlexception%' AND EventType = 1
GROUP BY CONVERT(VARCHAR(13),[TimeGenerated], 120) + ':00', [SourceName]
ORDER BY DataHora, SourceName