EXEC master..xp_servicecontrol 'QueryState', 'wsPropostasMKT'
EXEC master..xp_servicecontrol 'Start', 'wsPropostasMKT'
EXEC master..xp_servicecontrol 'Stop', 'wsPropostasMKT'
