SELECT traceid,property,value
FROM ::fn_trace_getinfo(0)
WHERE property = 5
--parametro 1 �  o ID e o parametro 2 � o status
EXEC sp_trace_setstatus 1, 1 --reinicia trace
EXEC sp_trace_setstatus 2,0 --reinicia para execu��o Trace
EXEC sp_trace_setstatus 2,2 --Deleta para execu��o Trace