
-- COLOCAR ESTA PROCEDURE NA BASE A SER MONITORADA
SELECT	p.name AS [procedureName],
		qs.execution_count,
		ISNULL(qs.execution_count/DATEDIFF(SECOND, qs.cached_time, GETDATE()), 0) AS [Executions/Second)],
		convert(decimal(19,2),qs.total_worker_time / 1000000) AS [TempoCPU (seg)],  
		convert(decimal(19,2),qs.total_elapsed_time / 1000000) as [TotalTempo (seg)], 
		convert(decimal(19,2),qs.min_elapsed_time / 1000) as [MinTempo (ms)], 
		convert(decimal(19,2),qs.max_elapsed_time / 1000) as [MaxTempo (ms)],
		qs.total_logical_reads,
		qs.total_logical_writes,
		qs.last_execution_time
FROM	sys.dm_exec_procedure_stats AS qs WITH (NOLOCK) JOIN sys.procedures p
ON		qs.object_id = p.object_id
where	last_execution_time > '2013-04-08'
ORDER BY qs.execution_count DESC OPTION (RECOMPILE);
GO
