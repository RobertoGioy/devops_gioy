USE [master]
GO

/****** Object:  StoredProcedure [dbo].[spPlanCacheTimeExecution]    Script Date: 07/18/2013 14:07:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[spPlanCacheTimeExecution]
	@DatabaseID INT
AS
BEGIN
	SELECT	qs.last_execution_time [HoraInicial],
			((qs.last_worker_time / qs.execution_count)/1000000) As 'Uso M�dio CPU(seg)',
			((qs.last_worker_time)/1000000) As 'Uso Total da CPU(seg)',
			qs.execution_count As 'Qtde de Execu��es',
			last_physical_reads,
			last_logical_reads,
			last_logical_writes,
			qs.last_rows,
			SUBSTRING(qt.[text],qs.statement_start_offset/2, 
			(CASE 
				WHEN qs.statement_end_offset = -1  
				THEN LEN(CONVERT(nvarchar(max), qt.[text])) * 2 
				ELSE qs.statement_end_offset  
			END - qs.statement_start_offset)/2) AS [Query Text]	
	FROM	sys.dm_exec_query_stats qs
			CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) As qt		
	WHERE	((qs.total_worker_time / qs.execution_count)/1000000) > 0
	OR		((qs.total_worker_time)/1000000)> 0
	AND		qt.dbid = @DatabaseID 
	ORDER BY [HoraInicial] DESC
END



GO


