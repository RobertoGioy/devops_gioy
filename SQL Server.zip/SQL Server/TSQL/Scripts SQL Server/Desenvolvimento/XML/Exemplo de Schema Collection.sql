CREATE XML SCHEMA COLLECTION PublishingSchema AS
'<schema xmlns="http://www.w3.org/2001/XMLSchema" attributeFormDefault="unqualified">
    <element name="Application" >
		<complexType>
			<sequence>
				<element name="ResourceTypes" minOccurs="1" maxOccurs="1" >
					<complexType>
						<sequence>
							<element name="ResourceType" minOccurs="1" maxOccurs="unbounded" />
						</sequence>
						<attribute name="Key" type="string" />
						<attribute name="Name" type="string" />
						<attribute name="Description" type="string" />
					</complexType>
				</element>
				<element name="Resources" minOccurs="1" maxOccurs="1" >
					<complexType>
						<sequence>
							<element name="Resource" minOccurs="1" maxOccurs="unbounded" >
								<complexType>
									<sequence>
										<element name="ResourceType" minOccurs="1" >
											<complexType>
												<attribute name="Key" type="string" use="required" />
											</complexType>
										</element>
										<element name="IsAdministrator" minOccurs="0" />
										<element name="IsActive" minOccurs="0" />
										<element name="SecurityRoles" minOccurs="0" />
										<element name="IsDynamic" minOccurs="0" />
										<element name="Informations" minOccurs="0" >
											<complexType>
												<sequence>
													<element name="Resource" minOccurs="0" maxOccurs="unbounded" >
														<complexType>
															<sequence>
																<element name="ResourceType" minOccurs="1" />
															</sequence>
															<attribute name="Key" type="string" use="required" />
														</complexType>
													</element>
												</sequence>
												<attribute name="Id" type="int" />
												<attribute name="SpecialKey" type="string" />
												<attribute name="Name" type="string" />
												<attribute name="Description" type="string" />
												<attribute name="VersionId" type="int" />
												<attribute name="Date" type="string" />
											</complexType>
										</element>
										<element name="Channel" minOccurs="0" />
										<element name="Rule" minOccurs="0" />
										<element name="BusinessObjectType" minOccurs="0" />
										<element name="BusinessObjectTypes" minOccurs="0" />
										<element name="RuleTypes" minOccurs="0" />
										<element name="IsConfigured" minOccurs="0" />
										
										<element name="InformationCode" minOccurs="0" />
										<element name="InformationType" minOccurs="0" />
										<element name="RelatedBusinessObjectType" minOccurs="0" />
										<element name="SourceCode" minOccurs="0" />
										<element name="DefaultValue" minOccurs="0" />
										<element name="InformationGroup" minOccurs="0" />
										<element name="BusinessObjectCategoricDomain" minOccurs="0" />
										<element name="InfoMapping" minOccurs="0" />
										<element name="ApplicationVersionLabel" minOccurs="0" />
										<element name="IsShortTag" minOccurs="0" />
									</sequence>
									<attribute name="Id" type="int" />
									<attribute name="SpecialKey" type="string" />
									<attribute name="Name" type="string" />
									<attribute name="Description" type="string" />
									<attribute name="VersionId" type="int" />
									<attribute name="Date" type="string" />
									<attribute name="Login" type="string" />
									<attribute name="Password" type="string" />
								</complexType>
							</element>
						</sequence>
					</complexType>
				</element>
			</sequence>
			<attribute name="DateCreated" type="string" />
		</complexType>
    </element>
</schema>'

--SELECT XML_SCHEMA_NAMESPACE (N'dbo', N'PublishingSchema')


--ALTER TABLE Server.ApplicationPublishing ALTER COLUMN ApplicationXml XML (PublishingSchema) NOT NULL

--ALTER TABLE Server.ApplicationPublishing ALTER COLUMN ApplicationXml XML NOT NULL