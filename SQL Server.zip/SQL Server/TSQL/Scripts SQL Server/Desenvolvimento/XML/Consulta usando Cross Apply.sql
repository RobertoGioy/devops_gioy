create table #temp
(
	Id			int identity(1,1),
	Information int
)

declare @PublishingID int

select @PublishingID = MAX(PublishingID) from [dbo].[UPSApplicationPublishing]

insert into #temp
select distinct ref.value('@Id[1] ', 'int') as InformationID
from [dbo].[UPSApplicationPublishing]
cross apply [Application].nodes('//Resource/ResourceType[@Key="Unear.Information"]/..') as A(ref)
where [PublishingID] = @PublishingID 
and [Application].exist('//Resource/ResourceType[@Key = "Unear.Information"]') = 1

select * from #temp

drop table #temp
