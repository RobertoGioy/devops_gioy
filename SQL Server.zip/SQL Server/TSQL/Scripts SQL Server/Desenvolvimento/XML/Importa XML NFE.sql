Use NFEPRD_HISTORICO_2012_GP
GO


EXEC master..xp_cmdshell 'DEL \\172.17.21.53\c$\NFE\*.XML','NO_OUTPUT'

GO


DECLARE @FILIAL CHAR(3)
Set @FILIAL = '139'

DECLARE @NUMNOT SYSNAME
DECLARE CURSOR1 CURSOR FOR

select DistincT NF from nfe07_nota  Where Id_Filial = 139 And NF = 24619 And Tipo = 6 Order By NF



OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @NUMNOT
WHILE @@FETCH_STATUS = 0
BEGIN
	
	
	
	EXEC ('
			DECLARE @ID_NOTA INT

			SET @ID_NOTA = (select MAX(ID_NOTA) from nfe07_nota  Where Id_Filial = ' + @FILIAL + '  And NF = ' + @NUMNOT + ' And Not Id_Lote Is Null)
			
			Truncate Table XML_EXPORT

			Declare @TABLE_XML TABLE
			(Ordem Int,
			 XML_ VARCHAR(MAX)
			)

			Declare @XML Varchar(MAX)

			IF (select Distinct(DT_EMISSAO) from nfe07_nota  Where Id_Filial = ' + @FILIAL + ' And NF = ' + @NUMNOT + ' And Not Id_Lote Is Null)<=''2009-12-31''
				Insert Into @TABLE_XML
				select 1,''<?xml version="1.0" encoding="UTF-8"?><nfeProc versao="1.10" xmlns="http://www.portalfiscal.inf.br/nfe">''
			ELSE
				Insert Into @TABLE_XML
				select 1,''<?xml version="1.0" encoding="UTF-8"?><nfeProc versao="2.00" xmlns="http://www.portalfiscal.inf.br/nfe">''

			Insert Into @TABLE_XML
			select 2,xml_envio from nfe07_nota  Where Id_Filial = ' + @FILIAL + '  And NF = ' + @NUMNOT + ' And Not Id_Lote Is Null And Id_Nota = @ID_NOTA

			Insert Into @TABLE_XML
			select 3,xml_retorno from nfe07_nota  Where Id_Filial = ' + @FILIAL + '  And NF = ' + @NUMNOT + ' And Not Id_Lote Is Null And Id_Nota = @ID_NOTA

			Insert Into @TABLE_XML
			select 4,''</nfeProc>''


			Set @XML = (Select XML_ From @TABLE_XML Where Ordem = 1)

			Set @XML = @XML + (Select XML_ From @TABLE_XML Where Ordem = 2)

			Set @XML = @XML + (Select XML_ From @TABLE_XML Where Ordem = 3)

			Set @XML = @XML + (Select XML_ From @TABLE_XML Where Ordem = 4)



			Insert Into XML_EXPORT
			Select @XML

			EXEC master..xp_cmdshell ''bcp "Select * From NFEPRD_HISTORICO_2012_GP.Dbo.XML_EXPORT" queryout "\\172.17.21.53\c$\NFE\' + @NUMNOT + '.xml" -T -c -SFRSRVBDSQL04\SIS01'',''NO_OUTPUT''
			')

	FETCH NEXT FROM CURSOR1 INTO @NUMNOT
END
CLOSE CURSOR1
DEALLOCATE CURSOR1