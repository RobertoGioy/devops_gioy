select EntityData.query('//Resource/InfoMapping/Resource[@SpecialKey="SMS.Variaveis"]/..') AS XmlData
from [BicUchannelsManagerTest2].[dbo].[UPMEntityHistory]
where EntityData.exist('//Resource/InfoMapping/Resource[@SpecialKey="SMS.Variaveis"]') = 1
and EntityData.exist('//Resource/InfoMapping/Resource[@Id="5343"]') = 1
and EntityID = 5881

update[BicUchannelsManagerTest2].[dbo].[UPMEntityHistory]
set EntityData.modify('
	replace value of (/Resource/InfoMapping/Resource/@SpecialKey)[3] with "SMS.Variaveis"')
from [BicUchannelsManagerTest2].[dbo].[UPMEntityHistory]
where EntityData.exist('//Resource/InfoMapping/Resource[@SpecialKey="Unear.Information.Descrina��o"]') = 1
and EntityData.exist('//Resource/InfoMapping/Resource[@Id="5343"]') = 1
and EntityID = 5881
