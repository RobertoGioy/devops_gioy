Truncate table XML_EXPORT


Use NFEPRD_ANTIGO



Truncate Table XML_EXPORT

Declare @TABLE_XML TABLE
(Ordem Int,
 XML_ VARCHAR(MAX)
)

Declare @XML Varchar(MAX)

IF (select Distinct(DT_EMISSAO) from nfe07_nota  Where Id_Filial = 506 And NF = 2551)<=2009
	Insert Into @TABLE_XML
	select 1,'<?xml version="1.0" encoding="UTF-8"?><nfeProc versao="1.10" xmlns="http://www.portalfiscal.inf.br/nfe">'
ELSE
	Insert Into @TABLE_XML
	select 1,'<?xml version="1.0" encoding="UTF-8"?><nfeProc versao="2.00" xmlns="http://www.portalfiscal.inf.br/nfe">'
select * From @TABLE_XML
Insert Into @TABLE_XML
select 2,xml_envio from nfe07_nota  Where  NF = 3

Insert Into @TABLE_XML
select 3,xml_retorno from nfe07_nota  Where NF = 2551

Insert Into @TABLE_XML
select 4,'</nfeProc>'


Set @XML = (Select XML_ From @TABLE_XML Where Ordem = 1)

Set @XML = @XML + (Select XML_ From @TABLE_XML Where Ordem = 2)

Set @XML = @XML + (Select XML_ From @TABLE_XML Where Ordem = 3)

Set @XML = @XML + (Select XML_ From @TABLE_XML Where Ordem = 4)



Insert Into XML_EXPORT
Select @XML

EXEC master..xp_cmdshell 'bcp "Select * From NFEPRD_ANTIGO.Dbo.XML_EXPORT" queryout "\\172.17.21.53\c$\NFE\2551.xml" -T -c'





