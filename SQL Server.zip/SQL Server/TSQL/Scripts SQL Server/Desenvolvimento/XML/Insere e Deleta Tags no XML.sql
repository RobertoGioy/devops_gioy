declare @xmlinput xml
declare @entityid int
declare @tag varchar(255)

select		top 1 eh.EntityData.query('//Resource/BusinessObject') as obj
into		#xml
from		Manager.EntityHistory eh
inner join	Manager.EntityLatestVersions lv
on			eh.VersionID = lv.VersionID
where		eh.EntityData.exist('//Resource/RuleType/Resource[@SpecialKey="Base.Uchannels.RuleType.GenericCommand"]') = 1
and			eh.EntityData.exist('//Resource/BusinessObject/Resource[@Id="9649"]/ResourceType[@Key="Unear.BusinessObject"]') = 1

select		@xmlinput = obj from #xml

select		eh.EntityID, eh.Tag, eh.EntityData as oldxml,
			eh.EntityData.query('//Resource/BusinessObject') as nodexml
into		#temp
from		Manager.EntityHistory eh
inner join	Manager.EntityLatestVersions lv
on			eh.VersionID = lv.VersionID
where		eh.EntityData.exist('//Resource/BusinessObject/Resource/ResourceType[@Key="Unear.BusinessObject"]') = 0
and			eh.EntityData.exist('//Resource/RuleType/Resource[@SpecialKey="Base.Uchannels.RuleType.GenericCommand"]') = 1

update #temp
set oldxml.modify('delete (/Resource/BusinessObject)[1]')

update #temp
set oldxml.modify('insert sql:variable("@xmlinput") into (/Resource)[1]')

INSERT [Manager].[EntityHistory] ([EntityID],[EntityData],[Tag],[CreationDate])
SELECT EntityID, oldxml, Tag, GETDATE()
FROM #temp

drop table #xml
drop table #temp


