use BicUchannelsManagerTemp

Declare @xmlData xml
Declare @tag varchar(255)
Declare @entityId int
Declare @versionId int 
Declare @nodeCodMsg xml
Declare @nodeVariaveis xml

declare @CodMsgId int;  
select  @CodMsgId = max(EntityId) from UPMEntityHistory H inner join vUPMEntityLatestVersions V on V.VersionId  = H.VersionId where CAST(EntityData.query('data(/Resource/@SpecialKey)') as varchar(1024)) = 'SMS.CodMsg';      
declare @VariaveisId int;     
select  @VariaveisId = max(EntityId) from UPMEntityHistory H inner join vUPMEntityLatestVersions V on V.VersionId  = H.VersionId where CAST(EntityData.query('data(/Resource/@SpecialKey)') as varchar(1024)) = 'SMS.Variaveis';       

declare CursorXml cursor for
select      EntityData, Tag, EntityId, 
            EntityData.query('//Resource/InfoMapping/Resource[@SpecialKey="Unear.Information.CodMsg"]/..'),
            EntityData.query('//Resource/InfoMapping/Resource[@SpecialKey="Unear.Information.Descrina��o"]/..')
from [UPMEntityHistory] H inner join vUPMEntityLatestVersions V 
      on V.VersionId  = H.VersionId
where EntityData.exist('//Resource/ResourceType[@Key="Unear.BusinessObject"]') = 1
and EntityData.exist('//Resource/BusinessObjectType/Resource[@SpecialKey="Campaign.SMS"]') = 1

open CursorXml 
fetch next from CursorXml into @xmlData, @tag, @entityId, @nodeCodMsg, @nodeVariaveis

while @@FETCH_STATUS = 0
begin
      set @nodeCodMsg.modify('
              replace value of (/InfoMapping/Resource/@Id)[1] with sql:variable("@CodMsgId")')
      set @nodeCodMsg.modify('
              replace value of (/InfoMapping/Resource/@SpecialKey)[1] with "SMS.CodMsg"')
      set @nodeCodMsg.modify('
              replace value of (/InfoMapping/Resource/@Name)[1] with "C�digo da mensagem"')


      set @nodeVariaveis.modify('
              replace value of (/InfoMapping/Resource/@Id)[1] with sql:variable("@VariaveisId")')
      set @nodeVariaveis.modify('
              replace value of (/InfoMapping/Resource/@SpecialKey)[1] with "SMS.Variaveis"')
      set @nodeVariaveis.modify('
              replace value of (/InfoMapping/Resource/@Name)[1] with "Vari�veis"')

      set @xmlData.modify('insert sql:variable("@nodeCodMsg") as last into (/Resource)[1]')
      set @xmlData.modify('insert sql:variable("@nodeVariaveis") as last into (/Resource)[1]')

      Declare @date varchar(255)
      select @date = convert(varchar(255), getDate(), 120)

      exec spUPMEntitySave @xmlData, @tag, @date, @entityId out, @versionId out

      fetch next from CursorXml into @xmlData, @tag, @entityId, @nodeCodMsg, @nodeVariaveis
end

close CursorXml
deallocate CursorXml
