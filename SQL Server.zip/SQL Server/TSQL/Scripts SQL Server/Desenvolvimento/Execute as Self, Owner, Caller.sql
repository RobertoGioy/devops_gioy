/*
	AUTHOR:			JOS� ROBERTO
	DESCRIPTION:	DEFINE O CONTEXTO DE EXECU��O
	
	{ CALLER | SELF | OWNER | 'user_name' } 
*/

CREATE PROCEDURE [dbo].[sp_SQLTruncate] 
	@Database	varchar(128),
	@Table		varchar(255)
WITH EXECUTE AS SELF
AS EXEC ('TRUNCATE TABLE ' + @Database + '..' + @Table);

GO


