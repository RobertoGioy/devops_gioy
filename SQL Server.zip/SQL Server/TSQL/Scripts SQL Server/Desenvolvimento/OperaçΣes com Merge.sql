--============================================================ 
-- MERGE
USE PEDIDOS;
-- Gera uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
SELECT * INTO EMP_TEMP FROM EMPREGADOS; 
-- Testando
SELECT * FROM EMP_TEMP;
-- Exclui o funcion�rio de c�digo 3 de EMP_TEMP
DELETE FROM EMP_TEMP WHERE COD_CARGO = 3;
-- Altera os sal�rios de EMP_TEMP dos funcion�rios do departamento 2
UPDATE EMP_TEMP SET SALARIO *= 1.2
WHERE COD_DEPTO = 2
-- Habilita a insers�o de dados no campo identidade
SET IDENTITY_INSERT EMP_TEMP ON;
-- Faz com que a tabela EMP_TEMP fique igual a tabela EMPREGADOS
MERGE EMP_TEMP AS ET    -- Tabela alvo
USING EMPREGADOS AS E   -- Tabela fonte
ON ET.CODFUN = E.CODFUN -- Condi��o de compara��o
-- Quando o registro existir nas 2 tabelas E o SALARIO for diferente
WHEN MATCHED AND E.SALARIO <> ET.SALARIO THEN
     -- Alterar o campo sal�rio de EMP_TEMP
     UPDATE SET ET.SALARIO = E.SALARIO
-- Quando o registro n�o existir em EMP_TEMP     
WHEN NOT MATCHED THEN
     -- Insere o registro em EMP_TEMP
     INSERT (CODFUN,NOME,COD_DEPTO,COD_CARGO,DATA_ADMISSAO, DATA_NASCIMENTO, 
             SALARIO, NUM_DEPEND, SINDICALIZADO, OBS, FOTO)     
     VALUES (CODFUN,NOME,COD_DEPTO,COD_CARGO,DATA_ADMISSAO, DATA_NASCIMENTO, 
             SALARIO, NUM_DEPEND, SINDICALIZADO, OBS, FOTO);
-- Desabilita a insers�o de dados no campo identidade                         
SET IDENTITY_INSERT EMP_TEMP OFF;