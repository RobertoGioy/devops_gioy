DECLARE @TableNameP VARCHAR(500)

SET @TableNameP = 'Users'

BEGIN
	DECLARE @TableId						INT,
			@Schema							VARCHAR(256),
			@TableName						VARCHAR(256),
			@TableNameComplete				VARCHAR(256),
			@ProcedureName					VARCHAR(256),
			@ProcedureNameInsert			VARCHAR(256),
			@ProcedureNameUpdate			VARCHAR(256),
			@ProcedureNameLoad				VARCHAR(256),
			@ProcedureNameCount				VARCHAR(256),
			@ProcedureNameList				VARCHAR(256),
			@ProcedureNameSave				VARCHAR(256),
			@ProcedureNameDelete			VARCHAR(256),
			@ProcedureNameListByLogDate		VARCHAR(256),
			@ProcedureNameCountByLogDate	VARCHAR(256),
			@ColumnName						VARCHAR(256),
			@TypeName						VARCHAR(256),
			@ProcedureCode					VARCHAR(8000),
			@IsIdentity						BIT,
			@Nullable						BIT,
			@IsPrimaryKey					BIT,
			@IsForeingKey					BIT

	SELECT	@TableId = OBJECT_ID, 
			@Schema = s.[name], 
			@TableName = o.[name], 
			@TableNameComplete = '[' + s.[name] + '].[' + o.[name] + ']',
			@ProcedureName = '[' + s.[name] + '].[sp' + o.[name] + ']',
			@ProcedureNameInsert = '[' + s.[name] + '].[sp' + o.[name] + 'Insert]',
			@ProcedureNameUpdate = '[' + s.[name] + '].[sp' + o.[name] + 'Update]',
			@ProcedureNameLoad = '[' + s.[name] + '].[sp' + o.[name] + 'Load]',
			@ProcedureNameCount = '[' + s.[name] + '].[sp' + o.[name] + 'Count]',
			@ProcedureNameList = '[' + s.[name] + '].[sp' + o.[name] + 'List]',
			@ProcedureNameSave = '[' + s.[name] + '].[sp' + o.[name] + 'Save]',
			@ProcedureNameDelete = '[' + s.[name] + '].[sp' + o.[name] + 'Delete]'
	FROM	sys.objects o INNER JOIN sys.schemas s 
	ON		o.[schema_id] = s.[schema_id] 
	WHERE	o.[name] = @TableNameP

	SELECT	@TableNameComplete AS 'tableNameComplete', 
			@TableName AS 'tableName',  
			c.[name] AS 'ColumnName', 
			c.[is_identity] AS 'Identity', 
			c.[is_nullable] AS 'Nullable', 
			CASE 
				WHEN t.[system_type_id] IN (35,99,167,231,239) THEN t.[name] + '(' + CASE WHEN c.[max_length] = -1 THEN 'MAX' ELSE CONVERT(VARCHAR, c.[max_length]) END  + ')' 
				WHEN t.[system_type_id] IN (106) THEN t.[name] + '(' + CAST(c.[precision] AS VARCHAR) + ',' + CAST(c.[scale] AS VARCHAR) + ')' 
				ELSE t.[name]
			END AS 'TypeName'
	INTO	#TEMP
	FROM	sys.columns c INNER JOIN sys.types t 
	ON		c.[system_type_id] = t.[system_type_id]
	WHERE	OBJECT_ID = @Tableid
	ORDER BY [column_id] ASC

	DECLARE ColumnsCursor CURSOR FOR 
	SELECT	ColumnName, 
			[Identity], 
			[Nullable],
			CASE 
				WHEN col1.[COLUMN_NAME] IS NULL OR col1.[CONSTRAINT_NAME] LIKE 'FK_%' OR col1.[CONSTRAINT_NAME] LIKE 'CK_%' OR col1.[CONSTRAINT_NAME] LIKE 'UQ_%' THEN 0 
				ELSE 1 
			END AS 'PrimaryKey',
			CASE 
				WHEN col1.[COLUMN_NAME] IS NOT NULL AND col1.[CONSTRAINT_NAME] LIKE 'FK_%' THEN 1 
				ELSE 0 
			END AS 'ForeignKey',
			UPPER([TypeName])
	FROM	#TEMP t LEFT JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE col1 
	ON		t.[ColumnName] = col1.[COLUMN_NAME] AND t.[tableName] = col1.[TABLE_NAME]
	WHERE	CASE WHEN [TABLE_NAME] IS NULL THEN '1' ELSE [TABLE_NAME] END = CASE WHEN [TABLE_NAME] IS NULL THEN '1' ELSE @tablename END 

	OPEN ColumnsCursor
	FETCH NEXT FROM ColumnsCursor INTO @ColumnName, @IsIdentity, @Nullable, @IsPrimaryKey, @IsForeingKey, @TypeName

	DECLARE @CheckMinDate		VARCHAR(8000),
			@CheckMinDateSelect VARCHAR(8000),
			@Parameters			VARCHAR(8000),
			@ParametersKey		VARCHAR(8000),
			@ParametersInsert	VARCHAR(8000),
			@ParametersSelect	VARCHAR(8000),
			@ParametersList		VARCHAR(8000),
			@ParameterKey		VARCHAR(8000),
			@InsertList			VARCHAR(8000),
			@InsertValues		VARCHAR(8000),
			@UpdateSetList		VARCHAR(8000),
			@WhereList			VARCHAR(8000),
			@SelectWhereList	VARCHAR(8000),
			@HasLogDate			BIT

	SET @Parameters = ''
	SET @ParametersKey = ''
	SET @ParametersInsert = ''
	SET @ParametersSelect = ''
	SET @ParametersList = ''
	SET @InsertList = ''
	SET @InsertValues = '(' + CHAR(13) + CHAR(10)
	SET @UpdateSetList = ''
	SET @WhereList = ''
	SET @SelectWhereList = ''
	SET @HasLogDate = 0
	SET @CheckMinDate = ''
	SET @CheckMinDateSelect = ''

	WHILE @@FETCH_STATUS = 0 
	BEGIN
		IF (@ColumnName = 'LogDate' AND @TypeName = 'datetime') 
		BEGIN
			SET @HasLogDate = 1;
		END 
	
		IF (@IsPrimaryKey = 1 AND @IsIdentity = 1)
		BEGIN
			SET @Parameters = @Parameters + CHAR(9) + '@' + @ColumnName + SPACE(1) + @TypeName + ' OUTPUT' + 
				CASE 
					WHEN (@Nullable = 1 OR (@IsPrimaryKey = 1 AND @Isidentity = 1)) THEN '' 
					WHEN @ColumnName = 'LogDate' AND @TypeName = 'datetime' THEN '' 
					ELSE '' 
				END  + ',' + CHAR(13) + CHAR(10)

			SET @ParametersKey = @ParametersKey + CHAR(9) + '@' + @ColumnName + SPACE(1) + @TypeName + 
				CASE 
					WHEN (@Nullable = 1 OR (@IsPrimaryKey = 1 AND @Isidentity = 1)) THEN '' 
					WHEN @ColumnName = 'LogDate' and @TypeName = 'datetime' THEN ''  ELSE '' 
				END  + ',' + CHAR(13) + CHAR(10)
		END 
		ELSE 
		BEGIN
			SET @Parameters = @Parameters + CHAR(9) + '@' + @ColumnName + SPACE(1) + @TypeName + 
				CASE 
					WHEN (@Nullable = 1 OR (@IsPrimaryKey = 1 AND @Isidentity = 1)) THEN ' = null' 
					WHEN @ColumnName = 'LogDate' AND @TypeName = 'datetime' THEN ' = null' 
					ELSE '' 
				END  + ',' + CHAR(13) + CHAR(10)
		END
	
		IF (@TypeName <> 'xml') 
		BEGIN
			SET @ParametersSelect = @ParametersSelect + CHAR(9) + '@' + @ColumnName + SPACE(1) + @TypeName + ' = null' + ',' + CHAR(13) + CHAR(10)

			IF (@TypeName = 'datetime') 
			BEGIN
				SET @ParametersSelect = @ParametersSelect + CHAR(9) + '@' + @ColumnName + 'Start ' + @TypeName + ' = null' + ',' + CHAR(13) + CHAR(10)
				SET @ParametersSelect = @ParametersSelect + CHAR(9) + '@' + @ColumnName + 'End ' + @TypeName + ' = null' + ',' + CHAR(13) + CHAR(10)
			END
		END
	
		IF @IsIdentity = 0 
		BEGIN
			SET @InsertList = @InsertList + CHAR(9) + CHAR(9) + '[' +  @ColumnName + ']' + ',' + CHAR(13) + CHAR(10)
			SET @ParametersInsert = @ParametersInsert + CHAR(9) + '@' + @ColumnName + SPACE(1) + @TypeName + 
				CASE 
					WHEN (@Nullable = 1 OR (@IsPrimaryKey = 1 AND @Isidentity = 1)) THEN '' 
					WHEN @ColumnName = 'LogDate' AND @TypeName = 'datetime' THEN ' = null'  
					ELSE '' 
				END  + ',' + CHAR(13) + CHAR(10)
			SET @InsertValues = @InsertValues + CHAR(9) + CHAR(9) + '@' + @ColumnName + ',' + CHAR(13) + CHAR(10)
			SET @UpdateSetList = @UpdateSetList + '[' +  @ColumnName + ']' + ' = @' + @ColumnName + ',' + CHAR(13) + CHAR(10) + SPACE(12)
		END

		IF @IsPrimaryKey = 1 
		BEGIN
			SET @WhereList = @WhereList + CHAR(9) + '[' +  @ColumnName + ']' + ' = @' + @ColumnName + ',' + CHAR(13) + CHAR(10)
		END
	
		IF @IsPrimaryKey = 1 AND @IsIdentity = 1 
		BEGIN
			SET @ParameterKey = '@' + @ColumnName 
		END

		IF (@TypeName <> 'xml') 
		BEGIN
			IF (@TypeName = 'datetime') 
			BEGIN
				SET @SelectWhereList = @SelectWhereList + 'CASE WHEN @' + @columnName + ' IS NULL THEN GETDATE() ELSE [' + @ColumnName + '] END = CASE WHEN @' + @columnName + ' IS NULL THEN GETDATE() ELSE @' + @ColumnName + ' END' + CHAR(13) + CHAR(10) + CHAR(9) + 'AND ' 
				SET @SelectWhereList = @SelectWhereList + '[' + @ColumnName + '] BETWEEN ISNULL(@' + @ColumnName + 'Start,''1900-01-01 00:00:00.000'') AND ISNULL(@' + @ColumnName + 'End,''3000-12-31 23:59:59.997'')' + CHAR(13) + CHAR(10) + CHAR(9) + 'AND '	
			END 
			ELSE 
			BEGIN
				SET @SelectWhereList = @SelectWhereList + 'CASE WHEN @' + @columnName + ' IS NULL THEN ''1'' ELSE [' + @ColumnName + '] END = CASE WHEN @' + @columnName + ' IS NULL THEN ''1'' ELSE @' + @ColumnName + ' END' + CHAR(13) + CHAR(10) + CHAR(9) + 'AND '
			END 
		END 
	
		FETCH NEXT FROM ColumnsCursor INTO @ColumnName, @IsIdentity, @Nullable, @IsPrimaryKey, @IsForeingKey, @TypeName
	END

	CLOSE ColumnsCursor
	DEALLOCATE ColumnsCursor

	DROP TABLE #TEMP

	SET @ParametersList = @ParametersSelect
	SET @ParametersList = @ParametersList + CHAR(9) + '@PAGE INT = 1,' + CHAR(13) + CHAR(10)
	SET @ParametersList = @ParametersList + CHAR(9) + '@PAGE_SIZE INT = 10,' + CHAR(13) + CHAR(10)
	SET @Parameters = + CHAR(13) + CHAR(10) + LEFT(@Parameters,LEN(@Parameters)-3)
	SET @ParametersKey = + CHAR(13) + CHAR(10) + LEFT(@ParametersKey,LEN(@ParametersKey)-3) 
	SET @ParametersInsert = + CHAR(13) + CHAR(10) + LEFT(@ParametersInsert,LEN(@ParametersInsert)-3) 
	SET @ParametersSelect = + CHAR(13) + CHAR(10) + LEFT(@ParametersSelect,LEN(@ParametersSelect)-3)
	SET @ParametersList = + CHAR(13) + CHAR(10) + LEFT(@ParametersList,LEN(@ParametersList)-3)
	SET @InsertList = + LEFT(@InsertList,LEN(@InsertList)-3)
	SET @InsertValues = + LEFT(@InsertValues,LEN(@InsertValues)-3) + CHAR(13) + CHAR(10) + CHAR(9) + ' )'
	SET @UpdateSetList = LEFT(@UpdateSetList,LEN(@UpdateSetList)-3)
	SET @WhereList = + LEFT(@WhereList,LEN(@WhereList)-3)
	SET @SelectWhereList = + LEFT(@SelectWhereList,LEN(@SelectWhereList)-7)

	PRINT 
	'IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''' + @ProcedureNameSave + ''') AND type in (N''P'', N''PC''))'+ CHAR(13)+CHAR(10) +
	CHAR(9) + 'DROP PROCEDURE ' + @ProcedureNameSave + CHAR(13) + CHAR(10) +
	'GO  ' +  CHAR(13) + CHAR(10) +
	'CREATE PROCEDURE ' + @ProcedureNameSave + @Parameters + CHAR(13) + CHAR(10) + 
	'AS' + CHAR(9) + 'BEGIN ' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'SET NOCOUNT;' + CHAR(13) + CHAR(10) + 
	CHAR(9) + CASE WHEN @HasLogDate = 1 THEN 'SET @LogDate = ISNULL(@LogDate,GETDATE());' ELSE '' END + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) +
	CHAR(9) + 'IF (' + @ParameterKey + ' IS NULL)' + ' BEGIN ' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'INSERT INTO ' + @TableNameComplete + ' (' + CHAR(13) + CHAR(10) + @InsertList + ' )' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'VALUES ' + @InsertValues + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'SELECT ' + @ParameterKey + ' = SCOPE_IDENTITY()' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'END' + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'ELSE BEGIN' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'UPDATE  ' + @TableNameComplete + ' WITH(ROWLOCK) ' + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'SET ' + CHAR(9) + @UpdateSetList + CHAR(13) + CHAR(10) +
	CHAR(9) + 'WHERE ' + @WhereList + CHAR(13) + CHAR(10) +
	CHAR(9) + 'END' + CHAR(13)+CHAR(10) +
	'END' + CHAR(13 )+ CHAR(10) +
	'GO' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)

	PRINT 
	'IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''' + @ProcedureNameInsert + ''') AND type in (N''P'', N''PC''))'+ CHAR(13) + CHAR(10) +
	CHAR(9) + 'DROP PROCEDURE ' + @ProcedureNameInsert + CHAR(13) + CHAR(10) +
	'GO  ' + CHAR(13) + CHAR(10) +
	'CREATE PROCEDURE ' + @ProcedureNameInsert  + @ParametersInsert + CHAR(13) + CHAR(10) + 
	'AS' + CHAR(9) + 'BEGIN ' + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'SET NOCOUNT;' + CHAR(13) + CHAR(10) + 
	CHAR(9) + CASE WHEN @HasLogDate = 1 THEN 'SET @LogDate = ISNULL(@LogDate,GETDATE());' ELSE '' END + CHAR(13) + CHAR(10) +
	CHAR(13) + CHAR(10) +
	CHAR(9) + 'INSERT INTO ' + @TableNameComplete + ' (' + CHAR(13) + CHAR(10) + @InsertList + ' )' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'VALUES ' + @InsertValues + CHAR(13) + CHAR(10) +
	'END' + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)

	PRINT 
	'IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''' + @ProcedureNameUpdate + ''') AND type in (N''P'', N''PC''))'+ CHAR(13) + CHAR(10) +
	CHAR(9) + 'DROP PROCEDURE ' + @ProcedureNameUpdate + CHAR(13) + CHAR(10) +
	'GO  ' + CHAR(13) + CHAR(10) +
	'CREATE PROCEDURE ' + @ProcedureNameUpdate  + @Parameters + CHAR(13) + CHAR(10) + 
	'AS' + CHAR(9) + 'BEGIN ' + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'SET NOCOUNT;' + CHAR(13) + CHAR(10) + 
	CHAR(9) + CASE WHEN @HasLogDate = 1 THEN 'SET @LogDate = ISNULL(@LogDate,GETDATE());' ELSE '' END + CHAR(13) + CHAR(10) +
	CHAR(13) + CHAR(10) +
	CHAR(9) + 'UPDATE  ' + @TableNameComplete + ' WITH(ROWLOCK) ' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'SET ' + CHAR(9) + @UpdateSetList + CHAR(13) + CHAR(10) +
	CHAR(9) + 'WHERE ' + @WhereList + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) +
	CHAR(9) + 'SELECT ' + @ParameterKey + ' = SCOPE_IDENTITY()' + CHAR(13) + CHAR(10) +
	'END' + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)

	PRINT 
	'IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''' + @ProcedureNameDelete + ''') AND type in (N''P'', N''PC''))'+ CHAR(13) + CHAR(10) +
	CHAR(9) + 'DROP PROCEDURE  ' + @ProcedureNameDelete + CHAR(13)+CHAR(10) +
	'GO  ' + CHAR(13)+CHAR(10) +
	'CREATE PROCEDURE ' + @ProcedureNameDelete  + @ParametersKey + CHAR(13) + CHAR(10) +
	'AS' + CHAR(9) + 'BEGIN ' + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'DELETE' + CHAR(9) + 'FROM ' + @TableNameComplete + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'WHERE ' + @WhereList + CHAR(13) + CHAR(10) +
	'END' + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)

	PRINT 
	'IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''' + @ProcedureNameLoad + ''') AND type in (N''P'', N''PC''))'+ CHAR(13) + CHAR(10) +
	CHAR(9) + 'DROP PROCEDURE ' + @ProcedureNameLoad + CHAR(13) + CHAR(10) +
	'GO  ' + CHAR(13) + CHAR(10) +
	'CREATE PROCEDURE ' + @ProcedureNameLoad  + @ParametersSelect + CHAR(13) + CHAR(10) +
	'AS' + CHAR(9) + 'BEGIN ' + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'SELECT ' + CHAR(13) + CHAR(10) + @InsertList + CHAR(13) + CHAR(10) +
	CHAR(9) + 'FROM ' + CHAR(13) + CHAR(10) + CHAR(9) + CHAR(9) + @TableNameComplete + ' WITH(NOLOCK)' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'WHERE ' + CHAR(13) + CHAR(10) + CHAR(9) + CHAR(9) + @SelectWhereList + CHAR(13) + CHAR(10) +
	'END' + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)

	PRINT 
	'IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''' + @ProcedureNameCount + ''') AND type in (N''P'', N''PC''))'+ CHAR(13) + CHAR(10) +
	CHAR(9) + 'DROP PROCEDURE ' + @ProcedureNameCount + CHAR(13) + CHAR(10) +
	'GO  ' + CHAR(13) + CHAR(10) +
	'CREATE PROCEDURE ' + @ProcedureNameCount  + @ParametersSelect + CHAR(13) + CHAR(10) +
	'AS' + CHAR(9) + 'BEGIN ' + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'SELECT ' + CHAR(13) + CHAR(10) + CHAR(9) + CHAR(9) + 'COUNT(1)' + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'FROM ' + CHAR(13) + CHAR(10) + CHAR(9) + CHAR(9) + @TableNameComplete + ' WITH(NOLOCK)' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'WHERE ' + CHAR(13) + CHAR(10) + CHAR(9) + CHAR(9) + @SelectWhereList + CHAR(13) + CHAR(10) +
	'END' + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)

	PRINT 
	'IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''' + @ProcedureNameList + ''') AND type in (N''P'', N''PC''))'+ CHAR(13) + CHAR(10) +
	CHAR(9) + 'DROP PROCEDURE  ' + @ProcedureNameList + CHAR(13) + CHAR(10) +
	'GO  ' + CHAR(13)+CHAR(10) +
	'CREATE PROCEDURE ' + @ProcedureNameList + @ParametersList + CHAR(13) + CHAR(10) +
	'AS' + CHAR(9) + 'BEGIN ' + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'DECLARE @START INT, @END INT' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) +
	CHAR(9) + 'SET @START = ((CASE WHEN @Page = 1 THEN 0 ELSE @Page-1 END)*@PAGE_SIZE) + 1;' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'SET @END = (@START + @PAGE_SIZE) - 1;'+ CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) +
	CHAR(9) + 'WITH CTA AS (' + CHAR(13) + CHAR(10) +
	CHAR(9) + CHAR(9) + 'SELECT ' + CHAR(13) + CHAR(10) + @InsertList + ',' + CHAR(13) + CHAR(10) + 
	CHAR(9) + CHAR(9) + 'ROW_NUMBER() OVER(ORDER BY ' + CASE WHEN @HasLogDate = 1 THEN 'LogDate' ELSE @ParameterKey END + ' DESC) [RowIndexGen] ' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'FROM ' + CHAR(13) + CHAR(10) + CHAR(9) + CHAR(9) + @TableNameComplete + ' WITH(NOLOCK)' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'WHERE ' + CHAR(13) + CHAR(10) + CHAR(9) + CHAR(9) + @SelectWhereList + CHAR(13) + CHAR(10) +
	CHAR(9) + ')' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'SELECT ' + CHAR(13) + CHAR(10) + @InsertList + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'FROM' + CHAR(13) + CHAR(10) + CHAR(9) + CHAR(9) + ' CTA ' + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'WHERE' + CHAR(13) + CHAR(10) + CHAR(9) + CHAR(9) + '[ROWINDEXGEN] >= @START AND [ROWINDEXGEN] <= @END'+ CHAR(13) + CHAR(10) +
	'END' + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10)
END
GO