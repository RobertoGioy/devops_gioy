(Select (cast((5354)as float)/(CAST((23)as Float))))
(Select round((cast((5354)as float)/(CAST((23)as Float))),3))




select case when veiter <> 'N' then 'Terceiro' 
			when veiter = '' then 'tesgsdafg' 
			else 'Proprio' end as TipVeiculo,veiter,* from veiculos
			
			
			