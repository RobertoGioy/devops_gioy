

Select (dateadd(mm,1,'2011-02-16')- day(dateadd(mm,1,'2011-02-16'))) as Data