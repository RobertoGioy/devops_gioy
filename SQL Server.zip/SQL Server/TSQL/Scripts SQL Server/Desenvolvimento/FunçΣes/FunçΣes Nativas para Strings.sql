USE PEDIDOS
---
----- Fun��es nativas para strings
--- C�digo de um dado caracter
SELECT ASCII( 'A' )
SELECT ASCII( 'B' )
SELECT ASCII( '0' )
--- Caracter que tem um determinado c�digo
SELECT CHAR(65)
--
DECLARE @COD INT;
SET @COD = 1;
WHILE @COD <= 255
   BEGIN
   PRINT CAST(@COD AS VARCHAR(3)) + ' - ' + CHAR(@COD);
   SET @COD = @COD + 1; 
   END
---
--- Posi��o de um string dentro de outro
SELECT CHARINDEX( 'PA', 'IMPACTA' )
SELECT CHARINDEX( 'MAGNO', 'CARLOS MAGNO' )
SELECT CHARINDEX( 'MANO', 'CARLOS MAGNO' )

--- Tamanho de um string
SELECT LEN( 'IMPACTA' ) 
SELECT LEN( 'IMPACTA TECNOLOGIA' )

--- Pegar uma parte de um string
SELECT LEFT( 'IMPACTA TECNOLOGIA', 5 )
SELECT RIGHT( 'IMPACTA TECNOLOGIA', 5 )
SELECT SUBSTRING( 'IMPACTA TECNOLOGIA', 5, 6 )

--- Eliminar espa�os em branco
SELECT 'IMPACTA     ' + '      TECNOLOGIA'
SELECT RTRIM('IMPACTA     ') + 'TECNOLOGIA'
SELECT 'IMPACTA' + LTRIM('      TECNOLOGIA')
SELECT RTRIM(LTRIM( '     TESTE      '))

--- Reverso de um string
SELECT REVERSE('IMPACTA')
SELECT REVERSE('MAGNO')
SELECT REVERSE('COMPUTADOR')

SELECT REVERSE('REVER')
SELECT REVERSE('MIRIM')
SELECT REVERSE('REVIVER')

--- Replicar string v�rias vezes
PRINT REPLICATE('IMPACTA ', 10)

--- Mai�sculo e min�sculo
PRINT UPPER('impacta @#$81') + LOWER( 'TECNOLOGIA' )

-- Substitui��o de texto
PRINT REPLACE( 'JOS�,CARLOS,ROBERTO,FERNANDO,MARCO',',',' - ')


---------------------------------------------------------------
-- 1. EXERC�CIO: Criar fun��o que complete um string � direita
-- Exemplo: 
--            SELECT FN_FILL_RIGHT( 'MAGNO', '.' , 10 )
--            MAGNO.....
--            SELECT FN_FILL_RIGHT( 'IMPACTA', '*' , 15 )
--            IMPACTA********
-- Par�metros:
--            @S VARCHAR(100)  : texto que ser� completado
--            @C CHAR(1)       : caracter usado para completar
--            @T TINYINT       : tamanho do texto resultante              
---------------------------------------------------------------
CREATE FUNCTION FN_FILL_RIGHT( @S VARCHAR(255), 
                               @C CHAR(1),
                               @T TINYINT )
   RETURNS VARCHAR(255)
AS BEGIN
-- Complete
RETURN @S + REPLICATE( @C, @T - LEN( @S ) ) 
END
-- Testando
SELECT DBO.FN_FILL_RIGHT( 'IMPACTA', '*' , 15 )
----------------------------------------------------------
-- 2. Fun��o para retornar somente com a primeira palavra 
--     de um nome
----------------------------------------------------------
CREATE FUNCTION FN_PRIM_NOME( @S VARCHAR(200) )
   RETURNS VARCHAR(200)
AS BEGIN
DECLARE @RET VARCHAR(200);
DECLARE @CONT INT;
SET @S = LTRIM( @S );
SET @RET = '';
SET @CONT = 1;
WHILE @CONT <= LEN(@S)
   BEGIN
   IF SUBSTRING(@S, @CONT, 1) = ' ' BREAK;
   SET @RET = @RET + SUBSTRING(@S, @CONT, 1);
   SET @CONT = @CONT + 1;
   END
RETURN @RET;
END
GO
-- TESTANDO
SELECT DBO.FN_PRIM_NOME( '  CARLOS  MAGNO' )
SELECT NOME, DBO.FN_PRIM_NOME( NOME ) FROM EMPREGADOS
GO
----------------------------------------------------------
-- 3. Fun��o para retornar somente com a �ltima palavra 
--     de um nome
----------------------------------------------------------
-- Dica: O loop deve percorrer o nome da �ltima letra at� a primeira
--       Se encontrar espa�o, abandona o loop
CREATE FUNCTION FN_ULT_NOME( @S VARCHAR(200) )
    RETURNS VARCHAR(200)
AS BEGIN    
DECLARE @RET VARCHAR(200) = '', @CONT INT;
SET @S = RTRIM( @S );
SET @CONT = LEN( @S );
WHILE @CONT > 0 
   BEGIN
   IF SUBSTRING(@S,@CONT,1) = ' ' BREAK;
   SET @RET = @RET + SUBSTRING(@S,@CONT,1);
   SET @CONT += 1;
   END
RETURN @RET   
END
GO
--
SELECT DBO.FN_ULT_NOME( '  CARLOS  MAGNO   ' )
SELECT NOME, DBO.FN_ULT_NOME(NOME) FROM EMPREGADOS
GO
----------------------------------------------------------
-- 4. Fun��o para formatar nomes pr�prios com as primeiras
--     letras de cada nome em mai�sculo
----------------------------------------------------------
CREATE FUNCTION FN_PROPER( @S VARCHAR(200) )
   RETURNS VARCHAR(200)
AS BEGIN
DECLARE @RET VARCHAR(200);
DECLARE @CONT INT;
SET @RET = UPPER(LEFT(@S,1));
SET @CONT = 2;
WHILE @CONT <= LEN(@S)
   BEGIN
   IF SUBSTRING(@S, @CONT - 1, 1) = ' '
      SET @RET = @RET + UPPER( SUBSTRING(@S, @CONT, 1) )
   ELSE
      SET @RET = @RET + LOWER( SUBSTRING(@S, @CONT, 1) )

   SET @CONT = @CONT + 1
   END
RETURN @RET;
END
GO
-- Testando
SELECT NOME, DBO.FN_PROPER( NOME ) FROM EMPREGADOS
----------------------------------------------------------------
SELECT * FROM EMPREGADOS WHERE NOME LIKE '%JOSE%'
SELECT * FROM EMPREGADOS WHERE NOME LIKE '%JOS�%'
GO
-----------------------------------------------------------------
-- 5. Substituir todos os caracteres acentuados de um 
-- texto pelo correspondente caracter n�o acentuado
-----------------------------------------------------------------
CREATE FUNCTION FN_TIRA_ACENTO( @S VARCHAR(200) )
  RETURNS VARCHAR( 200 )
AS BEGIN
DECLARE @I INT, @RET VARCHAR(200), @C CHAR(1);
SET @I = 1;
SET @RET = '';
-- Enquanto @I for menor que o tamanho de @S
WHILE @I <= LEN(@S)
   BEGIN
   SET @C = SUBSTRING( @S, @I, 1 );
   SET @RET = @RET + CASE 
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�')) THEN 'A'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�'),ASCII('�')) THEN 'a'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�')) THEN 'E'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�')) THEN 'e'
                       WHEN ASCII(@C) IN (ASCII('�')) THEN 'I'
                       WHEN ASCII(@C) IN (ASCII('�')) THEN 'i'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�')) THEN 'O'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�'),ASCII('�')) THEN 'o'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�')) THEN 'U'
                       WHEN ASCII(@C) IN (ASCII('�'),ASCII('�')) THEN 'u'
                       WHEN ASCII(@C) = ASCII('�') THEN 'C'
                       WHEN ASCII(@C) = ASCII('�') THEN 'c'
                       ELSE @C
                     END -- CASE   
    SET @I = @I + 1
    END  
RETURN (@RET);
END
GO
---
SELECT NOME FROM EMPREGADOS
WHERE DBO.FN_TIRA_ACENTO( NOME ) LIKE '%JOSE%'

SELECT NOME FROM EMPREGADOS
WHERE DBO.FN_TIRA_ACENTO( NOME ) LIKE '%JOAO%'


