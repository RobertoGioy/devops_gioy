--==============================================================================
-- Fun��es associadas a IDENTITY
--------------------------------------------
-- Criar banco de dados de teste
CREATE DATABASE TESTE_IDENTITY
GO
-- Colocar o banco de dados em uso
USE TESTE_IDENTITY
GO
-- Criar tabela PROFESSOR com campo identidade iniciando em 1 e incrementando 1
CREATE TABLE PROFESSOR
( COD_PROF		INT IDENTITY,
  NOME			VARCHAR(30),
  CONSTRAINT PK_PROFESSOR PRIMARY KEY (COD_PROF) )
GO
-- Criar tabela ALUNO com campo identidade iniciando em 10 e incrementando 2
CREATE TABLE ALUNO
( COD_ALUNO		INT IDENTITY(10,2),
  NOME			VARCHAR(30),
  CONSTRAINT PK_ALUNO PRIMARY KEY (COD_ALUNO) );
GO  
-- Inserir dados na tabela PROFESSOR
INSERT PROFESSOR 
VALUES ('MAGNO'),('AGNALDO'),('ROBERTO'),
       ('RENATA'),('EDUARDO'),('MARCIO');

-- Inserir dados na tabela ALUNO
INSERT ALUNO VALUES ('Z� DA SILVA'),('CARLOS P. D. KANA'),
                    ('ITAMAR E VAI PIORAR');
-- Consultar as tabelas
SELECT * FROM PROFESSOR;
SELECT * FROM ALUNO;

-- Criar tabela chamada MATERIAS com os campos
/*
 COD_MATERIA inteiro auto numera��o
              deve come�ar do 100 somando 5
 MATERIA      alfanumerico tamanho 30
 CARGA_HORARIA inteiro
*/
CREATE TABLE MATERIAS
(  COD_MATERIA	 INT	IDENTITY(100,5),
   MATERIA       VARCHAR(30),
   CARGA_HORARIA INT,
   CONSTRAINT PK_MATERIAS PRIMARY KEY(COD_MATERIA))
GO
-- Inserir 5 linhas na tabela MATERIAS
INSERT INTO MATERIAS
VALUES ('MATEM�TICA',40), ('F�SICA',40),
       ('PORTUGU�S',40),('GEOGRAFIA',20),
       ('HIST�RIA',20);

-- Consultar a tabela MATERIAS
SELECT * FROM MATERIAS;
         
-- Excluir o professor C�digo 2
DELETE FROM PROFESSOR WHERE COD_PROF = 2;
-- Consultar
SELECT * FROM PROFESSOR;
-- LIGA a possibilidade de inserir dados no campo IDENTITY
SET IDENTITY_INSERT PROFESSOR ON;
-- OBS.: N�o aceita INSERT posicional
INSERT PROFESSOR (COD_PROF, NOME)
VALUES (2,'GODOFREDO');
-- DESLIGA possibilidade de inserir dados no campo IDENTITY
SET IDENTITY_INSERT PROFESSOR OFF;
-- Consulta
SELECT * FROM PROFESSOR;

-- Qual � a coluna IDENTITY da tabela ?
SELECT IDENTITYCOL FROM PROFESSOR;
SELECT IDENTITYCOL FROM ALUNO;
-- Qual � o valor inicial do IDENTITY?
SELECT IDENT_SEED('PROFESSOR');
SELECT IDENT_SEED('ALUNO');
-- Qual � o incremento do IDENTITY ?
SELECT IDENT_INCR('PROFESSOR');
SELECT IDENT_INCR('ALUNO');

-- Qual foi o �ltimo valor de IDENTITY gerado
-- pelo SQL para o usu�rio atual ?
SELECT @@IDENTITY;
INSERT PROFESSOR VALUES ('TESTE');
SELECT @@IDENTITY;
-- Esta fun��o deve ser utilizada pelos aplicativos que 
-- precisarem saber qual foi o c�digo gerado para o �ltimo
-- INSERT executado.

-- Qual foi o �ltimo valor de IDENTITY gerado
-- pelo SQL para o usu�rio atual ?
SELECT SCOPE_IDENTITY();
INSERT ALUNO VALUES ('TESTE');
SELECT SCOPE_IDENTITY();
-- Esta fun��o N�O PODE ser utilizada pelos aplicativos porque
-- neles ela retorna sempre NULL. 
-- Ela deve ser utilizada dentro de stored procedures e triggers
-- do banco de dados quando for necess�rio saber qual foi o c�digo 
-- gerado para o �ltimo INSERT executado executado dentro da procedure
-- ou do trigger.

-- Qual foi o �ltimo valor de IDENTITY gerado
-- para uma determinada tabela
SELECT IDENT_CURRENT('PROFESSOR');
SELECT IDENT_CURRENT('ALUNO');

-- Excluir todos os registros da tabela PROFESSOR
DELETE FROM PROFESSOR;
-- Inserir um novo registro
INSERT INTO PROFESSOR VALUES ('MAGNO');
-- Consultar
SELECT * FROM PROFESSOR;
/*
   Observe que o c�digo gerado seguiu a mesma sequ�ncia anterior
*/

-- Exclua novamente os registros da tabela PROFESSOR
DELETE FROM PROFESSOR;
-- "Zerar" o contador do IDENTITY
DBCC CHECKIDENT( 'PROFESSOR', RESEED, 0 );
-- Inserir novos dados
INSERT PROFESSOR VALUES ('MAGNO'),('AGNALDO'),('ROBERTO'),
                        ('RENATA'),('EDUARDO'),('MARCIO');
-- Consultar
SELECT * FROM PROFESSOR;
                        

--============================================================ MERGE
-- Coloca o banco PEDIDOS em uso
USE PEDIDOS;

INSERT INTO EMPREGADOS (NOME, COD_DEPTO, COD_CARGO, SALARIO,
                        DATA_ADMISSAO )  
VALUES ('TESTE MERGE',1,1,100, GETDATE());
SELECT * FROM EMPREGADOS
-- Gera uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
--DROP TABLE EMP_TEMP
SELECT * INTO EMP_TEMP FROM EMPREGADOS; 
-- Testando
SELECT * FROM EMP_TEMP;
-- Exclui o funcion�rio de c�digo 3 de EMP_TEMP
DELETE FROM EMP_TEMP WHERE COD_CARGO = 3;
-- Altera os sal�rios de EMP_TEMP dos funcion�rios do departamento 2
UPDATE EMP_TEMP SET SALARIO *= 1.2
WHERE COD_DEPTO = 2
--
DELETE FROM EMPREGADOS WHERE CODFUN = 75


-- Habilita a insers�o de dados no campo identidade
SET IDENTITY_INSERT EMP_TEMP ON;

----------------------------------------------------------------
-- Faz com que a tabela EMP_TEMP fique igual a tabela EMPREGADOS
MERGE EMP_TEMP AS ET    -- Tabela alvo
USING EMPREGADOS AS E   -- Tabela fonte
ON ET.CODFUN = E.CODFUN -- Condi��o de compara��o
-- Quando o registro existir nas 2 tabelas E o SALARIO for diferente
WHEN MATCHED AND E.SALARIO <> ET.SALARIO THEN
     -- Alterar o campo sal�rio de EMP_TEMP
     UPDATE SET ET.SALARIO = E.SALARIO
-- Quando o registro n�o existir em EMP_TEMP     
WHEN NOT MATCHED THEN
     -- Insere o registro em EMP_TEMP
     INSERT (CODFUN,NOME,COD_DEPTO,COD_CARGO,DATA_ADMISSAO, DATA_NASCIMENTO, 
             SALARIO, NUM_DEPEND, SINDICALIZADO, OBS, FOTO)     
     VALUES (CODFUN,NOME,COD_DEPTO,COD_CARGO,DATA_ADMISSAO, DATA_NASCIMENTO, 
             SALARIO, NUM_DEPEND, SINDICALIZADO, OBS, FOTO)
WHEN NOT MATCHED BY SOURCE THEN             
     DELETE
OUTPUT INSERTED.CODFUN, INSERTED.NOME,
       DELETED.SALARIO AS SALARIO_ANTIGO,
       INSERTED.SALARIO AS SALARIO_NOVO, $ACTION;     
----------------------------------------------------------------
          
-- Desabilita a insers�o de dados no campo identidade                         
SET IDENTITY_INSERT EMP_TEMP OFF;
--
SELECT * FROM EMP_TEMP;


--==============================================================
-- Gerar uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
DROP TABLE EMP_TEMP;

CREATE TABLE EMP_TEMP
( CODFUN    INT PRIMARY KEY,
  NOME      VARCHAR(30),
  COD_DEPTO INT,
  COD_CARGO	INT,
  SALARIO	NUMERIC(10,2) )
GO  
-- Inserir dados e exibir os registros inseridos
INSERT INTO EMP_TEMP OUTPUT INSERTED.*
SELECT CODFUN, NOME, COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS;
GO

-- Excluir todos os registros
DELETE FROM EMP_TEMP;
-- Inserir dados e exibir algumas colunas
INSERT INTO EMP_TEMP 
OUTPUT INSERTED.CODFUN, INSERTED.NOME, INSERTED.COD_DEPTO
SELECT CODFUN, NOME, COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS WHERE COD_DEPTO = 2;
GO

--============================================================ OUTPUT com DELETE
-- Gera uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
DROP TABLE EMP_TEMP;

SELECT * INTO EMP_TEMP FROM EMPREGADOS
-- Deleta registros e mostra os registros deletados
BEGIN TRANSACTION

DELETE FROM EMP_TEMP OUTPUT DELETED.*
WHERE COD_DEPTO = 2
GO

-- OK
COMMIT
-- ERRADO
ROLLBACK

-- Deleta registros e mostra alguns campos dos registros deletados
DELETE FROM EMP_TEMP 
OUTPUT DELETED.CODFUN, DELETED.NOME, DELETED.COD_DEPTO
WHERE COD_DEPTO = 3
GO

--============================================================ OUTPUT com UPDATE
-- Gera uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
DROP TABLE EMP_TEMP;
SELECT * INTO EMP_TEMP FROM EMPREGADOS;
-- Altera registros e mostra os dados antes e depois da altera��o
UPDATE EMP_TEMP SET SALARIO *= 1.5
OUTPUT 
   INSERTED.CODFUN, INSERTED.NOME, INSERTED.COD_DEPTO, 
   DELETED.SALARIO AS SALARIO_ANTIGO, 
   INSERTED.SALARIO AS SALARIO_NOVO
WHERE COD_DEPTO = 3;
GO

