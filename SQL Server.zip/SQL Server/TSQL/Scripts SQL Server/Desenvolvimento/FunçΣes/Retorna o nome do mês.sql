-----------------------------------------------------------
-- 4. EXERC�CIO: Criar fun��o FN_NOME_MES que retorne com o nome do M�S
-- MONTH( DATA ) -> retorna o n�mero do m�s
-----------------------------------------------------------
CREATE FUNCTION FN_NOME_MES( @DT DATETIME )
    RETURNS VARCHAR(15)
AS BEGIN    

RETURN CASE MONTH(@DT)
          WHEN  1 THEN 'JANEIRO'
          WHEN  2 THEN 'FEVEREIRO'
          WHEN  3 THEN 'MAR�O'
          WHEN  4 THEN 'ABRIL'
          WHEN  5 THEN 'MAIO'
          WHEN  6 THEN 'JUNHO'
          WHEN  7 THEN 'JULHO'
          WHEN  8 THEN 'AGOSTO'
          WHEN  9 THEN 'SETEMBRO'
          WHEN 10 THEN 'OUTRUBRO'
          WHEN 11 THEN 'NOVEMBRO'
          WHEN 12 THEN 'DEZEMBRO'
       END
END
GO
-- Testando
SELECT NOME, DATA_ADMISSAO, DATENAME(MONTH,DATA_ADMISSAO),
       DBO.FN_NOME_MES(DATA_ADMISSAO)
FROM EMPREGADOS