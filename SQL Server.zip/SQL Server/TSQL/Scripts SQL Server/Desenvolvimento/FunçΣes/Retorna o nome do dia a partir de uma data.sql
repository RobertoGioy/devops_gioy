--------------------------------------------------------------
-- 3. Fun��o que retorna com o nome do dia da semana de uma data
-- em portugu�s
--------------------------------------------------------------
CREATE FUNCTION FN_NOME_DIA_SEMANA( @DT DATETIME )
   RETURNS VARCHAR(15)
AS BEGIN
DECLARE @NUM_DS INT, @NOME_DS VARCHAR(15);
SET @NUM_DS = DATEPART( WEEKDAY, @DT );
/*-------------------------------------------
IF @NUM_DS = 1 SET @NOME_DS = 'DOMINGO';
IF @NUM_DS = 2 SET @NOME_DS = 'SEGUNDA-FEIRA';
IF @NUM_DS = 3 SET @NOME_DS = 'TER�A-FEIRA';
IF @NUM_DS = 4 SET @NOME_DS = 'QUARTA-FEIRA';
IF @NUM_DS = 5 SET @NOME_DS = 'QUINTA-FEIRA';
IF @NUM_DS = 6 SET @NOME_DS = 'SEXTA-FEIRA';
IF @NUM_DS = 7 SET @NOME_DS = 'S�BADO';
---------------------------------------------*/
SET @NOME_DS = CASE @NUM_DS
                 WHEN 1 THEN 'DOMINGO'
                 WHEN 2 THEN 'SEGUNDA-FEIRA'
                 WHEN 3 THEN 'TER�A-FEIRA'
                 WHEN 4 THEN 'QUARTA-FEIRA'
                 WHEN 5 THEN 'QUINTA-FEIRA'
                 WHEN 6 THEN 'SEXTA-FEIRA'
                 WHEN 7 THEN 'S�BADO'
               END -- CASE
RETURN (@NOME_DS)
END
GO

-- TESTANDO
SELECT NOME, DATA_ADMISSAO, DATENAME(WEEKDAY,DATA_ADMISSAO),
       DBO.FN_NOME_DIA_SEMANA( DATA_ADMISSAO )
FROM EMPREGADOS
--
SELECT DBO.FN_NOME_DIA_SEMANA(CAST('1959.11.12' AS DATETIME) )
GO