-------------------------------------------------------------------------
-- 6. Fun��o que retorna com uma data a partir dos n�meros do ANO, M�S e DIA
------------------------------------------------------------------------- 
CREATE FUNCTION FN_MONTA_DATA( @ANO INT, @MES INT, @DIA INT)
   RETURNS DATETIME
AS BEGIN
DECLARE @RET DATETIME;
SET @RET = CONVERT( DATETIME,
                    CAST( @DIA AS VARCHAR(2) ) + '/' +
                    CAST( @MES AS VARCHAR(2) ) + '/' +
                    CAST( @ANO AS CHAR(4) ), 103 ) 
RETURN (@RET);
END
GO
--
SELECT DBO.FN_MONTA_DATA( 2009, 5, 28 )
GO

--------------------------------------------------------------------------
-- 7. Dada uma data, retorna com a primeira data do m�s
CREATE FUNCTION FN_PRIM_DATA( @DT DATETIME )
   RETURNS DATETIME
AS BEGIN
DECLARE @MES INT, @ANO INT;
SET @MES = MONTH(@DT);
SET @ANO = YEAR(@DT);
RETURN DBO.FN_MONTA_DATA( @ANO, @MES, 1 );
END
GO
-- Testando
SELECT NOME, DATA_ADMISSAO, DBO.FN_PRIM_DATA(DATA_ADMISSAO)
FROM EMPREGADOS
--
---------------------------------------------------------------
-- Criar fun��o que retorna com a �LTIMA data do m�s
-- Dica: Como a data � um n�mero onde cada dia corresponde a
--       1 unidade, podemos concluir que a �ltima data de um m�s
--       � igual a primeira data do m�s seguinte menos 1
-- Dica:
DECLARE @DT DATETIME;
SET @DT = '2008.3.1';
SELECT @DT - 1
GO
---------------------------------------------------------------
CREATE FUNCTION FN_ULT_DATA( @DT DATETIME )
   RETURNS DATETIME
AS BEGIN
DECLARE @MES INT, @ANO INT;
SET @MES = MONTH(@DT) + 1;  --<<<<<<<<<
SET @ANO = YEAR(@DT);

IF @MES > 12
   BEGIN
   SET @MES = 1;
   SET @ANO += 1; 
   END
   
RETURN DBO.FN_MONTA_DATA( @ANO, @MES, 1 ) - 1; --<<<<<<<<<
END
GO
-- Testando
SELECT DBO.FN_ULT_DATA( '2009.1.22' )
SELECT DBO.FN_ULT_DATA( '2008.2.22' )
SELECT DBO.FN_ULT_DATA( '2009.3.22' )
SELECT DBO.FN_ULT_DATA( '2009.4.22' )
---
SELECT DBO.FN_ULT_DATA( '2009.11.22' )
SELECT DBO.FN_ULT_DATA( '2009.12.22' )
GO

--------------------------------------------------------
-- 9. Calcula a N-�sima data �til a partir de uma data
--------------------------------------------------------
CREATE FUNCTION FN_N_ESIMA_DATA_UTIL ( @DT DATETIME,
                                       @N INT )
   RETURNS DATETIME
AS BEGIN
DECLARE @I INT;
SET @DT = DBO.FN_TRUNCA_DATA(@DT)
SET @I = 0;
WHILE @I < @N
   BEGIN
   SET @DT = @DT + 1;
   IF DATEPART(WEEKDAY, @DT) IN (1,7)  CONTINUE
   SET @I = @I + 1;
   END
RETURN ( @DT );
END
GO
-- TESTANDO
SELECT DBO.FN_N_ESIMA_DATA_UTIL( GETDATE(), 5 );
--
CREATE TABLE FERIADOS
( DATA DATETIME, 
  MOTIVO VARCHAR(40),
  CONSTRAINT PK_FERIADOS PRIMARY KEY (DATA) )
GO  
--
INSERT INTO FERIADOS VALUES ('2009.1.25','ANIV. S�O PAULO')
INSERT INTO FERIADOS VALUES ('2009.2.21','CARNAVAL')
INSERT INTO FERIADOS VALUES ('2009.2.22','CARNAVAL')
INSERT INTO FERIADOS VALUES ('2009.2.23','CARNAVAL')
INSERT INTO FERIADOS VALUES ('2009.2.24','CARNAVAL')
INSERT INTO FERIADOS VALUES ('2009.3.10','P�SCOA')
INSERT INTO FERIADOS VALUES ('2009.4.19','TIRADENTES')

INSERT INTO FERIADOS VALUES ('2009.5.1','TRABALHO')
INSERT INTO FERIADOS VALUES ('2009.5.2','TRABALHO PROLONGAMENTO')

INSERT INTO FERIADOS VALUES ('2009.6.11','CORPUS CRISTI')
INSERT INTO FERIADOS VALUES ('2009.6.12','CORPUS CRISTI PROLONGAMENTO')
INSERT INTO FERIADOS VALUES ('2009.6.13','CORPUS CRISTI PROLONGAMENTO')

INSERT INTO FERIADOS VALUES ('2009.9.14','DIA DA RESSACA')
GO
----------------------------------------------------------
-- 10. EXERC�CIO: Altere a fun��o anterior de modo que sejam
--            considerados tamb�m os feriados
-- Dica: SE O DIA DA SEMANA DA DATA FOR 1 OU 7 (***)
--       OU
--       A DATA ESTIVER CADASTRADA (EXISTIR) NA TABELA FERIADOS
----------------------------------------------------------
ALTER FUNCTION FN_N_ESIMA_DATA_UTIL ( @DT DATETIME,
                                       @N INT )
   RETURNS DATETIME
AS BEGIN
DECLARE @I INT;
SET @DT = DBO.FN_TRUNCA_DATA(@DT)
SET @I = 0;
WHILE @I < @N
   BEGIN
   SET @DT = @DT + 1;
   IF DATEPART(WEEKDAY, @DT) IN (1,7) OR
      EXISTS( SELECT * FROM FERIDADOS
              WHERE DATA = @DT)  CONTINUE
   SET @I = @I + 1;
   END
RETURN ( @DT );
END
GO
-- Testando
SELECT DBO.FN_N_ESIMA_DATA_UTIL( GETDATE(), 5 )

--- EXTRA -----------------
SELECT DATEDIFF(DAY, '2009.1.1', '2009.1.15')
--
SELECT DATEDIFF(MONTH, '2008.12.20', '2009.1.1')
--
SELECT DATEDIFF(YEAR, '2008.12.20', '2009.1.15')
--
CREATE FUNCTION FN_DIF_DATAS( @TIPO CHAR(1),
                           @DT1  DATETIME,
                           @DT2  DATETIME )
  RETURNS FLOAT
AS BEGIN
DECLARE @DIA1 INT, @MES1 INT, @ANO1 INT;
DECLARE @DIA2 INT, @MES2 INT, @ANO2 INT;
DECLARE @RET FLOAT;

SET @DIA1 = DAY(@DT1);
SET @MES1 = MONTH(@DT1);
SET @ANO1 = YEAR(@DT1);

SET @DIA2 = DAY(@DT2);
SET @MES2 = MONTH(@DT2);
SET @ANO2 = YEAR(@DT2);

IF @TIPO = 'D'
   SET @RET = CAST(@DT2 - @DT1 AS INT);
ELSE IF @TIPO = 'M'
   BEGIN
   IF @MES1 <= @MES2
      BEGIN
      SET @RET = 12 * (@ANO2 - @ANO1) + (@MES2 - @MES1)
      IF @DIA1 > @DIA2 SET @RET = @RET - 1; 
      END
   ELSE
      BEGIN
      SET @RET = 12 * (@ANO2 - (@ANO1 + 1)) + (12 - (@MES1 - @MES2));
      IF @DIA1 > @DIA2 SET @RET = @RET - 1; 
      END
   END
ELSE
   BEGIN 
   SET @RET = @ANO2 - @ANO1;
   IF @MES1 > @MES2 SET @RET = @RET - 1;
   IF @MES1 = @MES2 AND @DIA1 > @DIA2 SET @RET = @RET - 1;
   END
RETURN @RET; 
END
--
SELECT DBO.FN_DIF_DATAS('D', '2009.1.1', '2009.1.15')

SELECT DBO.FN_DIF_DATAS('M', '2008.1.2', '2009.2.15')
SELECT DBO.FN_DIF_DATAS('M', '2008.1.20', '2009.2.15')

SELECT DBO.FN_DIF_DATAS('M', '2008.8.2', '2009.2.15')
SELECT DBO.FN_DIF_DATAS('M', '2007.8.2', '2009.2.15')
SELECT DBO.FN_DIF_DATAS('M', '2007.8.20', '2009.2.15')

SELECT DBO.FN_DIF_DATAS('A', '2008.8.2', '2009.2.15')
SELECT DBO.FN_DIF_DATAS('A', '2006.8.2', '2009.10.15')
SELECT DBO.FN_DIF_DATAS('A', '2006.10.2', '2009.10.15')
SELECT DBO.FN_DIF_DATAS('A', '2006.11.2', '2009.10.15')
SELECT DBO.FN_DIF_DATAS('A', '2006.10.20', '2009.10.15')
