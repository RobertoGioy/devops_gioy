Declare @String varchar(255) = 'VBO001:0,VBO002:1,VBO003:0,VBO004:0'
Declare @Results TABLE (id INT IDENTITY(1,1), metric NVARCHAR(4000), submetric char(1))
Declare @Delimiter CHAR(1) = ','
Declare @subDelimiter CHAR(1) = ':'
Declare @Value VARCHAR(50)
Declare @metric varchar(30)
Declare @submetric char(1)

WHILE LEN(@String) > 0
BEGIN
    IF PATINDEX('%' + @Delimiter + '%',@String) > 0
    BEGIN
        SET @Value = SUBSTRING(@String, 0, PATINDEX('%' + @Delimiter + '%', @String))
        
        set @metric = SUBSTRING(@String, 0, PATINDEX('%' + @subDelimiter + '%', @String))
        
        set @submetric = SUBSTRING(@String, LEN(isnull(@Value,'')), PATINDEX('%' + @subDelimiter + '%', @String))
        
        INSERT INTO @Results(metric, submetric) VALUES(LTRIM(RTRIM(@metric)), LTRIM(RTRIM(@submetric)))

        SET @String = SUBSTRING(@String, LEN(@Value + @Delimiter) + 1, LEN(@String))
    END
    ELSE
    BEGIN
        SET @Value = @String
        SET @String = NULL
        
        set @metric = SUBSTRING(@Value, 0, PATINDEX('%' + @subDelimiter + '%', @Value))
        
        set @submetric = SUBSTRING(@Value, LEN(@Value), PATINDEX('%' + @subDelimiter + '%', @Value))
        
        INSERT INTO @Results(metric, submetric) VALUES(LTRIM(RTRIM(@metric)), LTRIM(RTRIM(@submetric)))
    END
END

SELECT r.id, r.metric, r.submetric FROM @Results r
