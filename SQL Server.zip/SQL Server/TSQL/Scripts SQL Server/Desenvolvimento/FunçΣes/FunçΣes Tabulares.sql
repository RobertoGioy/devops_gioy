USE PEDIDOS
GO
---
---------------------------------------------------------------------------------------
-- 1. Fun��o para retornar com a data da �ltima compra de um cliente
---------------------------------------------------------------------------------------
CREATE FUNCTION FN_DATA_ULT_COMPRA ( @CODCLI INT )
   RETURNS DATETIME
AS BEGIN

RETURN (SELECT MAX(DATA_EMISSAO) FROM PEDIDOS
        WHERE CODCLI = @CODCLI)

END
GO
-- Testando
SELECT CODCLI, NOME, DBO.FN_DATA_ULT_COMPRA( CODCLI )
FROM CLIENTES
GO
---------------------------------------------------------------------------------------
-- 2. EXERC�CIO: Criar fun��o que retorne o maior valor de pedido (VLR_TOTAL) 
-- vendido por um vendedor em um determinado ped�odo
-- Par�metros:
--         @CODVEN	 INT: C�digo do cliente
--         @DT1 DATETIME: Data Inicial
--         @DT2 DATETIME: Data Final

/*
         SELECT MAX(VLR_TOTAL) AS MAIOR_PEDIDO
         FROM PEDIDOS
         WHERE CODVEN = @CODVEN AND
               DATA_EMISSAO BETWEEN @DT1 AND @DT2
*/
---------------------------------------------------------------------------------------
CREATE FUNCTION FN_MAIOR_PEDIDO_VENDEDOR( @CODVEN INT,
                                          @DT1 DATETIME,
                                          @DT2 DATETIME )
   RETURNS FLOAT
AS BEGIN                                                 
RETURN (SELECT MAX(VLR_TOTAL) AS MAIOR_PEDIDO
         FROM PEDIDOS
         WHERE CODVEN = @CODVEN AND
               DATA_EMISSAO BETWEEN @DT1 AND @DT2)
END
GO
-- Testando
SELECT CODVEN, NOME, 
       DBO.FN_MAIOR_PEDIDO_VENDEDOR( CODVEN, '2007.1.1', '2007.1.31')
                 AS MAIOR_PEDIDO
FROM VENDEDORES
GO               

--===========================================================
-- 3. Cria��o de Fun��es TABULARES -- IN-LINE
-------------------------------------------------------------
CREATE FUNCTION FN_MAIOR_PEDIDO( @DT1 DATETIME,
                                 @DT2 DATETIME )
RETURNS TABLE
AS
RETURN ( SELECT MONTH( DATA_EMISSAO ) AS MES, 
                YEAR( DATA_EMISSAO ) AS ANO, 
                MAX( VLR_TOTAL ) AS MAIOR_VALOR
                FROM PEDIDOS
                WHERE DATA_EMISSAO BETWEEN @DT1 AND @DT2
                GROUP BY MONTH( DATA_EMISSAO ), 
                         YEAR( DATA_EMISSAO ) )
GO
-- Testando
SELECT * FROM DBO.FN_MAIOR_PEDIDO( '2006.1.1','2006.12.31')
ORDER BY ANO, MES
--
SELECT F.MES, F.ANO, F.MAIOR_VALOR, P.NUM_PEDIDO
FROM FN_MAIOR_PEDIDO( '2006.1.1','2006.12.31') F
     JOIN PEDIDOS P 
     ON F.MES = MONTH( P.DATA_EMISSAO ) AND
        F.ANO = YEAR( P.DATA_EMISSAO ) AND
        F.MAIOR_VALOR = P.VLR_TOTAL
ORDER BY F.ANO, F.MES
GO
-------------------------------------------------------------------
-- 4. EXERCICIO: Criar uma fun��o tabular (FN_VENDAS_POR_PRODUTO)
-- que receba as datas inicial (@DT1) e final (@DT2) de um per�odo
-- e retorne com o total vendido de cada produto neste per�odo
------------------------------------------------------------------
/*
 	SELECT
		Pr.ID_PRODUTO, Pr.DESCRICAO, SUM( I.QUANTIDADE ) AS QTD_TOTAL,
		SUM( I.QUANTIDADE * I.PR_UNITARIO ) AS VALOR_TOTAL
	FROM ITENSPEDIDO I
		 JOIN PRODUTOS Pr ON I.ID_PRODUTO=Pr.ID_PRODUTO
		 JOIN PEDIDOS Pe ON I.NUM_PEDIDO=Pe.NUM_PEDIDO
	WHERE 
	     Pe.DATA_EMISSAO BETWEEN @DT1 AND @DT2
	GROUP BY Pr.ID_PRODUTO, Pr.DESCRICAO
*/
CREATE FUNCTION FN_VENDAS_POR_PRODUTO( @DT1 DATETIME,
                                       @DT2 DATETIME )
   RETURNS TABLE
AS
RETURN
(
 	SELECT
		Pr.ID_PRODUTO, Pr.DESCRICAO, SUM( I.QUANTIDADE ) AS QTD_TOTAL,
		SUM( I.QUANTIDADE * I.PR_UNITARIO ) AS VALOR_TOTAL
	FROM ITENSPEDIDO I
		 JOIN PRODUTOS Pr ON I.ID_PRODUTO=Pr.ID_PRODUTO
		 JOIN PEDIDOS Pe ON I.NUM_PEDIDO=Pe.NUM_PEDIDO
	WHERE 
	     Pe.DATA_EMISSAO BETWEEN @DT1 AND @DT2
	GROUP BY Pr.ID_PRODUTO, Pr.DESCRICAO
)                                            



-- Testando a fun��o
SELECT * FROM FN_VENDAS_POR_PRODUTO( '2006.1.1','2006.12.31')
ORDER BY 3
--
SELECT * FROM FN_VENDAS_POR_PRODUTO( '2006.1.1','2006.12.31')
ORDER BY DESCRICAO
--
SELECT TOP 10 * 
FROM FN_VENDAS_POR_PRODUTO( '2006.1.1','2006.12.31')
ORDER BY 4 DESC
GO
-----------------------------------------------------------
-- 5. Mostra os funcion�rios de cada departamento e a soma 
-- dos sal�rios de cada departamento
CREATE FUNCTION FN_TOT_DEPTOS()
   RETURNS @TotDeptos TABLE ( COD_DEPTO INT, 
                              NOME VARCHAR(40),          
                              TIPO CHAR(1),
                              VALOR NUMERIC(12,2) )
AS BEGIN
DECLARE @I INT; -- Contador
DECLARE @TOT INT; -- Maior codigo de departamento existente
SELECT @TOT = MAX(COD_DEPTO) FROM TABELADEP
SET @I = 1;
WHILE @I <= @TOT
   BEGIN
   -- Se existir o departamento de c�digo = @I...
   IF EXISTS( SELECT * FROM TABELADEP
              WHERE COD_DEPTO = @I )
      BEGIN
      -- Inserir na tabela de retorno os funcion�rios do
      -- departamento c�digo @I
      INSERT INTO @TotDeptos
      SELECT COD_DEPTO, NOME, 'D', SALARIO 
      FROM EMPREGADOS WHERE COD_DEPTO = @I;
      -- Inserir na tabela de retorno uma linha contendo
      -- o total de sal�rios do departamento @I
      -- Coloque no campo NOME a mensagem 'TOTAL' e no
      -- campo TIPO a letra 'T'. 
      -- O campo VALOR vai armazenar o total de sal�rios
      INSERT INTO @TotDeptos
      SELECT COD_DEPTO, 'TOTAL DO DEPTO.:', 'T',
             SUM( SALARIO ) 
      FROM EMPREGADOS WHERE COD_DEPTO = @I
      GROUP BY COD_DEPTO;      
      END -- IF EXISTS
   SET @I = @I + 1;
   END -- WHILE
RETURN
END -- FUNCTION
--
SELECT * FROM FN_TOT_DEPTOS()
GO
-- Criar fun��o tabular que receba 2 datas e retorne:
--   CODVEN		TIPO		VALOR
--   
--      Onde CODVEN = C�digo do vendedor
--           TIPO   = 'D' para detalhe e 'T' para total
--           VALOR  = VLR_TOTAL do pedido se for detalhe
--                    sen�o, a SOMA DO VLR_TOTAL de todos os pedidos   
--                    do vendedor no per�odo
                      



--
SELECT * FROM FN_VENDAS_POR_VENDEDOR('2007.1.1','2007.1.31')