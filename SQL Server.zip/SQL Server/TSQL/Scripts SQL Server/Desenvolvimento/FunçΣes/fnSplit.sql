Declare @String varchar(255) = 'VBO001,VBO002,VBO003,VBO004'
Declare @Results TABLE (id INT IDENTITY(1,1), value NVARCHAR(4000))
Declare @Delimiter CHAR(1) = ','
Declare @Value VARCHAR(50)

WHILE LEN(@String) > 0
BEGIN
    IF PATINDEX('%' + @Delimiter + '%',@String) > 0
    BEGIN
        SET @Value = SUBSTRING(@String, 0, PATINDEX('%' + @Delimiter + '%',@String))
        INSERT INTO @Results(value) VALUES(LTRIM(RTRIM(@Value)))

        SET @String = SUBSTRING(@String, LEN(@Value + @Delimiter) + 1, LEN(@String))
    END
    ELSE
    BEGIN
        SET @Value = @String
        SET @String = NULL
        INSERT INTO @Results(value) VALUES(LTRIM(RTRIM(@Value)))
    END
END

SELECT r.id, r.value FROM @Results r
