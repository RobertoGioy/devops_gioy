declare @horas		int
declare @minutos	int
declare @segundos	int

;WITH DifSegs 
AS (
	SELECT	SUM(DATEDIFF(SS, ReceiveDate,StartAnswerDate)) / COUNT(LogID) AS segundos
	FROM	RedecardUchannels.SMSLog
	WHERE	StartAnswerDate IS NOT NULL
)
SELECT	@horas		= (SUM(segundos) / 3600), 
		@minutos	= (SUM(segundos) % 3600) / 60, 
		@segundos	= (SUM(segundos) % 3600) % 60
FROM DifSegs

SELECT	ProcessName,
		COUNT(LogID) AS 'qtd_Atendimento',
		CONVERT(CHAR(2),REPLICATE('0', 2 - LEN(@horas)) + CAST(@horas AS CHAR)) + ':' + CONVERT(CHAR(2), REPLICATE('0', 2 - LEN(@minutos)) + CAST(@minutos AS CHAR)) + ':' + CONVERT(CHAR(2), REPLICATE('0', 2 - LEN(@segundos)) + CAST(@segundos AS CHAR)) AS [Tempo M�dio Espera]
FROM	RedecardUchannels.SMSLog
WHERE	StartAnswerDate IS NOT NULL
GROUP BY ProcessName