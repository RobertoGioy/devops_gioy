Declare @Var Varchar(100), @Tam Int, @Reg Int, @Text Varchar(10), @Var2 Int

DECLARE CURSOR1 CURSOR FOR

Select Endcli,Codcli From Clientes

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR,@VAR2
WHILE @@FETCH_STATUS = 0
      Begin
      Set @Tam = Len(@Var)
      Set @Reg = 1
      Set @Text = ''

      while @Reg <= @Tam
            Begin
            If ISNUMERIC ( Substring(@Var,@Reg,1 )) = 1 and Substring(@Var,@Reg,1 ) <> ',' And Substring(@Var,@Reg,1 ) <> '-' And Substring(@Var,@Reg,1 ) <> '.'
                  Set @Text = @Text + substring(@Var,@Reg,1 )
            Set @Reg = @Reg + 1     
            end
            --select @text
            Update Clientes Set Numcli = @Text Where Codcli =@Var2
            FETCH NEXT FROM CURSOR1 INTO @VAR,@VAR2

      END
CLOSE CURSOR1
DEALLOCATE CURSOR1


/*
Select Endcli,Codcli From Clientes
Select Replace(EndCli,'1','') From Clientes
Update Clientes Set EndCli = Replace(EndCli,'/',' ') 
Update Clientes Set EndCli = Replace(EndCli,'1','') 
Update Clientes Set EndCli = Replace(EndCli,'2','') 
Update Clientes Set EndCli = Replace(EndCli,'3','') 
Update Clientes Set EndCli = Replace(EndCli,'4','') 
Update Clientes Set EndCli = Replace(EndCli,'5','') 
Update Clientes Set EndCli = Replace(EndCli,'6','') 
Update Clientes Set EndCli = Replace(EndCli,'7','') 
Update Clientes Set EndCli = Replace(EndCli,'8','') 
Update Clientes Set EndCli = Replace(EndCli,'9','') 
*/