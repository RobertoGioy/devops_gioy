Select 
	Case When Numnot = 'Total_NF' Then '' Else Numnot End Numnot, 
	Case When Datent = 'Total_NF' Then '' Else Datent End Datent,
	Case When Codcli = 'Total_NF' Then '' Else Codcli End Codcli,
	Case When Nomcli = 'Total_NF' Then '' Else Nomcli End Nomcli,
	Case When CgcCli = 'Total_NF' Then '' Else CgcCli End CgcCli,
	Case When Descid = 'Total_NF' Then '' Else Descid End Descid,
	Case When Codpro = 'Total_NF' Then '' Else Codpro End Codpro,
	Case When Despro = 'Total_NF' Then '' Else Despro End Despro,
	Case When Valor_Itens = 'Total_NF' Then '' Else Valor_Itens End Valor_Itens
From (
Select 
	Case When GROUPING(A.Numnot) =1 Then 'Total_NF' Else Convert(Varchar(50),A.Numnot) End Numnot , 
	Case When GROUPING(A.Datent) =1 Then 'Total_NF' Else Convert(Varchar(10),A.Datent,120) End Datent, 
	Case When GROUPING(C.Codcli) =1 Then 'Total_NF' Else Convert(Varchar(50),C.Codcli) End Codcli,
	Case When GROUPING(C.Nomcli) =1 Then 'Total_NF' Else Convert(Varchar(50),C.Nomcli) End Nomcli,
	Case When GROUPING(C.CgcCli) =1 Then 'Total_NF' Else Convert(Varchar(50),C.CgcCli) End CgcCli,
	Case When GROUPING(D.Descid) =1 Then 'Total_NF' Else Convert(Varchar(50),D.Descid) End Descid,
	Case When GROUPING(E.Codpro) =1 Then 'Total_NF' Else Convert(Varchar(50),E.Codpro) End Codpro,
	Case When GROUPING(E.Despro) =1 Then 'Total_NF' Else Convert(Varchar(50),E.Despro) End Despro,
	Convert(Varchar(50),SUM(B.Valbru))  Valor_Itens
From Nota_Fiscal A
Inner Join Itens_Nota_Fiscal B On A.Codemp=B.Codemp And A.Numnot=B.Numnot And A.Sernot=B.Sernot And 
								  A.Tipnot=B.Tipnot And A.Codope=B.Codope And A.Datent=B.Datent And
								  A.Pericm=B.Pericm And A.Codcli=B.Codcli
Inner Join Clientes C On A.CodEmp=C.Codemp And A.Codcli=C.Codcli
Inner Join Cidades  D On D.Codcid=C.Codcid
Inner Join Produtos E On B.Codemp=E.Codemp And B.Codpro=E.Codpro
Where (A.Status Is Null Or A.Status <>'C') And A.Tipnot = 'S'
--And A.Numnot in (100,1000)
Group by A.Numnot, A.Datent, C.Codcli, C.Nomcli, C.CgcCli, D.Descid, E.Codpro, E.Despro
With Rollup
) A
Where (Despro <>'Total_NF' OR Datent = 'Total_NF')
Group By Numnot, Datent,Codcli, Nomcli, CgcCli, Descid, Codpro, Despro, Valor_Itens