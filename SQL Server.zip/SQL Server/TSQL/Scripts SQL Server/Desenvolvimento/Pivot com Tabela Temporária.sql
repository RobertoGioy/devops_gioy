/*
	AUTHOR:			JOS� ROBERTO
	DESCRIPTION:	PIVOT USANDO TABELA TEMPOR�RIA
*/

with cte as (
select	c.contactid ,c.contactname, e.email, count(1) as total
from	dbo.Contacts c inner join dbo.Emails e
on		c.contactid = e.contactid
group by c.contactid ,c.contactname, e.email
)
select contactid, contactname, email, RANK() OVER (PARTITION BY contactid ORDER BY email) AS EmailRank
into #temp
from cte
order by contactid

select contactid, contactname, [1] as Email1, [2] as Email2, [3] as Email3
from #temp
PIVOT (MAX(email) FOR EmailRank IN ([1],[2],[3])) AS P

drop table #temp

