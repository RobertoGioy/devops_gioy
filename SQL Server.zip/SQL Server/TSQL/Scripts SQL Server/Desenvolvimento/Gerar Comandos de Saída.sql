DECLARE @SchemaName			SYSNAME,
		@SourceTable		SYSNAME,
		@DestinationTable	SYSNAME,
		@DropCommand		NVARCHAR (MAX),
		@CreateCommand		NVARCHAR (MAX)

CREATE TABLE #Table (comando nvarchar(max) )

DECLARE INDEXCURSOR CURSOR LOCAL FOR
SELECT	[SchemaName],
		[SourceTable],
		[DestinationTable],
		[DropCommand],
		[CreateCommand]
  FROM [dbo].[PlanPartitionTables]
ORDER BY 1


OPEN INDEXCURSOR
FETCH NEXT FROM INDEXCURSOR INTO 
		@SchemaName,			
		@SourceTable,		
		@DestinationTable,
		@DropCommand,	
		@CreateCommand		
WHILE @@FETCH_STATUS = 0
BEGIN
	INSERT INTO #Table 
	VALUES (
		'INSERT INTO [dbo].[PlanPartitionTables]([SchemaName],[SourceTable],[DestinationTable],[DropCommand],[CreateCommand])
		VALUES (''' + @SchemaName + ''',''' + @SourceTable + ''',''' + @DestinationTable + ''',''' + @DropCommand  + ''',''' + @CreateCommand +''') '
	)

	FETCH NEXT FROM INDEXCURSOR INTO
		@SchemaName,			
		@SourceTable,		
		@DestinationTable,
		@DropCommand,	
		@CreateCommand
END

CLOSE INDEXCURSOR
DEALLOCATE INDEXCURSOR

SELECT * FROM #Table

DROP TABLE #Table

