--Vers�o 1
DECLARE @TABLE TABLE (CodEmp CHAR(3), CGCFor VARCHAR(30), CodFor INT) 

INSERT INTO @TABLE 
SELECT TAB1.CodEmp, TAB1.CGCFor, FRN.CodFor 
FROM ( SELECT CodEmp, CGCFor FROM FRDCA.Dbo.Fornecedores A (NOLOCK)
       WHERE EXISTS (SELECT * FROM FRDCA.Dbo.Nota_Fiscal B (NOLOCK) WHERE A.Codemp=B.Codemp And A.Codfor=B.Codcli)
         AND A.Codemp In (190, 126, 124, 114, 159, 128, 327, 101, 125, 116, 143, 131, 160, 157, 274, 953, 115, 130, 117, 123, 113, 129, 127, 105, 109,'022', '167', '313','504') 
       GROUP BY A.CodEmp, A.CGCFor 
       HAVING COUNT(1) > 1 --ORDER BY CodEmp 
     ) TAB1
JOIN FRDCA.Dbo.FornecedoreS FRN ON TAB1.CodEmp = FRN.CodEmp AND TAB1.CGCFor = FRN.CGCFor 
ORDER BY TAB1.CodEmp, FRN.CodFor 

SELECT 
   CodEmp, CGCFor, 
   Codigos = STUFF( (SELECT ', ' + CONVERT(VARCHAR, B.CodFor) FROM @TABLE B WHERE B.CgcFor = A.CgcFor FOR XML PATH('')), 1, 2, '' ) 
FROM 
   @TABLE A 
GROUP BY CodEMp, CGCFor 



--Vers�o 2
DECLARE @TABLE TABLE (CodEmp CHAR(3), CGCFor VARCHAR(30), CodFor INT) 

INSERT INTO @TABLE 
Select Codemp,CgcFor,CodFor From  EMPDCA.Dbo.Fornecedores FRN
Where Exists (
Select * From (
Select A.Codemp, A.CgcFor, Count(2) as Qtd From EMPDCA.Dbo.Fornecedores A
Where 
A.Codemp = '327' 
And 
Exists (Select * From EMPDCA.Dbo.Nota_Fiscal B Where A.Codemp=B.Codemp And A.Codfor=B.Codcli)
Group By A.Codemp, A.CgcFor
Having Count(1)>1
)Tab Where FRN.Codemp=Tab.Codemp And FRN.CgcFor=Tab.CgcFor
) 

SELECT 
   CodEmp, CGCFor, 
   Codigos = STUFF( (SELECT ', ' + CONVERT(VARCHAR, B.CodFor) FROM @TABLE B WHERE B.CgcFor = A.CgcFor FOR XML PATH('')), 1, 2, '' ) 
FROM 
   @TABLE A 
GROUP BY CodEMp, CGCFor 
