Sp_AddLinkedServer [172.17.6.102,1805]


Alter Table IMOB_CCUSTO_ NoCheck Constraint All
Set Identity_Insert IMOB_CCUSTO_ On
Delete IMOB_CCUSTO_
Insert Into IMOB_CCUSTO_(ccusto_id, ccusto_codemp, ccusto_codigo, ccusto_descr, ccusto_dtinc)
select ROW_NUMBER() Over(Partition by ccusto_codemp order by ccusto_codemp), '518', ccusto_codigo, ccusto_descr, ccusto_dtinc
from [172.17.6.102,1805].SL2009b.dbo.IMOB_CCUSTO_ where ccusto_codemp = '350'
Alter Table IMOB_CCUSTO_ Check Constraint All
Set Identity_Insert IMOB_CCUSTO_ Off



Alter Table IMOB_DESCRBEM_ NoCheck Constraint All
Set Identity_Insert IMOB_DESCRBEM_ On
Delete IMOB_DESCRBEM_
Insert Into IMOB_DESCRBEM_(descrbem_id, descrbem_codemp, descrbem_codigo, descrbem_descr, descrbem_dtinc, descrbem_codcat, descrbem_codoriginal, descrbem_tipo)
select ROW_NUMBER() Over(Partition by descrbem_codemp order by descrbem_codemp), '518', descrbem_codigo, descrbem_descr, descrbem_dtinc, descrbem_codcat, descrbem_codoriginal, descrbem_tipo
from [172.17.6.102,1805].SL2009b.dbo.IMOB_DESCRBEM_ where descrbem_codemp = '350'
Alter Table IMOB_DESCRBEM_ Check Constraint All
Set Identity_Insert IMOB_DESCRBEM_ Off


Alter Table IMOB_DESCRSUC_ NoCheck Constraint All
Set Identity_Insert IMOB_DESCRSUC_ On
Delete IMOB_DESCRSUC_
Insert Into IMOB_DESCRSUC_(descrsuc_id, descrsuc_codemp, descrsuc_codigo, descrsuc_descr, descrsuc_dtinc)
select ROW_NUMBER() Over(Partition by descrsuc_codemp order by descrsuc_codemp), '518', descrsuc_codigo, descrsuc_descr, descrsuc_dtinc
from [172.17.6.102,1805].SL2009b.dbo.IMOB_DESCRSUC_ where descrsuc_codemp = '350'
Alter Table IMOB_DESCRSUC_ Check Constraint All
Set Identity_Insert IMOB_DESCRSUC_ Off



Alter Table IMOB_GRUPO_ NoCheck Constraint All
Set Identity_Insert IMOB_GRUPO_ On
Delete IMOB_GRUPO_
Insert Into IMOB_GRUPO_(grupo_id, grupo_codemp, grupo_codigo, grupo_descr, grupo_percdepr, grupo_os, grupo_deprecia, grupo_dtinc, natbccred_codigo, pridentbem_codigo)
select ROW_NUMBER() Over(Partition by grupo_codemp order by grupo_codemp), '518', grupo_codigo, grupo_descr, grupo_percdepr, grupo_os, grupo_deprecia, grupo_dtinc, natbccred_codigo, pridentbem_codigo
from [172.17.6.102,1805].SL2009b.dbo.IMOB_GRUPO_ where grupo_codemp = '350'
Alter Table IMOB_GRUPO_ Check Constraint All
Set Identity_Insert IMOB_GRUPO_ Off


Alter Table IMOB_LOCAL_ NoCheck Constraint All
Set Identity_Insert IMOB_LOCAL_ On
Delete IMOB_LOCAL_
Insert Into IMOB_LOCAL_(local_id, local_codemp, local_codigo, local_descr, local_ctadebdepr, local_dtinc)
select ROW_NUMBER() Over(Partition by local_codemp order by local_codemp), '518', local_codigo, local_descr, local_ctadebdepr, local_dtinc
from [172.17.6.102,1805].SL2009b.dbo.IMOB_LOCAL_ where local_codemp = '350'
Alter Table IMOB_LOCAL_ Check Constraint All
Set Identity_Insert IMOB_LOCAL_ Off


Alter Table IMOB_ORIGEMBEM_ NoCheck Constraint All
Delete IMOB_ORIGEMBEM_
Insert Into IMOB_ORIGEMBEM_(origembem_codigo, origembem_descricao, origembem_datacadastro, origembem_ativo)
select origembem_codigo, origembem_descricao, origembem_datacadastro, origembem_ativo
from [172.17.6.102,1805].SL2009b.dbo.IMOB_ORIGEMBEM_
Alter Table IMOB_ORIGEMBEM_ Check Constraint All


Alter Table IMOB_PRAQ_ NoCheck Constraint All
Set Identity_Insert IMOB_PRAQ_ On
Delete IMOB_PRAQ_
Insert Into IMOB_PRAQ_(praq_id, grupo_id, praq_codemp, praq_ctadebimob, praq_ctacredimob, praq_ctacreddepr, praq_ctaicmscprazo, praq_ctaicmslprazo, praq_ctapiscprazo, praq_ctapislprazo, praq_ctacofinscprazo, praq_ctacofinslprazo)
select ROW_NUMBER() Over(Partition by praq_codemp order by praq_codemp), ROW_NUMBER() Over(Partition by praq_codemp order by praq_codemp), 
       '518', praq_ctadebimob, praq_ctacredimob, praq_ctacreddepr, praq_ctaicmscprazo, praq_ctaicmslprazo, praq_ctapiscprazo, praq_ctapislprazo, praq_ctacofinscprazo, praq_ctacofinslprazo
from [172.17.6.102,1805].SL2009b.dbo.IMOB_PRAQ_ where praq_codemp = '350'
Alter Table IMOB_PRAQ_ Check Constraint All
Set Identity_Insert IMOB_PRAQ_ Off



Alter Table IMOB_PRBX_ NoCheck Constraint All
Set Identity_Insert IMOB_PRBX_ On
Delete IMOB_PRBX_
Insert Into IMOB_PRBX_(prbx_id, grupo_id, prbx_codemp, prbx_ctacredimob, prbx_ctadebcusto, prbx_ctadebdepr, prbx_ctacredicmscprazo, prbx_ctacredicmslprazo, prbx_ctacredpiscprazo, prbx_ctacredpislprazo, prbx_ctacredcofinscprazo, prbx_ctacredcofinslprazo)
select ROW_NUMBER() Over(Partition by prbx_codemp order by prbx_codemp), ROW_NUMBER() Over(Partition by prbx_codemp order by prbx_codemp), 
       '518', prbx_ctacredimob, prbx_ctadebcusto, prbx_ctadebdepr, prbx_ctacredicmscprazo, prbx_ctacredicmslprazo, prbx_ctacredpiscprazo, prbx_ctacredpislprazo, prbx_ctacredcofinscprazo, prbx_ctacredcofinslprazo
from [172.17.6.102,1805].SL2009b.dbo.IMOB_PRBX_ where prbx_codemp = '350'
Alter Table IMOB_PRBX_ Check Constraint All
Set Identity_Insert IMOB_PRBX_ Off



Alter Table IMOB_PRIDENTBEM_ NoCheck Constraint All
Delete IMOB_PRIDENTBEM_
Insert Into IMOB_PRIDENTBEM_(pridentbem_codigo, pridentbem_descricao, pridentbem_datacadastro, pridentbem_ativo)
select pridentbem_codigo, pridentbem_descricao, pridentbem_datacadastro, pridentbem_ativo
from [172.17.6.102,1805].SL2009b.dbo.IMOB_PRIDENTBEM_ 
Alter Table IMOB_PRIDENTBEM_ Check Constraint All



Alter Table IMOB_PRNATBCCRED_ NoCheck Constraint All
Delete IMOB_PRNATBCCRED_
Insert Into IMOB_PRNATBCCRED_(natbccred_codigo, natbccred_descricao, natbccred_datacadastro, natbccred_ativo, natbccred_imobilizado)
select natbccred_codigo, natbccred_descricao, natbccred_datacadastro, natbccred_ativo, natbccred_imobilizado
from [172.17.6.102,1805].SL2009b.dbo.IMOB_PRNATBCCRED_ 
Alter Table IMOB_PRNATBCCRED_ Check Constraint All



Alter Table IMOB_PRTR_ NoCheck Constraint All
Set Identity_Insert IMOB_PRTR_ On
Delete IMOB_PRTR_
Insert Into IMOB_PRTR_(prtr_id, grupo_id, prtr_codemp, prtr_ctacredimob, prtr_ctadebtransf, prtr_ctadebdepr, prtr_ctacredicmscprazo, prtr_ctacredicmslprazo, prtr_ctacredpiscprazo, prtr_ctacredpislprazo, prtr_ctacredcofinscprazo, prtr_ctacredcofinslprazo)
select ROW_NUMBER() Over(Partition by prtr_codemp order by prtr_codemp), ROW_NUMBER() Over(Partition by prtr_codemp order by prtr_codemp), 
       '518', prtr_ctacredimob, prtr_ctadebtransf, prtr_ctadebdepr, prtr_ctacredicmscprazo, prtr_ctacredicmslprazo, prtr_ctacredpiscprazo, prtr_ctacredpislprazo, prtr_ctacredcofinscprazo, prtr_ctacredcofinslprazo
from [172.17.6.102,1805].SL2009b.dbo.IMOB_PRTR_ where prtr_codemp = '350'
Alter Table IMOB_PRTR_ Check Constraint All
Set Identity_Insert IMOB_PRTR_ Off



Alter Table IMOB_STCOF_ NoCheck Constraint All
Delete IMOB_STCOF_
Insert Into IMOB_STCOF_(stcof_codigo, stcof_descricao, stcof_datacadastro, stcof_ativo)
select stcof_codigo, stcof_descricao, stcof_datacadastro, stcof_ativo
from [172.17.6.102,1805].SL2009b.dbo.IMOB_STCOF_ 
Alter Table IMOB_STCOF_ Check Constraint All




Alter Table IMOB_TIPOBAIXA_ NoCheck Constraint All
Delete IMOB_TIPOBAIXA_
Insert Into IMOB_TIPOBAIXA_(tipobaixa_codigo, tipobaixa_descricao, tipobaixa_nomedocumento, tipobaixa_datacadastro)
select tipobaixa_codigo, tipobaixa_descricao, tipobaixa_nomedocumento, tipobaixa_datacadastro
from [172.17.6.102,1805].SL2009b.dbo.IMOB_TIPOBAIXA_ 
Alter Table IMOB_TIPOBAIXA_ Check Constraint All




Alter Table IMOB_USOBEM_ NoCheck Constraint All
Delete IMOB_USOBEM_
Insert Into IMOB_USOBEM_(usobem_codigo, usobem_descricao, usobem_datacadastro, usobem_ativo)
select usobem_codigo, usobem_descricao, usobem_datacadastro, usobem_ativo
from [172.17.6.102,1805].SL2009b.dbo.IMOB_USOBEM_ 
Alter Table IMOB_USOBEM_ Check Constraint All
