/*
	Exemplo de como renomear tabelas e colunas ou adicionar colunas na tabela
*/

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'U' AND name = 'nome antigo')
BEGIN
	EXEC sp_rename 'nome antigo', 'nome novo';
END
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'nome da tabela' AND COLUMN_NAME = 'nome da coluna')
BEGIN
	EXEC sp_rename '<table>.[Column]', 'novo nome da coluna', 'COLUMN';
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'nome da tabela' AND COLUMN_NAME = 'nome da coluna')
BEGIN
	ALTER TABLE <tabela> ADD <column> <type> NOT NULL CONSTRAINT <name> DEFAULT ((0))
END
GO