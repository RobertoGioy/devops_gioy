Alter Proc Usp_Atualiza_ControleRemessa
As
Declare @Data DateTime

Set @Data = Rtrim(Year(Getdate()))+'-'+Right('0'+Rtrim(Month(GetDate())-1),2)+'-01'
--Set @Data = '2011-07-18'

Delete From Fato_ControleRemessa Where  Ano >= Year(@data) And Mes >= Month(@Data) And Dia >= Day(@Data)

       
--Atualiza Cadastro De Insumos      
Insert Into ProdutosCons        
Select Codemp,Codpro,'I',Convert(Varchar(60),Descricao),Isnull(Codcat,0)
From DC.DC.Dbo.Insumos A (Nolock)        
   Where Not Exists         
      (Select * From ProdutosCons B(Nolock) Where A.Codemp=B.Codemp And A.Codpro=B.Codpro And Isnull(A.Codcat,0)=Isnull(B.Codcat,0) And 'I'=B.Tippro)        
Group By Codemp,Codpro,Descricao,Isnull(Codcat,0)         
         
        
         
          
--Atualiza Cadastro Embalagens      
Insert Into ProdutosCons        
Select Codemp,Codemb,'E',Desemb,Isnull(Codcat,0)
From DC.DC.Dbo.Embalagens A(Nolock)         
   Where Not Exists         
      (Select * From ProdutosCons B(Nolock) Where A.Codemp=B.Codemp And A.CodEmb=B.Codpro And Isnull(A.Codcat,0)=Isnull(B.Codcat,0) And 'E'=B.Tippro)        
Group By Codemp,Codemb,Desemb,Isnull(Codcat,0)         
        
          
          
--Atualiza Cadastro Vasilhames                                                            
Insert Into ProdutosCons        
Select Codemp,CodVas,'V',Desvas,Isnull(Codcat,0)
From DC.DC.Dbo.Vasilhames A(Nolock)         
   Where Not Exists         
      (Select * From ProdutosCons B(Nolock) Where A.Codemp=B.Codemp And A.Codvas=B.Codpro And Isnull(A.Codcat,0)=Isnull(B.Codcat,0) And 'V'=B.Tippro)        
Group By Codemp,CodVas,Desvas,Isnull(Codcat,0)                                                       
          
          
          
--Atualiza Cadastro Produtos                                                           
Insert Into ProdutosCons        
Select Codemp,Codpro,'P',Despro,Isnull(Codcat,0)
From DC.DC.Dbo.Produtos A(Nolock)         
   Where Not Exists         
      (Select * From ProdutosCons B(Nolock) Where A.Codemp=B.Codemp And A.Codpro=B.Codpro And Isnull(A.Codcat,0)=Isnull(B.Codcat,0) And 'P'=B.Tippro)        
Group By Codemp,Codpro,Despro,Isnull(Codcat,0)




--Insere Tabela Fato_ControleRemessa
Insert Into Fato_ControleRemessa(Codemp, Cliente, Ano, Mes, Dia, Nota, Item, Cfop, Tipnot, Quantidade, Valor, Situacao, Dias)
SELECT R.Codemp Codemp , 
       Rtrim(R.Codcli)+ ' - ' +Rtrim(Upper(Ci.Descid)) Cliente, 
       Year(R.DatEnt) Ano, Month(R.DatEnt) Mes, Day(R.DatEnt) Dia, 
       R.Numnot Nota,  
       Rtrim(R.Codpro)+' - '+Rtrim(R.Descricao) ITEM, R.Codope CFOP, R.Tipnot, 
       Sum(R.QtdAberto) QTDE, Sum(R.ValAberto) VALOR, R.Situacao SITUACAO, R.Dias DIAS FROM 
( 
 SELECT I.Codemp,I.CodCli, I.DatEnt, I.NumNot, I.CodPro, I.CodOpe, 
 RTRIM(LTRIM(E.Despro)) Descricao, 
 ISNULL(I.QtdPro,0)-SUM(ISNULL(R.QtdPro,0)) QtdAberto, 
 (ISNULL(I.QtdPro,0)-SUM(ISNULL(R.QtdPro,0))) * ISNULL(I.ValLiq,0) ValAberto ,
 Case When ISNULL(I.QtdPro,0)-SUM(ISNULL(R.QtdPro,0))= 0 Then 'FECHADO' Else 'ABERTO' End Situacao,
 Case When ISNULL(I.QtdPro,0)-SUM(ISNULL(R.QtdPro,0))= 0 Then '0' Else DateDiff(DD,I.Datent,GetDate())End Dias,
 I.Tipnot
 FROM DC.EMPDCAB.Dbo.Nota_Fiscal N(NoLock) 
 INNER JOIN DC.EMPDCAB.Dbo.Itens_Nota_Fiscal I(NoLock) ON N.CodEmp = I.CodEmp AND N.NumNot = I.NumNot AND N.SerNot = I.SerNot AND N.TipNot = I.TipNot AND N.CodOpe = I.CodOpe AND N.CodCli = I.CodCli AND N.CodMod = I.CodMod AND N.DatEnt = I.DatEnt 
 LEFT JOIN 
 ( 
  SELECT R.CodEmp_REM, R.NumNot_REM, R.SerNot_REM, R.TipNot_REM, R.CodOpe_REM, R.PerIcm_REM, R.CodCli_REM, R.CodMod_REM, R.DatEnt_REM, I.CodPro, I.TipPro, SUM(I.QtdPro) QtdPro, SUM(I.ValBru) ValBru, I.Tipnot
  FROM DC.EMPDCAB.Dbo.Remessa_Cliente R(NoLock) 
  INNER JOIN DC.EMPDCAB.Dbo.Itens_Nota_Fiscal I(NoLock) ON R.CodEmp = I.CodEmp AND R.NumNot = I.NumNot AND R.SerNot = I.SerNot AND R.TipNot = I.TipNot AND R.CodOpe = I.CodOpe AND R.CodCli = I.CodCli AND R.CodMod = I.CodMod AND R.DatEnt = I.DatEnt 
  GROUP BY R.CodEmp_REM, R.NumNot_REM, R.SerNot_REM, R.TipNot_REM, R.CodOpe_REM, R.PerIcm_REM, R.CodCli_REM, R.CodMod_REM, R.DatEnt_REM, I.CodPro, I.TipPro, I.Tipnot
 ) R ON I.CodEmp = R.CodEmp_REM AND I.NumNot = R.NumNot_REM AND I.SerNot = R.SerNot_REM AND I.TipNot = R.TipNot_REM AND I.CodOpe = R.CodOpe_REM AND I.PerIcm = R.PerIcm_REM AND I.CodCli = R.CodCli_REM AND 
        I.CodMod = R.CodMod_REM AND I.DatEnt = R.DatEnt_REM AND I.CodPro = R.CodPro AND I.TipPro = R.TipPro 
 INNER JOIN ProdutosCons E ON I.CodEmp = E.CodEmp AND I.CodPro = E.Codpro AND I.TipPro = E.TipPro 
 WHERE N.CodOpe IN (5920,6920) AND N.DatEnt >= @Data  AND N.Status <> 'C' And Clifor = 'C'
 GROUP BY I.Codemp, I.CodCli, I.DatEnt, I.NumNot, I.Reg, I.CodPro, I.CodOpe, E.Despro, I.QtdPro, I.ValBru, I.ValLiq, I.Tipnot 
) R
Inner Join DC.EMPDCAB.Dbo.Clientes C(NoLock) On R.Codemp=C.Codemp And R.Codcli=C.Codcli
Inner Join DC.EMPDCAB.Dbo.Cidades Ci(NoLock) On C.Codcid=Ci.Codcid
Group By R.Codemp , Rtrim(R.Codcli)+ ' - ' +Rtrim(Upper(Ci.Descid)), Year(R.DatEnt), Month(R.DatEnt), Day(R.DatEnt), R.Numnot, Rtrim(R.Codpro)+' - '+Rtrim(R.Descricao), R.Codope, R.Situacao, R.Dias, R.Tipnot
UNION ALL
SELECT  R.CodEmp Codemp , 
       Rtrim(R.Codcli)+ ' - ' +Rtrim(Upper(Ci.Descid)) Cliente, 
       Year(R.DatEnt) Ano, Month(R.DatEnt) Mes, Day(R.DatEnt) Dia, 
       R.Numnot Nota,  
       Rtrim(R.Codpro)+' - '+Rtrim(R.Descricao) ITEM, R.Codope CFOP, R.Tipnot, 
       Sum(R.QtdAberto) QTDE, Sum(R.ValAberto) VALOR, R.Situacao SITUACAO, R.Dias DIAS 
       FROM 
            (SELECT I.Codemp, I.CodCli, I.DatEnt, I.NumNot, I.CodPro, I.CodOpe, 
                    RTRIM(LTRIM(E.Despro)) Descricao, 
                    ISNULL(I.QtdPro,0)-SUM(ISNULL(R.Qtde,0)) QtdAberto, 
                    (ISNULL(I.QtdPro,0)-SUM(ISNULL(R.Qtde,0))) * ISNULL(I.ValLiq,0) ValAberto,
                    Case When ISNULL(I.QtdPro,0)-SUM(ISNULL(R.Qtde,0))= 0 Then 'FECHADO' Else 'ABERTO' End Situacao,
		            Case When ISNULL(I.QtdPro,0)-SUM(ISNULL(R.Qtde,0))= 0 Then '0' Else DateDiff(DD,I.Datent,GetDate())End Dias,
                    I.Tipnot
             FROM DC.EMPDCAB.Dbo.Nota_Fiscal N  (Nolock)
             INNER JOIN DC.EMPDCAB.Dbo.Itens_Nota_Fiscal I (Nolock) ON N.CodEmp = I.CodEmp AND N.NumNot = I.NumNot AND N.SerNot = I.SerNot AND 
                                               N.TipNot = I.TipNot AND N.CodOpe = I.CodOpe AND N.CodCli = I.CodCli AND 
                                               N.CodMod = I.CodMod AND N.DatEnt = I.DatEnt  
            LEFT JOIN (SELECT R.CodEmp_REM, R.NumNot_REM, R.SerNot_REM, R.TipNot_REM, R.CodOpe_REM, R.PerIcm_REM, R.CodCli_REM, 
                              R.CodMod_REM, R.DatEnt_REM, I.Pecodi, I.TipPro, SUM(I.Qtde) Qtde, SUM(I.ValBru) ValBru   
                       FROM DC.EMPDCAB.Dbo.Remessa_Fornecedor R  (Nolock) 
                       INNER JOIN DC.EMPDCAB.Dbo.Itens_Pedido I (Nolock) ON R.CodEmp = I.CodEmp AND R.NumMap = I.NumMap AND R.NumPed = I.NumPed AND 
                                                    R.TipPed = I.TipPed  
                       GROUP BY R.CodEmp_REM, R.NumNot_REM, R.SerNot_REM, R.TipNot_REM, R.CodOpe_REM, R.PerIcm_REM, R.CodCli_REM, 
                                R.CodMod_REM, R.DatEnt_REM, I.Pecodi, I.TipPro  ) R ON I.CodEmp = R.CodEmp_REM AND I.NumNot = R.NumNot_REM AND 
                                                                                       I.SerNot = R.SerNot_REM AND I.TipNot = R.TipNot_REM AND 
                                                                                       I.CodOpe = R.CodOpe_REM AND I.PerIcm = R.PerIcm_REM AND 
                                                                                       I.CodCli = R.CodCli_REM AND I.CodMod = R.CodMod_REM AND 
                                                                                       I.DatEnt = R.DatEnt_REM AND I.CodPro = R.Pecodi AND 
                                                                                       I.TipPro = R.TipPro  
            INNER JOIN  ProdutosCons E (Nolock) ON I.CodEmp = E.CodEmp AND I.CodPro = E.Codpro AND I.TipPro = E.TipPro  
            WHERE N.TipNot = 'E' AND N.CodOpe IN (1920,2920,1949,2949) AND N.CliFor = 'F' AND N.DatEnt >= @Data AND  N.Status <> 'C'  
GROUP BY I.Codemp, I.CodCli, I.DatEnt, I.NumNot, I.Reg, I.CodPro, I.CodOpe, E.Despro, I.QtdPro, I.ValBru, I.ValLiq, I.Tipnot) R 
Inner Join DC.EMPDCAB.Dbo.Fornecedores F(NoLock) On R.Codemp=F.Codemp And R.Codcli=F.Codfor
Inner Join DC.EMPDCAB.Dbo.Cidades Ci(NoLock) On F.Codcid=Ci.Codcid
Group By R.Codemp , Rtrim(R.Codcli)+ ' - ' +Rtrim(Upper(Ci.Descid)), Year(R.DatEnt), Month(R.DatEnt), Day(R.DatEnt), R.Numnot, Rtrim(R.Codpro)+' - '+Rtrim(R.Descricao), R.Codope, R.Situacao, R.Dias, R.Tipnot
ORDER BY R.Codemp,Rtrim(R.Codcli)+ ' - ' +Rtrim(Upper(Ci.Descid)), Year(R.DatEnt), Month(R.DatEnt), Day(R.DatEnt), R.Numnot, Rtrim(R.Codpro)+' - '+Rtrim(R.Descricao)
