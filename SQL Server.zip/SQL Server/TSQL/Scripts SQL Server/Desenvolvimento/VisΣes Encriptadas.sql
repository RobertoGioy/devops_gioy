--================================================
-- Cap. 4 - VIEWS
-- Uma view serve para armazenar uma instru��o SELECT.
-- Para que utilizar uma VIEW?
--    .Centralizar a instru��o SELECT para que n�o
--     seja necess�rio digit�-la repetidas vezes.
--    .Proteger informa��es (colunas e/ou linhas)
--    .Simplifica��o de c�digo no caso de SELECTs
--     muito complexos.
--------------------------------------------------- 

USE PEDIDOS
-- 1.
CREATE VIEW VIE_EMP1 AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
-- Testando a VIEW
SELECT * FROM VIE_EMP1
--
SELECT CODFUN, NOME FROM VIE_EMP1

-- N�O PODE ...
ALTER VIEW VIE_EMP1 AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
ORDER BY NOME

-- MAS PODE !!!
ALTER VIEW VIE_EMP1 AS
SELECT TOP 999999 CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
ORDER BY NOME

-- Procure esta view no Object Explorer e 
-- d� om click direito sobre ela


-- 2.
CREATE VIEW VIE_EMP2 WITH ENCRYPTION
AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
-- Procure esta view no Object Explorer e 
-- d� om click direito sobre ela

-- 3.
CREATE VIEW VIE_EMP3 WITH ENCRYPTION
AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
WHERE COD_DEPTO = 2
--
SELECT * FROM VIE_EMP3
--
INSERT INTO VIE_EMP3
( NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO)
VALUES
('TESTE INCLUS�O', GETDATE(), 1, 1, 1000)
-- 
SELECT * FROM EMPREGADOS
--
SELECT * FROM VIE_EMP3
--
ALTER VIEW VIE_EMP3 WITH ENCRYPTION
AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS
WHERE COD_DEPTO = 2
WITH CHECK OPTION
-------------------------------------------------------------
CREATE VIEW VIE_EMP4 AS
SELECT E.CODFUN, E.NOME, E.DATA_ADMISSAO, 
       E.COD_DEPTO, E.COD_CARGO, E.SALARIO, D.DEPTO
FROM EMPREGADOS E 
     JOIN TABELADEP D ON E.COD_DEPTO = D.COD_DEPTO
---- FUNCIONA
INSERT INTO VIE_EMP1
( NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO)
VALUES
('TESTE INCLUS�O', GETDATE(), 1, 1, 1000)
-- TESTE
SELECT * FROM EMPREGADOS
---- FUNCIONA
INSERT INTO TABELADEP (DEPTO) VALUES ('TESTE...')
-- TESTE
SELECT * FROM TABELADEP

---- N�O FUNCIONA. INSERT EM MULTIPLAS TABELAS
INSERT INTO VIE_EMP1
( NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO, DEPTO)
VALUES
('TESTE INCLUS�O', GETDATE(), 1, 1, 1000, 'TESTE1')

--=============================================
-- Para que uma VIEW possa ser indexada, ela deve 
-- ser criada da seguinte forma:
CREATE VIEW VIE_EMP5 
WITH ENCRYPTION, SCHEMABINDING
AS
SELECT CODFUN, NOME, DATA_ADMISSAO, 
       COD_DEPTO, COD_CARGO, SALARIO
FROM DBO.EMPREGADOS
WHERE COD_DEPTO = 2
WITH CHECK OPTION
--
EXEC sp_rename @OBJNAME = 'EMPREGADOS.CODFUN', 
               @NEWNAME = 'COD_FUNC', @objtype  = 'COLUMN';

DROP TABLE EMPREGADOS

--
CREATE UNIQUE CLUSTERED INDEX IX_VIE_EMP4_CODFUN
ON VIE_EMP4(CODFUN)
--
CREATE INDEX IX_VIE_EMP4_NOME
ON VIE_EMP4(NOME)

--===============================================
















     