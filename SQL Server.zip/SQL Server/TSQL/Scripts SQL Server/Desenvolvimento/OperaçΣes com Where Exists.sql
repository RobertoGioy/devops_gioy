Select * From OCORRENCIAAV Where Sto_Codsetor = 1 And Qav_Codquesito = '6' And Rev_COdrev = '016' 
                                 And Sia_CodSub <>1 And Oco_DataOco Between '2011-07-01' And '2011-07-31'

Update OCORRENCIAAV Set Sia_CodSub = 1 Where Sto_Codsetor = 1 And Qav_Codquesito = '6' And Rev_COdrev = '016' 
                                 And Sia_CodSub <>1 And Oco_DataOco Between '2011-07-01' And '2011-07-31'




Select * From PeriodoCorrente A 
    Where 
    Exists
    (Select B.REV_CODEMP, B.REV_CODREV, B.STO_CODSETOR, B.OCO_DATAOCO, B.QAV_CODQUESITO
       From OCORRENCIAAV B Where B.Oco_DataOco Between '2011-07-01' And '2011-07-31' And B.Rev_Codrev = '016' And 
                                 B.Sto_Codsetor = 1 And A.Rev_Codrev=B.Rev_Codrev And A.Qav_Codquesito=B.Qav_Codquesito
Group By B.REV_CODEMP, B.REV_CODREV, B.STO_CODSETOR, B.OCO_DATAOCO, B.QAV_CODQUESITO)
    And A.Pco_Pontuou = 1 And A.Rev_Codrev = '016' And A.Sto_Codsetor = 1
    
    
Update A Set A.Pco_Pontuou=0 From PeriodoCorrente A 
    Where 
    Exists
    (Select B.REV_CODEMP, B.REV_CODREV, B.STO_CODSETOR, B.OCO_DATAOCO, B.QAV_CODQUESITO
       From OCORRENCIAAV B Where B.Oco_DataOco Between '2011-07-01' And '2011-07-31' And B.Rev_Codrev = '016' And 
                                 B.Sto_Codsetor = 1 And A.Rev_Codrev=B.Rev_Codrev And A.Qav_Codquesito=B.Qav_Codquesito
Group By B.REV_CODEMP, B.REV_CODREV, B.STO_CODSETOR, B.OCO_DATAOCO, B.QAV_CODQUESITO)
    And A.Pco_Pontuou = 1 And A.Rev_Codrev = '016' And A.Sto_Codsetor = 1