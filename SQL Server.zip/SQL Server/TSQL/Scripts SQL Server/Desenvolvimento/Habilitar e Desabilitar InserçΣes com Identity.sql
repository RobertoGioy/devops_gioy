--Sp_AddLinkedServer 'CEBTV1151'
/**********************************************************************************************************************************************************/
--INSERE TABELA IMOB_GRUPO_
Go
Set Identity_Insert Imob_Grupo_ On
Go
Insert Into IMOB_GRUPO_(Grupo_id,Grupo_Codemp, Grupo_Codigo, Grupo_Descr, Grupo_PercDepr, Grupo_Os, Grupo_Deprecia, Grupo_Dtinc, Natbccred_Codigo, Pridentbem_Codigo)
Select Grupo_id,Grupo_Codemp, Grupo_Codigo, Grupo_Descr, Grupo_PercDepr, Grupo_Os, Grupo_Deprecia, Grupo_Dtinc, Natbccred_Codigo, Pridentbem_Codigo
   From [CEBTV1151].T_SL2000BTR.Dbo.IMOB_GRUPO_ 
        Where Grupo_Codemp = '128'
Go
Set Identity_Insert Imob_Grupo_ Off
Go
Select * From Imob_Grupo_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_PRAQ_
Go
Set Identity_Insert IMOB_PRAQ_ On
Go
Insert Into IMOB_PRAQ_(praq_id, grupo_id, praq_codemp, praq_ctadebimob, praq_ctacredimob, praq_ctacreddepr, praq_ctaicmscprazo, praq_ctaicmslprazo, praq_ctapiscprazo, praq_ctapislprazo, praq_ctacofinscprazo, praq_ctacofinslprazo)
Select praq_id, grupo_id, praq_codemp, praq_ctadebimob, praq_ctacredimob, praq_ctacreddepr, praq_ctaicmscprazo, praq_ctaicmslprazo, praq_ctapiscprazo, praq_ctapislprazo, praq_ctacofinscprazo, praq_ctacofinslprazo
    From [CEBTV1151].T_SL2000BTR.Dbo.IMOB_PRAQ_
         Where Praq_codemp = '128'
Go
Set Identity_Insert IMOB_PRAQ_ Off
Go
Select * From IMOB_PRAQ_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_PRBX_
Go
Set Identity_Insert IMOB_PRBX_ On
Go
Insert Into IMOB_PRBX_(prbx_id, grupo_id, prbx_codemp, prbx_ctacredimob, prbx_ctadebcusto, prbx_ctadebdepr, prbx_ctacredicmscprazo, prbx_ctacredicmslprazo, prbx_ctacredpiscprazo, prbx_ctacredpislprazo, prbx_ctacredcofinscprazo, prbx_ctacredcofinslprazo)
Select prbx_id, grupo_id, prbx_codemp, prbx_ctacredimob, prbx_ctadebcusto, prbx_ctadebdepr, prbx_ctacredicmscprazo, prbx_ctacredicmslprazo, prbx_ctacredpiscprazo, prbx_ctacredpislprazo, prbx_ctacredcofinscprazo, prbx_ctacredcofinslprazo
   From [CEBTV1151].T_SL2000BTR.Dbo.IMOB_PRBX_
        Where prbx_codemp = '128'
Go
Set Identity_Insert IMOB_PRBX_ Off
Go
Select * From IMOB_PRBX_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_PRTR_
Go
Set Identity_Insert IMOB_PRTR_ On
Go
Insert Into IMOB_PRTR_(prtr_id, grupo_id, prtr_codemp, prtr_ctacredimob, prtr_ctadebtransf, prtr_ctadebdepr, prtr_ctacredicmscprazo, prtr_ctacredicmslprazo, prtr_ctacredpiscprazo, prtr_ctacredpislprazo, prtr_ctacredcofinscprazo, prtr_ctacredcofinslprazo)
Select prtr_id, grupo_id, prtr_codemp, prtr_ctacredimob, prtr_ctadebtransf, prtr_ctadebdepr, prtr_ctacredicmscprazo, prtr_ctacredicmslprazo, prtr_ctacredpiscprazo, prtr_ctacredpislprazo, prtr_ctacredcofinscprazo, prtr_ctacredcofinslprazo
   From [CEBTV1151].T_SL2000BTR.Dbo.IMOB_PRTR_
        Where Prtr_codemp = '128'
Go
Set Identity_Insert IMOB_PRTR_ Off
Go
Select * From IMOB_PRTR_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_LOCAL_
Go
Set Identity_Insert IMOB_LOCAL_ On
Go
Insert Into IMOB_LOCAL_(local_id, local_codemp, local_codigo, local_descr, local_ctadebdepr, local_dtinc)
Select local_id, local_codemp, local_codigo, local_descr, local_ctadebdepr, local_dtinc
   From [CEBTV1151].T_SL2000BTR.Dbo.IMOB_LOCAL_
        Where local_codemp = '128'
Go
Set Identity_Insert IMOB_LOCAL_ Off
Go
Select * From IMOB_LOCAL_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_CCUSTO_
Go
Set Identity_Insert IMOB_CCUSTO_ On
Go
Insert Into IMOB_CCUSTO_(ccusto_id, ccusto_codemp, ccusto_codigo, ccusto_descr, ccusto_dtinc)
Select ccusto_id, ccusto_codemp, ccusto_codigo, ccusto_descr, ccusto_dtinc
   From [CEBTV1151].T_SL2000BTR.Dbo.IMOB_CCUSTO_
        Where Ccusto_Codemp = '128'
Go
Set Identity_Insert IMOB_CCUSTO_ Off
Go
Select * From IMOB_CCUSTO_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_ITEM_
Go
Set Identity_Insert IMOB_ITEM_ On
go
Alter Table IMOB_ITEM_ NoCheck Constraint All
Go
Insert Into IMOB_ITEM_(item_id, item_codemp, item_codigo, grupo_id, ccusto_id, local_id, descrbem_id, descrsuc_id, item_dtaaqu, item_modal, item_creicm, item_crepis, item_crecof, item_valdutil, item_valcicmutil, item_nparicmrem, item_valcpisutil, item_nparpisrem, item_valccofutil, item_nparcofrem, item_tipomerc, item_vinculo, item_tipmovbem, item_valbru, item_txdepr, item_tiplan, item_codfor, item_indemit, item_dtemi, item_sernot, item_numnot, item_numseq, item_codpro, item_qtde, item_status, item_aliqicms, item_percrbc, item_valicm, item_valicmsT, item_valicmfrete, item_valdifaliq, item_valparicm, item_dtaapr, item_nparcicm, item_dtsuspciap, item_qtdparaprant, item_dtrevsusp, item_qtdparaprrev, item_obser, item_valmobra, item_valprest, item_placa, item_imagem, item_dtaprpis, item_valbaspis, item_percpis, item_valpis, item_qtdparpis, item_valparpis, item_dtsusppis, item_qtdparaprantpis, item_dtrevsusppis, item_qtdparaprrevpis, item_dtaprcof, item_valbascof, item_perccof, item_valcof, item_qtdparcof, item_valparcof, item_dtsuspcof, item_qtdparaprantcof, item_dtrevsuspcof, item_qtdparaprrevcof, item_doc, item_dtencerramento, item_numos, item_dtfabricacao, item_dtbaixa, origembem_codigopis, usobem_codigopis, stpis_codigo, origembem_codigocof, usobem_codigocof, stcof_codigo, item_deprecaceleracao, item_valfrete)
Select item_id, item_codemp, item_codigo, grupo_id, ccusto_id, local_id, descrbem_id, descrsuc_id, item_dtaaqu, item_modal, item_creicm, item_crepis, item_crecof, item_valdutil, item_valcicmutil, item_nparicmrem, item_valcpisutil, item_nparpisrem, item_valccofutil, item_nparcofrem, item_tipomerc, item_vinculo, item_tipmovbem, item_valbru, item_txdepr, item_tiplan, item_codfor, item_indemit, item_dtemi, item_sernot, item_numnot, item_numseq, item_codpro, item_qtde, item_status, item_aliqicms, item_percrbc, item_valicm, item_valicmsT, item_valicmfrete, item_valdifaliq, item_valparicm, item_dtaapr, item_nparcicm, item_dtsuspciap, item_qtdparaprant, item_dtrevsusp, item_qtdparaprrev, item_obser, item_valmobra, item_valprest, item_placa, item_imagem, item_dtaprpis, item_valbaspis, item_percpis, item_valpis, item_qtdparpis, item_valparpis, item_dtsusppis, item_qtdparaprantpis, item_dtrevsusppis, item_qtdparaprrevpis, item_dtaprcof, item_valbascof, item_perccof, item_valcof, item_qtdparcof, item_valparcof, item_dtsuspcof, item_qtdparaprantcof, item_dtrevsuspcof, item_qtdparaprrevcof, item_doc, item_dtencerramento, item_numos, item_dtfabricacao, item_dtbaixa, origembem_codigopis, usobem_codigopis, stpis_codigo, origembem_codigocof, usobem_codigocof, stcof_codigo, item_deprecaceleracao, item_valfrete
   From [CEBTV1151].T_SL2000BTR.Dbo.IMOB_ITEM_
        Where item_codemp = '128'
Go
Set Identity_Insert IMOB_ITEM_ Off
Go
Alter Table IMOB_ITEM_ Check Constraint All
Go
Select * From IMOB_ITEM_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_DESCRBEM_
Go
Set Identity_Insert IMOB_DESCRBEM_ On
go
Alter Table IMOB_DESCRBEM_ NoCheck Constraint All
Go
Insert Into IMOB_DESCRBEM_(descrbem_id, descrbem_codemp, descrbem_codigo, descrbem_descr, descrbem_dtinc, descrbem_codcat, descrbem_codoriginal, descrbem_tipo)
Select descrbem_id, descrbem_codemp, descrbem_codigo, descrbem_descr, descrbem_dtinc, descrbem_codcat, descrbem_codoriginal, descrbem_tipo
   From [CEBTV1151].T_SL2000BTR.Dbo.IMOB_DESCRBEM_
        Where descrbem_codemp = '128'
Go
Set Identity_Insert IMOB_DESCRBEM_ Off
Go
Alter Table IMOB_DESCRBEM_ Check Constraint All
Go
Select * From IMOB_DESCRBEM_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_DESCRSUC_
Go
Set Identity_Insert IMOB_DESCRSUC_ On
go
Alter Table IMOB_DESCRSUC_ NoCheck Constraint All
Go
Insert Into IMOB_DESCRSUC_(descrsuc_id, descrsuc_codemp, descrsuc_codigo, descrsuc_descr, descrsuc_dtinc)
Select descrsuc_id, descrsuc_codemp, descrsuc_codigo, descrsuc_descr, descrsuc_dtinc
   From [CEBTV1151].T_SL2000BTR.Dbo.IMOB_DESCRSUC_
        Where descrsuc_codemp = '128'
Go
Set Identity_Insert IMOB_DESCRSUC_ Off
Go
Alter Table IMOB_DESCRSUC_ Check Constraint All
Go
Select * From IMOB_DESCRSUC_
