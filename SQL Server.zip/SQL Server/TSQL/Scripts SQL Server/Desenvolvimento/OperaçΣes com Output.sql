
--============================================================ 
-- OUTPUT com INSERT
-- Gera uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
IF OBJECT_ID('EMP_TEMP','U') IS NOT NULL
   DROP TABLE EMP_TEMP;
CREATE TABLE EMP_TEMP
( CODFUN    INT PRIMARY KEY,
  NOME      VARCHAR(30),
  COD_DEPTO INT,
  COD_CARGO	INT,
  SALARIO	NUMERIC(10,2) );
-- Inserir dados e exibir os registros inseridos
INSERT INTO EMP_TEMP OUTPUT INSERTED.*
SELECT CODFUN, NOME, COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS;
GO

-- Excluir todos os registros
DELETE FROM EMP_TEMP;
-- Inserir dados e exibir algumas colunas
INSERT INTO EMP_TEMP 
OUTPUT INSERTED.CODFUN, INSERTED.NOME, INSERTED.COD_DEPTO
SELECT CODFUN, NOME, COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS WHERE COD_DEPTO = 2;
GO

-- Declara vari�vel tabular
DECLARE @REG_INSERT TABLE ( CODFUN    INT,
							NOME      VARCHAR(30),
							COD_DEPTO INT,
							COD_CARGO	INT,
							SALARIO	NUMERIC(10,2) );
-- Inserir dados e exibir algumas colunas
INSERT INTO EMP_TEMP 
OUTPUT INSERTED.* INTO @REG_INSERT
SELECT CODFUN, NOME, COD_DEPTO, COD_CARGO, SALARIO
FROM EMPREGADOS WHERE COD_DEPTO = 3;
-- Registros inseridos
SELECT * FROM @REG_INSERT;
-- Todos os registros
SELECT * FROM EMP_TEMP;
GO

--============================================================ OUTPUT com DELETE
-- Gera uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
IF OBJECT_ID('EMP_TEMP','U') IS NOT NULL
   DROP TABLE EMP_TEMP;

SELECT * INTO EMP_TEMP FROM EMPREGADOS
-- Deleta registros e mostra os registros deletados
DELETE FROM EMP_TEMP OUTPUT DELETED.*
WHERE COD_DEPTO = 2
GO

-- Deleta registros e mostra alguns campos dos registros deletados
DELETE FROM EMP_TEMP 
OUTPUT DELETED.CODFUN, DELETED.NOME, DELETED.COD_DEPTO
WHERE COD_DEPTO = 3
GO

-- Declara vari�vel tabular
DECLARE @REG_DELETED TABLE ( CODFUN    INT,
							NOME      VARCHAR(30),
							COD_DEPTO INT,
							SALARIO	NUMERIC(10,2) );
-- Inserir dados e exibir algumas colunas
DELETE FROM EMP_TEMP
OUTPUT 
  DELETED.CODFUN, DELETED.NOME, DELETED.COD_DEPTO, DELETED.SALARIO
  INTO @REG_DELETED
WHERE COD_DEPTO = 5;
-- Registros excluidos
SELECT * FROM @REG_DELETED;
-- Registros restantes
SELECT * FROM EMP_TEMP;
GO

--============================================================ OUTPUT com UPDATE
-- Gera uma c�pia da tabela EMPREGADOS chamada EMP_TEMP
IF OBJECT_ID('EMP_TEMP','U') IS NOT NULL
   DROP TABLE EMP_TEMP;
SELECT * INTO EMP_TEMP FROM EMPREGADOS;
-- Altera registros e mostra os dados antes e depois da altera��o
UPDATE EMP_TEMP SET SALARIO = SALARIO * 1.5
OUTPUT 
   INSERTED.CODFUN, INSERTED.NOME, INSERTED.COD_DEPTO, 
   DELETED.SALARIO, INSERTED.SALARIO
WHERE COD_DEPTO = 3;
GO

-- Declara vari�vel tabular
DECLARE @REG_UPDATED TABLE (	CODFUN			INT,
								NOME			VARCHAR(30),
								COD_DEPTO		INT,
								SALARIO_ANTIGO	NUMERIC(10,2),
								SALARIO_NOVO	NUMERIC(10,2) );
-- Altera registros	e mostra os dados de antes e depois da altera��o
UPDATE EMP_TEMP SET SALARIO = SALARIO * 1.5
OUTPUT 
   INSERTED.CODFUN, INSERTED.NOME, INSERTED.COD_DEPTO, 
   DELETED.SALARIO, INSERTED.SALARIO
   INTO @REG_UPDATED
WHERE COD_DEPTO = 2
-- Exibir resultado 
SELECT * FROM @REG_UPDATED;  
GO


                        