/*
	AUTHOR:			CLELIA MARCIA
	PROJECT:		ITA� 30 HORAS UDIAL
	DATABASE:		DBBC805
	DESCRIPTION:	PROCESSO DE DROP DE TODOS OS OBJETOS DE DADOS (SINONIMOS, PROCEDURES, VIEWS, FUNCTIONS, FOREIGN KEYS E TABLES)
	DATE CREATED:	13/09/2013
*/

print 'criando tabela temporaria - lista de objetos a serem dropados'
go
create table #tmpObjects(idobj int identity (1,1) primary key clustered, objschema varchar(50), objname varchar(200), objtype varchar(2),msg varchar(500))
go

print 'populando tabela temporaria - lista de objetos a serem dropados'
go

Insert into #tmpObjects (objschema, objname, objtype)
select s.name, o.name, type from sys.objects o inner join sys.schemas s on o.schema_id=s.schema_id where o.type = 'SN'  -- sinonimos
go

Insert into #tmpObjects (objschema, objname, objtype)
select s.name, o.name, type from sys.objects o inner join sys.schemas s on o.schema_id=s.schema_id where o.type = 'P'  -- procedures
go


Insert into #tmpObjects (objschema, objname, objtype)
select TABLE_SCHEMA, TABLE_NAME, type= 'V' from INFORMATION_SCHEMA.VIEWS  --views
go

Insert into #tmpObjects (objschema, objname, objtype)
select s.name, o.name, type from sys.objects o inner join sys.schemas s on o.schema_id=s.schema_id where o.type in ('TF','FN')  --table function, scalar function
go

Insert into #tmpObjects (objschema, objname, objtype,msg)
select s.name, o.name, o.type, t.name 
from sys.objects o inner join sys.schemas s on o.schema_id=s.schema_id 
inner join sys.objects t on o.parent_object_id= t.object_id
where o.type = 'F'  --foreing keys
go

Insert into #tmpObjects (objschema, objname, objtype)
select TABLE_SCHEMA, TABLE_NAME, type= 'T' from INFORMATION_SCHEMA.TABLES where TABLE_TYPE='BASE TABLE' --tabelas
go

--
select * from #tmpObjects
--

print 'construindo script para drop dos objetos'
go

DECLARE @ID INT, @SCHEMA VARCHAR(50), @NAME VARCHAR(200), @TYPE VARCHAR(2), @MSG varchar(200)
DECLARE @STRING VARCHAR(MAX)

DECLARE object_cursor CURSOR FOR 
select idobj, objschema, objname, objtype, msg from #tmpObjects

OPEN object_cursor;
FETCH NEXT FROM object_cursor INTO @ID, @SCHEMA, @NAME, @TYPE, @MSG

    WHILE @@FETCH_STATUS = 0
    BEGIN
    
        
IF @type = 'SN'  --SYNONYM
BEGIN
		set @STRING = 'DROP SYNONYM ' + @SCHEMA+'.'+@NAME
END


IF @type = 'P'   --PROCEDURE
BEGIN
		set @STRING = 'DROP PROCEDURE ' + @SCHEMA+'.'+@NAME
END

IF @type = 'V'   --VIEW
BEGIN
		set @STRING = 'DROP VIEW ' + @SCHEMA+'.'+@NAME
END

IF @type = 'FN'  --FUNCTION
BEGIN
		set @STRING = 'DROP FUNCTION ' + @SCHEMA+'.'+@NAME
END

IF @type = 'F'   --FOREIGN KEY
BEGIN
		set @STRING = 'ALTER TABLE ' + @SCHEMA+'.'+@MSG + ' DROP CONSTRAINT '+@NAME
END

IF @type = 'T'   --TABLE
BEGIN
			set @STRING = 'DROP TABLE ' + @SCHEMA+'.'+@NAME
END
        
        --SELECT @STRING 
        print 'dropando objeto  '+ @schema + '.'+ @name + ' do tipo: '+ @type

        EXEC(@STRING)
                
        FETCH NEXT FROM object_cursor INTO @ID, @SCHEMA, @NAME, @TYPE, @MSG
        END;

    CLOSE object_cursor;
    DEALLOCATE object_cursor;
GO

--verifica o que n�o conseguiu dropar  (rodar novamente o script se necess�rio) 
select * from sys.objects where type not in ('S', 'IT','SQ')

--drop tabela temporaria de objetos
Drop table #tmpObjects

GO

