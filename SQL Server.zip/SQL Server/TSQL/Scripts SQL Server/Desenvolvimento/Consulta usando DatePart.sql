Select '� VISTA' As 'PRAZO',     
  Case 
     When DatePart(MM,Datinc) = 1 Then '01 - Janeiro'
     When DatePart(MM,Datinc) = 2 Then '02 - Fevereiro' 
     When DatePart(MM,Datinc) = 3 Then '03 - Mar�o'
     When DatePart(MM,Datinc) = 4 Then '04 - Abril' 
     When DatePart(MM,Datinc) = 5 Then '05 - Maio' 
     When DatePart(MM,Datinc) = 6 Then '06 - Junho' 
     When DatePart(MM,Datinc) = 7 Then '07 - Julho'
     When DatePart(MM,Datinc) = 8 Then '08 - Agosto' 
     When DatePart(MM,Datinc) = 9 Then '09 - Setembro' 
     When DatePart(MM,Datinc) = 10 Then '10 - Outubro'
     When DatePart(MM,Datinc) = 11 Then '11 - Novembro'
     When DatePart(MM,Datinc) = 12 Then '12 - Dezembro' End As 'M�s', 
     Sum(Valdup) As 'Valor', Round(Sum(Valdup/100*1.45),2) As 'Porcentagem'  From Duplicata  Where Datinc Between '2010-01-01' And '2010-12-31' And Nummap <>0 And Codemp = 114 And DateDiff(DD,Datinc,Datven) In (0,1)
Group By DATEPART(MM,Datinc)
Union All
Select 'AT� SETE DIAS' As 'PRAZO', 
    Case 
     When DatePart(MM,Datinc) = 1 Then '01 - Janeiro'
     When DatePart(MM,Datinc) = 2 Then '02 - Fevereiro' 
     When DatePart(MM,Datinc) = 3 Then '03 - Mar�o'
     When DatePart(MM,Datinc) = 4 Then '04 - Abril' 
     When DatePart(MM,Datinc) = 5 Then '05 - Maio' 
     When DatePart(MM,Datinc) = 6 Then '06 - Junho' 
     When DatePart(MM,Datinc) = 7 Then '07 - Julho'
     When DatePart(MM,Datinc) = 8 Then '08 - Agosto' 
     When DatePart(MM,Datinc) = 9 Then '09 - Setembro' 
     When DatePart(MM,Datinc) = 10 Then '10 - Outubro'
     When DatePart(MM,Datinc) = 11 Then '11 - Novembro'
     When DatePart(MM,Datinc) = 12 Then '12 - Dezembro' End As 'M�s', 
  Sum(Valdup) As 'Valor', Round(Sum(Valdup/100*0.30),2) As 'Porcentagem'  From Duplicata  Where Datinc Between '2010-01-01' And '2010-12-31' And Nummap <>0 And Codemp = 114 And DateDiff(DD,Datinc,Datven) > 1 And DateDiff(DD,Datinc,Datven) <= 7 
Group By DATEPART(MM,Datinc)
Union All
Select 'MAIOR QUE SETE DIAS' As 'PRAZO', 
    Case 
     When DatePart(MM,Datinc) = 1 Then '01 - Janeiro'
     When DatePart(MM,Datinc) = 2 Then '02 - Fevereiro' 
     When DatePart(MM,Datinc) = 3 Then '03 - Mar�o'
     When DatePart(MM,Datinc) = 4 Then '04 - Abril' 
     When DatePart(MM,Datinc) = 5 Then '05 - Maio' 
     When DatePart(MM,Datinc) = 6 Then '06 - Junho' 
     When DatePart(MM,Datinc) = 7 Then '07 - Julho'
     When DatePart(MM,Datinc) = 8 Then '08 - Agosto' 
     When DatePart(MM,Datinc) = 9 Then '09 - Setembro' 
     When DatePart(MM,Datinc) = 10 Then '10 - Outubro'
     When DatePart(MM,Datinc) = 11 Then '11 - Novembro'
     When DatePart(MM,Datinc) = 12 Then '12 - Dezembro' End As 'M�s', 
  Sum(Valdup) As 'Valor', Round(Sum(Valdup/100*0.05),2) As 'Porcentagem'  From Duplicata  Where Datinc Between '2010-01-01' And '2010-12-31' And Nummap <>0 And Codemp = 114 And DateDiff(DD,Datinc,Datven) > 7
Group By DATEPART(MM,Datinc)
Order By M�s
