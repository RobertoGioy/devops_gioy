Declare @codemp char(3), @datini Datetime, @datfin Datetime

Set @codemp = '236'
Set @datini = '2010-01-01'
Set @DatFin = '2010-01-31'

Select Round((
((Select Isnull(Sum(Valor),0) From Balanco_Dados Where Codigo In (10,11,12,13,14,16,17,22,24,25,26,42,5) And Indice = 1 And Codemp = @codemp And Data = @datini And Tipmet In ('0','9'))+
(Select Isnull(Sum(Valor),0) From Balanco_Dados Where Codigo In (690,691,692,693) And Indice = 0 And Codemp = @codemp And Data = @datini And Tipmet In ('0','9'))+
(Select Isnull(Sum(Valor),0) From Balanco_DespInc Where Codorc='I03' And Tiplan In ('0','9') And Codemp = @codemp And Data=@datini)+
(Select Isnull(Sum(Valatu),0) From Balanco_Estoque Where CodGru<800 And Codemp = @codemp And Datmov = @datfin And Tiplan In ('0','9'))+
(Select Isnull(Sum(Valven),0) From Balanco_Estoque Where CodGru<800 And Codemp = @codemp And Datmov = @datfin And Tiplan In ('0','9')))
-
((Select Isnull(Sum(Valor),0) From Balanco_Dados Where Codigo In (150,30,31,32,35,40,57) And Indice = 1 And Codemp = @codemp And Data = @datini And Tipmet In ('0','9'))+
(Select Isnull(Sum(Valor),0) From Balanco_Dados Where Codigo In (700,701,702,703) And Indice = 50 And Codemp = @codemp And Data = @datini And Tipmet In ('0','9'))+
(Select Isnull(Sum(Valor),0) From Balanco_Desp Where Codorc In ('A01','A02','A03','A04','A05','A06','A07','A08','A09','C00','C01','C02','D01','D02','D03','D04','D05','D06','D07','D08','D09','E01','E02','E03','E04','E05','E06','E07','E08','E09','E10','V01','V02','V03','V04','V05','V06','V07','V08','V09','V10','V11','V12','X01','X02','X03','X04','X05','X06','X07','X08','X09','X10','X11','X12','X13','X15','X16','X17','X18','X19') 
                             And Codemp = @codemp And Data = @datfin And Tiplan In ('0','9'))+
(Select Isnull(Sum(Valor),0) From Balanco_Desp Where Codred In ('39008','39009','39036','39037') And Codemp = @codemp And Data = @datfin And Tiplan In ('0','9'))+
(Select Isnull(Sum(Valor),0) From Balanco_DespInc Where Codorc In ('I03','P01','P02') And Codemp = @codemp And Data = @datfin And Tiplan In ('0','9'))+
(Select Isnull(Sum(Valor),0) From Balanco_DespInc Where Codred In ('39105') And Codemp = @codemp And Data = @datfin And Tiplan In ('0','9'))+
(Select Isnull(Sum(Valor),0) From Balanco_DespItens Where Codorc In ('A01','A03','A06','A08','D06','D08','E09','V09','X09') And Codemp = @codemp And Data = @datfin And Tiplan In ('0','9'))+
(Select Isnull(Sum(Mao_Obra),0) From Balanco_Estoque Where CodGru<800 And Codemp = @codemp And Datmov = @datfin And Tiplan In ('0','9'))+
(Select Isnull(Sum(ValCom + ValFre + Val_Acre_Compra + Val_Desc_Compra),0) From Balanco_Estoque Where CodGru = 100 And Codemp = @codemp And Datmov = @datfin And Tiplan In ('0','9'))+
(Select Isnull(Sum(Valant),0) From Balanco_Estoque Where CodGru<800 And Codemp = @codemp And Datmov = @datfin And Tiplan In ('0','9'))+
(Select Isnull(Sum(ValCom + ValFre + ValTransf),0) From Balanco_Estoque Where CodGru<800 And Codgru Not In (100)  And Codemp = @codemp And Datmov = @datfin And Tiplan In ('0','9')))
),2) As Lucro_Liquido