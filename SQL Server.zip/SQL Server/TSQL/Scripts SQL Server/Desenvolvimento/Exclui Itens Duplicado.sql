--SELECT *
--FROM Itens_Tabela
SELECT line, *
FROM Itens_Tabela I
INNER JOIN (
	SELECT Row_Number() OVER (
			PARTITION BY A.Codemp, A.Codtab, A.Codpro, A.Tippro ORDER BY A.Codemp, A.Codtab, A.Codpro, A.Tippro
			) AS Line, A.Codemp, A.Codtab, A.Codpro, A.Tippro, A.Reg
	FROM Itens_Tabela A
	INNER JOIN (
		SELECT Codemp, Codtab, Codpro, Tippro
		FROM Itens_Tabela
		GROUP BY Codemp, Codtab, Codpro, Tippro
		HAVING COUNT(Reg) > 1
		) B ON A.Codemp = B.Codemp
		AND A.Codtab = B.Codtab
		AND A.Codpro = B.Codpro
		AND A.Tippro = B.Tippro
	) Tb ON I.Codemp = Tb.Codemp
	AND I.Codtab = Tb.Codtab
	AND I.Codpro = Tb.Codpro
	AND I.Tippro = Tb.Tippro
	AND I.Reg = Tb.Reg
WHERE Line >= 2
ORDER BY Line


/*
Delete I
FROM Itens_Tabela I
INNER JOIN (
	SELECT Row_Number() OVER (
			PARTITION BY A.Codemp, A.Codtab, A.Codpro, A.Tippro ORDER BY A.Codemp, A.Codtab, A.Codpro, A.Tippro
			) AS Line, A.Codemp, A.Codtab, A.Codpro, A.Tippro, A.Reg
	FROM Itens_Tabela A
	INNER JOIN (
		SELECT Codemp, Codtab, Codpro, Tippro
		FROM Itens_Tabela
		GROUP BY Codemp, Codtab, Codpro, Tippro
		HAVING COUNT(Reg) > 1
		) B ON A.Codemp = B.Codemp
		AND A.Codtab = B.Codtab
		AND A.Codpro = B.Codpro
		AND A.Tippro = B.Tippro
	) Tb ON I.Codemp = Tb.Codemp
	AND I.Codtab = Tb.Codtab
	AND I.Codpro = Tb.Codpro
	AND I.Tippro = Tb.Tippro
	AND I.Reg = Tb.Reg
WHERE Line >= 2
*/
