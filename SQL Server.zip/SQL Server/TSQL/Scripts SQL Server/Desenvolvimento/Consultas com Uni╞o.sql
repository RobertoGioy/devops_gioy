


select 'Abertos' as status,count(cdchamado) as 'Abertos'
from hd_chamado a
where cdequipe in ('19')
and dtchamado between '2011-07-01' and '2011-07-31'
and cdsituacao!=8 
UNION 
select 'Atrasados' as status,sum(case when dttermino >= dtprevisaotermino then 1 else 0 end) as 'Status'
from hd_chamado a
where cdequipe in ('19')
and dtchamado between '2011-07-01' and '2011-07-31'
and cdsituacao!=8 
UNION
select 'Em Dia' as status,(COUNT(cdchamado)-(sum(case when dttermino >= dtprevisaotermino then 1 else 0 end))) as 'Status'
from hd_chamado a
where cdequipe in ('19')
and dtchamado between '2011-07-01' and '2011-07-31'
and cdsituacao!=8 
