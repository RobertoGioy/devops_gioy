declare @grupo varchar(8000),
  @caracter char(1) = NULL

set @grupo = 'Umagnet.EndcallLog'
set @caracter = '.'
 
begin
 
  -- ***************
  -- SQL Burger 2011
  -- Fun��o SPLIT, separa string dividida por
  -- caracter de controle. Esta fun��o s� pode ser
  -- utilizada e distribu�da caso os cr�ditos ao autor
  -- sejam citados.
  -- ***************
  
  if @caracter is null set @caracter = ','
 
  declare @pos int
  declare @buffer varchar(8000)
  declare @buffer2 varchar(8000)
 
  create table #ret (texto varchar(8000) null, ordem int not null identity(1,1))
 
  while charindex('"', @grupo) > 0
  begin
 
    select @pos = charindex('"', @grupo)
 
    select @buffer = left(@grupo, @pos)
 
    select @grupo = substring(@grupo, @pos + 1, len(@grupo))
 
    select @pos = charindex('"', @grupo)
 
    select @buffer2 = left(@grupo, @pos)
 
    select @grupo = substring(@grupo, @pos + 1, len(@grupo))
 
    select @buffer = replace(@buffer, '"','')
         , @buffer2 = replace(@buffer2, '"', '')
 
    select @buffer2 = replace(@buffer2, @caracter, char(254))
    
    select @buffer2 = replace(@buffer2, ';', char(253))
 
    select @grupo = rtrim(@buffer) + rtrim(@buffer2) + rtrim(@grupo)
 
  end
  
  while charindex(@caracter,@grupo) > 0
  begin
    select @pos = charindex(@caracter,@grupo)
    select @buffer = left(@grupo,@pos - 1)
    select @grupo = right(@grupo,len(rtrim(@grupo)) - @pos)
    
    select @buffer = replace(@buffer, char(254), @caracter)
    select @buffer = replace(@buffer, char(253), ';')
    
    insert into #ret (texto)
      select rtrim(ltrim(@buffer))
  end
 
  if @grupo <> ''
  begin
    select @buffer =replace(@grupo,@caracter,'')
 
    insert into #ret (texto)
      select rtrim(ltrim(@buffer))
  end
 
  select texto from #ret order by ordem
 
	drop table #ret
end