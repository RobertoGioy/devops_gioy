Go

CREATE TRIGGER TRG_Agencias_DELETE_BARLEY ON Agencias FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Agencias A 
INNER JOIN Deleted B ON A.Codban= B.Codban AND A.Codage= B.Codage  
WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Agencias_INSERT_BARLEY ON Agencias FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Agencias(Codemp,Codban,Codage,Desage,Endage,Baiage,Sigest,Codcid,Telage,Gercon,Ativo,Datinc,Seqban)SELECT '210',Codban,Codage,Desage,Endage,Baiage,Sigest,Codcid,Telage,Gercon,Ativo,Datinc,Seqban FROM Inserted GO

Go

CREATE TRIGGER TRG_Agencias_UPDATE_BARLEY ON Agencias FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Agencias A INNER JOIN Deleted B ON A.Codban= B.Codban AND A.Codage= B.Codage  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Agencias(Codemp,Codban,Codage,Desage,Endage,Baiage,Sigest,Codcid,Telage,Gercon,Ativo,Datinc,Seqban)SELECT '210',Codban,Codage,Desage,Endage,Baiage,Sigest,Codcid,Telage,Gercon,Ativo,Datinc,Seqban FROM Inserted GO

Go

CREATE TRIGGER TRG_Agrupamentos_DELETE_BARLEY ON Agrupamentos FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Agrupamentos A INNER JOIN Deleted B ON A.Codagru= B.Codagru 

Go

CREATE TRIGGER TRG_Agrupamentos_INSERT_BARLEY ON Agrupamentos FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Agrupamentos(Codagru,Desagru,Ativo,Datinc)SELECT Codagru,Desagru,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Agrupamentos_UPDATE_BARLEY ON Agrupamentos FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Agrupamentos A INNER JOIN Deleted B ON A.Codagru= B.Codagru INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Agrupamentos(Codagru,Desagru,Ativo,Datinc)SELECT Codagru,Desagru,Ativo,Datinc FROM Inserted 

Go


CREATE TRIGGER TRG_Ajudantes_DELETE_BARLEY ON Ajudantes FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Ajudantes A INNER JOIN Deleted B ON A.CodiGO= B.CodiGO  WHERE A.Codemp = '210'

Go


CREATE TRIGGER TRG_Ajudantes_INSERT_BARLEY ON Ajudantes FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Ajudantes(Codemp,CodiGO,Nomaju,Endereco,Bairro,Sigest,Codcid,Telefone,Cep,Admissao,Cpfaju,Rgaju,Inclusao,Ativo)SELECT '210',CodiGO,Nomaju,Endereco,Bairro,Sigest,Codcid,Telefone,Cep,Admissao,Cpfaju,Rgaju,Inclusao,Ativo FROM Inserted 

Go

CREATE TRIGGER TRG_Ajudantes_UPDATE_BARLEY ON Ajudantes FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Ajudantes A INNER JOIN Deleted B ON A.CodiGO= B.CodiGO  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Ajudantes(Codemp,CodiGO,Nomaju,Endereco,Bairro,Sigest,Codcid,Telefone,Cep,Admissao,Cpfaju,Rgaju,Inclusao,Ativo)SELECT '210',CodiGO,Nomaju,Endereco,Bairro,Sigest,Codcid,Telefone,Cep,Admissao,Cpfaju,Rgaju,Inclusao,Ativo FROM Inserted 

Go

CREATE TRIGGER TRG_Balanco_Geral_DELETE_BARLEY ON Balanco_Geral FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Balanco_Geral A INNER JOIN Deleted B ON A.Indice= B.Indice AND A.Codigo= B.Codigo 

Go

CREATE TRIGGER TRG_Balanco_Geral_INSERT_BARLEY ON Balanco_Geral FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Balanco_Geral(Indice,Codigo,Seq,Nome,Codagru,Oper,Tipo,Nivel,InvVal,Metres,Conta)SELECT Indice,Codigo,Seq,Nome,Codagru,Oper,Tipo,Nivel,InvVal,Metres,Conta FROM Inserted 

Go

CREATE TRIGGER TRG_Balanco_Geral_UPDATE_BARLEY ON Balanco_Geral FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Balanco_Geral A INNER JOIN Deleted B ON A.Indice= B.Indice AND A.Codigo= B.Codigo INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Balanco_Geral(Indice,Codigo,Seq,Nome,Codagru,Oper,Tipo,Nivel,InvVal,Metres,Conta)SELECT Indice,Codigo,Seq,Nome,Codagru,Oper,Tipo,Nivel,InvVal,Metres,Conta FROM Inserted 

Go

CREATE TRIGGER TRG_C_Custo_DELETE_BARLEY ON C_Custo FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.C_Custo A INNER JOIN Deleted B ON A.Codred= B.Codred 

Go

CREATE TRIGGER TRG_C_Custo_INSERT_BARLEY ON C_Custo FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.C_Custo(Codred,Codest,Nomcon,Tipcon,Nivcon,Codagru,Ativo,Datinc,Revenda,Codorc,RedCon,SalAnt,IncPer,BaiPer,SalFin,AcuVal,Rateio)SELECT Codred,Codest,Nomcon,Tipcon,Nivcon,Codagru,Ativo,Datinc,Revenda,Codorc,RedCon,SalAnt,
IncPer,BaiPer,SalFin,AcuVal,Rateio FROM Inserted 

Go

CREATE TRIGGER TRG_C_Custo_UPDATE_BARLEY ON C_Custo FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.C_Custo A INNER JOIN Deleted B ON A.Codred= B.Codred INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.C_Custo(Codred,Codest,Nomcon,Tipcon,Nivcon,Codagru,Ativo,Datinc,Revenda,Codorc,RedCon,SalAnt,IncPer,BaiPer,SalFin,AcuVal,Rateio)SELECT Codred,Codest,Nomcon,Tipcon,Nivcon,Codagru,Ativo,Datinc,Revenda,Codorc,RedCon,SalAnt,IncPer,BaiPer,SalFin,AcuVal,Rateio FROM Inserted 

Go

CREATE TRIGGER TRG_Cadastro_Caixa_DELETE_BARLEY ON Cadastro_Caixa FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Cadastro_Caixa A INNER JOIN Deleted B ON A.CodMod= B.CodMod 

Go

CREATE TRIGGER TRG_Cadastro_Caixa_INSERT_BARLEY ON Cadastro_Caixa FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Cadastro_Caixa(CodMod,Descricao,Tipo,Quadro,Status)SELECT CodMod,Descricao,Tipo,Quadro,Status FROM Inserted 

Go

CREATE TRIGGER TRG_Cadastro_Caixa_UPDATE_BARLEY ON Cadastro_Caixa FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Cadastro_Caixa A INNER JOIN Deleted B ON A.CodMod= B.CodMod INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Cadastro_Caixa(CodMod,Descricao,Tipo,Quadro,Status)SELECT CodMod,Descricao,Tipo,Quadro,Status FROM Inserted 

Go


CREATE TRIGGER TRG_Calendario_DELETE_BARLEY ON Calendario FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Calendario A INNER JOIN Deleted B ON A.MESANO= B.MESANO  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Calendario_INSERT_BARLEY ON Calendario FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Calendario(CODEMP,MESANO,VALORES,DATA)SELECT '210',MESANO,VALORES,DATA FROM Inserted 

Go

CREATE TRIGGER TRG_Calendario_UPDATE_BARLEY ON Calendario FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Calendario A INNER JOIN Deleted B ON A.MESANO= B.MESANO  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Calendario(CODEMP,MESANO,VALORES,DATA)SELECT '210',MESANO,VALORES,DATA FROM Inserted 

Go

CREATE TRIGGER TRG_Canais_DELETE_BARLEY ON Canais FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Canais A INNER JOIN Deleted B ON A.Codgru= B.Codgru AND A.Codcan= B.Codcan  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Canais_INSERT_BARLEY ON Canais FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Canais(Codemp,Codgru,Codcan,Descan,Ativo,Datinc)SELECT '210',Codgru,Codcan,Descan,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Canais_UPDATE_BARLEY ON Canais FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Canais A INNER JOIN Deleted B ON A.Codgru= B.Codgru AND A.Codcan= B.Codcan  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Canais(Codemp,Codgru,Codcan,Descan,Ativo,Datinc)SELECT '210',Codgru,Codcan,Descan,Ativo,Datinc FROM Inserted 

Go


CREATE TRIGGER TRG_CateGOria_DELETE_BARLEY ON CateGOria FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.CateGOria A INNER JOIN Deleted B ON A.Codcat= B.Codcat  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_CateGOria_INSERT_BARLEY ON CateGOria FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.CateGOria(Codemp,Codcat,Descat,Ativo,Datinc,Marca,Seleciona,Codtip,Valoriza,Codpal)SELECT '210',Codcat,Descat,Ativo,Datinc,Marca,Seleciona,Codtip,Valoriza,Codpal FROM Inserted 

Go

CREATE TRIGGER TRG_CateGOria_UPDATE_BARLEY ON CateGOria FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.CateGOria A INNER JOIN Deleted B ON A.Codcat= B.Codcat  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.CateGOria(Codemp,Codcat,Descat,Ativo,Datinc,Marca,Seleciona,Codtip,Valoriza,Codpal)SELECT '210',Codcat,Descat,Ativo,Datinc,Marca,Seleciona,Codtip,Valoriza,Codpal FROM Inserted 

Go

CREATE TRIGGER TRG_Cidades_DELETE_BARLEY ON Cidades FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Cidades A INNER JOIN Deleted B ON A.Sigest= B.Sigest AND A.Codcid= B.Codcid AND A.Codibge= B.Codibge 

Go

CREATE TRIGGER TRG_Cidades_INSERT_BARLEY ON Cidades FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Cidades(Sigest,Codcid,Codibge,Descid,Cepcid,Tipcid,Qtdhab,Ativo,Datinc,Cidfab)SELECT Sigest,Codcid,Codibge,Descid,Cepcid,Tipcid,Qtdhab,Ativo,Datinc,Cidfab FROM Inserted 

Go

CREATE TRIGGER TRG_Cidades_UPDATE_BARLEY ON Cidades FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Cidades A INNER JOIN Deleted B ON A.Sigest= B.Sigest AND A.Codcid= B.Codcid AND A.Codibge= B.Codibge INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Cidades(Sigest,Codcid,Codibge,Descid,Cepcid,Tipcid,Qtdhab,Ativo,Datinc,Cidfab)SELECT Sigest,Codcid,Codibge,Descid,Cepcid,Tipcid,Qtdhab,Ativo,Datinc,Cidfab FROM Inserted 

Go


CREATE TRIGGER [dbo].[TRG_Clientes_DELETE_BARLEY] ON [dbo].[Clientes] FOR DELETE AS 
DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Clientes A 
INNER JOIN Deleted B ON A.Codcli= B.Codcli 
WHERE A.Codemp = '210'


Go

CREATE TRIGGER TRG_Clientes_INSERT_BARLEY ON Clientes FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Clientes(Codemp,Codcli,Nomcli,Endcli,Baicli,Sigest,Codcid,Cepcli,Tippes,CGCcli,Inscli,Foncli,Faxcli,Concli,Fancli,Endpagto,Baipagto,Sigpagto,Cidpagto,Ceppagto,Fonpagto,Timecli,Datnasc,Limcre,LimcreDisp,Numven,Nomconj,Aniconj,Cpfconj,Codpas,Codgcan,Codcan,Codven,CodBan,Nomche1,Cpfche1,Nomche2,Cpfche2,Hobcli,E_Mail,Site,Celular,Temcor,Sexcli,Ativo,Datinc,Exccli,Cercli,Blocli,Tipven,Tescpf,contrib,Sitesp,Codreg,Seqent,NomProp,RGProp,CPFProp,CidProp,SigProp,Liminar,AutoCep,Tipcons,Coordx,Coordy,Cepnum,SubBairro,NumCli,CplCli,Numpagto,Cplpagto,InscricaoMunicipal,CodMunicipioZF,CodSistema,CodIncra,RegistroCacel,Suframa,CodZonaFranca,NumPis,CEPCaixaPostal,CaixaPostal,InscricaoINSS,CodCtb)SELECT '210',Codcli,Nomcli,Endcli,Baicli,Sigest,Codcid,Cepcli,Tippes,CGCcli,Inscli,Foncli,Faxcli,Concli,Fancli,Endpagto,Baipagto,Sigpagto,Cidpagto,Ceppagto,Fonpagto,Timecli,Datnasc,Limcre,LimcreDisp,Numven,Nomconj,Aniconj,Cpfconj,Codpas,Codgcan,Codcan,Codven,CodBan,Nomche1,Cpfche1,Nomche2,Cpfche2,Hobcli,E_Mail,Site,Celular,Temcor,Sexcli,Ativo,Datinc,Exccli,Cercli,Blocli,Tipven,Tescpf,contrib,Sitesp,Codreg,Seqent,NomProp,RGProp,CPFProp,CidProp,SigProp,Liminar,AutoCep,Tipcons,Coordx,Coordy,Cepnum,SubBairro,NumCli,CplCli,Numpagto,Cplpagto,InscricaoMunicipal,CodMunicipioZF,CodSistema,CodIncra,RegistroCacel,Suframa,CodZonaFranca,NumPis,CEPCaixaPostal,CaixaPostal,InscricaoINSS,CodCtb FROM Inserted 

Go


CREATE TRIGGER [dbo].[TRG_Clientes_UPDATE_BARLEY] ON [dbo].[Clientes] FOR UPDATE AS 
DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Clientes A 
INNER JOIN Deleted B ON A.Codcli= B.Codcli  
WHERE A.Codemp = '210'
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Clientes(Codemp,Codcli,Nomcli,Endcli,Baicli,Sigest,Codcid,Cepcli,Tippes,CGCcli,Inscli,Foncli,Faxcli,Concli,Fancli,Endpagto,Baipagto,Sigpagto,Cidpagto,Ceppagto,Fonpagto,Timecli,Datnasc,Limcre,LimcreDisp,Numven,Nomconj,Aniconj,Cpfconj,Codpas,Codgcan,Codcan,Codven,CodBan,Nomche1,Cpfche1,Nomche2,Cpfche2,Hobcli,E_Mail,Site,Celular,Temcor,Sexcli,Ativo,Datinc,Exccli,Cercli,Blocli,Tipven,Tescpf,contrib,Sitesp,Codreg,Seqent,NomProp,RGProp,CPFProp,CidProp,SigProp,Liminar,AutoCep,Tipcons,Coordx,Coordy,Cepnum,SubBairro,NumCli,CplCli,Numpagto,Cplpagto,InscricaoMunicipal,CodMunicipioZF,CodSistema,CodIncra,RegistroCacel,Suframa,CodZonaFranca,NumPis,CEPCaixaPostal,CaixaPostal,InscricaoINSS,CodCtb)
SELECT '210',Codcli,Nomcli,Endcli,Baicli,Sigest,Codcid,Cepcli,Tippes,CGCcli,Inscli,Foncli,Faxcli,Concli,Fancli,Endpagto,Baipagto,Sigpagto,Cidpagto,Ceppagto,Fonpagto,Timecli,Datnasc,Limcre,LimcreDisp,Numven,Nomconj,Aniconj,Cpfconj,Codpas,Codgcan,Codcan,Codven,CodBan,Nomche1,Cpfche1,Nomche2,Cpfche2,Hobcli,E_Mail,Site,Celular,Temcor,Sexcli,Ativo,Datinc,Exccli,Cercli,Blocli,Tipven,Tescpf,contrib,Sitesp,Codreg,Seqent,NomProp,RGProp,CPFProp,CidProp,SigProp,Liminar,AutoCep,Tipcons,Coordx,Coordy,Cepnum,SubBairro,NumCli,CplCli,Numpagto,Cplpagto,InscricaoMunicipal,CodMunicipioZF,CodSistema,CodIncra,RegistroCacel,Suframa,CodZonaFranca,NumPis,CEPCaixaPostal,CaixaPostal,InscricaoINSS,CodCtb 
FROM Inserted 


Go

CREATE TRIGGER [dbo].[TRG_ClixPosto_DELETE_BARLEY] ON [dbo].[ClixPosto] FOR DELETE AS 
DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.ClixPosto A 
INNER JOIN Deleted B ON A.Codcli= B.Codcli 
WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_ClixPosto_INSERT_BARLEY ON ClixPosto FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.ClixPosto(Codemp,Codcli,CodBandeira,CodLjConveniencia)SELECT '210',Codcli,CodBandeira,CodLjConveniencia FROM Inserted 

Go


CREATE TRIGGER [dbo].[TRG_ClixPosto_UPDATE_BARLEY] ON [dbo].[ClixPosto] FOR UPDATE AS 

DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.ClixPosto A 
INNER JOIN Deleted B ON A.Codcli= B.Codcli  
WHERE A.Codemp = '210'

INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.ClixPosto(Codemp,Codcli,CodBandeira,CodLjConveniencia)
SELECT '210',Codcli,CodBandeira,CodLjConveniencia 
FROM Inserted 


Go

CREATE TRIGGER TRG_clixvend_DELETE_BARLEY ON clixvend FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.clixvend A INNER JOIN Deleted B ON A.Codcli= B.Codcli AND A.Codven= B.Codven  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_clixvend_INSERT_BARLEY ON clixvend FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.clixvend(Codemp,Codcli,Codven)SELECT '210',Codcli,Codven FROM Inserted 

Go

CREATE TRIGGER TRG_clixvend_UPDATE_BARLEY ON clixvend FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.clixvend A INNER JOIN Deleted B ON A.Codcli= B.Codcli AND A.Codven= B.Codven  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.clixvend(Codemp,Codcli,Codven)SELECT '210',Codcli,Codven FROM Inserted 

Go

CREATE TRIGGER TRG_Cod_Tributario_DELETE_BARLEY ON Cod_Tributario FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Cod_Tributario A INNER JOIN Deleted B ON A.Codtri= B.Codtri 

Go

CREATE TRIGGER TRG_Cod_Tributario_INSERT_BARLEY ON Cod_Tributario FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Cod_Tributario(Codtri,Destri,Icms,Substit,Datinc,Ativo)SELECT Codtri,Destri,Icms,Substit,Datinc,Ativo FROM Inserted 

Go

CREATE TRIGGER TRG_Cod_Tributario_UPDATE_BARLEY ON Cod_Tributario FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Cod_Tributario A INNER JOIN Deleted B ON A.Codtri= B.Codtri INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Cod_Tributario(Codtri,Destri,Icms,Substit,Datinc,Ativo)SELECT Codtri,Destri,Icms,Substit,Datinc,Ativo FROM Inserted 

Go

CREATE TRIGGER TRG_Comissao_DELETE_BARLEY ON Comissao FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Comissao A 
INNER JOIN Deleted B ON A.Codgrupo= B.Codgrupo AND A.Codtab= B.Codtab AND A.Codpag= B.Codpag AND A.Codpro= B.Codpro  
WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Comissao_INSERT_BARLEY ON Comissao FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Comissao(Codemp,Codgrupo,Codtab,Codpag,Codpro,Comissao,Datinc)SELECT '210',Codgrupo,Codtab,Codpag,Codpro,Comissao,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Comissao_UPDATE_BARLEY ON Comissao FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Comissao A 
INNER JOIN Deleted B ON A.Codgrupo= B.Codgrupo AND A.Codtab= B.Codtab AND A.Codpag= B.Codpag AND A.Codpro= B.Codpro  WHERE A.Codemp = '210' INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Comissao(Codemp,Codgrupo,Codtab,Codpag,Codpro,Comissao,Datinc)SELECT '210',Codgrupo,Codtab,Codpag,Codpro,Comissao,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Cotacoes_DELETE_BARLEY ON Cotacoes FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Cotacoes A INNER JOIN Deleted B ON A.Codidx= B.Codidx AND A.Datcot= B.Datcot 

Go

CREATE TRIGGER TRG_Efetuar_DELETE_BARLEY ON Efetuar FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Efetuar A INNER JOIN Deleted B ON A.CodiGO= B.CodiGO AND A.Cod= B.Cod  WHERE A.Codemp = '210'

Go


CREATE TRIGGER TRG_Efetuar_INSERT_BARLEY ON Efetuar FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Efetuar(Codemp,CodiGO,Cod,Nome,Codorc,Tabela,Tipo)SELECT '210',CodiGO,Cod,Nome,Codorc,Tabela,Tipo FROM Inserted GO

Go


CREATE TRIGGER TRG_Efetuar_UPDATE_BARLEY ON Efetuar FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Efetuar A INNER JOIN Deleted B ON A.CodiGO= B.CodiGO AND A.Cod= B.Cod  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Efetuar(Codemp,CodiGO,Cod,Nome,Codorc,Tabela,Tipo)SELECT '210',CodiGO,Cod,Nome,Codorc,Tabela,Tipo FROM Inserted 

Go


CREATE TRIGGER [dbo].[TRG_Embalagens_DELETE_BARLEY] ON [dbo].[Embalagens] FOR DELETE AS 
DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Embalagens A 
INNER JOIN Deleted B ON A.CodEmb= B.CodEmb   
WHERE A.Codemp = '210'


Go

CREATE TRIGGER TRG_Embalagens_INSERT_BARLEY ON Embalagens FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Embalagens(CodEmp,CodEmb,Desemb,Nompal,Codcat,Codtip,Valque,qtdcxa,Valcus,Pesliq,Ativo,DatInc,Qtdtra,Qtdfat,Qtdemb,Qtdcom,Qtdpro,Desc99,Mod3,Clafis,SQtdtra,SQtdfat,SQtdemb,SQtdcom,SQtdpro,Codaux,PrazoCom,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN)
SELECT '210',CodEmb,Desemb,Nompal,Codcat,Codtip,Valque,qtdcxa,Valcus,Pesliq,Ativo,DatInc,Qtdtra,Qtdfat,Qtdemb,Qtdcom,Qtdpro,Desc99,Mod3,Clafis,SQtdtra,SQtdfat,SQtdemb,SQtdcom,SQtdpro,Codaux,PrazoCom,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN FROM Inserted 

Go


CREATE TRIGGER [dbo].[TRG_Embalagens_UPDATE_BARLEY] ON [dbo].[Embalagens] FOR UPDATE AS 
DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Embalagens A 
INNER JOIN Deleted B ON A.CodEmb= B.CodEmb AND A.CodEmb= B.CodEmb   
WHERE A.Codemp = '210'
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Embalagens(CodEmp,CodEmb,Desemb,Nompal,Codcat,Codtip,Valque,qtdcxa,Valcus,Pesliq,Ativo,DatInc,Qtdtra,Qtdfat,Qtdemb,Qtdcom,Qtdpro,Desc99,Mod3,Clafis,SQtdtra,SQtdfat,SQtdemb,SQtdcom,SQtdpro,Codaux,PrazoCom,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN)
SELECT '210',CodEmb,Desemb,Nompal,Codcat,Codtip,Valque,qtdcxa,Valcus,Pesliq,Ativo,DatInc,Qtdtra,Qtdfat,Qtdemb,Qtdcom,Qtdpro,Desc99,Mod3,Clafis,SQtdtra,SQtdfat,SQtdemb,SQtdcom,SQtdpro,Codaux,PrazoCom,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN 
FROM Inserted 


Go

CREATE TRIGGER TRG_Equipe_Venda_DELETE_BARLEY ON Equipe_Venda FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Equipe_Venda A INNER JOIN Deleted B ON A.CodEqui= B.CodEqui  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Equipe_Venda_INSERT_BARLEY ON Equipe_Venda FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Equipe_Venda(Codemp,CodEqui,Descricao,Data)SELECT '210',CodEqui,Descricao,Data FROM Inserted 

Go

CREATE TRIGGER TRG_Equipe_Venda_UPDATE_BARLEY ON Equipe_Venda FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Equipe_Venda A INNER JOIN Deleted B ON A.CodEqui= B.CodEqui  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Equipe_Venda(Codemp,CodEqui,Descricao,Data)SELECT '210',CodEqui,Descricao,Data FROM Inserted 

Go

CREATE TRIGGER TRG_Estados_DELETE_BARLEY ON Estados FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Estados A INNER JOIN Deleted B ON A.Sigest= B.Sigest 

Go

CREATE TRIGGER TRG_Estados_INSERT_BARLEY ON Estados FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Estados(Sigest,Nomest,Ativo,Datinc)SELECT Sigest,Nomest,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Estados_UPDATE_BARLEY ON Estados FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Estados A INNER JOIN Deleted B ON A.Sigest= B.Sigest INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Estados(Sigest,Nomest,Ativo,Datinc)SELECT Sigest,Nomest,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Form_PagtoClientes_DELETE_BARLEY ON Form_PagtoClientes FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Form_PagtoClientes A INNER JOIN Deleted B ON A.Codcli= B.Codcli AND A.Codpag= B.Codpag  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Form_PagtoClientes_INSERT_BARLEY ON Form_PagtoClientes FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Form_PagtoClientes(Codemp,Codcli,Codpag)SELECT '210',Codcli,Codpag FROM Inserted 

Go

CREATE TRIGGER TRG_Form_PagtoClientes_UPDATE_BARLEY ON Form_PagtoClientes FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Form_PagtoClientes A INNER JOIN Deleted B ON A.Codcli= B.Codcli AND A.Codpag= B.Codpag  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Form_PagtoClientes(Codemp,Codcli,Codpag)SELECT '210',Codcli,Codpag FROM Inserted 

Go

CREATE TRIGGER TRG_Forma_Pagto_DELETE_BARLEY ON Forma_Pagto FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Forma_Pagto A INNER JOIN Deleted B ON A.Codpag= B.Codpag  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Forma_Pagto_INSERT_BARLEY ON Forma_Pagto FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Forma_Pagto(Codemp,Codpag,Despag,Codpal,Prazo,Viacob,Tipvia,Ativo,Datinc,SN_Palmtop)SELECT '210',Codpag,Despag,Codpal,Prazo,Viacob,Tipvia,Ativo,Datinc,SN_Palmtop FROM Inserted 

Go

CREATE TRIGGER TRG_Forma_Pagto_UPDATE_BARLEY ON Forma_Pagto FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Forma_Pagto A INNER JOIN Deleted B ON A.Codpag= B.Codpag  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Forma_Pagto(Codemp,Codpag,Despag,Codpal,Prazo,Viacob,Tipvia,Ativo,Datinc,SN_Palmtop)SELECT '210',Codpag,Despag,Codpal,Prazo,Viacob,Tipvia,Ativo,Datinc,SN_Palmtop FROM Inserted 

Go

CREATE TRIGGER TRG_Fornecedores_DELETE_BARLEY ON Fornecedores FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Fornecedores A 
INNER JOIN Deleted B ON A.CodFor= B.CodFor AND A.CodFor= B.CodFor AND A.CodFor= B.CodFor AND A.SigEst= B.SigEst AND A.SigEst= B.SigEst  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Fornecedores_INSERT_BARLEY ON Fornecedores FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Fornecedores(CodEmp,CodFor,RazFor,NomFan,EndFor,BaiFor,SigEst,Codcid,CepFor,TelFor,FaxFor,Tippes,CGCFor,InsFor,Contato,E_mail,Site,DatInc,Ativo,Tescpf,impctb,NumFor,CplFor,CodCtb,InscricaoMunicipal,CodMunicipioZF,CodSistema,CodIncra,RegistroCacel,Suframa,CodZonaFranca,NumPis,CEPCaixaPostal,CaixaPostal,InscricaoINSS)SELECT '210',CodFor,RazFor,NomFan,EndFor,BaiFor,SigEst,Codcid,CepFor,TelFor,FaxFor,Tippes,CGCFor,InsFor,Contato,E_mail,Site,DatInc,Ativo,Tescpf,impctb,NumFor,CplFor,CodCtb,InscricaoMunicipal,CodMunicipioZF,CodSistema,CodIncra,RegistroCacel,Suframa,CodZonaFranca,NumPis,CEPCaixaPostal,CaixaPostal,InscricaoINSS FROM Inserted 

Go

CREATE TRIGGER TRG_Fornecedores_UPDATE_BARLEY ON Fornecedores FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Fornecedores A INNER JOIN Deleted B ON A.CodFor= B.CodFor WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Fornecedores(CodEmp,CodFor,RazFor,NomFan,EndFor,BaiFor,SigEst,Codcid,CepFor,TelFor,FaxFor,Tippes,CGCFor,InsFor,Contato,E_mail,Site,DatInc,Ativo,Tescpf,impctb,NumFor,CplFor,CodCtb,InscricaoMunicipal,CodMunicipioZF,CodSistema,CodIncra,RegistroCacel,Suframa,CodZonaFranca,NumPis,CEPCaixaPostal,CaixaPostal,InscricaoINSS)SELECT '210',CodFor,RazFor,NomFan,EndFor,BaiFor,SigEst,Codcid,CepFor,TelFor,FaxFor,Tippes,CGCFor,InsFor,Contato,E_mail,Site,DatInc,Ativo,Tescpf,impctb,NumFor,CplFor,CodCtb,InscricaoMunicipal,CodMunicipioZF,CodSistema,CodIncra,RegistroCacel,Suframa,CodZonaFranca,NumPis,CEPCaixaPostal,CaixaPostal,InscricaoINSS FROM Inserted 


Go

CREATE TRIGGER TRG_Grupo_canais_DELETE_BARLEY ON Grupo_canais FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Grupo_canais A INNER JOIN Deleted B ON A.Codgru= B.Codgru  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Grupo_canais_INSERT_BARLEY ON Grupo_canais FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Grupo_canais(Codemp,Codgru,Desgru,Ativo,Datinc)SELECT '210',Codgru,Desgru,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Grupo_canais_UPDATE_BARLEY ON Grupo_canais FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Grupo_canais A INNER JOIN Deleted B ON A.Codgru= B.Codgru  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Grupo_canais(Codemp,Codgru,Desgru,Ativo,Datinc)SELECT '210',Codgru,Desgru,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Grupo_Comissao_DELETE_BARLEY ON Grupo_Comissao FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Grupo_Comissao A INNER JOIN Deleted B ON A.Codgrupo= B.Codgrupo  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Grupo_Comissao_INSERT_BARLEY ON Grupo_Comissao FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Grupo_Comissao(Codemp,Codgrupo,Descricao)SELECT '210',Codgrupo,Descricao FROM Inserted 

Go

CREATE TRIGGER TRG_Grupo_Comissao_UPDATE_BARLEY ON Grupo_Comissao FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Grupo_Comissao A INNER JOIN Deleted B ON A.Codgrupo= B.Codgrupo  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Grupo_Comissao(Codemp,Codgrupo,Descricao)SELECT '210',Codgrupo,Descricao FROM Inserted 

Go

CREATE TRIGGER TRG_H_Padrao_DELETE_BARLEY ON H_Padrao FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.H_Padrao A INNER JOIN Deleted B ON A.Codhis= B.Codhis 

Go

CREATE TRIGGER TRG_H_Padrao_INSERT_BARLEY ON H_Padrao FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.H_Padrao(Codhis,Deshis,Tipmov,Codcaixa,Ativo,Datinc,Contabil)SELECT Codhis,Deshis,Tipmov,Codcaixa,Ativo,Datinc,Contabil FROM Inserted 

Go

CREATE TRIGGER TRG_H_Padrao_UPDATE_BARLEY ON H_Padrao FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.H_Padrao A INNER JOIN Deleted B ON A.Codhis= B.Codhis INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.H_Padrao(Codhis,Deshis,Tipmov,Codcaixa,Ativo,Datinc,Contabil)SELECT Codhis,Deshis,Tipmov,Codcaixa,Ativo,Datinc,Contabil FROM Inserted 

Go

CREATE TRIGGER TRG_HisCaixa_DELETE_BARLEY ON HisCaixa FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.HisCaixa A INNER JOIN Deleted B ON A.Codhiscxa= B.Codhiscxa 

Go

CREATE TRIGGER TRG_HisCaixa_INSERT_BARLEY ON HisCaixa FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.HisCaixa(Codhiscxa,Deshiscxa)SELECT Codhiscxa,Deshiscxa FROM Inserted 

Go

CREATE TRIGGER TRG_HisCaixa_UPDATE_BARLEY ON HisCaixa FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.HisCaixa A INNER JOIN Deleted B ON A.Codhiscxa= B.Codhiscxa INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.HisCaixa(Codhiscxa,Deshiscxa)SELECT Codhiscxa,Deshiscxa 
FROM Inserted 

Go

CREATE TRIGGER TRG_HPadrao_CP_DELETE_BARLEY ON HPadrao_CP FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.HPadrao_CP A INNER JOIN Deleted B ON A.Codhis= B.Codhis 

Go

CREATE TRIGGER TRG_HPadrao_CP_INSERT_BARLEY ON HPadrao_CP FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.HPadrao_CP(Codhis,Deshis,Datinc,Ativo)SELECT Codhis,Deshis,Datinc,Ativo FROM Inserted 

Go

CREATE TRIGGER TRG_HPadrao_CP_UPDATE_BARLEY ON HPadrao_CP FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.HPadrao_CP A INNER JOIN Deleted B ON A.Codhis= B.Codhis INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.HPadrao_CP(Codhis,Deshis,Datinc,Ativo)SELECT Codhis,Deshis,Datinc,Ativo FROM Inserted 

Go

CREATE TRIGGER TRG_Investimentos_DELETE_BARLEY ON Investimentos FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Investimentos A INNER JOIN Deleted B ON A.CodInv= B.CodInv  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Itens_Mod_Balanco_DELETE_BARLEY ON Itens_Mod_Balanco FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Itens_Mod_Balanco A INNER JOIN Deleted B ON A.Balanco= B.Balanco AND A.Seq= B.Seq AND A.Seq1= B.Seq1 

Go

CREATE TRIGGER TRG_Itens_Mod_Balanco_INSERT_BARLEY ON Itens_Mod_Balanco FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Itens_Mod_Balanco(Balanco,Seq,Seq1,Tabela,Campo,Conta,Campo_Cal,Expr,Sinal,MesAnt,Acum,Ind)SELECT Balanco,Seq,Seq1,Tabela,Campo,Conta,Campo_Cal,Expr,Sinal,MesAnt,Acum,Ind FROM Inserted 

Go

CREATE TRIGGER TRG_Itens_Mod_Balanco_UPDATE_BARLEY ON Itens_Mod_Balanco FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Itens_Mod_Balanco A INNER JOIN Deleted B ON A.Balanco= B.Balanco AND A.Seq= B.Seq AND A.Seq1= B.Seq1 INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Itens_Mod_Balanco(Balanco,Seq,Seq1,Tabela,Campo,Conta,Campo_Cal,Expr,Sinal,MesAnt,Acum,Ind)SELECT Balanco,Seq,Seq1,Tabela,Campo,Conta,Campo_Cal,Expr,Sinal,MesAnt,Acum,Ind FROM Inserted 

Go

CREATE TRIGGER TRG_Itens_Mod_Nota_DELETE_BARLEY ON Itens_Mod_Nota FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Itens_Mod_Nota A INNER JOIN Deleted B ON A.Modelo= B.Modelo AND A.Seq= B.Seq 

Go

CREATE TRIGGER TRG_Itens_Mod_Nota_INSERT_BARLEY ON Itens_Mod_Nota FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Itens_Mod_Nota(Modelo,Seq,Descricao,Tamanho,Linha,Coluna,Imprime,Tabela,Campo,Campo_Itens,Condensado,Condicao)SELECT Modelo,Seq,Descricao,Tamanho,Linha,Coluna,Imprime,Tabela,Campo,Campo_Itens,Condensado,Condicao 
FROM Inserted 

Go

CREATE TRIGGER TRG_Itens_Mod_Nota_UPDATE_BARLEY ON Itens_Mod_Nota FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Itens_Mod_Nota A INNER JOIN Deleted B ON A.Modelo= B.Modelo AND A.Seq= B.Seq INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Itens_Mod_Nota(Modelo,Seq,Descricao,Tamanho,Linha,Coluna,Imprime,Tabela,Campo,Campo_Itens,Condensado,Condicao)SELECT Modelo,Seq,Descricao,Tamanho,Linha,Coluna,Imprime,Tabela,Campo,Campo_Itens,Condensado,Condicao FROM Inserted 

Go

CREATE TRIGGER TRG_Itens_Tabela_DELETE_BARLEY ON Itens_Tabela FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Itens_Tabela A 
INNER JOIN Deleted B ON A.Codtab= B.Codtab AND A.Reg= B.Reg AND A.Codpro= B.Codpro AND A.Tippro= B.Tippro  
WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Itens_Tabela_INSERT_BARLEY ON Itens_Tabela FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Itens_Tabela(Codemp,Codtab,Reg,Codpro,Tippro,Valpro,Perdes,Ativo,CodCat,Datinc,descricao,ValProDes,ValProAcr)SELECT '210',Codtab,Reg,Codpro,Tippro,Valpro,Perdes,Ativo,CodCat,Datinc,descricao,ValProDes,ValProAcr FROM Inserted 

Go

CREATE TRIGGER TRG_Itens_Tabela_UPDATE_BARLEY ON Itens_Tabela FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Itens_Tabela A INNER JOIN Deleted B ON A.Codtab= B.Codtab AND A.Reg= B.Reg AND A.Codpro= B.Codpro AND A.Tippro= B.Tippro  
WHERE A.Codemp = '210' INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Itens_Tabela(Codemp,Codtab,Reg,Codpro,Tippro,Valpro,Perdes,Ativo,CodCat,Datinc,descricao,ValProDes,ValProAcr)
SELECT '210',Codtab,Reg,Codpro,Tippro,Valpro,Perdes,Ativo,CodCat,Datinc,descricao,ValProDes,ValProAcr FROM Inserted 

Go

CREATE TRIGGER TRG_Logins_DELETE_BARLEY ON Logins FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Logins A INNER JOIN Deleted B ON A.login= B.login 

Go

CREATE TRIGGER TRG_Logins_INSERT_BARLEY ON Logins FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Logins(login,Status,Usuario,Fecha,Senha,NomeLog,FuncaoLog)SELECT login,Status,Usuario,Fecha,Senha,NomeLog,FuncaoLog FROM Inserted 

Go

CREATE TRIGGER TRG_Logins_UPDATE_BARLEY ON Logins FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Logins A INNER JOIN Deleted B ON A.login= B.login INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Logins(login,Status,Usuario,Fecha,Senha,NomeLog,FuncaoLog)SELECT login,Status,Usuario,Fecha,Senha,NomeLog,FuncaoLog FROM Inserted 

Go

CREATE TRIGGER TRG_Marcas_DELETE_BARLEY ON Marcas FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Marcas A INNER JOIN Deleted B ON A.Codmar= B.Codmar  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Marcas_INSERT_BARLEY ON Marcas FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Marcas(Codemp,Codmar,Desmar,Ativo,Datinc,CodPal)SELECT '210',Codmar,Desmar,Ativo,Datinc,CodPal FROM Inserted 

Go

CREATE TRIGGER TRG_Marcas_UPDATE_BARLEY ON Marcas FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Marcas A INNER JOIN Deleted B ON A.Codmar= B.Codmar  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Marcas(Codemp,Codmar,Desmar,Ativo,Datinc,CodPal)SELECT '210',Codmar,Desmar,Ativo,Datinc,CodPal FROM Inserted 

Go

CREATE TRIGGER TRG_Mensagem_DELETE_BARLEY ON Mensagem FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Mensagem A INNER JOIN Deleted B ON A.Codmen= B.Codmen 

Go

CREATE TRIGGER TRG_Mensagem_INSERT_BARLEY ON Mensagem FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Mensagem(Codmen,Mens1,Mens2)SELECT Codmen,Mens1,Mens2 FROM Inserted 

Go

CREATE TRIGGER TRG_Mensagem_UPDATE_BARLEY ON Mensagem FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Mensagem A INNER JOIN Deleted B ON A.Codmen= B.Codmen INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Mensagem(Codmen,Mens1,Mens2)SELECT Codmen,Mens1,Mens2 FROM Inserted 

Go

CREATE TRIGGER TRG_Mod_Balanco_DELETE_BARLEY ON Mod_Balanco FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Mod_Balanco A INNER JOIN Deleted B ON A.Balanco= B.Balanco AND A.Seq= B.Seq 

Go

CREATE TRIGGER TRG_Mod_Balanco_INSERT_BARLEY ON Mod_Balanco FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Mod_Balanco(Balanco,Seq,Descricao,Negrito,Identado,Queb_Pag,Perc,Cabec,Total,Dif,TipTT,MetRel,Stot,TTMeta,Fluxo,Formato,Tipo)SELECT Balanco,Seq,Descricao,Negrito,Identado,Queb_Pag,Perc,Cabec,Total,Dif,TipTT,MetRel,Stot,TTMeta,Fluxo,Formato,Tipo FROM Inserted 

Go

CREATE TRIGGER TRG_Mod_Balanco_UPDATE_BARLEY ON Mod_Balanco FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Mod_Balanco A INNER JOIN Deleted B ON A.Balanco= B.Balanco AND A.Seq= B.Seq INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Mod_Balanco(Balanco,Seq,Descricao,Negrito,Identado,Queb_Pag,Perc,Cabec,Total,Dif,TipTT,MetRel,Stot,TTMeta,Fluxo,Formato,Tipo)SELECT Balanco,Seq,Descricao,Negrito,Identado,Queb_Pag,Perc,Cabec,Total,Dif,TipTT,MetRel,Stot,TTMeta,Fluxo,Formato,Tipo FROM Inserted 

Go

CREATE TRIGGER TRG_Mod_Nota_DELETE_BARLEY ON Mod_Nota FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Mod_Nota A INNER JOIN Deleted B ON A.Modelo= B.Modelo 

Go

CREATE TRIGGER TRG_Mod_Nota_INSERT_BARLEY ON Mod_Nota FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Mod_Nota(Modelo,Descricao,Largura,Altura,Qtditens,Qtdsalto,Imagem,Qtde,Imp18,Tipo)SELECT Modelo,Descricao,Largura,Altura,Qtditens,Qtdsalto,Imagem,Qtde,Imp18,Tipo FROM Inserted 

Go

CREATE TRIGGER TRG_Mod_Nota_UPDATE_BARLEY ON Mod_Nota FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Mod_Nota A INNER JOIN Deleted B ON A.Modelo= B.Modelo INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Mod_Nota(Modelo,Descricao,Largura,Altura,Qtditens,Qtdsalto,Imagem,Qtde,Imp18,Tipo)SELECT Modelo,Descricao,Largura,Altura,Qtditens,Qtdsalto,Imagem,Qtde,Imp18,Tipo FROM Inserted 

Go

CREATE TRIGGER TRG_Modulos_DELETE_BARLEY ON Modulos FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Modulos A INNER JOIN Deleted B ON A.Modulo= B.Modulo 

Go

CREATE TRIGGER TRG_Modulos_INSERT_BARLEY ON Modulos FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Modulos(Modulo,item)SELECT Modulo,item FROM Inserted 

Go

CREATE TRIGGER TRG_Modulos_UPDATE_BARLEY ON Modulos FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Modulos A INNER JOIN Deleted B ON A.Modulo= B.Modulo INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Modulos(Modulo,item)SELECT Modulo,item FROM Inserted 

Go

CREATE TRIGGER TRG_Mot_saida_DELETE_BARLEY ON Mot_saida FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Mot_saida A INNER JOIN Deleted B ON A.Codsai= B.Codsai  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Mot_saida_INSERT_BARLEY ON Mot_saida FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Mot_saida(Codemp,Codsai,Dessai,Ativo,Datinc)SELECT '210',Codsai,Dessai,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Mot_saida_UPDATE_BARLEY ON Mot_saida FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Mot_saida A INNER JOIN Deleted B ON A.Codsai= B.Codsai  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Mot_saida(Codemp,Codsai,Dessai,Ativo,Datinc)SELECT '210',Codsai,Dessai,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Motivos_DELETE_BARLEY ON Motivos FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Motivos A INNER JOIN Deleted B ON A.Motdev= B.Motdev 

Go

CREATE TRIGGER TRG_Motivos_INSERT_BARLEY ON Motivos FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Motivos(Motdev,Desdev,Ativo,Datinc,MotFabr)SELECT Motdev,Desdev,Ativo,Datinc,MotFabr FROM Inserted 

Go

CREATE TRIGGER TRG_Motivos_UPDATE_BARLEY ON Motivos FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Motivos A INNER JOIN Deleted B ON A.Motdev= B.Motdev INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Motivos(Motdev,Desdev,Ativo,Datinc,MotFabr)SELECT Motdev,Desdev,Ativo,Datinc,MotFabr FROM Inserted 

Go

CREATE TRIGGER TRG_Motorista_DELETE_BARLEY ON Motorista FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Motorista A INNER JOIN Deleted B ON A.Codmot= B.Codmot  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Motorista_INSERT_BARLEY ON Motorista FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Motorista(Codemp,Codmot,Nommot,Endmot,Baimot,Sigest,Codcid,Telmot,Cpfmot,Rgmot,CnhMot,CnhCat,Vencnh,Ativo,Datinc)SELECT '210',Codmot,Nommot,Endmot,Baimot,Sigest,Codcid,Telmot,Cpfmot,Rgmot,CnhMot,CnhCat,Vencnh,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Motorista_UPDATE_BARLEY ON Motorista FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Motorista A INNER JOIN Deleted B ON A.Codmot= B.Codmot  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Motorista(Codemp,Codmot,Nommot,Endmot,Baimot,Sigest,Codcid,Telmot,Cpfmot,Rgmot,CnhMot,CnhCat,Vencnh,Ativo,Datinc)SELECT '210',Codmot,Nommot,Endmot,Baimot,Sigest,Codcid,Telmot,Cpfmot,Rgmot,CnhMot,CnhCat,Vencnh,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Nat_Oper_DELETE_BARLEY ON Nat_Oper FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Nat_Oper A INNER JOIN Deleted B ON A.Codnat= B.Codnat AND A.Codnat= B.Codnat AND A.Extcod= B.Extcod AND A.Desnat= B.Desnat 

Go

CREATE TRIGGER TRG_Nat_Oper_INSERT_BARLEY ON Nat_Oper FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Nat_Oper(Codnat,Extcod,Descricao,Desnat,Ativo,Datinc)SELECT Codnat,Extcod,Descricao,Desnat,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Nat_Oper_UPDATE_BARLEY ON Nat_Oper FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Nat_Oper A INNER JOIN Deleted B ON A.Codnat= B.Codnat AND A.Codnat= B.Codnat AND A.Extcod= B.Extcod AND A.Desnat= B.Desnat INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Nat_Oper(Codnat,Extcod,Descricao,Desnat,Ativo,Datinc)SELECT Codnat,Extcod,Descricao,Desnat,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Nivel_DELETE_BARLEY ON Nivel FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Nivel A INNER JOIN Deleted B ON A.CodNiv= B.CodNiv  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Nivel_INSERT_BARLEY ON Nivel FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Nivel(Codemp,CodNiv,DesNiv,Ativo,DatInc)SELECT '210',CodNiv,DesNiv,Ativo,DatInc FROM Inserted 

Go

CREATE TRIGGER TRG_Nivel_UPDATE_BARLEY ON Nivel FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Nivel A INNER JOIN Deleted B ON A.CodNiv= B.CodNiv  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Nivel(Codemp,CodNiv,DesNiv,Ativo,DatInc)SELECT '210',CodNiv,DesNiv,Ativo,DatInc FROM Inserted 

Go

CREATE TRIGGER TRG_Orcamentos_DELETE_BARLEY ON Orcamentos FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Orcamentos A INNER JOIN Deleted B ON A.Codorc= B.Codorc 

Go

CREATE TRIGGER TRG_Orcamentos_INSERT_BARLEY ON Orcamentos FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Orcamentos(Codorc,Desorc,Valqui,Valpag,Tiporc,Datinc,Ativo)SELECT Codorc,Desorc,Valqui,Valpag,Tiporc,Datinc,Ativo FROM Inserted 

Go

CREATE TRIGGER TRG_Orcamentos_UPDATE_BARLEY ON Orcamentos FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Orcamentos A INNER JOIN Deleted B ON A.Codorc= B.Codorc INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Orcamentos(Codorc,Desorc,Valqui,Valpag,Tiporc,Datinc,Ativo)SELECT Codorc,Desorc,Valqui,Valpag,Tiporc,Datinc,Ativo FROM Inserted 

Go

CREATE TRIGGER TRG_Pastas_DELETE_BARLEY ON Pastas FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Pastas A INNER JOIN Deleted B ON A.Codpas= B.Codpas  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Pastas_INSERT_BARLEY ON Pastas FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Pastas(Codemp,Codpas,Despas,Codven,Visseg,Vister,Visqua,Visqui,Vissex,Vissab,Kmsrot,Temrot,Ativo,Datinc,Marcar,Libera,ValFre)SELECT '210',Codpas,Despas,Codven,Visseg,Vister,Visqua,Visqui,Vissex,Vissab,Kmsrot,Temrot,Ativo,Datinc,Marcar,Libera,ValFre FROM Inserted 

Go

CREATE TRIGGER TRG_Pastas_UPDATE_BARLEY ON Pastas FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Pastas A INNER JOIN Deleted B ON A.Codpas= B.Codpas  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Pastas(Codemp,Codpas,Despas,Codven,Visseg,Vister,Visqua,Visqui,Vissex,Vissab,Kmsrot,Temrot,Ativo,Datinc,Marcar,Libera,ValFre)SELECT '210',Codpas,Despas,Codven,Visseg,Vister,Visqua,Visqui,Vissex,Vissab,Kmsrot,Temrot,Ativo,Datinc,Marcar,Libera,ValFre FROM Inserted 

Go


CREATE TRIGGER [dbo].[TRG_Produtos_DELETE_BARLEY] ON [dbo].[Produtos] FOR DELETE AS 
DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Produtos A 
INNER JOIN Deleted B ON A.Codpro= B.Codpro  
WHERE A.Codemp = '210'


Go

CREATE TRIGGER TRG_Produtos_INSERT_BARLEY ON Produtos FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Produtos(Codemp,Codpro,Despro,UndCom,Volcom,Undven,Volven,Codcat,Codtip,Tipbeb,CodMar,Codsab,Litros,NomPal,Numnot,Valcus,Codvas,Codemb,Pesliq,Pesbru,QtdpalA,QtdpalB,QtdpalC,QtdEst,QtdMin,Temcor,Ativo,DatInc,Qtdtra,Qtdfat,Codpal,Coddiv,Qtdind,Fatind,Codfabr,Desc99,Metcub,Cappro,Mod3,Clafis,SQtdtra,SQtdfat,SQtdest,SQtdind,Codaux,Flag,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN)SELECT '210',Codpro,Despro,UndCom,Volcom,Undven,Volven,Codcat,Codtip,Tipbeb,CodMar,Codsab,Litros,NomPal,Numnot,Valcus,Codvas,Codemb,Pesliq,Pesbru,QtdpalA,QtdpalB,QtdpalC,QtdEst,QtdMin,Temcor,Ativo,DatInc,Qtdtra,Qtdfat,Codpal,Coddiv,Qtdind,Fatind,Codfabr,Desc99,Metcub,Cappro,Mod3,Clafis,SQtdtra,SQtdfat,SQtdest,SQtdind,Codaux,Flag,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN FROM Inserted 

Go

CREATE TRIGGER TRG_Produtos_UPDATE_BARLEY ON Produtos FOR UPDATE AS  
DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Produtos A 
INNER JOIN Deleted B ON A.Codpro= B.Codpro 
WHERE A.Codemp = '210' 

INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Produtos(Codemp,Codpro,Despro,UndCom,Volcom,Undven,Volven,Codcat,Codtip,Tipbeb,CodMar,Codsab,Litros,NomPal,Numnot,Valcus,Codvas,Codemb,Pesliq,Pesbru,QtdpalA,QtdpalB,QtdpalC,QtdEst,QtdMin,Temcor,Ativo,DatInc,Qtdtra,Qtdfat,Codpal,Coddiv,Qtdind,Fatind,Codfabr,Desc99,Metcub,Cappro,Mod3,Clafis,SQtdtra,SQtdfat,SQtdest,SQtdind,Codaux,Flag,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN) 
SELECT '210',Codpro,Despro,UndCom,Volcom,Undven,Volven,Codcat,Codtip,Tipbeb,CodMar,Codsab,Litros,NomPal,Numnot,Valcus,Codvas,Codemb,Pesliq,Pesbru,QtdpalA,QtdpalB,QtdpalC,QtdEst,QtdMin,Temcor,Ativo,DatInc,Qtdtra,Qtdfat,Codpal,Coddiv,Qtdind,Fatind,Codfabr,Desc99,Metcub,Cappro,Mod3,Clafis,SQtdtra,SQtdfat,SQtdest,SQtdind,Codaux,Flag,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN 
FROM Inserted 

Go

CREATE TRIGGER TRG_Sabor_DELETE_BARLEY ON Sabor FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Sabor A INNER JOIN Deleted B ON A.Codsab= B.Codsab  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Sabor_INSERT_BARLEY ON Sabor FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Sabor(Codemp,Codsab,Dessab,Ativo,Datinc)SELECT '210',Codsab,Dessab,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Sabor_UPDATE_BARLEY ON Sabor FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Sabor A INNER JOIN Deleted B ON A.Codsab= B.Codsab  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Sabor(Codemp,Codsab,Dessab,Ativo,Datinc)SELECT '210',Codsab,Dessab,Ativo,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_Subordinacao_DELETE_BARLEY ON Subordinacao FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Subordinacao A INNER JOIN Deleted B ON A.Codsup= B.Codsup AND A.Codsub= B.Codsub  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Subordinacao_INSERT_BARLEY ON Subordinacao FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Subordinacao(CodEmp,Codsup,Codsub,Limini,Limfim,Comissao,Ativo,DatInc)SELECT '210',Codsup,Codsub,Limini,Limfim,Comissao,Ativo,DatInc FROM Inserted 

Go

CREATE TRIGGER TRG_Subordinacao_UPDATE_BARLEY ON Subordinacao FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Subordinacao A INNER JOIN Deleted B ON A.Codsup= B.Codsup AND A.Codsub= B.Codsub  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Subordinacao(CodEmp,Codsup,Codsub,Limini,Limfim,Comissao,Ativo,DatInc)SELECT '210',Codsup,Codsub,Limini,Limfim,Comissao,Ativo,DatInc FROM Inserted 

Go

CREATE TRIGGER TRG_Tabela_IBGE_DELETE_BARLEY ON Tabela_IBGE FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Tabela_IBGE A INNER JOIN Deleted B ON A.SigEst= B.SigEst AND A.CodIbge= B.CodIbge 

Go

CREATE TRIGGER TRG_Tabela_IBGE_INSERT_BARLEY ON Tabela_IBGE FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Tabela_IBGE(SigEst,CodIbge,DesIbge)SELECT SigEst,CodIbge,DesIbge FROM Inserted 

Go

CREATE TRIGGER TRG_Tabela_IBGE_UPDATE_BARLEY ON Tabela_IBGE FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Tabela_IBGE A INNER JOIN Deleted B ON A.SigEst= B.SigEst AND A.CodIbge= B.CodIbge INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Tabela_IBGE(SigEst,CodIbge,DesIbge)SELECT SigEst,CodIbge,DesIbge FROM Inserted 

Go

CREATE TRIGGER TRG_Tabela_IPI_DELETE_BARLEY ON Tabela_IPI FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Tabela_IPI A INNER JOIN Deleted B ON A.Codpro= B.Codpro AND A.Tippro= B.Tippro  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Tabela_Preco_DELETE_BARLEY ON Tabela_Preco FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Tabela_Preco A INNER JOIN Deleted B ON A.Codtab= B.Codtab  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Tabela_Preco_INSERT_BARLEY ON Tabela_Preco FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Tabela_Preco(Codemp,Codtab,Destab,Pamto,Obstab,Valini,Valfin,Ativo,Datinc,Codpal)SELECT '210',Codtab,Destab,Pamto,Obstab,Valini,Valfin,Ativo,Datinc,Codpal FROM Inserted 

Go

CREATE TRIGGER TRG_Tabela_Preco_UPDATE_BARLEY ON Tabela_Preco FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Tabela_Preco A INNER JOIN Deleted B ON A.Codtab= B.Codtab  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Tabela_Preco(Codemp,Codtab,Destab,Pamto,Obstab,Valini,Valfin,Ativo,Datinc,Codpal)SELECT '210',Codtab,Destab,Pamto,Obstab,Valini,Valfin,Ativo,Datinc,Codpal FROM Inserted 

Go

CREATE TRIGGER TRG_Tipo_Controle_DELETE_BARLEY ON Tipo_Controle FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Tipo_Controle A INNER JOIN Deleted B ON A.Codcon= B.Codcon  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Tipo_Controle_INSERT_BARLEY ON Tipo_Controle FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Tipo_Controle(Codemp,Codcon,Descon)SELECT '210',Codcon,Descon FROM Inserted 

Go

CREATE TRIGGER TRG_Tipo_Controle_UPDATE_BARLEY ON Tipo_Controle FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Tipo_Controle A INNER JOIN Deleted B ON A.Codcon= B.Codcon  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Tipo_Controle(Codemp,Codcon,Descon)SELECT '210',Codcon,Descon FROM Inserted 

Go

CREATE TRIGGER TRG_Tipo_DELETE_BARLEY ON Tipo FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Tipo A INNER JOIN Deleted B ON A.Codtip= B.Codtip  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Tipo_INSERT_BARLEY ON Tipo FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Tipo(Codemp,Codtip,Destip,Ativo,Datinc,Codpal)SELECT '210',Codtip,Destip,Ativo,Datinc,Codpal FROM Inserted 

Go

CREATE TRIGGER TRG_Tipo_UPDATE_BARLEY ON Tipo FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Tipo A INNER JOIN Deleted B ON A.Codtip= B.Codtip  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Tipo(Codemp,Codtip,Destip,Ativo,Datinc,Codpal)SELECT '210',Codtip,Destip,Ativo,Datinc,Codpal FROM Inserted 

Go

CREATE TRIGGER TRG_TipoAuxiliar_DELETE_BARLEY ON TipoAuxiliar FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.TipoAuxiliar A INNER JOIN Deleted B ON A.CodAux= B.CodAux  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_TipoAuxiliar_INSERT_BARLEY ON TipoAuxiliar FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.TipoAuxiliar(Codemp,CodAux,DesAux,Datinc)SELECT '210',CodAux,DesAux,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_TipoAuxiliar_UPDATE_BARLEY ON TipoAuxiliar FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.TipoAuxiliar A INNER JOIN Deleted B ON A.CodAux= B.CodAux  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.TipoAuxiliar(Codemp,CodAux,DesAux,Datinc)SELECT '210',CodAux,DesAux,Datinc FROM Inserted 

Go

CREATE TRIGGER TRG_TiposBloqueios_DELETE_BARLEY ON TiposBloqueios FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.TiposBloqueios A INNER JOIN Deleted B ON A.Codbloc= B.Codbloc  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_TiposBloqueios_INSERT_BARLEY ON TiposBloqueios FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.TiposBloqueios(CodEmp,Codbloc,DesBloc)SELECT '210',Codbloc,DesBloc FROM Inserted 

Go

CREATE TRIGGER TRG_TiposBloqueios_UPDATE_BARLEY ON TiposBloqueios FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.TiposBloqueios A INNER JOIN Deleted B ON A.Codbloc= B.Codbloc  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.TiposBloqueios(CodEmp,Codbloc,DesBloc)SELECT '210',Codbloc,DesBloc FROM Inserted 

Go

CREATE TRIGGER TRG_Transacao_DELETE_BARLEY ON Transacao FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Transacao A INNER JOIN Deleted B ON A.CodiGO= B.CodiGO  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Transacao_INSERT_BARLEY ON Transacao FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Transacao(Codemp,CodiGO,Descricao,Estoque,Entsai,Comissao,Carrega,Datinc,Ativo,Tipo,Estfis,Coddev)SELECT '210',CodiGO,Descricao,Estoque,Entsai,Comissao,Carrega,Datinc,Ativo,Tipo,Estfis,Coddev FROM Inserted 

Go

CREATE TRIGGER TRG_Transacao_UPDATE_BARLEY ON Transacao FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Transacao A 
INNER JOIN Deleted B ON A.CodiGO= B.CodiGO  
WHERE A.Codemp = '210'
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Transacao(Codemp,CodiGO,Descricao,Estoque,Entsai,Comissao,Carrega,Datinc,Ativo,Tipo,Estfis,Coddev)SELECT '210',CodiGO,Descricao,Estoque,Entsai,Comissao,Carrega,Datinc,Ativo,Tipo,Estfis,Coddev FROM Inserted 

Go

CREATE TRIGGER TRG_Transportadora_DELETE_BARLEY ON Transportadora FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Transportadora A INNER JOIN Deleted B ON A.Codtransp= B.Codtransp  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Transportadora_INSERT_BARLEY ON Transportadora FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Transportadora(Codemp,Codtransp,RazTransp,EndTransp,CidTransp,UFTransp,CGCTransp,InsTransp)SELECT '210',Codtransp,RazTransp,EndTransp,CidTransp,UFTransp,CGCTransp,InsTransp FROM Inserted 

Go

CREATE TRIGGER TRG_Transportadora_UPDATE_BARLEY ON Transportadora FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Transportadora A INNER JOIN Deleted B ON A.Codtransp= B.Codtransp  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Transportadora(Codemp,Codtransp,RazTransp,EndTransp,CidTransp,UFTransp,CGCTransp,InsTransp)SELECT '210',Codtransp,RazTransp,EndTransp,CidTransp,UFTransp,CGCTransp,InsTransp FROM Inserted 

Go

CREATE TRIGGER TRG_Usuarios_DELETE_BARLEY ON Usuarios FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Usuarios A INNER JOIN Deleted B ON A.Nome= B.Nome AND A.modulo= B.modulo 

Go

CREATE TRIGGER TRG_Usuarios_INSERT_BARLEY ON Usuarios FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Usuarios(Nome,modulo,acesso,item)SELECT Nome,modulo,acesso,item FROM Inserted 

Go

CREATE TRIGGER TRG_Usuarios_UPDATE_BARLEY ON Usuarios FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Usuarios A INNER JOIN Deleted B ON A.Nome= B.Nome AND A.modulo= B.modulo INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Usuarios(Nome,modulo,acesso,item)SELECT Nome,modulo,acesso,item FROM Inserted 

Go

CREATE TRIGGER TRG_Valor_EmbVas_DELETE_BARLEY ON Valor_EmbVas FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Valor_EmbVas A INNER JOIN Deleted B ON A.CodTip= B.CodTip AND A.CodCat= B.CodCat  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Valor_EmbVas_INSERT_BARLEY ON Valor_EmbVas FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Valor_EmbVas(CodEmp,CodTip,CodCat,DesTip,DesCat,Valor)SELECT '210',CodTip,CodCat,DesTip,DesCat,Valor FROM Inserted 

Go

CREATE TRIGGER TRG_Valor_EmbVas_UPDATE_BARLEY ON Valor_EmbVas FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Valor_EmbVas A INNER JOIN Deleted B ON A.CodTip= B.CodTip AND A.CodCat= B.CodCat  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Valor_EmbVas(CodEmp,CodTip,CodCat,DesTip,DesCat,Valor)SELECT '210',CodTip,CodCat,DesTip,DesCat,Valor FROM Inserted 

Go

CREATE TRIGGER TRG_Vasilhames_DELETE_BARLEY ON Vasilhames FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Vasilhames A INNER JOIN Deleted B ON A.Codvas= B.Codvas  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Vasilhames_INSERT_BARLEY ON Vasilhames FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Vasilhames(CodEmp,Codvas,Desvas,NomPal,CodCat,Codtip,Codemb,Valque,Qtdcxa,Valcus,Pesliq,Ativo,DatInc,Qtdtra,Qtdfat,Qtdvas,Qtdcom,Qtdpro,Desc99,Mod3,Clafis,SQtdfat,SQtdtra,SQtdvas,SQtdcom,SQtdpro,Codaux,PrazoCom,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN)SELECT '210',Codvas,Desvas,NomPal,CodCat,Codtip,Codemb,Valque,Qtdcxa,Valcus,Pesliq,Ativo,DatInc,Qtdtra,Qtdfat,Qtdvas,Qtdcom,Qtdpro,Desc99,Mod3,Clafis,SQtdfat,SQtdtra,SQtdvas,SQtdcom,SQtdpro,Codaux,PrazoCom,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN FROM Inserted 

Go

CREATE TRIGGER TRG_Vasilhames_UPDATE_BARLEY ON Vasilhames FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Vasilhames A INNER JOIN Deleted B ON A.Codvas= B.Codvas  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Vasilhames(CodEmp,Codvas,Desvas,NomPal,CodCat,Codtip,Codemb,Valque,Qtdcxa,Valcus,Pesliq,Ativo,DatInc,Qtdtra,Qtdfat,Qtdvas,Qtdcom,Qtdpro,Desc99,Mod3,Clafis,SQtdfat,SQtdtra,SQtdvas,SQtdcom,SQtdpro,Codaux,PrazoCom,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN)SELECT '210',Codvas,Desvas,NomPal,CodCat,Codtip,Codemb,Valque,Qtdcxa,Valcus,Pesliq,Ativo,DatInc,Qtdtra,Qtdfat,Qtdvas,Qtdcom,Qtdpro,Desc99,Mod3,Clafis,SQtdfat,SQtdtra,SQtdvas,SQtdcom,SQtdpro,Codaux,PrazoCom,Incentivado,ClassProdutoDIEF,CodGeneroItem,CodEX,TipoItem,CodServico,CodEnquadramentoIPI,CodCombustivelANP,CodEAN FROM Inserted 

Go

CREATE TRIGGER TRG_Veiculos_DELETE_BARLEY ON Veiculos FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Veiculos A INNER JOIN Deleted B ON A.Numpla= B.Numpla  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Veiculos_INSERT_BARLEY ON Veiculos FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Veiculos(Codemp,Numpla,Modvar,Codfab,Numcha,Codcom,Kmsatu,Anomod,Anofab,Codtip,Placid,Plaest,Codmot,Linini,Linven,Valcus,Valven,Numcer,Valfre,Datbai,Motbai,Obsbai,numaba,foraba,Ultaba,Ultins,Depmes,Valdep,Ativo,Datinc,Veiter,Veiali,Terali,Nomali,Codmod,Tipuso,Metcub,Peso,Cor,Arrendat,Contrato,NomRegAtu,NomRegAnt,DatAqui,Observ,DocExp,ValIPVA)SELECT '210',Numpla,Modvar,Codfab,Numcha,Codcom,Kmsatu,Anomod,Anofab,Codtip,Placid,Plaest,Codmot,Linini,Linven,Valcus,Valven,Numcer,Valfre,Datbai,Motbai,Obsbai,numaba,foraba,Ultaba,Ultins,Depmes,Valdep,Ativo,Datinc,Veiter,Veiali,Terali,Nomali,Codmod,Tipuso,Metcub,Peso,Cor,Arrendat,Contrato,NomRegAtu,NomRegAnt,DatAqui,Observ,DocExp,ValIPVA FROM Inserted 

Go

CREATE TRIGGER TRG_Veiculos_UPDATE_BARLEY ON Veiculos FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Veiculos A INNER JOIN Deleted B ON A.Numpla= B.Numpla  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Veiculos(Codemp,Numpla,Modvar,Codfab,Numcha,Codcom,Kmsatu,Anomod,Anofab,Codtip,Placid,Plaest,Codmot,Linini,Linven,Valcus,Valven,Numcer,Valfre,Datbai,Motbai,Obsbai,numaba,foraba,Ultaba,Ultins,Depmes,Valdep,Ativo,Datinc,Veiter,Veiali,Terali,Nomali,Codmod,Tipuso,Metcub,Peso,Cor,Arrendat,Contrato,NomRegAtu,NomRegAnt,DatAqui,Observ,DocExp,ValIPVA)SELECT '210',Numpla,Modvar,Codfab,Numcha,Codcom,Kmsatu,Anomod,Anofab,Codtip,Placid,Plaest,Codmot,Linini,Linven,Valcus,Valven,Numcer,Valfre,Datbai,Motbai,Obsbai,numaba,foraba,Ultaba,Ultins,Depmes,Valdep,Ativo,Datinc,Veiter,Veiali,Terali,Nomali,Codmod,Tipuso,Metcub,Peso,Cor,Arrendat,Contrato,NomRegAtu,NomRegAnt,DatAqui,Observ,DocExp,ValIPVA 
FROM Inserted 

Go

CREATE TRIGGER TRG_Vendedores_DELETE_BARLEY ON Vendedores FOR DELETE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Vendedores A INNER JOIN Deleted B ON A.Codven= B.Codven  WHERE A.Codemp = '210'

Go

CREATE TRIGGER TRG_Vendedores_INSERT_BARLEY ON Vendedores FOR INSERT AS 
INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Vendedores(Codemp,Codven,Codniv,Nomven,Endven,Baiven,Sigest,Codcid,Cepven,Fonres,Celular,E_mail,CpfVen,RgVen,Datnasc,Datadm,Temcor,Ativo,Datinc,Comissao,CodGrupo,CodEqu)
SELECT '210',Codven,Codniv,Nomven,Endven,Baiven,Sigest,Codcid,Cepven,Fonres,Celular,E_mail,CpfVen,RgVen,Datnasc,Datadm,Temcor,Ativo,Datinc,Comissao,CodGrupo,CodEqu FROM Inserted 

Go

CREATE TRIGGER TRG_Vendedores_UPDATE_BARLEY ON Vendedores FOR UPDATE AS DELETE A FROM [FIN210_BARLEY_JUNCAO].DBO.Vendedores A INNER JOIN Deleted B ON A.Codven= B.Codven  WHERE A.Codemp = '210'INSERT INTO [FIN210_BARLEY_JUNCAO].DBO.Vendedores(Codemp,Codven,Codniv,Nomven,Endven,Baiven,Sigest,Codcid,Cepven,Fonres,Celular,E_mail,CpfVen,RgVen,Datnasc,Datadm,Temcor,Ativo,Datinc,Comissao,CodGrupo,CodEqu)SELECT '210',Codven,Codniv,Nomven,Endven,Baiven,Sigest,Codcid,Cepven,Fonres,Celular,E_mail,CpfVen,RgVen,Datnasc,Datadm,Temcor,Ativo,Datinc,Comissao,CodGrupo,CodEqu FROM Inserted 

Go

CREATE TRIGGER TRG_Pedido_INSERT_BARLEY ON Pedido FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Pedido (codemp,nummap,numped,tipped,datped,codven,descon,valped,codcli,numnot,forpag,datcai,codrot,tipven,valdev,vememb,vemvas,valfre,tembon,notbon,percom,codset,codram,tipnot,numpla,notdev,pedemi,peddev,datven,temsub,bloped,obsped,motdev,Cupom,Emicup,Sernot,Devpar,AcreNot,RemAut,PedTransf,ValProDes,ValProAcr,CPED)
SELECT '210',nummap,numped,tipped,datped,codven,descon,valped,codcli,numnot,forpag,datcai,codrot,tipven,valdev,vememb,vemvas,valfre,tembon,notbon,percom,codset,codram,tipnot,numpla,notdev,pedemi,peddev,datven,temsub,bloped,obsped,motdev,Cupom,Emicup,Sernot,Devpar,AcreNot,RemAut,PedTransf,ValProDes,ValProAcr,CPED
FROM Inserted

Go

CREATE TRIGGER TRG_Pedido_DELETE_BARLEY ON Dbo.Pedido FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Pedido A 
INNER JOIN Deleted D ON  A.Nummap = D.Nummap And A.Numped=D.Numped And A.Datped=D.Datped And A.Tipped=D.Tipped
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Pedido_UPDATE_BARLEY ON Dbo.Pedido FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Pedido A 
INNER JOIN Deleted D ON  A.Nummap = D.Nummap And A.Numped=D.Numped And A.Datped=D.Datped And A.Tipped=D.Tipped
WHERE A.CODEMP = '210'

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Pedido (codemp,nummap,numped,tipped,datped,codven,descon,valped,codcli,numnot,forpag,datcai,codrot,tipven,valdev,vememb,vemvas,valfre,tembon,notbon,percom,codset,codram,tipnot,numpla,notdev,pedemi,peddev,datven,temsub,bloped,obsped,motdev,Cupom,Emicup,Sernot,Devpar,AcreNot,RemAut,PedTransf,ValProDes,ValProAcr,CPED)
SELECT '210',nummap,numped,tipped,datped,codven,descon,valped,codcli,numnot,forpag,datcai,codrot,tipven,valdev,vememb,vemvas,valfre,tembon,notbon,percom,codset,codram,tipnot,numpla,notdev,pedemi,peddev,datven,temsub,bloped,obsped,motdev,Cupom,Emicup,Sernot,Devpar,AcreNot,RemAut,PedTransf,ValProDes,ValProAcr,CPED 
FROM Inserted


Go

CREATE TRIGGER Dbo.TRG_Itens_Pedido_INSERT_BARLEY ON Dbo.Itens_Pedido FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Itens_Pedido (Codemp,nummap,numped,pecodi,tippro,tipped,Nompro,qtde,Induni,valbru,valuni,pevruc,stapro,datcai,pericm,qtddev,Valdev,tipoco,codtab,codvas,codemb,valdes,perdes,valvar,datped,percom,temsub,bloped,codcat,ValProDes,ValProAcr,AcreNot)
SELECT '210',nummap,numped,pecodi,tippro,tipped,Nompro,qtde,Induni,valbru,valuni,pevruc,stapro,datcai,pericm,qtddev,Valdev,tipoco,codtab,codvas,codemb,valdes,perdes,valvar,datped,percom,temsub,bloped,codcat,ValProDes,ValProAcr,AcreNot
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Itens_Pedido_DELETE_BARLEY ON Dbo.Itens_Pedido FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Itens_Pedido A 
INNER JOIN Deleted D ON  A.Nummap = D.Nummap And A.Numped=D.Numped And A.Datped=D.Datped And A.Tipped=D.Tipped And A.Pecodi=D.Pecodi
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Itens_Pedido_UPDATE_BARLEY ON Dbo.Itens_Pedido FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Itens_Pedido A 
INNER JOIN Deleted D ON  A.Nummap = D.Nummap And A.Numped=D.Numped And A.Datped=D.Datped And A.Tipped=D.Tipped And A.Pecodi=D.Pecodi
WHERE A.CODEMP = '210'

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Itens_Pedido (Codemp,nummap,numped,pecodi,tippro,tipped,Nompro,qtde,Induni,valbru,valuni,pevruc,stapro,datcai,pericm,qtddev,Valdev,tipoco,codtab,codvas,codemb,valdes,perdes,valvar,datped,percom,temsub,bloped,codcat,ValProDes,ValProAcr,AcreNot)
SELECT '210',nummap,numped,pecodi,tippro,tipped,Nompro,qtde,Induni,valbru,valuni,pevruc,stapro,datcai,pericm,qtddev,Valdev,tipoco,codtab,codvas,codemb,valdes,perdes,valvar,datped,percom,temsub,bloped,codcat,ValProDes,ValProAcr,AcreNot
FROM Inserted



Go

CREATE TRIGGER Dbo.TRG_Mapas_INSERT_BARLEY ON Dbo.Mapas FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Mapas (codemp,nummap,Tipped,datger,codven,valvas,valemb,valpro,qtdped,codrot,valdin,valass,valche,vasdin,vasche,vasass,embdin,embche,embass,datcai,valdev,retvas,retemb,difvas,venvas,difemb,venemb,valdep,procar,valval,valbol,datpro,kmssai,kmsent,horsai,horent,plavei,codmot,qtdlit,valcom,veiter,codaj1,codaj2,codaj3,codaj4,codaj5,codsai,UfVei)
SELECT '210',nummap,Tipped,datger,codven,valvas,valemb,valpro,qtdped,codrot,valdin,valass,valche,vasdin,vasche,vasass,embdin,embche,embass,datcai,valdev,retvas,retemb,difvas,venvas,difemb,venemb,valdep, procar,valval,valbol,datpro,kmssai,kmsent,horsai,horent,plavei,codmot,qtdlit,valcom,veiter,codaj1, codaj2,codaj3,codaj4,codaj5,codsai,UfVei
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Mapas_DELETE_BARLEY ON Dbo.Mapas FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Mapas A 
INNER JOIN Deleted D ON  A.Nummap = D.Nummap And  A.Datger=D.Datger And A.Tipped=D.Tipped
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Mapas_UPDATE_BARLEY ON Dbo.Mapas FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Mapas A 
INNER JOIN Deleted D ON  A.Nummap = D.Nummap And  A.Datger=D.Datger And A.Tipped=D.Tipped
WHERE A.CODEMP = '210'

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Mapas (codemp,nummap,Tipped,datger,codven,valvas,valemb,valpro,qtdped,codrot,valdin,valass,valche,vasdin,vasche,vasass,embdin,embche,embass,datcai,valdev,retvas,retemb,difvas,venvas,difemb,venemb,valdep,procar,valval,valbol,datpro,kmssai,kmsent,horsai,horent,plavei,codmot,qtdlit,valcom,veiter,codaj1,codaj2,codaj3,codaj4,codaj5,codsai,UfVei)
SELECT '210',nummap,Tipped,datger,codven,valvas,valemb,valpro,qtdped,codrot,valdin,valass,valche,vasdin,vasche,vasass,embdin,embche,embass,datcai,valdev,retvas,retemb,difvas,venvas,difemb,venemb,valdep, procar,valval,valbol,datpro,kmssai,kmsent,horsai,horent,plavei,codmot,qtdlit,valcom,veiter,codaj1, codaj2,codaj3,codaj4,codaj5,codsai,UfVei
FROM Inserted



Go

CREATE TRIGGER Dbo.TRG_Itens_Mapa_INSERT_BARLEY ON Dbo.Itens_Mapa FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Itens_Mapa (codemp,nummap,pecodi,stapro,Tipped,Nompro,qtdpro,valpro,qtdret,qtddev,ficcom,saicom,qtdbon,qtddif,qtdcon,valbon,valdev,qtdven,datcai,foqtpr,fovapr,foqtbo,fovabo,foqtco,foqtve,foqtdv,fovrdv)
SELECT '210',nummap,pecodi,stapro,Tipped,Nompro,qtdpro,valpro,qtdret,qtddev,ficcom,saicom,qtdbon,qtddif,qtdcon,valbon,valdev,qtdven,datcai,foqtpr,fovapr,foqtbo,fovabo,foqtco,foqtve,foqtdv,fovrdv
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Itens_Mapa_DELETE_BARLEY ON Dbo.Itens_Mapa FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Itens_Mapa A 
INNER JOIN Deleted D ON  A.Nummap = D.Nummap And A.Pecodi=D.Pecodi And A.Stapro=D.StaPro And A.Tipped=D.Tipped
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Itens_Mapa_UPDATE_BARLEY ON Dbo.Itens_Mapa FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Itens_Mapa A 
INNER JOIN Deleted D ON  A.Nummap = D.Nummap  And A.Pecodi=D.Pecodi And A.Stapro=D.StaPro And A.Tipped=D.Tipped
WHERE A.CODEMP = '210'

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Itens_Mapa (codemp,nummap,pecodi,stapro,Tipped,Nompro,qtdpro,valpro,qtdret,qtddev,ficcom,saicom,qtdbon,qtddif,qtdcon,valbon,valdev,qtdven,datcai,foqtpr,fovapr,foqtbo,fovabo,foqtco,foqtve,foqtdv,fovrdv)
SELECT '210',nummap,pecodi,stapro,Tipped,Nompro,qtdpro,valpro,qtdret,qtddev,ficcom,saicom,qtdbon,qtddif,qtdcon,valbon,valdev,qtdven,datcai,foqtpr,fovapr,foqtbo,fovabo,foqtco,foqtve,foqtdv,fovrdv
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_LivroCaixa_INSERT_BARLEY ON Dbo.LivroCaixa FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.LivroCaixa (Codemp,CodCon,Numdoc,Datlan,TipLan,Vallan,Datqui,Valqui,Valpag,Valbai,Datbai,Hislan,Tipoper,Codmod,SCodmod)
SELECT '210',CodCon,Numdoc,Datlan,TipLan,Vallan,Datqui,Valqui,Valpag,Valbai,Datbai,Hislan,Tipoper,Codmod,SCodmod
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_LivroCaixa_DELETE_BARLEY ON Dbo.LivroCaixa FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.LivroCaixa A 
INNER JOIN Deleted D ON  A.CodCon = D.CodCon And A.Numdoc=D.Numdoc And A.Datlan=D.Datlan And A.Tiplan=D.Tiplan
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_LivroCaixa_UPDATE_BARLEY ON Dbo.LivroCaixa FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.LivroCaixa A 
INNER JOIN Deleted D ON  A.CodCon = D.CodCon And A.Numdoc=D.Numdoc And A.Datlan=D.Datlan And A.Tiplan=D.Tiplan
WHERE A.CODEMP = '210'

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.LivroCaixa (Codemp,CodCon,Numdoc,Datlan,TipLan,Vallan,Datqui,Valqui,Valpag,Valbai,Datbai,Hislan,Tipoper,Codmod,SCodmod)
SELECT '210',CodCon,Numdoc,Datlan,TipLan,Vallan,Datqui,Valqui,Valpag,Valbai,Datbai,Hislan,Tipoper,Codmod,SCodmod
FROM Inserted


Go

CREATE TRIGGER Dbo.TRG_Baixa_LivCai_INSERT_BARLEY ON Dbo.Baixa_LivCai FOR INSERT AS
INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Baixa_LivCai (Codemp,Codcon,Numdoc,Reg,Datlan,TipLan,Datbai,Valbai)
SELECT '210',Codcon,Numdoc,Reg,Datlan,TipLan,Datbai,Valbai
FROM Inserted
Go

CREATE TRIGGER Dbo.TRG_Baixa_LivCai_DELETE_BARLEY ON Dbo.Baixa_LivCai FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Baixa_LivCai A 
INNER JOIN Deleted D ON  A.CodCon = D.CodCon And A.Numdoc=D.Numdoc And A.Datlan=D.Datlan And A.Tiplan=D.Tiplan And A.Reg=D.Reg
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Baixa_LivCai_UPDATE_BARLEY ON Dbo.Baixa_LivCai FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Baixa_LivCai A 
INNER JOIN Deleted D ON  A.CodCon = D.CodCon And A.Numdoc=D.Numdoc And A.Datlan=D.Datlan And A.Tiplan=D.Tiplan And A.Reg=D.Reg
WHERE A.CODEMP = '210'
INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Baixa_LivCai (Codemp,Codcon,Numdoc,Reg,Datlan,TipLan,Datbai,Valbai)
SELECT '210',Codcon,Numdoc,Reg,Datlan,TipLan,Datbai,Valbai
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Movim_Livro_INSERT_BARLEY ON Dbo.Movim_Livro FOR INSERT AS
INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Movim_Livro (Codemp,Numdoc,Data,Tiplan,Reg,Salatu,Valdoc,Salfin,Debcre,Hislan,TipPag,Conta)
SELECT '210',Numdoc,Data,Tiplan,Reg,Salatu,Valdoc,Salfin,Debcre,Hislan,TipPag,Conta
FROM Inserted
Go

CREATE TRIGGER Dbo.TRG_Movim_Livro_DELETE_BARLEY ON Dbo.Movim_Livro FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Movim_Livro A 
INNER JOIN Deleted D ON  A.Numdoc = D.Numdoc And A.Data=D.Data And A.TipLan=D.Tiplan
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Movim_Livro_UPDATE_BARLEY ON Dbo.Movim_Livro FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Movim_Livro A 
INNER JOIN Deleted D ON  A.Numdoc = D.Numdoc And A.Data=D.Data And A.TipLan=D.Tiplan
WHERE A.CODEMP = '210'

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Movim_Livro (Codemp,Numdoc,Data,Tiplan,Reg,Salatu,Valdoc,Salfin,Debcre,Hislan,TipPag,Conta)
SELECT '210',Numdoc,Data,Tiplan,Reg,Salatu,Valdoc,Salfin,Debcre,Hislan,TipPag,Conta
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Mov_Bancaria_INSERT_BARLEY ON Dbo.Mov_Bancaria FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Mov_Bancaria (Codemp,Codbco,Codage,Numcon,Numdoc,Datlan,TipLan,Tipmov,Valdoc,Codhis,Comhis,Salmov,Datinc,Ativo,Codmod,Tipcai,TipEmp)
SELECT '210',Codbco,Codage,Numcon,Numdoc,Datlan,TipLan,Tipmov,Valdoc,Codhis,Comhis,Salmov,Datinc,Ativo,Codmod,Tipcai,TipEmp
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Mov_Bancaria_DELETE_BARLEY ON Dbo.Mov_Bancaria FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Mov_Bancaria A 
INNER JOIN Deleted D ON  A.Codbco = D.Codbco And A.CodAge=D.CodAge And A.Numcon=D.Numcon And A.Numdoc=D.Numdoc And A.Datlan=D.Datlan And A.Tiplan=D.Tiplan
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Mov_Bancaria_UPDATE_BARLEY ON Dbo.Mov_Bancaria FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Mov_Bancaria A 
INNER JOIN Deleted D ON  A.Codbco = D.Codbco And A.CodAge=D.CodAge And A.Numcon=D.Numcon And A.Numdoc=D.Numdoc And A.Datlan=D.Datlan And A.Tiplan=D.Tiplan
WHERE A.CODEMP = '210'


INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Mov_Bancaria (Codemp,Codbco,Codage,Numcon,Numdoc,Datlan,TipLan,Tipmov,Valdoc,Codhis,Comhis,Salmov,Datinc,Ativo,Codmod,Tipcai,TipEmp)
SELECT '210',Codbco,Codage,Numcon,Numdoc,Datlan,TipLan,Tipmov,Valdoc,Codhis,Comhis,Salmov,Datinc,Ativo,Codmod,Tipcai,TipEmp
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Mov_Faturas_INSERT_BARLEY ON Dbo.Mov_Faturas FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Mov_Faturas (Codemp,Numfat,Numpar,Codfor,Tiplan,Datinc,Datven,Valparc,Datqui,Valpgto,Valbai,Datbai,valdesc,valjur,emiche,TotFat,Codred,Codban,Cheque,Tipbai,Serie,Conta,Ir,Inss,Icms,Ipi,Tipent,Emissao,Cccont,Tipfat)
SELECT '210',Numfat,Numpar,Codfor,Tiplan,Datinc,Datven,Valparc,Datqui,Valpgto,Valbai,Datbai,valdesc,valjur,emiche,TotFat,Codred,Codban,Cheque,Tipbai,Serie,Conta,Ir,Inss,Icms,Ipi,Tipent,Emissao,Cccont,Tipfat
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Mov_Faturas_DELETE_BARLEY ON Dbo.Mov_Faturas FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Mov_Faturas A 
INNER JOIN Deleted D ON  A.Numfat = D.Numfat And A.Numpar=D.Numpar And A.Codfor=D.Codfor And A.Tiplan=D.Tiplan And A.Datinc=D.Datinc
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Mov_Faturas_UPDATE_BARLEY ON Dbo.Mov_Faturas FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Mov_Faturas A 
INNER JOIN Deleted D ON  A.Numfat = D.Numfat And A.Numpar=D.Numpar And A.Codfor=D.Codfor And A.Tiplan=D.Tiplan And A.Datinc=D.Datinc
WHERE A.CODEMP = '210'


INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Mov_Faturas (Codemp,Numfat,Numpar,Codfor,Tiplan,Datinc,Datven,Valparc,Datqui,Valpgto,Valbai,Datbai,valdesc,valjur,emiche,TotFat,Codred,Codban,Cheque,Tipbai,Serie,Conta,Ir,Inss,Icms,Ipi,Tipent,Emissao,Cccont,Tipfat)
SELECT '210',Numfat,Numpar,Codfor,Tiplan,Datinc,Datven,Valparc,Datqui,Valpgto,Valbai,Datbai,valdesc,valjur,emiche,TotFat,Codred,Codban,Cheque,Tipbai,Serie,Conta,Ir,Inss,Icms,Ipi,Tipent,Emissao,Cccont,Tipfat
FROM Inserted


Go

CREATE TRIGGER Dbo.TRG_Apropria_Cp_INSERT_BARLEY ON Dbo.Apropria_Cp FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Apropria_Cp (Codemp,Numfat,Numpar,Codfor,Codred,Tiplan,Datinc,Totcus,Valpgto,Valbai,Valdes,Valjur,CodHis,Deshis,Redcon,Serie,Cccont,codcli,codreg,codset,coddep)
SELECT '210',Numfat,Numpar,Codfor,Codred,Tiplan,Datinc,Totcus,Valpgto,Valbai,Valdes,Valjur,CodHis,Deshis,Redcon,Serie,Cccont,codcli,codreg,codset,coddep
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Apropria_Cp_DELETE_BARLEY ON Dbo.Apropria_Cp FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Apropria_Cp A 
INNER JOIN Deleted D ON  A.Numfat = D.Numfat And A.Numpar=D.Numpar And A.Codfor=D.Codfor And A.Tiplan=D.Tiplan And A.Datinc=D.Datinc And A.Codred=D.Codred And A.Codcli=D.Codcli
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Apropria_Cp_UPDATE_BARLEY ON Dbo.Apropria_Cp FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Apropria_Cp A 
INNER JOIN Deleted D ON  A.Numfat = D.Numfat And A.Numpar=D.Numpar And A.Codfor=D.Codfor And A.Tiplan=D.Tiplan And A.Datinc=D.Datinc
And A.Codred=D.Codred And A.Codcli=D.Codcli
WHERE A.CODEMP = '210'
INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Apropria_Cp (Codemp,Numfat,Numpar,Codfor,Codred,Tiplan,Datinc,Totcus,Valpgto,Valbai,Valdes,Valjur,CodHis,Deshis,Redcon,Serie,Cccont,codcli,codreg,codset,coddep)
SELECT '210',Numfat,Numpar,Codfor,Codred,Tiplan,Datinc,Totcus,Valpgto,Valbai,Valdes,Valjur,CodHis,Deshis,Redcon,Serie,Cccont,codcli,codreg,codset,coddep
FROM Inserted


Go

CREATE TRIGGER Dbo.TRG_Baixa_Cp2_INSERT_BARLEY ON Dbo.Baixa_Cp2 FOR INSERT AS
INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Baixa_Cp2 (Codemp,Numfat,Numpar,Codfor,Codred,Reg,Tiplan,Datinc,Datbai,Valbai,Serie,Tipbai,Cccont,codcli,Codban)
SELECT '210',Numfat,Numpar,Codfor,Codred,Reg,Tiplan,Datinc,Datbai,Valbai,Serie,Tipbai,Cccont,codcli,Codban
FROM Inserted
Go

CREATE TRIGGER Dbo.TRG_Baixa_Cp2_DELETE_BARLEY ON Dbo.Baixa_Cp2 FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Baixa_Cp2 A 
INNER JOIN Deleted D ON  A.Numfat = D.Numfat And A.Numpar=D.Numpar And A.Codfor=D.Codfor And A.Tiplan=D.Tiplan And A.Datinc=D.Datinc And A.Codred=D.Codred And A.Reg=D.Reg
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Baixa_Cp2_UPDATE_BARLEY ON Dbo.Baixa_Cp2 FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Baixa_Cp2 A 
INNER JOIN Deleted D ON  A.Numfat = D.Numfat And A.Numpar=D.Numpar And A.Codfor=D.Codfor And A.Tiplan=D.Tiplan And A.Datinc=D.Datinc And A.Codred=D.Codred And A.Reg=D.Reg
WHERE A.CODEMP = '210'
INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Baixa_Cp2 (Codemp,Numfat,Numpar,Codfor,Codred,Reg,Tiplan,Datinc,Datbai,Valbai,Serie,Tipbai,Cccont,codcli,Codban)
SELECT '210',Numfat,Numpar,Codfor,Codred,Reg,Tiplan,Datinc,Datbai,Valbai,Serie,Tipbai,Cccont,codcli,Codban
FROM Inserted
Go

CREATE TRIGGER Dbo.TRG_Nota_Fiscal_INSERT_BARLEY ON Dbo.Nota_Fiscal FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Nota_Fiscal (Codemp,Numnot,Sernot,Tipnot,Codope,Pericm,Codcli,CodMod,Clifor,Datnot,Datent,Codven,Forpag,Numped,Nummap,Valbru,Valdes,Valliq,Valvar,Basicm,Valicm,Bassub,Icmsub,Valipi,Valfre,Valseg,Valout,Status,Observ,Extope,Valise,Basipi,Tipope,Tipoco,Ctapag,Estoque,Tipo,Contab,IseIpi,OutIpi,Tipobs,Media,Pis,Cofins,OutDes,BasIss,Datexp,Placa)
SELECT '210',Numnot,Sernot,Tipnot,Codope,Pericm,Codcli,CodMod,Clifor,Datnot,Datent,Codven,Forpag,
Numped,Nummap,Valbru,Valdes,Valliq,Valvar,Basicm,Valicm,Bassub,Icmsub,Valipi,Valfre,Valseg,Valout,Status,Observ,Extope,Valise,Basipi,Tipope,Tipoco,Ctapag,Estoque,Tipo,Contab,IseIpi,OutIpi,Tipobs,Media,Pis,Cofins,OutDes,BasIss,Datexp,Placa
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Nota_Fiscal_DELETE_BARLEY ON Dbo.Nota_Fiscal FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Nota_Fiscal A 
INNER JOIN Deleted D ON  A.Numnot = D.Numnot And A.Sernot=D.Sernot And A.Tipnot=D.Tipnot And A.Codope=D.Codope And A.Pericm=D.Pericm And A.Codcli=D.Codcli And A.Codmod=D.Codmod And A.Datent=D.Datent
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Nota_Fiscal_UPDATE_BARLEY ON Dbo.Nota_Fiscal FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Nota_Fiscal A 
INNER JOIN Deleted D ON  A.Numnot = D.Numnot And A.Sernot=D.Sernot And A.Tipnot=D.Tipnot And A.Codope=D.Codope And A.Pericm=D.Pericm And A.Codcli=D.Codcli And A.Codmod=D.Codmod And A.Datent=D.Datent
WHERE A.CODEMP = '210'


INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Nota_Fiscal (Codemp,Numnot,Sernot,Tipnot,Codope,Pericm,Codcli,CodMod,Clifor,Datnot,Datent,Codven,Forpag,Numped,Nummap,Valbru,Valdes,Valliq,Valvar,Basicm,Valicm,Bassub,Icmsub,Valipi,Valfre,Valseg,Valout,Status,Observ,Extope,Valise,Basipi,Tipope,Tipoco,Ctapag,Estoque,Tipo,Contab,IseIpi,OutIpi,Tipobs,Media,Pis,Cofins,OutDes,BasIss,Datexp,Placa)
SELECT '210',Numnot,Sernot,Tipnot,Codope,Pericm,Codcli,CodMod,Clifor,Datnot,Datent,Codven,Forpag,Numped,Nummap,Valbru,Valdes,Valliq,Valvar,Basicm,Valicm,Bassub,Icmsub,Valipi,Valfre,Valseg,Valout,Status,Observ,Extope,Valise,Basipi,Tipope,Tipoco,Ctapag,Estoque,Tipo,Contab,IseIpi,OutIpi,Tipobs,Media,Pis,Cofins,OutDes,BasIss,Datexp,Placa
FROM Inserted


Go

CREATE TRIGGER Dbo.TRG_Itens_Nota_Fiscal_INSERT_BARLEY ON Dbo.Itens_Nota_Fiscal FOR INSERT AS
INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Itens_Nota_Fiscal (Codemp,Numnot,Sernot,Tipnot,Codope,Codcli,Codpro,Tippro,Induni,Reg,CodMod,Datnot,Datent,Qtdpro,Valbru,Valdes,Valliq,Valipi,Pericm,Codtri,Univar,Perred,Status,Basicm,Valicm,Bassub,Icmsub,Extope,Valise,Valout,Basipi,Valfre,Valseg,Tipope,Tipoco,IseIpi,OutIpi,Tipopest,Qtd,Valirr,Valinss,Pis,Cofins,CSocial,DifAliq,DifIPI,DifST,Presumido,NFIndust,Codred,tipo,CSLL,Basiss,Periss,Valiss,Media,Valori,Tipopeipi,Peripi,Tipopepis,Perpis,Tipopecof,Percof,IPInaoDebitado,AliqDiferencial,BaseDiferencial,ICMSnaoCreditadoValor,ICMSnaoCreditadoAliquota,CodAntecipacao,ContaContabil,CodImposto,DeducoesBase,OutrasDeducoes,FlagEstorno,DatContabilizacao,DatProvisao,DatRecolhimento,DatPagamento,InsINSS,CodRecolhimentoISS,NomeOperacao,CodMunicipio,CodTipoMunicipio,CodModalidadeServico,RetIss,INss,MovimentaEstoque)
SELECT '210',Numnot,Sernot,Tipnot,Codope,Codcli,Codpro,Tippro,Induni,Reg,CodMod,Datnot,Datent,Qtdpro,Valbru,Valdes,Valliq,Valipi,Pericm,Codtri,Univar,Perred,Status,Basicm,Valicm,Bassub,Icmsub,Extope,Valise,Valout,Basipi,Valfre,Valseg,Tipope,Tipoco,IseIpi,OutIpi,Tipopest,Qtd,Valirr,Valinss,Pis,Cofins,CSocial,DifAliq,DifIPI,DifST,Presumido,NFIndust,Codred,tipo,CSLL,Basiss,Periss,Valiss,Media,Valori,Tipopeipi,Peripi,Tipopepis,Perpis,Tipopecof,Percof,IPInaoDebitado,AliqDiferencial,BaseDiferencial,ICMSnaoCreditadoValor,ICMSnaoCreditadoAliquota,CodAntecipacao,ContaContabil,CodImposto,DeducoesBase,OutrasDeducoes,FlagEstorno,DatContabilizacao,DatProvisao,DatRecolhimento,DatPagamento,InsINSS,CodRecolhimentoISS,NomeOperacao,CodMunicipio,CodTipoMunicipio,CodModalidadeServico,RetIss,INss,MovimentaEstoque
FROM Inserted
Go

CREATE TRIGGER Dbo.TRG_Itens_Nota_Fiscal_DELETE_BARLEY ON Dbo.Itens_Nota_Fiscal FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Itens_Nota_Fiscal A 
INNER JOIN Deleted D ON  A.Numnot = D.Numnot And A.Sernot=D.Sernot And A.Tipnot=D.Tipnot And A.Codope=D.Codope And A.Pericm=D.Pericm And A.Codcli=D.Codcli And A.Codmod=D.Codmod And A.Datent=D.Datent And A.Codpro=D.Codpro And A.Tippro=D.Tippro And A.Induni=D.Induni And A.Reg=D.Reg
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Itens_Nota_Fiscal_UPDATE_BARLEY ON Dbo.Itens_Nota_Fiscal FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Itens_Nota_Fiscal A 
INNER JOIN Deleted D ON  A.Numnot = D.Numnot And A.Sernot=D.Sernot And A.Tipnot=D.Tipnot And A.Codope=D.Codope And A.Pericm=D.Pericm And A.Codcli=D.Codcli And A.Codmod=D.Codmod And A.Datent=D.Datent And A.Codpro=D.Codpro And A.Tippro=D.Tippro And A.Induni=D.Induni And A.Reg=D.Reg
WHERE A.CODEMP = '210'
INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Itens_Nota_Fiscal (Codemp,Numnot,Sernot,Tipnot,Codope,Codcli,Codpro,Tippro,Induni,Reg,CodMod,Datnot,Datent,Qtdpro,Valbru,Valdes,Valliq,Valipi,Pericm,Codtri,Univar,Perred,Status,Basicm,Valicm,Bassub,Icmsub,Extope,Valise,Valout,Basipi,Valfre,Valseg,Tipope,Tipoco,IseIpi,OutIpi,Tipopest,Qtd,Valirr,Valinss,Pis,Cofins,CSocial,DifAliq,DifIPI,DifST,Presumido,NFIndust,Codred,tipo,CSLL,Basiss,Periss,Valiss,Media,Valori,Tipopeipi,Peripi,Tipopepis,Perpis,Tipopecof,Percof,IPInaoDebitado,AliqDiferencial,BaseDiferencial,ICMSnaoCreditadoValor,ICMSnaoCreditadoAliquota,CodAntecipacao,ContaContabil,CodImposto,DeducoesBase,OutrasDeducoes,FlagEstorno,DatContabilizacao,DatProvisao,DatRecolhimento,DatPagamento,InsINSS,CodRecolhimentoISS,NomeOperacao,CodMunicipio,CodTipoMunicipio,CodModalidadeServico,RetIss,INss,MovimentaEstoque)
SELECT '210',Numnot,Sernot,Tipnot,Codope,Codcli,Codpro,Tippro,Induni,Reg,CodMod,Datnot,Datent,Qtdpro,Valbru,Valdes,Valliq,Valipi,Pericm,Codtri,Univar,Perred,Status,Basicm,Valicm,Bassub,Icmsub,Extope,Valise,Valout,Basipi,Valfre,Valseg,Tipope,Tipoco,IseIpi,OutIpi,Tipopest,Qtd,Valirr,Valinss,Pis,Cofins,CSocial,DifAliq,DifIPI,DifST,Presumido,NFIndust,Codred,tipo,CSLL,Basiss,Periss,Valiss,Media,Valori,Tipopeipi,Peripi,Tipopepis,Perpis,Tipopecof,Percof,IPInaoDebitado,AliqDiferencial,BaseDiferencial,ICMSnaoCreditadoValor,ICMSnaoCreditadoAliquota,CodAntecipacao,ContaContabil,CodImposto,DeducoesBase,OutrasDeducoes,FlagEstorno,DatContabilizacao,DatProvisao,DatRecolhimento,DatPagamento,InsINSS,CodRecolhimentoISS,NomeOperacao,CodMunicipio,CodTipoMunicipio,CodModalidadeServico,RetIss,INss,MovimentaEstoque
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Nota_Fiscal_Cpl_INSERT_BARLEY ON Dbo.Nota_Fiscal_Cpl FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Nota_Fiscal_Cpl (Codemp,Numnot,Sernot,Tipnot,Codope,Pericm,Codcli,CodMod,Datent,TipFre,CodANTT,Plavei,UFVei,NomTra,EndTra,CidTra,UFTra,CNPJTra,InsTra,QtdVol,Especie,Marca,NumVol,PesBru,PesLiq,MensAdic,MensCpl,Datven,ValFat,Integrado,Impresso,NumNFe,NumDocImp,DatDocImp,LocDesAdu,UFDesAdu,DatDesAdu,BasImp,ValImp,ValDesAdu,IOFImp,CodPais,RefNumNot,RefTipNot,RefCodCli,RefCodMod,RefDatEnt,RefSerNot,InsSubTrib,ContribuinteFinal,ViaTransporte,Desfazimento,DatZFM,ObsZFM,ContaContabil,CodObservacao,CodInformacaoComp,TipoDeclaracao,AliqIRRF,ValIRRF,ValBasINSS,Modelo,AtividadeBasCalRed,CodObservacaoOutras,CodAjuste,DesComplementar,CodItem,NumOrdenacao,sInfo)
SELECT '210',Numnot,Sernot,Tipnot,Codope,Pericm,Codcli,CodMod,Datent,TipFre,CodANTT,Plavei,UFVei,NomTra,EndTra,CidTra,UFTra,CNPJTra,InsTra,QtdVol,Especie,Marca,NumVol,PesBru,PesLiq,MensAdic,MensCpl,Datven,ValFat,Integrado,Impresso,NumNFe,NumDocImp,DatDocImp,LocDesAdu,UFDesAdu,DatDesAdu,BasImp,ValImp,ValDesAdu,IOFImp,CodPais,RefNumNot,RefTipNot,RefCodCli,RefCodMod,RefDatEnt,RefSerNot,InsSubTrib,ContribuinteFinal,ViaTransporte,Desfazimento,DatZFM,ObsZFM,ContaContabil,CodObservacao,CodInformacaoComp,TipoDeclaracao,AliqIRRF,ValIRRF,ValBasINSS,Modelo,AtividadeBasCalRed,CodObservacaoOutras,CodAjuste,DesComplementar,CodItem,NumOrdenacao,sInfo
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Nota_Fiscal_Cpl_DELETE_BARLEY ON Dbo.Nota_Fiscal_Cpl FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Nota_Fiscal_Cpl A 
INNER JOIN Deleted D ON  A.Numnot = D.Numnot And A.Sernot=D.Sernot And A.Tipnot=D.Tipnot And A.Codope=D.Codope And A.Pericm=D.Pericm And A.Codcli=D.Codcli And A.CodMod=D.CodMod And A.Datent=D.Datent
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Nota_Fiscal_Cpl_UPDATE_BARLEY ON Dbo.Nota_Fiscal_Cpl FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Nota_Fiscal_Cpl A 
INNER JOIN Deleted D ON  A.Numnot = D.Numnot And A.Sernot=D.Sernot And A.Tipnot=D.Tipnot And A.Codope=D.Codope And A.Pericm=D.Pericm And A.Codcli=D.Codcli And A.CodMod=D.CodMod And A.Datent=D.Datent
WHERE A.CODEMP = '210'
INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Nota_Fiscal_Cpl (Codemp,Numnot,Sernot,Tipnot,Codope,Pericm,Codcli,CodMod,Datent,TipFre,CodANTT,Plavei,UFVei,NomTra,EndTra,CidTra,UFTra,CNPJTra,InsTra,QtdVol,Especie,Marca,NumVol,PesBru,PesLiq,MensAdic,MensCpl,Datven,ValFat,Integrado,Impresso,NumNFe,NumDocImp,DatDocImp,LocDesAdu,UFDesAdu,DatDesAdu,BasImp,ValImp,ValDesAdu,IOFImp,CodPais,RefNumNot,RefTipNot,RefCodCli,RefCodMod,RefDatEnt,RefSerNot,InsSubTrib,ContribuinteFinal,ViaTransporte,Desfazimento,DatZFM,ObsZFM,ContaContabil,CodObservacao,CodInformacaoComp,TipoDeclaracao,AliqIRRF,ValIRRF,ValBasINSS,Modelo,AtividadeBasCalRed,CodObservacaoOutras,CodAjuste,DesComplementar,CodItem,NumOrdenacao,sInfo)
SELECT '210',Numnot,Sernot,Tipnot,Codope,Pericm,Codcli,CodMod,Datent,TipFre,CodANTT,Plavei,UFVei,NomTra,EndTra,CidTra,UFTra,CNPJTra,InsTra,QtdVol,Especie,Marca,NumVol,PesBru,PesLiq,MensAdic,MensCpl,Datven,ValFat,Integrado,Impresso,NumNFe,NumDocImp,DatDocImp,LocDesAdu,UFDesAdu,DatDesAdu,BasImp,ValImp,ValDesAdu,IOFImp,CodPais,RefNumNot,RefTipNot,RefCodCli,RefCodMod,RefDatEnt,RefSerNot,InsSubTrib,ContribuinteFinal,ViaTransporte,Desfazimento,DatZFM,ObsZFM,ContaContabil,CodObservacao,CodInformacaoComp,TipoDeclaracao,AliqIRRF,ValIRRF,ValBasINSS,Modelo,AtividadeBasCalRed,CodObservacaoOutras,CodAjuste,DesComplementar,CodItem,NumOrdenacao,sInfo
FROM Inserted


GO

CREATE TRIGGER Dbo.TRG_Baixa_Dpl_INSERT_BARLEY ON Dbo.Baixa_Dpl FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Baixa_Dpl (Codemp, Numdup, Codcli, Numpar, Item, Datbai, Tiplan, Datinc, Valbai, Viacob, Tipvia, Tipo, Tiprec, Clirev)
SELECT '210', Numdup, Codcli, Numpar, Item, Datbai, Tiplan, Datinc, Valbai, Viacob, Tipvia, Tipo, Tiprec, Clirev
FROM Inserted

Go

CREATE TRIGGER Dbo.TRG_Baixa_Dpl_DELETE_BARLEY ON Dbo.Baixa_Dpl FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Baixa_Dpl A 
INNER JOIN Deleted D ON  A.Numdup = D.Numdup And A.Numpar=D.Numpar And A.CodCli=D.CodCli And A.Tiplan=D.Tiplan And A.Datinc=D.Datinc And A.Viacob=D.Viacob And A.Tipvia=D.Tipvia
WHERE A.CODEMP = '210'


Go

CREATE TRIGGER Dbo.TRG_Baixa_Dpl_UPDATE_BARLEY ON Dbo.Baixa_Dpl FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Baixa_Dpl A 
INNER JOIN Deleted D ON  A.Numdup = D.Numdup And A.Numpar=D.Numpar And A.CodCli=D.CodCli And A.Tiplan=D.Tiplan And A.Datinc=D.Datinc And A.Viacob=D.Viacob And A.Tipvia=D.Tipvia
WHERE A.CODEMP = '210'


INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Baixa_Dpl (Codemp, Numdup, Codcli, Numpar, Item, Datbai, Tiplan, Datinc, Valbai, Viacob, Tipvia, Tipo, Tiprec, Clirev)
SELECT '210', Numdup, Codcli, Numpar, Item, Datbai, Tiplan, Datinc, Valbai, Viacob, Tipvia, Tipo, Tiprec, Clirev
FROM Inserted




GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[TRG_Duplicata_DELETE_BARLEY] ON [dbo].[Duplicata] FOR DELETE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Duplicata A 
INNER JOIN Deleted D ON  A.Numdup = D.Numdup And A.Nparc=D.Nparc And A.CodCli=D.CodCli And A.Tiplan=D.Tiplan And A.Datinc=D.Datinc And A.Viacob=D.Viacob And A.Tipvia=D.Tipvia
WHERE A.CODEMP = '210'


 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[TRG_Duplicata_INSERT_BARLEY] ON [dbo].[Duplicata] FOR INSERT AS

INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Duplicata (Codemp,numdup,codcli,nparc,Tiplan,datinc,datemi,datven,datqui,valdup,valpag,valjur,valdesc,codven,viacob,tipvia,nbco,nagen,percom,tiprec,datche,numche,numdig,nummap,numped,alinea,numnot,valbai,datbai,venant,rotcli,maquina,ncomp,nc1,nconta,nc2,nc3,Codred,Lote,DatIncRev,LoteRev,Tippes,Tipinc,CgcPes,SitInad,ValProDes,ValProAcr)
SELECT '210',numdup,codcli,nparc,Tiplan,datinc,datemi,datven,datqui,valdup,valpag,valjur,valdesc,codven,viacob,tipvia,nbco,nagen,percom,tiprec,datche,numche,numdig,nummap,numped,alinea,numnot,valbai,datbai,venant,rotcli,maquina,ncomp,nc1,nconta,nc2,nc3,Codred,Lote,DatIncRev,LoteRev,Tippes,Tipinc,CgcPes,SitInad,ValProDes,ValProAcr
FROM Inserted

 
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[TRG_Duplicata_UPDATE_BARLEY] ON [dbo].[Duplicata] FOR UPDATE AS

DELETE A FROM FIN210_BARLEY_JUNCAO.Dbo.Duplicata A 
INNER JOIN Deleted D ON  A.Numdup = D.Numdup And A.Nparc=D.Nparc And A.CodCli=D.CodCli And A.Tiplan=D.Tiplan And A.Datinc=D.Datinc And A.Viacob=D.Viacob And A.Tipvia=D.Tipvia
WHERE A.CODEMP = '210'


INSERT INTO FIN210_BARLEY_JUNCAO.Dbo.Duplicata (Codemp,numdup,codcli,nparc,Tiplan,datinc,datemi,datven,datqui,valdup,valpag,valjur,valdesc,codven,viacob,tipvia,nbco,nagen,percom,tiprec,datche,numche,numdig,nummap,numped,alinea,numnot,valbai,datbai,venant,rotcli,maquina,ncomp,nc1,nconta,nc2,nc3,Codred,Lote,DatIncRev,LoteRev,Tippes,Tipinc,CgcPes,SitInad,ValProDes,ValProAcr)
SELECT '210',numdup,codcli,nparc,Tiplan,datinc,datemi,datven,datqui,valdup,valpag,valjur,valdesc,codven,viacob,tipvia,nbco,nagen,percom,tiprec,datche,numche,numdig,nummap,numped,alinea,numnot,valbai,datbai,venant,rotcli,maquina,ncomp,nc1,nconta,nc2,nc3,Codred,Lote,DatIncRev,LoteRev,Tippes,Tipinc,CgcPes,SitInad,ValProDes,ValProAcr
FROM Inserted



GO


