declare @DateLoggedStart datetime
declare @DateLoggedEnd datetime
declare @Local int

set @DateLoggedStart = '2010-03-01'
set @DateLoggedEnd = '2010-03-18'
set @Local = 0

SELECT	OperatorId, 
		count([0]) AS [Default], 
		count([1]) AS HightFriction, 
		count([2]) AS Dissatisfied, 
		count([3]) AS Satisfied, 
		count([4]) AS VerySatisfied, 
		count([21]) AS Procom
FROM HipercardUmagnetEndCallLog WITH (NOLOCK)
PIVOT (SUM(BusinessObjectId) FOR OldSmile IN ([0], [1], [2], [3], [4], [21])) AS P
WHERE LogDate BETWEEN (@DateLoggedStart) AND (@DateLoggedEnd)
GROUP BY OperatorId
ORDER BY OperatorId
