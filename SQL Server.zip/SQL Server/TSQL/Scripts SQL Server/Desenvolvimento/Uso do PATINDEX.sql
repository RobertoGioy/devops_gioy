DECLARE @SchemaName			SYSNAME,
		@SourceTable		SYSNAME,
		@DestinationTable	SYSNAME,
		@PartitionScheme	VARCHAR(255), 
		@PartitionFunction	VARCHAR(255), 
		@DropCommand		NVARCHAR (MAX),
		@CreateCommand		NVARCHAR (MAX),
		@FirstCommand		NVARCHAR (MAX),
		@LastCommand		NVARCHAR (MAX),
		@NewCommand			NVARCHAR (MAX)

CREATE TABLE #Table (comando nvarchar(max) )

DECLARE INDEXCURSOR CURSOR LOCAL FOR
SELECT	[SchemaName],
		[SourceTable],
		[DestinationTable],
		[PartitionScheme],
		[PartitionFunction],
		[DropCommand],
		[CreateCommand]
  FROM [Support].[PartitionedTables]
ORDER BY 1


OPEN INDEXCURSOR
FETCH NEXT FROM INDEXCURSOR INTO 
		@SchemaName,			
		@SourceTable,		
		@DestinationTable,
		@PartitionScheme,
		@PartitionFunction,
		@DropCommand,	
		@CreateCommand		
WHILE @@FETCH_STATUS = 0
BEGIN
	SET		@FirstCommand = SUBSTRING(@DropCommand, 0, CHARINDEX('= N',@DropCommand) + 4) 
	SELECT	@LastCommand = value FROM [dbo].[fnSplit](@DropCommand, '= N') ORDER BY value DESC
	SELECT	@LastCommand = substring(@LastCommand,PATINDEX('%)%',@LastCommand)+1,LEN(@LastCommand))
	SET		@NewCommand = @FirstCommand + '''' + @DestinationTable + ''''')' + @LastCommand
	
	INSERT INTO #Table 
	VALUES (
		'INSERT INTO [Support].[PartitionedTables]([SchemaName],[SourceTable],[DestinationTable],[PartitionScheme],[PartitionFunction],[DropCommand],[CreateCommand],[LastUpdate])
		VALUES (''' + @SchemaName + ''',''' + @SourceTable + ''',''' + @DestinationTable + ''',''' + @PartitionScheme + ''',''' + @PartitionFunction + ''',''' + @NewCommand  + ''',''' + @CreateCommand + ''', ''' + CONVERT(VARCHAR,GETDATE(),120) + ''') '
	)

	FETCH NEXT FROM INDEXCURSOR INTO
		@SchemaName,			
		@SourceTable,		
		@DestinationTable,
		@PartitionScheme,
		@PartitionFunction,
		@DropCommand,	
		@CreateCommand
END

CLOSE INDEXCURSOR
DEALLOCATE INDEXCURSOR

SELECT * FROM #Table

DROP TABLE #Table

