select convert(varchar(5), [s-ip], 108) as horario, [cs-uri-query], count(*) as n, 
	count(all case when [time-taken] < 3000 then null else [time-taken] end) as moreThan3000, 
	count(all case when [time-taken] < 7000 then null else [time-taken] end) as moreThan7000, 
	AVG([time-taken]) as average, min([time-taken]) as min, max([time-taken]) as max
from Pasta3
group by convert(varchar(5), [s-ip], 108), [cs-uri-query]
order by horario

select convert(varchar(5), [s-ip], 108) as horario, count(*) as n, 
	count(all case when [time-taken] < 3000 then null else [time-taken] end) as moreThan3000, 
	count(all case when [time-taken] < 7000 then null else [time-taken] end) as moreThan7000, 
	AVG([time-taken]) as average, min([time-taken]) as min, max([time-taken]) as max
from Pasta3
group by convert(varchar(5), [s-ip], 108)
order by horario

