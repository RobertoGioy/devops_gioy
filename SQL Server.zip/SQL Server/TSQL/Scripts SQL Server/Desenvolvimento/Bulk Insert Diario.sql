DECLARE @SchemaName SYSNAME
DECLARE @TableName	SYSNAME
DECLARE @DayID		INT
DECLARE @DayName	VARCHAR(20)
DECLARE @FileDate	VARCHAR(10)

SELECT @FileDate = CASE DATEPART(DW, GETDATE())
	WHEN 1 THEN '2011-05-01'
	WHEN 2 THEN '2011-05-02'
	WHEN 3 THEN '2011-05-03'
	WHEN 4 THEN '2011-05-04'
	WHEN 5 THEN '2011-05-05'
	WHEN 6 THEN '2011-05-06'
	WHEN 7 THEN '2011-05-07'
END 

SELECT @DayName = CASE DATEPART(DW, GETDATE())
	WHEN 1 THEN 'Domingo'
	WHEN 2 THEN 'Segunda'
	WHEN 3 THEN 'Terca'
	WHEN 4 THEN 'Quarta'
	WHEN 5 THEN 'Quinta'
	WHEN 6 THEN 'Sexta'
	WHEN 7 THEN 'Sabado'
END

SELECT @DayID = CASE DATEPART(DW, GETDATE())
	WHEN 1 THEN 7
	WHEN 2 THEN 1
	WHEN 3 THEN 2
	WHEN 4 THEN 3
	WHEN 5 THEN 4
	WHEN 6 THEN 5
	WHEN 7 THEN 6
END

DECLARE TableCursor CURSOR FOR
SELECT TABLE_SCHEMA, TABLE_NAME  
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = N'Udial' AND TABLE_NAME LIKE '%Log' AND TABLE_NAME NOT IN ('IvrLog', 'CellLog')
ORDER BY TABLE_NAME

OPEN TableCursor
FETCH NEXT FROM TableCursor INTO @SchemaName, @TableName

WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE @Code NVARCHAR(MAX) 
	
	SET @Code = '
	DECLARE @MaxLogID	BIGINT
	DECLARE @MaxDate	DATETIME
	DECLARE @Days		INT '

	SET @Code = @Code + '
	SELECT @MaxLogID = MAX(LogID) FROM [' + @SchemaName + '].[' +  @TableName + '] '
	
	SET @Code = @Code + '
	SELECT @MaxDate = DATEADD(DD, 1, MAX(LogDate)) FROM [' + @SchemaName + '].[' +  @TableName + '] WHERE DATEPART(DW,LogDate) = ' + CONVERT(VARCHAR,@DayID) + ' '
	
	SET @Code = @Code + '
	SELECT @Days = DATEDIFF(DD, ''' + @FileDate + ''', @MaxDate) '
	
	SET @Code = @Code + '
	BULK INSERT [' + @SchemaName + '].[' +  @TableName + ']
	FROM ''C:\bcp\' + @DayName + '_' + @TableName + '.txt''
	WITH (
	FIRSTROW = 1,
	FIELDTERMINATOR = ''\t'',
	FORMATFILE = ''C:\bcp\formatos\' + @TableName + '-c.fmt''); '
	
	SET @Code = @Code + '
	UPDATE [' + @SchemaName + '].[' +  @TableName + '] SET LogDate = DATEADD(DD, @Days, LogDate) WHERE LogID > @MaxLogID '
	
	EXEC sp_executesql @Code
	
	FETCH NEXT FROM TableCursor INTO @SchemaName, @TableName
END

CLOSE TableCursor
DEALLOCATE TableCursor