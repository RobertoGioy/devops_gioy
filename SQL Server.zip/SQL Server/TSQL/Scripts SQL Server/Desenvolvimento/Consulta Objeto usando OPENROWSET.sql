SELECT * 
FROM OPENROWSET('ADSDSOObject', '','SELECT name,whenCreated,userAccountControl FROM ''LDAP://FRS'' where objectclass = ''user'' AND name=''*ger*105*''') 
