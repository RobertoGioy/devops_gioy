USE [MagazineLuizaServerDev]
SELECT		SUBSTRING([SecundaryLogin], CHARINDEX('@', [SecundaryLogin])+1, LEN([SecundaryLogin])) As Provedor,
			RIGHT(CONVERT(VARCHAR, [LogDate], 103), 7) As Mes,
			COUNT([LogID]) AS 'Transations'
INTO		#tmp
FROM		[Uweb].[AnalysisOneHourLog] 
WHERE		[InteractionType] = 'Transaction'
GROUP BY	SUBSTRING([SecundaryLogin], CHARINDEX('@', [SecundaryLogin])+1, LEN([SecundaryLogin])),
			RIGHT(CONVERT(VARCHAR, [LogDate], 103), 7)
ORDER BY	Provedor, Mes

Declare @PivotCols Varchar(2000)    
Set @PivotCols=''
Select @PivotCols=(Select DISTINCT '[' + RIGHT(CONVERT(VARCHAR, [LogDate], 103), 7) +'],' from [Uweb].[AnalysisOneHourLog] for Xml Path(''))
Set @PivotCols=SUBSTRING(@PivotCols,1,len(@PivotCols)-1)


exec ('SELECT * FROM #tmp PIVOT (SUM(Transations) FOR Mes IN (' + @PivotCols + ')) AS P')
GO

drop table #tmp