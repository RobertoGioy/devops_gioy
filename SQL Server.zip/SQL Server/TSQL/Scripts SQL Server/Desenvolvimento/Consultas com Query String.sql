SET QUOTED_IDENTIFIER OFF 

DECLARE @CMD VARCHAR(MAX)

DECLARE @base sysname, @reg int, @tot int

create table #temp1 (Base1 Varchar(max))
create table #temp (Servidor Varchar(max), Base Varchar(max), empresa Varchar(max))


SET @CMD = 
"
declare @wcodemp char (3)
declare @wEst  char (2)
declare @wTerc char(1)
declare CursorEmp cursor for 
select e.CODEMP,e.ESTEMP,cfg.terc from  empresas e
inner join config cfg on e.codemp= cfg.codemp
Open CursorEmp 
fetch next from  CursorEmp into @wcodemp,@west,@wTerc
WHILE @@Fetch_Status = 0
  BEGIN
	 if (@West in ('MG','GO','RO','AC','RJ')	and @wterc <>'C')
	   -- Print bloqueia
	   insert into parametros values (@wcodemp,'BloqReq','Bloqueia acesso a tela de requisi��o','True','boolean')
	  else
	   insert into parametros values (@wcodemp,'BloqReq','Bloqueia acesso a tela de requisi��o','False','boolean')
	   -- Print 'libera'
	 FETCH NEXT FROM CursorEmp into @wcodemp,@west,@wterc
  End
  CLOSE CursorEmp
DEALLOCATE CursorEmp
"

set @tot = (select count(name) as Reg from sys.sysdatabases where not name in ('Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','EMPDCA','EMPDCAB','DC','FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%')and not name like ('%SPED%'))

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where not name in ('Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','EMPDCA','EMPDCAB','DC','FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%')and not name like ('%SPED%')) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
	IF not (select OBJECT_ID ('Mov_Estoque2')) IS NULL
		if (select count(*) from sysobjects o inner join syscolumns c on o.id = c.id where o.name = 'Config' and c.name = 'Terc' ) > 0
			exec('if (select count(*) from config where terc <> ''C'' ) > 0
				INSERT into #temp1 SELECT ""[" + @base + "]"" ')
	")
	set @reg = @reg + 1
	end

update #temp1 set base1 = replace(replace(base1,'[',''),']','')



set @tot = (select count(name) as Reg from sys.sysdatabases where name in (select base1 from #Temp1) and not name in ('Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','EMPDCA','EMPDCAB','DC','FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%')and not name like ('%SPED%'))

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where name in (select base1 from #Temp1) and not name in ('Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','EMPDCA','EMPDCAB', 'DC', 'FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%')and not name like ('%SPED%')) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
		IF not (select OBJECT_ID ('mov_estoque2')) IS NULL 
			begin
					begin try
						EXEC (""" + @CMD + """) 
      					INSERT into #temp SELECT distinct @@servername as Servidor, ""[" + @base + "]"" as Base, '' as empresa
					end try
				begin catch
       				INSERT into #temp SELECT distinct '(' + ERROR_MESSAGE() +') ' + @@servername as Servidor, ""[" + @base + "]"" as Base, '' as empresa
				end catch
			end	
	")
	
	set @reg = @reg + 1
	end
	
SELECT Servidor, Base, empresa FROM #temp
