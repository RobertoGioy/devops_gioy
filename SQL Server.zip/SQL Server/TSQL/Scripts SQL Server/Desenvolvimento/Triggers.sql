--====================================================
-- TRIGGERS - de DML (Data Manipulation Language)
--     Triggers s�o rotinas executadas automaticamente 
--     pelo banco de dados. Um trigger pode ser executado
--     em 3 situa��es:
--			DELETE e/ou INSERT e/ou UPDATE
--====================================================
USE PEDIDOS;


CREATE TABLE EMPREGADOS_HIST_SALARIO
( NUM_MOVTO			INT IDENTITY,
  CODFUN		    INT,
  DATA_ALTERACAO	DATETIME,
  SALARIO_ANTIGO	NUMERIC(12,2),	
  SALARIO_NOVO		NUMERIC(12,2),
  CONSTRAINT PK_EMPREGADOS_HIST_SALARIO
    PRIMARY KEY (NUM_MOVTO) )
GO    
--------------------------------------------------------    
-- Griar trigger para cadastrar hit�rico de reajuste de sal�rio
CREATE TRIGGER TRG_EMPREGADOS_HIST_SALARIO ON EMPREGADOS
  FOR UPDATE
AS BEGIN  
-- Declarar vari�veis auxiliares
DECLARE @CODFUN INT, @SALARIO_ANTIGO FLOAT, @SALARIO_NOVO FLOAT;
-- Descobrir qual era o sal�rio antes da altera��o
SELECT @SALARIO_ANTIGO = SALARIO FROM DELETED;
-- Descobrir qual � o sal�rio ap�s a altera��o
SELECT @CODFUN = CODFUN, @SALARIO_NOVO = SALARIO
FROM INSERTED;
-- Se houve altera��o de salario, gravar na tabela de hist�rico
IF @SALARIO_ANTIGO <> @SALARIO_NOVO
   INSERT INTO EMPREGADOS_HIST_SALARIO
   VALUES (@CODFUN, GETDATE(), @SALARIO_ANTIGO, @SALARIO_NOVO)
END
GO
-- Testando
UPDATE EMPREGADOS SET SALARIO = SALARIO * 1.2
WHERE CODFUN = 3
--
SELECT * FROM EMPREGADOS_HIST_SALARIO 
-- Observe que foi inserido na tabela o registro referente a altera��o efetuada

-- Vamos fazer agora uma altera��o de sal�rio "em lote"
UPDATE EMPREGADOS SET SALARIO = SALARIO * 1.2
WHERE CODFUN IN (4,5,7)
-- Confira se foram gerados os hist�ricos para os 3 funcion�rios
SELECT * FROM EMPREGADOS_HIST_SALARIO 
-- RESPOSTA : N�O
GO
--------------------------------------------------------------
-- Alterar o TRIGGER de modo a processar altera��es em lote
ALTER TRIGGER TRG_EMPREGADOS_HIST_SALARIO ON EMPREGADOS
  FOR UPDATE
AS BEGIN 
   INSERT INTO EMPREGADOS_HIST_SALARIO
   (CODFUN, DATA_ALTERACAO, SALARIO_ANTIGO, SALARIO_NOVO)
   SELECT I.CODFUN, GETDATE(), D.SALARIO, I.SALARIO
   FROM INSERTED I JOIN DELETED D ON I.CODFUN = D.CODFUN
   WHERE I.SALARIO <> D.SALARIO;
END
GO
-- Testando
DELETE FROM EMPREGADOS_HIST_SALARIO 

UPDATE EMPREGADOS SET SALARIO = SALARIO * 1.2
WHERE CODFUN IN (4,5,7)
--
SELECT * FROM EMPREGADOS_HIST_SALARIO 
--
UPDATE EMPREGADOS SET NUM_DEPEND=2
WHERE CODFUN = 1
GO
----------------------------------------------------
-- Criar tabela para armazenar hist�rico de reajuste
-- de pre�o (PRECO_VENDA) da tabela PRODUTOS
CREATE TABLE PRODUTOS_HIST_PRECO
( NUM_MOVTO			INT IDENTITY,
  ID_PRODUTO		    INT,
  DATA_ALTERACAO	DATETIME,
  PRECO_ANTIGO	NUMERIC(12,4),	
  PRECO_NOVO		NUMERIC(12,4),
  CONSTRAINT PK_PRODUTOS_HIST_PRECO
    PRIMARY KEY (NUM_MOVTO) )
GO    
--------------------------------------------------------
-- Criar trigger para PRODUTOS que seja executado sempre
-- que ocorrer altera��o de registro. Deve inserir dados
-- na tabela de hist�rico se houve altera��o de PRECO_VENDA
CREATE TRIGGER TRG_PRODUTOS_HIST_PRECO ON PRODUTOS
   FOR UPDATE
AS BEGIN   

INSERT INTO PRODUTOS_HIST_PRECO
(ID_PRODUTO, DATA_ALTERACAO, PRECO_ANTIGO, PRECO_NOVO)
SELECT I.ID_PRODUTO, GETDATE(), D.PRECO_VENDA, I.PRECO_VENDA
FROM INSERTED I JOIN DELETED D ON I.ID_PRODUTO = D.ID_PRODUTO
WHERE I.PRECO_VENDA <> D.PRECO_VENDA;

END
GO
--- TESTANDO
UPDATE PRODUTOS SET PRECO_VENDA = PRECO_VENDA * 1.5
WHERE COD_TIPO = 2
--
SELECT * FROM PRODUTOS_HIST_PRECO
GO
---------------------------------------------------
-- Criar Trigger para recalcular o valor total do
-- pedido (PEDIDOS.VLR_TOTAL) quando um item de 
-- pedido (ITENSPEDIDO) for alterado, inclu�do ou
-- exclu�do.
---------------------------------------------------
CREATE TRIGGER TRG_CORRIGE_VLR_TOTAL ON ITENSPEDIDO
   FOR DELETE, INSERT, UPDATE
AS BEGIN
-- Se o trigger foi executado por DELETE
IF NOT EXISTS( SELECT * FROM INSERTED )
   UPDATE PEDIDOS
   SET VLR_TOTAL = (SELECT SUM( PR_UNITARIO * QUANTIDADE *
                                ( 1 - DESCONTO/100 ) )
                    FROM ITENSPEDIDO
                    WHERE NUM_PEDIDO = P.NUM_PEDIDO)
   FROM PEDIDOS P JOIN DELETED D
        ON P.NUM_PEDIDO = D.NUM_PEDIDO
-- Se foi executado por INSERT ou UPDATE
ELSE -- COMPLETE
   UPDATE PEDIDOS
   SET VLR_TOTAL = (SELECT SUM( PR_UNITARIO * QUANTIDADE *
                                ( 1 - DESCONTO/100 ) )
                    FROM ITENSPEDIDO
                    WHERE NUM_PEDIDO = P.NUM_PEDIDO)
   FROM PEDIDOS P JOIN INSERTED I
        ON P.NUM_PEDIDO = I.NUM_PEDIDO
END
GO
-- Testando
SELECT * FROM PEDIDOS WHERE NUM_PEDIDO = 1000
-- Pedido 1000 -> VLR_TOTAL = 380
SELECT * FROM ITENSPEDIDO WHERE NUM_PEDIDO = 1000
-- Possui um �nico item com PR_UNITARIO = 1
UPDATE ITENSPEDIDO SET PR_UNITARIO = 2
WHERE NUM_PEDIDO = 1000
--
SELECT * FROM PEDIDOS WHERE NUM_PEDIDO = 1000
-- VLR_TOTAL = 760
GO

-----------------------------------------------------
-- EXERC�CIO:
-- Criar trigger TRG_ITENSPEDIDO_CORRIGE_ESTOQUE
-- para DELETE, INSERT, UPDATE. Ele deve:
CREATE TRIGGER TRG_ITENSPEDIDO_CORRIGE_ESTOQUE ON ITENSPEDIDO
   FOR DELETE, INSERT, UPDATE
AS BEGIN
--  .SE o trigger foi executado por "culpa" de INSERT
--      .Subtrair de PRODUTOS.QTD_REAL a QUANTIDADE do
--       item que foi inserido
IF NOT EXISTS(SELECT * FROM DELETED)
   UPDATE PRODUTOS
   SET QTD_REAL = P.QTD_REAL - I.QUANTIDADE
   FROM PRODUTOS P 
        JOIN INSERTED I ON P.ID_PRODUTO = I.ID_PRODUTO
--  .SE o trigger foi executado por "culpa" de DELETE
--      .Somar em PRODUTOS.QTD_REAL a QUANTIDADE do
--       item que foi deletado
ELSE IF NOT EXISTS(SELECT * FROM INSERTED)
   UPDATE PRODUTOS
   SET QTD_REAL = P.QTD_REAL + D.QUANTIDADE
   FROM PRODUTOS P 
        JOIN DELETED D ON P.ID_PRODUTO = D.ID_PRODUTO
--  .SE o trigger foi executado por "culpa" de UPDATE
--      .Somar em PRODUTOS.QTD_REAL o valor resultante
--       de (DELETED.QUANTIDADE - INSERTED.QUANTIDADE)
ELSE -- COMPLETE 
   UPDATE PRODUTOS
   SET QTD_REAL = P.QTD_REAL + (D.QUANTIDADE - I.QUANTIDADE)
   FROM PRODUTOS P 
        JOIN INSERTED I ON P.ID_PRODUTO = I.ID_PRODUTO
        JOIN DELETED D ON P.ID_PRODUTO = D.ID_PRODUTO

END
-----------------------------------------------------

-- Testando
SELECT * FROM ITENSPEDIDO WHERE NUM_PEDIDO = 1000
-- 1 item do produto ID_PRODUTO = 12 
-- QUANTIDADE = 400
SELECT ID_PRODUTO, QTD_REAL FROM PRODUTOS
WHERE ID_PRODUTO = 12
-- Produdo 12 -> QTD_REAL = 4372
UPDATE ITENSPEDIDO
SET QUANTIDADE = 200 WHERE NUM_PEDIDO = 1000
--
SELECT ID_PRODUTO, QTD_REAL FROM PRODUTOS
WHERE ID_PRODUTO = 12
GO
-- Produdo 12 -> QTD_REAL = 6372
--=================================================
-- Triggers do tipo INSTEAD OFF
ALTER TABLE CLIENTES 
ADD SN_ATIVO CHAR(1) NOT NULL DEFAULT 'S'
GO
-- Criar Trigger do tipo INSTEAD OF DELETE que grave 'N' no campo
CREATE TRIGGER TRG_CLIENTES_DESATIVA ON CLIENTES
   INSTEAD OF DELETE
AS BEGIN
  UPDATE CLIENTES SET SN_ATIVO = 'N'
  FROM CLIENTES C JOIN DELETED D ON C.CODCLI = D.CODCLI
END
GO
-- TESTANDO
SELECT CODCLI, NOME, SN_ATIVO FROM CLIENTES
--
DELETE FROM CLIENTES WHERE CODCLI IN (4,7,11)
--
SELECT CODCLI, NOME, SN_ATIVO FROM CLIENTES
----------------------------------------------------------
-- Fa�a o mesmo para as tabelas VENDEDORES e PRODUTOS
ALTER TABLE VENDEDORES
ADD SN_ATIVO CHAR(1) NOT NULL DEFAULT 'S'
GO
ALTER TABLE PRODUTOS 
ADD SN_ATIVO CHAR(1) NOT NULL DEFAULT 'S'
GO
CREATE TRIGGER TRG_VENDEDORES_DESATIVA ON CLIENTES
   INSTEAD OF DELETE
AS BEGIN
  UPDATE VENDEDORES SET SN_ATIVO = 'N'
  FROM VENDEDORES V JOIN DELETED D ON V.CODVEN = D.CODVEN
END
GO
CREATE TRIGGER TRG_PRODUTOS_DESATIVA ON CLIENTES
   INSTEAD OF DELETE
AS BEGIN
  UPDATE PRODUTOS SET SN_ATIVO = 'N'
  FROM PRODUTOS P JOIN DELETED D ON P.ID_PRODUTO = D.ID_PRODUTO
END
GO






--====================================================
-- Desabilitar um TRIGGER
ALTER TABLE CLIENTES
DISABLE TRIGGER TRG_CLIENTES_DESATIVA

-- Reabilitar um TRIGGER
ALTER TABLE CLIENTES
ENABLE TRIGGER TRG_CLIENTES_DESATIVA
GO
--====================================================
-- TRIGGER de DDL (Data Definition Language)
-- CREATE ____, ALTER ____, DROP ____
-- ou DDL_DATABASE_LEVEL_EVENTS
------------------------------------------------------
-- Vers�o 1
CREATE TRIGGER TRG_LOG_BANCO 
   ON  DATABASE  -- ALL SERVER
   FOR DDL_DATABASE_LEVEL_EVENTS
AS BEGIN
DECLARE @DATA XML;
-- Recupera todas as informa��e sobre o motivo da
-- execu��o do trigger
SET @DATA = EVENTDATA();
-- Transforma o tipo XML em VARCHAR
PRINT CAST( @DATA AS VARCHAR(5000) );
END
GO
-- Testando
CREATE TABLE TESTE ( COD INT, NOME VARCHAR(30) )
GO
/*
<EVENT_INSTANCE>
    <EventType>CREATE_TABLE</EventType>
    <PostTime>2009-09-27T15:47:37.637</PostTime>
    <SPID>52</SPID>
    <ServerName>P38_INSTRUTOR</ServerName>
    <LoginName>PAULISTA38\Administrator</LoginName>
    <UserName>dbo</UserName>
    <DatabaseName>PEDIDOS</DatabaseName>
    <SchemaName>dbo</SchemaName>
    <ObjectName>TESTE</ObjectName>
    <ObjectType>TABLE</ObjectType>
    <TSQLCommand>
       <SetOptions ANSI_NULLS="ON" ANSI_NULL_DEFAULT="ON" ANSI_PADDING="ON" QUOTED_IDENTIFIER="ON" ENCRYPTED="FALSE"/>
      <CommandText>
         CREATE TABLE TESTE ( COD INT, NOME VARCHAR(30) )&#x0D;
      </CommandText>
    </TSQLCommand>
</EVENT_INSTANCE>
*/


------------------------------------------------------
-- Vers�o 2
ALTER TRIGGER TRG_LOG_BANCO 
   ON  DATABASE
   FOR DDL_DATABASE_LEVEL_EVENTS
AS BEGIN
DECLARE @DATA XML, @MSG VARCHAR(5000);
-- Recupera todas as informa��e sobre o motivo da
-- execu��o do trigger
SET @DATA = EVENTDATA();

SET @MSG = @DATA.value('(/EVENT_INSTANCE/EventType)[1]',
                        'Varchar(100)');
PRINT @MSG;

SET @MSG = @DATA.value('(/EVENT_INSTANCE/ObjectType)[1]',
                        'Varchar(100)');
PRINT @MSG;

SET @MSG = @DATA.value('(/EVENT_INSTANCE/ObjectName)[1]',
                        'Varchar(100)');
PRINT @MSG;

SET @MSG = @DATA.value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]',
                        'Varchar(8000)');
           
PRINT @MSG;

END
GO
---- TESTANDO
DROP TABLE TESTE
CREATE TABLE TESTE ( COD INT, NOME VARCHAR(30) )
ALTER TABLE TESTE ADD E_MAIL VARCHAR(100)
GO
------------------------------------------------------
CREATE TABLE TAB_LOG_BANCO
(
	ID				INT IDENTITY PRIMARY KEY,
    EventType		VARCHAR(100),
	PostTime		VARCHAR(50),
	UserName		VARCHAR(100),
	ObjectType		VARCHAR(100),
	ObjectName		VARCHAR(300),
    CommandText		Text 
)
GO
--------------------------------------------------------
-- Vers�o 3: O trigger deve inserir na tabela TAB_LOG_BANCO
--           as informa��es recuperadas por EVENTDATA()
ALTER TRIGGER TRG_LOG_BANCO ON  DATABASE
   FOR DDL_DATABASE_LEVEL_EVENTS
AS BEGIN
DECLARE @DATA XML;
-- Recupera todas as informa��e sobre o motivo da
-- execu��o do trigger
SET @DATA = EVENTDATA();

INSERT INTO TAB_LOG_BANCO
(EventType, PostTime, UserName, ObjectType, ObjectName,
 CommandText )
VALUES
(
@DATA.value('(/EVENT_INSTANCE/EventType)[1]','Varchar(100)'),
@DATA.value('(/EVENT_INSTANCE/PostTime)[1]','Varchar(100)'),
@DATA.value('(/EVENT_INSTANCE/UserName)[1]','Varchar(100)'),
@DATA.value('(/EVENT_INSTANCE/ObjectType)[1]','Varchar(100)'),
@DATA.value('(/EVENT_INSTANCE/ObjectName)[1]','Varchar(300)'),
@DATA.value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]',
            'Varchar(8000)')
) 	
END
---- TESTANDO
DROP TABLE TESTE
CREATE TABLE TESTE ( COD INT, NOME VARCHAR(30) )
ALTER TABLE TESTE ADD E_MAIL VARCHAR(100)
--
SELECT * FROM TAB_LOG_BANCO

SELECT * FROM SYSOBJECTS WHERE XTYPE = 'TR'
-- ID : ID do trigger
-- PARENT_OBJ: tabela dona do trigger

SELECT TR.NAME AS NOME_TRIGGER, T.NAME AS TABELA,
       CM.TEXT AS COMANDO
FROM SYSOBJECTS TR 
     JOIN SYSOBJECTS T ON TR.PARENT_OBJ = T.ID
     JOIN SYSCOMMENTS CM ON TR.ID = CM.ID
WHERE TR.XTYPE = 'TR'
