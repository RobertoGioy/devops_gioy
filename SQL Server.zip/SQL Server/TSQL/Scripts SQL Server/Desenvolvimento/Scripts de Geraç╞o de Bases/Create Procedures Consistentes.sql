/*
	AUTHOR:			JOS� ROBERTO
	DESCRIPTION:	CRIA AS PROCEDURES DO BANCO DE DADOS ADICIONANDO AS CONSIST�NCIAS DE VERIFICA��O
*/


DECLARE @procedureName	NVARCHAR(100), 
		@schemaName		NVARCHAR(50), 
		@procedureText	VARCHAR(MAX), 
		@consistence	VARCHAR(MAX),
		@CurrentEnd		BIGINT, /* track the length of the next substring */
        @offset			TINYINT /*tracks the amount of offset needed */

DECLARE PROC_CURSOR CURSOR FOR
SELECT [name], SCHEMA_NAME([schema_id]) AS SchemaName 
FROM sys.procedures 
ORDER BY [name]

OPEN PROC_CURSOR
FETCH NEXT FROM PROC_CURSOR INTO @procedureName, @schemaName

WHILE @@FETCH_STATUS = 0
BEGIN
	WITH CTE AS (
		SELECT STUFF((
			SELECT	[text]
			FROM	syscomments sysco INNER JOIN sys.procedures syssp
			ON		syssp.object_id = sysco.id
			WHERE	syssp.name = @procedureName AND syssp.schema_id = schema_id(@schemaName)
			FOR XML PATH ('')), 1, 0, ''
		) AS P
	)
	SELECT @procedureText = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(P, '<text>', ''), '&#x0D;', ''), '</text>', ''), '&lt;' , '<'), '&gt;', '>')  FROM CTE
	
	SET @consistence = CHAR(13) + CHAR(10) + 
	'IF EXISTS (SELECT * FROM sys.procedures WHERE name = N''' + @procedureName + ''' AND SCHEMA_ID = SCHEMA_ID(''' + @schemaName + '''))' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'DROP PROCEDURE [' + @schemaName + '].[' + @procedureName + ']' + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10) +
	'PRINT ''Creating procedure [' + @schemaName + '].[' + @procedureName + '] ...''' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10)
	
	SET @procedureText = @procedureText + CHAR(13) + CHAR(10) + 'GO'
	
	PRINT @consistence
	
	WHILE LEN(@procedureText) > 1
	BEGIN
		IF CHARINDEX(CHAR(10), @procedureText) between 1 AND 4000
		BEGIN
           SET @CurrentEnd =  CHARINDEX(CHAR(10), @procedureText) -1
           SET @offset = 2
		END
		ELSE
		BEGIN
			SET @CurrentEnd = 4000
			SET @offset = 1
		END 
		
		PRINT SUBSTRING(@procedureText, 1, @CurrentEnd) 
		
		SET @procedureText = SUBSTRING(@procedureText, @CurrentEnd+@offset, 1073741822)
	END
	
	SET @consistence = ''
	SET @procedureText = ''
	
	FETCH NEXT FROM PROC_CURSOR INTO @procedureName, @schemaName	
END

CLOSE PROC_CURSOR
DEALLOCATE PROC_CURSOR