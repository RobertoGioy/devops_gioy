DECLARE @functionName	VARCHAR(100),
		@schemaName		VARCHAR(50),
		@functionText	VARCHAR(MAX),
		@consistence	VARCHAR(MAX),
		@CurrentEnd		BIGINT, /* track the length of the next substring */
        @offset			TINYINT /*tracks the amount of offset needed */

DECLARE FUNCTION_CURSOR CURSOR FOR
SELECT	[name], SCHEMA_NAME([schema_id]) AS SchemaName 
FROM	sys.objects
WHERE	[type] IN (N'FN', N'IF', N'TF', N'FS', N'FT') AND [name] NOT LIKE ('%diagram%')
ORDER BY [name]

OPEN FUNCTION_CURSOR
FETCH NEXT FROM FUNCTION_CURSOR INTO @functionName, @schemaName

WHILE @@FETCH_STATUS = 0
BEGIN
	WITH CTE AS (
		SELECT STUFF((
			SELECT	[text]
			FROM	syscomments sysco INNER JOIN sys.objects sysobj
			ON		sysobj.object_id = sysco.id
			WHERE	sysobj.name = @functionName AND sysobj.name NOT LIKE '%diagram%' AND sysobj.schema_id = schema_id('dbo')
			FOR XML PATH ('')), 1, 0, ''
		) AS P
	)
	SELECT @functionText = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(P, '<text>', ''), '&#x0D;', ''), '</text>', ''), '&lt;' , '<'), '&gt;', '>')  FROM CTE
	
	SET @consistence = CHAR(13) + CHAR(10) + 
	'IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[' + @schemaName + '].[' + @functionName + ']'') AND [type] IN (N''FN'', N''IF'', N''TF'', N''FS'', N''FT''))'  + CHAR(13) + CHAR(10) +
	CHAR(9) + 'DROP FUNCTION [' + @schemaName + '].[' + @functionName + ']' + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10) +
	'PRINT ''Creating function [' + @schemaName + '].[' + @functionName + '] ...''' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10)
	
	--SET @functionText = @functionText + 'GO'
	
	PRINT @consistence
	
	WHILE LEN(@functionText) > 1
	BEGIN
		IF CHARINDEX(CHAR(10), @functionText) between 1 AND 4000
		BEGIN
           SET @CurrentEnd =  CHARINDEX(CHAR(10), @functionText) -1
           SET @offset = 2
		END
		ELSE
		BEGIN
			SET @CurrentEnd = 4000
			SET @offset = 1
		END 
		
		PRINT SUBSTRING(@functionText, 1, @CurrentEnd) 
		
		SET @functionText = SUBSTRING(@functionText, @CurrentEnd+@offset, 1073741822)
	END
	
	SET @consistence = ''
	SET @functionText = ''

	FETCH NEXT FROM FUNCTION_CURSOR INTO @functionName, @schemaName
END

CLOSE FUNCTION_CURSOR
DEALLOCATE FUNCTION_CURSOR