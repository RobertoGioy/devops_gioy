/*
	AUTHOR:			JOS� ROBERTO
	DESCRIPTION:	CRIA AS VIEWS DO BANCO DE DADOS ADICIONANDO AS CONSIST�NCIAS DE VERIFICA��O
*/

DECLARE @viewName		NVARCHAR(100),
		@schemaName		NVARCHAR(50),
		@viewText		NVARCHAR(MAX),
		@consistence	NVARCHAR(MAX) 

DECLARE VIEW_CURSOR CURSOR FOR
SELECT [name], SCHEMA_NAME([schema_id]) AS SchemaName 
FROM sys.views
ORDER BY [name]

OPEN VIEW_CURSOR
FETCH NEXT FROM VIEW_CURSOR INTO @viewName, @schemaName

WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT	@viewText = [text] 
	FROM	syscomments c INNER JOIN sys.views v
	ON		v.object_id = c.id
	WHERE	v.name = @viewName AND v.schema_id = schema_id(@schemaName)
	
	SET @consistence = CHAR(13) + CHAR(10) + 
	'IF EXISTS (SELECT * FROM sys.views WHERE name = N''' + @viewName + ''' AND SCHEMA_ID = SCHEMA_ID(N''' + @schemaName + '''))' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'DROP VIEW [' + @schemaName + '].[' + @viewName + ']' + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10) +
	'PRINT ''Creating view [' + @schemaName + '].[' + @viewName + '] ...''' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) +
	'GO' + CHAR(13) + CHAR(10)
	
	SET @viewText = @viewText + CHAR(13) + CHAR(10) + 'GO' + CHAR(13) + CHAR(10)
	
	PRINT @consistence
	PRINT @viewText
	
	SET @consistence = ''
	SET @viewText = ''
	
	FETCH NEXT FROM VIEW_CURSOR INTO @viewName, @schemaName
END

CLOSE VIEW_CURSOR
DEALLOCATE VIEW_CURSOR


