/*
	AUTHOR:			JOS� ROBERTO
	DESCRIPTION:	CRIA AS TABELAS E OBJETOS RLACIONADOS A ELA ADICIONANDO AS CONSIST�NCIAS DE VERIFICA��O
*/

DECLARE @SchemaName			SYSNAME, 
		@tableName			SYSNAME,
		@TableColumns		NVARCHAR(MAX),
		@tableText			NVARCHAR(MAX),
		@consistence		NVARCHAR(800),
		@indexKeys			NVARCHAR(MAX),
		@foreignKeys		NVARCHAR(MAX),
		@indexes			NVARCHAR(MAX),
		@filegroup			VARCHAR(50),
		@dataType			SYSNAME

DECLARE TablesCursor CURSOR FOR
SELECT	TABLE_SCHEMA, TABLE_NAME
FROM	INFORMATION_SCHEMA.TABLES 
WHERE	TABLE_TYPE = N'BASE TABLE'
ORDER BY 
	CASE WHEN TABLE_NAME IN ('BusinessObjects') THEN 1 ELSE 2 END, 
	TABLE_SCHEMA, TABLE_NAME

OPEN TablesCursor
FETCH NEXT FROM TablesCursor INTO @SchemaName, @tableName

WHILE @@FETCH_STATUS = 0 
BEGIN 	
	SELECT	@TableColumns = ISNULL(@TableColumns + ',', '') + CHAR(13) + CHAR(10) + CHAR(9) + 
			'[' + c.name + '] ' +
			UPPER(dt.name) + 
			CASE 
				WHEN dt.name NOT IN('varchar','nvarchar', 'char', 'nchar', 'decimal') THEN ''
				WHEN dt.name = 'decimal' THEN '(' + CAST(sc.NUMERIC_PRECISION AS VARCHAR) + ',' + CAST(sc.NUMERIC_SCALE AS VARCHAR) + ')'
				ELSE CASE WHEN c.max_length = -1 AND dt.name <> 'xml' THEN '(MAX)' ELSE '(' + CAST(CHARACTER_MAXIMUM_LENGTH AS VARCHAR) + ')' END
			END +
			CASE WHEN c.is_identity = 1 THEN ' IDENTITY(1,1)' ELSE '' END + 
			CASE WHEN c.is_sparse = 1 THEN ' SPARSE' ELSE '' END +
			CASE WHEN c.is_nullable = 0 THEN ' NOT NULL' ELSE ' NULL' END +
			CASE WHEN sc.COLUMN_DEFAULT IS NOT NULL THEN ' CONSTRAINT [' + dc.name + '] DEFAULT ' + UPPER(dc.[definition]) ELSE '' END +
			CASE WHEN c.column_id = cc.parent_column_id THEN ' CONSTRAINT [' + cc.name + '] CHECK (' + cc.[definition] + ')' ELSE '' END
	FROM	sys.columns c INNER JOIN sys.tables t
	ON		c.object_id = t.object_id LEFT JOIN INFORMATION_SCHEMA.COLUMNS sc
	ON		t.name = sc.TABLE_NAME AND sc.COLUMN_NAME = c.name INNER JOIN sys.types dt
	ON		c.system_type_id = dt.system_type_id AND c.user_type_id = dt.user_type_id LEFT JOIN sys.default_constraints dc
	ON		t.object_id = dc.parent_object_id AND dc.parent_column_id = c.column_id LEFT JOIN sys.check_constraints cc
	ON		t.object_id = cc.parent_object_id AND c.column_id = cc.parent_column_id
	WHERE	t.name = @tableName AND T.schema_id = SCHEMA_ID(@SchemaName)
	ORDER BY t.name, c.column_id
	
	SELECT	@filegroup = '[' + s.groupname + ']'
	FROM	sysfilegroups s, sysindexes i,sysobjects o
	WHERE	i.indid < 2 AND i.groupid = s.groupid AND i.id=o.id AND o.name = @tableName
	
	IF @filegroup IS NULL OR @filegroup = ''
		SELECT	TOP 1 @filegroup = '[' + ps.name + ']([' + C.name + '])'
		FROM	sysfilegroups s RIGHT JOIN sysindexes i
		ON		i.indid < 2 AND i.groupid = s.groupid LEFT JOIN sysobjects o
		ON		i.id=o.id RIGHT JOIN sys.partitions p
		ON		o.id = p.object_id INNER JOIN sys.destination_data_spaces ds
		ON		p.partition_number = ds.destination_id RIGHT JOIN sys.partition_schemes ps
		ON		ds.partition_scheme_id = ps.data_space_id INNER JOIN sys.partition_functions pf
		ON		ps.data_space_id = ds.partition_scheme_id INNER JOIN sys.partition_parameters pp
		ON		PS.function_id = PP.function_id INNER JOIN sys.columns c
		ON		pp.system_type_id = c.system_type_id and pp.user_type_id = c.user_type_id and c.object_id = p.object_id
		WHERE	o.name = @tableName
		
	SELECT	@indexKeys = ISNULL(@indexKeys + ',', '') + CHAR(13) + CHAR(10) + CHAR(9) + 
			'CONSTRAINT [' + IndexName + ']' + SUBSTRING(Attributes, 1, LEN(Attributes) - 3) 
	FROM	Support.MapIndexes I  
	WHERE	TableName = @tableName AND SchemaName = @SchemaName AND Command LIKE 'ALTER%'
	
	IF @indexKeys IS NULL OR @indexKeys = ''
		SET @indexKeys = '' 
	ELSE
		SET @indexKeys = @indexKeys + '' 
		
	SELECT	@foreignKeys = ISNULL(@foreignKeys + ',', '') + CHAR(13) + CHAR(10) + CHAR(9) + 
			'CONSTRAINT [' + FK.name + '] FOREIGN KEY ([' + C.name + ']) REFERENCES [' + SC.name + '].[' + T.name + '] ([' + C.name + '])' +
			CASE 
				WHEN FK.delete_referential_action = 1 THEN ' ON DELETE CASCADE'
				WHEN FK.update_referential_action = 1 THEN ' ON UPDATE CASCADE'
				ELSE ''
			END
	FROM	sys.foreign_keys FK INNER JOIN sys.foreign_key_columns FKC
	ON		FK.parent_object_id = FKC.parent_object_id INNER JOIN sys.tables T
	ON		FK.referenced_object_id = T.object_id AND FK.schema_id = T.schema_id LEFT JOIN sys.columns C
	ON		C.object_id = FK.referenced_object_id AND C.column_id = FKC.constraint_column_id INNER JOIN sys.schemas SC
	ON		T.schema_id = SC.schema_id
	WHERE	OBJECT_NAME(FK.parent_object_id) = @tableName
	
	IF @foreignKeys IS NULL OR @foreignKeys = ''
		SET @foreignKeys = ''
	ELSE
		SET @foreignKeys = @foreignKeys + ''
		
	SELECT	@indexes = ISNULL(@indexes, '') + CHAR(13) + CHAR(10) + 
			Command + '[' + IndexName + '] ON [' + @schemaName + '].[' + @tableName + ']' + 
			SUBSTRING(Attributes, 1, LEN(Attributes) - 3) + CHAR(13) + CHAR(10) + 
			'ON ' + @filegroup + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)
	FROM	Support.MapIndexes
	WHERE	TableName = @tableName AND Command LIKE 'CREATE%'
	
	IF @indexes IS NULL OR @indexes = ''
		SET @indexes = ''
	ELSE
		SET @indexes = @indexes + ''

	SET @consistence = 'IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N''' + @tableName + '''AND TABLE_SCHEMA = N''' + @SchemaName + ''')' + CHAR(13) + CHAR(10) +
		'BEGIN' + CHAR(13) + CHAR(10) +
		'PRINT ''Creating table [' + @schemaName + '].[' + @tableName + '] ...''' + CHAR(13) + CHAR(10) 
	
	SET @tableText =  'CREATE TABLE [' + @SchemaName + '].[' + @tableName + '] (' + 
		@TableColumns + @indexKeys + @foreignKeys + CHAR(13) + CHAR(10) + 
		') ON ' + @filegroup + CHAR(13) + CHAR(10) + @indexes +
		'END' + CHAR(13) + CHAR(10) + 
		'GO' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)

	PRINT @consistence
	PRINT @tableText

	SET @TableColumns = NULL
	SET @tableText = ''
	SET @filegroup = ''
	SET @indexKeys = ''
	SET @foreignKeys = ''
	SET @indexes = ''

	FETCH NEXT FROM TablesCursor INTO @SchemaName, @tableName
END

CLOSE TablesCursor
DEALLOCATE TablesCursor