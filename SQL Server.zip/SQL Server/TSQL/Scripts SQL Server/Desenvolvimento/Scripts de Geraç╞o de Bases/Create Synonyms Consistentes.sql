/*
	AUTHOR:			JOS� ROBERTO
	DESCRIPTION:	CRIA OS SINONIMOS DO BANCO DE DADOS ADICIONANDO AS CONSIST�NCIAS DE VERIFICA��O
*/

DECLARE @synonymName	NVARCHAR(100),
		@schemaName		NVARCHAR(50),
		@objectName		NVARCHAR(255),
		@synonymText	NVARCHAR(MAX),
		@consistence	NVARCHAR(MAX) 

DECLARE SYNONYM_CURSOR CURSOR FOR
SELECT [name], SCHEMA_NAME([schema_id]) AS SchemaName, [base_object_name] 
FROM sys.synonyms
ORDER BY [name]

OPEN SYNONYM_CURSOR
FETCH NEXT FROM SYNONYM_CURSOR INTO @synonymName, @schemaName, @objectName

WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT	@synonymText = [text] 
	FROM	syscomments c INNER JOIN sys.synonyms s
	ON		s.object_id = c.id
	WHERE	s.name = @synonymName AND s.schema_id = schema_id(@schemaName) AND S.base_object_name = @objectName
	
	SET @consistence = CHAR(13) + CHAR(10) + 
	'IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N''' + @synonymName + ''' AND schema_id = schema_id(N''' + @schemaName + ''') AND base_object_name = N''' + @objectName + ''')' + CHAR(13) + CHAR(10) +
	'BEGIN' + CHAR(13) + CHAR(10) +
	CHAR(9) + 'PRINT ''Creating synonyms [' + @schemaName + '].[' + @synonymName + '] ...''' + CHAR(13) + CHAR(10) + 
	CHAR(9) + 'CREATE SYNONYM [' + @schemaName + '].[' + @synonymName + '] FOR ' + @objectName + CHAR(13) + CHAR(10) + 
	'END' + CHAR(13) + CHAR(10) + 
	'GO'
	
	PRINT @consistence
	PRINT @synonymText
	
	SET @consistence = ''
	SET @synonymText = ''
	
	FETCH NEXT FROM SYNONYM_CURSOR INTO @synonymName, @schemaName, @objectName
END

CLOSE SYNONYM_CURSOR
DEALLOCATE SYNONYM_CURSOR