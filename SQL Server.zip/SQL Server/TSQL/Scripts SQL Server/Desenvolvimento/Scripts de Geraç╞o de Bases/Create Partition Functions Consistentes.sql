DECLARE @funtionId		INT,
		@dataspaceid	INT,
		@functionName	NVARCHAR(50),
		@pschemeName	NVARCHAR(50),	
		@dataType		VARCHAR(20),
		@direction		CHAR(6),
		@boundary		NVARCHAR(MAX),
		@filegroups		NVARCHAR(MAX),
		@funtionText	NVARCHAR(MAX),
		@pSchemeText	NVARCHAR(MAX)

DECLARE FUNCTION_CURSOR CURSOR FOR
SELECT	PF.function_id,	
		PF.name,
		UPPER(T.name),
		CASE WHEN boundary_value_on_right = 0 THEN 'LEFT' ELSE 'RIGHT' END
FROM	sys.partition_functions PF 
		INNER JOIN sys.partition_parameters PP
ON		PF.function_id = PP.function_id
		INNER JOIN sys.types T
ON		PP.system_type_id = T.system_type_id
ORDER BY PF.function_id


OPEN FUNCTION_CURSOR
FETCH NEXT FROM FUNCTION_CURSOR INTO @funtionId, @functionName, @dataType, @direction

WHILE @@FETCH_STATUS = 0
BEGIN	
	SELECT	@boundary = ISNULL(CAST(@boundary AS VARCHAR(MAX)) + ', ', '') + CHAR(13) + CHAR(10) + CHAR(9) + CHAR(9) + 
			'''' + CONVERT(VARCHAR, CAST([value] AS DATETIME), 120) +
			CASE WHEN @direction = 'LEFT' THEN + '.997''' ELSE '.000' END
	FROM	sys.partition_range_values
	WHERE	function_id = @funtionId
	
	SET @funtionText = 'IF NOT EXISTS (SELECT * FROM sys.partition_functions WHERE name = N''' + @functionName + ''')' + CHAR(13) + CHAR(10) + 
		'BEGIN' + CHAR(13) + CHAR(10) + 
		CHAR(9) + 'PRINT ''Creating partition function [' + @functionName + '] ... ''' + CHAR(13) + CHAR(10) + 
		CHAR(9) + 'CREATE PARTITION FUNCTION [' + @functionName + '](' + @dataType + ')' + CHAR(13) + CHAR(10) + 
		CHAR(9) + 'AS RANGE ' + LTRIM(RTRIM(@direction)) + ' FOR VALUES (' + @boundary + CHAR(13) + CHAR(10) + 
		CHAR(9) + ');' + CHAR(13) + CHAR(10) + 
		'END' + CHAR(13) + CHAR(10) +
		'GO' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)
	
	SELECT	@pschemeName = PS.name, 
			@dataspaceid = D.data_space_id
	FROM	sys.data_spaces D RIGHT JOIN sys.partition_schemes PS
	ON		D.data_space_id = PS.data_space_id 
	WHERE	PS.function_id = @funtionId
	
	SELECT	@filegroups = ISNULL(@filegroups + ',', '') + CHAR(13) + CHAR(10) + CHAR(9) + CHAR(9) + '[' + D.name + ']'
	FROM	sys.destination_data_spaces DS LEFT JOIN sys.data_spaces D
	ON		DS.data_space_id = D.data_space_id
	WHERE	DS.partition_scheme_id = @dataspaceid
	ORDER BY DS.data_space_id
	
	SET @pSchemeText = 'IF NOT EXISTS (SELECT * FROM sys.partition_schemes WHERE name = N''' + @pschemeName + ''')' + CHAR(13) + CHAR(10) + 
		'BEGIN' + CHAR(13) + CHAR(10) + 
		CHAR(9) + 'PRINT ''Creating partition scheme [' + @pschemeName + '] ... ''' + CHAR(13) + CHAR(10) + 
		CHAR(9) + 'CREATE PARTITION SCHEME [' + @pschemeName + ']' + CHAR(13) + CHAR(10) + 
		CHAR(9) + 'AS PARTITION [' + @functionName + ']' + CHAR(13) + CHAR(10) + 
		CHAR(9) + 'TO (' + @filegroups + CHAR(13) + CHAR(10) + 
		CHAR(9) + ');' + CHAR(13) + CHAR(10) +
		'END' + CHAR(13) + CHAR(10) +
		'GO' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)
	
	PRINT @funtionText
	PRINT @pSchemeText
	
	SET @funtionText = ''
	SET @pSchemeText = ''
	SET @boundary = ''
	
	FETCH NEXT FROM FUNCTION_CURSOR INTO @funtionId, @functionName, @dataType, @direction
END

CLOSE FUNCTION_CURSOR
DEALLOCATE FUNCTION_CURSOR



