/*
	AUTHOR:			JOS� ROBERTO
	DESCRIPTION:	CRIA OS INDICES RLACIONADOS A BASE ADICIONANDO AS CONSIST�NCIAS DE VERIFICA��O
*/

SET NOCOUNT ON;

CREATE TABLE #IncludedColumns (RowNumber TINYINT, ColumnName NVARCHAR(128))

DECLARE @ObjectID INT, @GroupID INT, @IndexID INT, @ObjectName NVARCHAR(776), @SchemaName NVARCHAR(128),
		@GroupName SYSNAME, @IndexName SYSNAME, @ColumnGroup SYSNAME, @IndexType NVARCHAR(128), @Indexkeys NVARCHAR(2126),
		@FillFactor	TINYINT, @IsPrimaryKey BIT, @IsUniqueKey BIT, @IsUnique	BIT, @IsPadded BIT, @IgnoreDupKey BIT,
		@AutoCreated BIT, @NoRecompute BIT, @AllowRowLock BIT, @AllowPageLock BIT, @HasFilter BIT, @IncludeCount TINYINT,
		@LoopCount TINYINT, @IncludeKeys NVARCHAR(255), @FilterDesc	NVARCHAR(255), @Command	NVARCHAR(4000),
		@Filegroup NVARCHAR(50), @DataCompressionType NVARCHAR(500), @consistence NVARCHAR(800), @indexText	NVARCHAR(MAX)

DECLARE IndexCursor CURSOR LOCAL STATIC FOR	
SELECT	SH.[name],
		ST.[object_id],
		ST.[name],
		SI.[index_id],
		SI.[name],
		SI.[type_desc],
		SI.[data_space_id],
		SI.[is_primary_key],
		SI.[is_unique_constraint],
		SI.[is_unique],
		SI.[is_padded],
		SI.[ignore_dup_key],
		SI.[allow_row_locks],
		SI.[allow_page_locks],
		SI.[fill_factor],
		SI.[has_filter],
		SI.[filter_definition],
		SS.[no_recompute],
		SS.[auto_created]
FROM	sys.indexes SI 
		INNER JOIN sys.stats SS
ON		SI.[object_id] = SS.[object_id] AND SI.[index_id] = SS.[stats_id] 
		INNER JOIN sys.tables ST
ON		SI.[object_id] = ST.[object_id] 
		INNER JOIN sys.schemas SH
ON		SH.[schema_id] = ST.[schema_id]
WHERE	SI.[name] IS NOT NULL AND SH.[principal_id] = 1
ORDER BY SH.[name], ST.[name]

OPEN IndexCursor
FETCH IndexCursor INTO 
	@SchemaName, @ObjectID, @ObjectName, @IndexID, @IndexName, @IndexType, @GroupID, @IsPrimaryKey, @IsUniqueKey, @IsUnique, 
	@IsPadded, @IgnoreDupKey, @AllowRowLock, @AllowPageLock, @FillFactor, @HasFilter, @FilterDesc, @NoRecompute, @AutoCreated

WHILE @@FETCH_STATUS >= 0
BEGIN
	DECLARE @i INT, @thiskey NVARCHAR(131)

	SELECT @Indexkeys = '[' + INDEX_COL(@SchemaName + '.' + @ObjectName, @IndexID, 1) + ']', @i = 2

	IF(INDEXKEY_PROPERTY(@ObjectID, @IndexID, 1, 'isdescending') = 1)
		SELECT @Indexkeys = @Indexkeys  + ' DESC'
	ELSE
		SELECT @Indexkeys = @Indexkeys  + ' ASC'

	SELECT @thiskey = '[' + INDEX_COL(@SchemaName + '.' + @ObjectName, @IndexID, @i) + ']'

	IF((@thiskey IS NOT NULL) AND (INDEXKEY_PROPERTY(@ObjectID, @IndexID, @i, 'isdescending') = 1))
		SELECT @thiskey = @thiskey + ' DESC'
	ELSE
		SELECT @thiskey = @thiskey + ' ASC'

	WHILE (@thiskey IS NOT NULL)
	BEGIN
		SELECT @Indexkeys = @Indexkeys + ', ' + @thiskey, @i = @i + 1

		SELECT @thiskey = '[' + INDEX_COL(@SchemaName + '.' + @ObjectName, @IndexID, @i) + ']'

		IF((@thiskey IS NOT NULL) AND (INDEXKEY_PROPERTY(@ObjectID, @IndexID, @i, 'isdescending') = 1))
			SELECT @thiskey = @thiskey + ' DESC'
		ELSE
			SELECT @thiskey = @thiskey + ' ASC'
	END

	SELECT	@IncludeCount = COUNT(*)
	FROM	sys.tables ST 
			INNER JOIN sys.indexes SI
	ON		SI.[index_id] > 0 AND SI.[is_hypothetical] = 0 AND (SI.[object_id] = ST.[object_id])
			INNER JOIN sys.index_columns IC
	ON		(IC.[column_id] > 0 and (IC.[key_ordinal] > 0 OR IC.[partition_ordinal] = 0 OR IC.[is_included_column] != 0))
	AND		(IC.[index_id] = CAST(SI.[index_id] AS INT) AND IC.[object_id] = SI.[object_id])
			INNER JOIN sys.columns SC
	ON		SC.[object_id] = IC.[object_id] AND SC.[column_id] = IC.[column_id]
	WHERE	IC.[is_included_column] = 1 AND (SI.[index_id] = @IndexID) AND (ST.[object_id] = @ObjectID)

	IF(@IncludeCount > 0)
	BEGIN
		DELETE FROM #IncludedColumns

		INSERT INTO #IncludedColumns
		SELECT	ROW_NUMBER() OVER (ORDER BY IC.[index_column_id]), SC.[name]
		FROM	sys.tables ST 
				INNER JOIN sys.indexes SI
		ON		SI.[index_id] > 0 AND SI.[is_hypothetical] = 0 AND (SI.[object_id] = ST.[object_id])
				INNER JOIN sys.index_columns IC
		ON		(IC.[column_id] > 0 and (IC.[key_ordinal] > 0 OR IC.[partition_ordinal] = 0 OR IC.[is_included_column] != 0))
		AND		(IC.[index_id] = CAST(SI.[index_id] AS INT) AND IC.[object_id] = SI.[object_id])
				INNER JOIN sys.columns SC
		ON		SC.[object_id] = IC.[object_id] AND SC.[column_id] = IC.[column_id]
		WHERE	IC.[is_included_column] = 1 AND (SI.[index_id] = @IndexID) AND (ST.[object_id] = @ObjectID)

		SELECT @IncludeKeys = '[' + ColumnName + ']' FROM #IncludedColumns WHERE RowNumber = 1

		SET @LoopCount = 1

		WHILE (@LoopCount < @IncludeCount)
		BEGIN
			SELECT	@IncludeKeys = @IncludeKeys + ', [' + ColumnName + ']'
			FROM	#IncludedColumns
			WHERE	RowNumber = @LoopCount + 1
	
			SET @LoopCount = @LoopCount + 1
		END
	END
	ELSE
		SET @IncludeKeys = NULL

	SELECT @GroupName = [name] FROM sys.data_spaces WHERE [data_space_id] = @GroupID

	SELECT	@ColumnGroup = '(' + c.name + ')'
	FROM	sys.tables AS tbl 
			INNER JOIN sys.indexes AS idx 
	ON		idx.object_id = tbl.object_id AND idx.index_id < 2 
			INNER JOIN sys.index_columns ic 
	ON		(ic.partition_ordinal > 0) AND (ic.index_id = idx.index_id AND ic.object_id = CAST(tbl.object_id AS INT)) 
			INNER JOIN sys.columns c 
	ON		c.object_id = ic.object_id AND c.column_id = ic.column_id 
	WHERE  (tbl.name = @ObjectName AND SCHEMA_NAME(tbl.schema_id) = @SchemaName)

	IF(@FillFactor = 0) SET @FillFactor = 100
	
	SELECT	@filegroup = '[' + s.groupname + ']'
	FROM	sysfilegroups s, sysindexes i,sysobjects o
	WHERE	i.indid < 2 AND i.groupid = s.groupid AND i.id=o.id AND o.name = @ObjectName
	
	IF @filegroup IS NULL OR @filegroup = ''
		SELECT	TOP 1 @filegroup = '[' + ps.name + ']([' + C.name + '])'
		FROM	sysfilegroups s RIGHT JOIN sysindexes i
		ON		i.indid < 2 AND i.groupid = s.groupid LEFT JOIN sysobjects o
		ON		i.id=o.id RIGHT JOIN sys.partitions p
		ON		o.id = p.object_id INNER JOIN sys.destination_data_spaces ds
		ON		p.partition_number = ds.destination_id RIGHT JOIN sys.partition_schemes ps
		ON		ds.partition_scheme_id = ps.data_space_id INNER JOIN sys.partition_functions pf
		ON		ps.data_space_id = ds.partition_scheme_id INNER JOIN sys.partition_parameters pp
		ON		PS.function_id = PP.function_id INNER JOIN sys.columns c
		ON		pp.system_type_id = c.system_type_id and pp.user_type_id = c.user_type_id and c.object_id = p.object_id
		WHERE	o.name = @ObjectName

	SELECT	@DataCompressionType = ISNULL(p.data_compression_desc,'NONE')			
	FROM	sys.partitions p 
	WHERE	p.object_id = @ObjectID AND p.index_id IN (0,1) AND p.partition_number = 1
	
	SELECT @Command =
	CASE 
		WHEN (@IndexID = 1 AND @IsPrimaryKey = 1) OR @IsUniqueKey = 1 THEN 'ALTER TABLE [' + @SchemaName + '].[' + @ObjectName + ']' + ' ADD CONSTRAINT [' + @IndexName + ']'
		WHEN @IndexID = 1 AND @IsPrimaryKey = 0 THEN 'CREATE ' + CASE WHEN @IsUnique = 1 THEN 'UNIQUE ' ELSE '' END + @IndexType + ' INDEX [' + @IndexName + 'Out] ON [' + @SchemaName + '].[' + @ObjectName + ']'
		ELSE 'CREATE ' + CASE WHEN @IsUnique = 1 THEN 'UNIQUE ' ELSE '' END + @IndexType + ' INDEX [' + @IndexName + 'Out] ON [' + @SchemaName + '].[' + @ObjectName + ']'
	END + 
	CASE 
		WHEN @IndexID = 1 AND @IsPrimaryKey = 1 THEN ' PRIMARY KEY ' + @IndexType + ' (' + @Indexkeys + ') WITH (FILLFACTOR = ' + CONVERT(VARCHAR, @FillFactor) + ' ' +
			CASE WHEN @IsPadded = 1 THEN ', PAD_INDEX = ON ' ELSE ', PAD_INDEX = OFF ' END +
			CASE WHEN @NoRecompute = 1 THEN ', STATISTICS_NORECOMPUTE = ON ' ELSE ', STATISTICS_NORECOMPUTE = OFF ' END +
			CASE WHEN @IgnoreDupKey = 1 THEN ', IGNORE_DUP_KEY = ON ' ELSE ', IGNORE_DUP_KEY = OFF ' END +
			CASE WHEN @AllowRowLock = 1 THEN ', ALLOW_ROW_LOCKS = ON ' ELSE ', ALLOW_ROW_LOCKS = OFF ' END +
			CASE WHEN @AllowPageLock = 1 THEN ', ALLOW_PAGE_LOCKS = ON' ELSE ', ALLOW_PAGE_LOCKS = OFF' END + ', DATA_COMPRESSION = ' + @DataCompressionType + ')'
		WHEN @IsUniqueKey = 1 THEN ' UNIQUE ' + @IndexType + ' (' + @Indexkeys + ') WITH (FILLFACTOR = ' + CONVERT(VARCHAR, @FillFactor) + ' ' +
			CASE WHEN @IsPadded = 1 THEN ', PAD_INDEX = ON ' ELSE ', PAD_INDEX = OFF ' END +
			CASE WHEN @NoRecompute = 1 THEN ', STATISTICS_NORECOMPUTE = ON ' ELSE ', STATISTICS_NORECOMPUTE = OFF ' END +
			CASE WHEN @IgnoreDupKey = 1 THEN ', IGNORE_DUP_KEY = ON ' ELSE ', IGNORE_DUP_KEY = OFF ' END +
			CASE WHEN @AllowRowLock = 1 THEN ', ALLOW_ROW_LOCKS = ON ' ELSE ', ALLOW_ROW_LOCKS = OFF ' END +
			CASE WHEN @AllowPageLock = 1 THEN ', ALLOW_PAGE_LOCKS = ON' ELSE ', ALLOW_PAGE_LOCKS = OFF' END + ', DATA_COMPRESSION = ' + @DataCompressionType + ')'
		WHEN @IndexID = 1 AND @IsPrimaryKey = 0 THEN ' (' + @Indexkeys + ') ' +
			CASE WHEN @IncludeCount > 0 THEN 'INCLUDE (' + @IncludeKeys + ') ' ELSE '' END + 
			CASE WHEN @HasFilter = 1 THEN 'WHERE ' + @FilterDesc + ' ' ELSE '' END + 'WITH (FILLFACTOR = ' + CONVERT(VARCHAR, @FillFactor) + 
			CASE WHEN @IsPadded = 1 THEN ', PAD_INDEX = ON ' ELSE ', PAD_INDEX = OFF ' END +
			CASE WHEN @NoRecompute = 1 THEN ', STATISTICS_NORECOMPUTE = ON ' ELSE ', STATISTICS_NORECOMPUTE = OFF ' END +
			CASE WHEN @IgnoreDupKey = 1 THEN ', IGNORE_DUP_KEY = ON ' ELSE ', IGNORE_DUP_KEY = OFF ' END +
			CASE WHEN @AllowRowLock = 1 THEN ', ALLOW_ROW_LOCKS = ON ' ELSE ', ALLOW_ROW_LOCKS = OFF ' END +
			CASE WHEN @AllowPageLock = 1 THEN ', ALLOW_PAGE_LOCKS = ON' ELSE ', ALLOW_PAGE_LOCKS = OFF' END + ', DATA_COMPRESSION = ' + @DataCompressionType + ')'
		ELSE ' (' + @Indexkeys + ') ' +
			CASE WHEN @IncludeCount > 0 THEN 'INCLUDE (' + @IncludeKeys + ') ' ELSE '' END + 
			CASE WHEN @HasFilter = 1 THEN 'WHERE ' + @FilterDesc + ' ' ELSE '' END + 'WITH (FILLFACTOR = ' + CONVERT(VARCHAR, @FillFactor) + 
			CASE WHEN @IsPadded = 1 THEN ', PAD_INDEX = ON ' ELSE ', PAD_INDEX = OFF ' END + 
			CASE WHEN @NoRecompute = 1 THEN ', STATISTICS_NORECOMPUTE = ON ' ELSE ', STATISTICS_NORECOMPUTE = OFF ' END +
			CASE WHEN @IgnoreDupKey = 1 THEN ', IGNORE_DUP_KEY = ON ' ELSE ', IGNORE_DUP_KEY = OFF ' END +
			CASE WHEN @AllowRowLock = 1 THEN ', ALLOW_ROW_LOCKS = ON ' ELSE ', ALLOW_ROW_LOCKS = OFF ' END +
			CASE WHEN @AllowPageLock = 1 THEN ', ALLOW_PAGE_LOCKS = ON' ELSE ', ALLOW_PAGE_LOCKS = OFF' END + ', DATA_COMPRESSION = ' + @DataCompressionType + ')'
	END + ' ON ' + @Filegroup + ''
	
	SET @consistence = 'IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N''' + @IndexName + ''' AND object_id = OBJECT_ID(N''' + @ObjectName + '''))' + CHAR(13) + CHAR(10) +
		'BEGIN' + CHAR(13) + CHAR(10) +
		'PRINT ''Creating index [' + @IndexName + '] on table [' + @schemaName + '].[' + @ObjectName + '] ...''' + CHAR(13) + CHAR(10) 
		
	SET @indexText = @Command + CHAR(13) + CHAR(10) + 'END' + CHAR(13) + CHAR(10) + 'GO' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)
	
	PRINT @consistence
	PRINT @indexText

	SET @ColumnGroup = ''
	SET @indexText = ''

	FETCH IndexCursor INTO 
		@SchemaName, @ObjectID, @ObjectName, @IndexID, @IndexName, @IndexType, @GroupID, @IsPrimaryKey, @IsUniqueKey, @IsUnique, 
		@IsPadded, @IgnoreDupKey, @AllowRowLock, @AllowPageLock, @FillFactor, @HasFilter, @FilterDesc, @NoRecompute, @AutoCreated
END

CLOSE IndexCursor
DEALLOCATE IndexCursor

DROP TABLE #IncludedColumns