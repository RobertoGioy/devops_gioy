DECLARE @ZZAA1 SYSNAME
DECLARE CURSOR333 CURSOR FOR

SELECT CODEMP FROM EMPRESAS WHERE CODEMP <> '397' ORDER BY CODEMP

OPEN CURSOR333
FETCH NEXT FROM CURSOR333 INTO @ZZAA1
WHILE @@FETCH_STATUS = 0
BEGIN

DECLARE @CMD333 VARCHAR(MAX)

	SET @CMD333 =  ('
			
						DECLARE @TB SYSNAME, @COL SYSNAME, @CMD VARCHAR(MAX),@TBANT SYSNAME  
								CREATE TABLE ##TBSYS (TABELA SYSNAME,CMDCAMPOS VARCHAR(MAX))  
						SET @CMD = ''''  
						SET NOCOUNT ON  
						DECLARE REG CURSOR FOR 
						SELECT S1.NAME, S2.NAME FROM [CEBTV1491].[SL2000TBT_COMP].DBO.SYSOBJECTS S1 
								INNER JOIN [CEBTV1491].[SL2000TBT_COMP].DBO.SYSCOLUMNS S2 ON S2.ID = S1.ID 
										WHERE S1.NAME IN 
										(''AbrevPed'',''Bancos'',''Bloqueia_CCustos'',''CadcontObsPadrao'',''Calendario'',''Canais'',''Categoria'',''CfgNFe'',''Combustivel'',''Config'',
										''CP_ClienteXNivel'',''Cupom'',''Efetuar'',''Embalagens'',''Fab_veiculos'',''Fat_Contab'',''Forma_Pagto'',''GP_Produtos'',''Grupo_canais'',
										''Grupo_Imob'',''Grupo_Mod3'',''Insumos'',''Itens_Grupo_Mod3'',''Marcas'',''Marcas_Pneus'',''Mod_Veiculos'',''Mot_saida'',''Nivel'',
										''Parametros'',''Pis_Cofins'',''Produto_ClientexNivel'',''Produto_NatRec'',''Produtos'',''Sabor'',''Tip_veiculos'',''Tipo'',''Tipo_Controle'',''TipoAuxiliar'',
										''Tipos_Manutencao'',''TiposBloqueios'',''Transacao'',''Vasilhames'')
								ORDER BY S1.NAME, S2.COLID, S2.NAME 
  
           
						OPEN REG  
						FETCH NEXT FROM REG INTO @TB,@COL  
						SET @TBANT = @TB  
						WHILE @@FETCH_STATUS = 0  
							BEGIN  
							IF @TBANT <> @TB  
							BEGIN  
							SET @CMD = ''''  
							SET @TBANT = @TB  
							END  
     
							SET @CMD = @CMD + '','' + @COL 

							DELETE FROM ##TBSYS WHERE TABELA = @TB
  
							INSERT INTO ##TBSYS SELECT @TB,@CMD  
  
							FETCH NEXT FROM REG INTO @TB,@COL  
  
							END  
  
						CLOSE REG  
						DEALLOCATE REG  


						
						
						DECLARE @ZZAA33 SYSNAME,@ZZAA34 VARCHAR(MAX)
						DECLARE CURSOR666 CURSOR FOR

						SELECT TABELA,(SUBSTRING (MAX(CMDCAMPOS),2,LEN(MAX(CMDCAMPOS)))) FROM ##TBSYS GROUP BY TABELA,CMDCAMPOS

						OPEN CURSOR666
						FETCH NEXT FROM CURSOR666 INTO @ZZAA33,@ZZAA34
						WHILE @@FETCH_STATUS = 0
						BEGIN


							EXEC  (''
											DECLARE @CMD2 VARCHAR(MAX)
											SET @CMD2	= (
				
														''''
																INSERT INTO [CEBTV1491].[SL2000TBT_COMP].DBO.''+@ZZAA33+'' (''+@ZZAA34+'')
																SELECT ''+@ZZAA34+''
																FROM [CEBTV1491].[SL2000TBT_COMP].DBO.''+@ZZAA33+'' A WHERE A.CODEMP =''''''''397''''''''

														'''')
														IF (SELECT COUNT(*)
																				FROM SYS.COLUMNS C
																					INNER JOIN SYS.TYPES T ON T.SYSTEM_TYPE_ID = C.SYSTEM_TYPE_ID
																				WHERE IS_IDENTITY = ''''TRUE'''' AND OBJECT_NAME(OBJECT_ID) = ''''''+@ZZAA33+'''''')>0
														BEGIN
																DECLARE @CAMPREG VARCHAR(MAX)
																SET @CAMPREG = (SELECT C.NAME
																						FROM SYS.COLUMNS C
																							INNER JOIN SYS.TYPES T ON T.SYSTEM_TYPE_ID = C.SYSTEM_TYPE_ID
																						WHERE IS_IDENTITY = ''''TRUE'''' AND OBJECT_NAME(OBJECT_ID) = ''''''+@ZZAA33+'''''')
																SET @CMD2 = (REPLACE(@CMD2,'''' CODEMP,'''','''' '''''''''+@ZZAA1+''''''''',''''))
																SET @CMD2 = (REPLACE(@CMD2,@CAMPREG,'''' '''''''''''''''',''''))
																SET @CMD2 = (REPLACE(@CMD2,'''' '''''''''''''''',,'''',''''''''))
														END
														ELSE
														BEGIN
																SET @CMD2 = (REPLACE(@CMD2,'''' CODEMP,'''','''' '''''''''+@ZZAA1+''''''''',''''))
														END
														EXEC (@CMD2)
														
			
									'')
							FETCH NEXT FROM CURSOR666 INTO @ZZAA33,@ZZAA34
							
						END
						CLOSE CURSOR666
						DEALLOCATE CURSOR666

						DROP TABLE ##TBSYS


			
			')
			
			EXEC(@CMD333)
	FETCH NEXT FROM CURSOR333 INTO @ZZAA1

END
CLOSE CURSOR333
DEALLOCATE CURSOR333