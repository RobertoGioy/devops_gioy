/*
	Insere informa��es hist�ricas escolhidas aleatoriamente a partir da publica��o da aplica��o
	No caso do Ita� ACC atualmente s� se usa informa��es hist�ricas do tipo num�rica.
	Para facilitar a l�gica, ser� inserido o valor default das informa��es.
*/

DECLARE @BusinessObjectID	INT
DECLARE @TotalBOID			INT
DECLARE @InformationID		INT
DECLARE @DefaultValue		INT
		
--------------------------- CONFIGURA��O ---------------------------------------

-- DEFINIR BOID INICIAL	
SET @BusinessObjectID = 1
-- DEFINIR TOTAL DE BOIDS DESEJADOS
SELECT @TotalBOID = COUNT(1) FROM dbo.UPSBusinessObjects

--------------------------------------------------------------------------------

--------------------------- N�O MEXER NO C�DIGO ABAIXO -------------------------

-- descobrir as informa��es hist�ricas no xml da publica��o
;WITH CTE AS (
	SELECT	ref.query('..') AS InformationXml
	FROM	[dbo].[UPSApplicationPublishing] WITH (NOLOCK)
			CROSS APPLY [Application].nodes ('//Resource/ResourceType[@Key="Unear.Information"]') AS A(ref)
	WHERE	[PublishingID] = (SELECT MAX(PublishingID) FROM [dbo].[UPSApplicationPublishing] WITH (NOLOCK))
)
SELECT	ref.value('(//Resource/BusinessObjectType/Resource/@Id)[1] ', 'int') AS BusinessObjectTypeID,
		ref.value('(//Resource/BusinessObjectType/Resource/@Name)[1] ', 'varchar(255)') AS BusinessObjectTypeName,
		ref.value('(//Resource/@Id)[1] ', 'int') AS InformationID,
		ref.value('(//Resource/@Name)[1] ', 'varchar(255)') AS InformationName,
		ref.value('(/Resource/@SpecialKey)[1] ', 'varchar(255)') AS InformationKey,
		ref.value('(./Resource/@Name)[1] ', 'varchar(255)') AS InformationType,
		ref.value('(//Resource/DefaultValue)[1] ', 'varchar(255)') AS DefaultValue,
		CASE WHEN ref.exist('//Resource/HistoricPeriod') = 1 THEN 1 ELSE 0 END AS IsHistory,
		ref.value('(//Resource/HistoricPeriod)[1] ', 'int') AS HistoricPeriod,
		ref.value('(//Resource/InformationGroup/Resource/@Id)[1] ', 'int') AS InformationGroupId,
		ref.value('(//Resource/InformationGroup/Resource/@Name)[1] ', 'varchar(255)') AS InformationGroupName
INTO	#Informations
FROM	CTE 
CROSS APPLY InformationXml.nodes('//Resource/InformationType') AS A(ref)

-- selecionar as informa��es desejadas
SELECT	InformationID, DefaultValue, InformationType, HistoricPeriod
INTO	#History 
FROM	#Informations
WHERE	BusinessObjectTypeID = 31 AND IsHistory = 1
AND		[InformationID] IN (70,71,78,83,186,256,285,722,937,938,939,2220,2657,2663,2889,3528,4323,12063,13404,13405)

TRUNCATE TABLE dbo.UPSInformationHistoryPeriods

-- Insere o per�odo da informa��o
INSERT INTO dbo.UPSInformationHistoryPeriods
SELECT InformationID, HistoricPeriod 
FROM #History

-- Insere as informa��es hist�ricas na base
WHILE @BusinessObjectID <= @TotalBOID
BEGIN
	DECLARE InformationHistory CURSOR LOCAL FOR
	SELECT	InformationID, DefaultValue
	FROM	#History
	ORDER BY InformationID
	
	OPEN InformationHistory
	FETCH NEXT FROM InformationHistory INTO @InformationID, @DefaultValue
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO dbo.UPSBusinessObjectInformationsHistory (
			BusinessObjectID,
			InformationID,
			Value,
			[Date] )
		VALUES (
			@BusinessObjectID,
			@InformationID,
			@DefaultValue,
			GETDATE()
		)
		
		FETCH NEXT FROM InformationHistory INTO @InformationID, @DefaultValue
	END
	
	CLOSE InformationHistory
	DEALLOCATE InformationHistory
	
	SET @BusinessObjectID = @BusinessObjectID + 1
END

DROP TABLE #Informations
DROP TABLE #History
