USE [ItaucardServerDev]
GO

/****** Object:  StoredProcedure [dbo].[spGeraDadosItau]    Script Date: 07/25/2013 10:54:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spGeraDadosItau]
	@TotLigacoes int,
	@DtInicial datetime
AS
BEGIN
/*
	Script para gerar massa de dados para 01 dia para o ambiente itaucard
	Roberto Gioy
*/

CREATE TABLE #Menu (
	[Id]	[int] IDENTITY(1,1),
	[Menu]	[varchar](255) 
)

INSERT INTO #Menu ([Menu]) VALUES ('1,749,2429,7245,3')
INSERT INTO #Menu ([Menu]) VALUES ('4,26423,6639,9')
INSERT INTO #Menu ([Menu]) VALUES ('2,824,244,5272,8')
INSERT INTO #Menu ([Menu]) VALUES ('4,2644,22,0635,9')
INSERT INTO #Menu ([Menu]) VALUES ('5,265#,65*,8')
INSERT INTO #Menu ([Menu]) VALUES ('3,26422,23#,066#,9')
INSERT INTO #Menu ([Menu]) VALUES ('1,742,244,39,8')
INSERT INTO #Menu ([Menu]) VALUES ('7,822#,2*,59,8')
INSERT INTO #Menu ([Menu]) VALUES ('2,84*,232#,3522o2,9')
INSERT INTO #Menu ([Menu]) VALUES ('5,749,2322,352*,8')
INSERT INTO #Menu ([Menu]) VALUES ('3,83o#,239,9')
INSERT INTO #Menu ([Menu]) VALUES ('5,232,3422*,9')
INSERT INTO #Menu ([Menu]) VALUES ('2,267,242,527#,8')
INSERT INTO #Menu ([Menu]) VALUES ('6,242,349,9')
INSERT INTO #Menu ([Menu]) VALUES ('6,452,23#,349,8')

CREATE TABLE #Reasons (Ordem INT, ReasonID INT)
CREATE TABLE #Results (Ordem INT, ResultID INT, ResultType INT)
CREATE TABLE #Incentives (Ordem INT, IncentiveID INT)
CREATE TABLE #Arguments (Ordem INT, ArgumentID INT)

-- insere argumentos
exec Umagnet.spArgumentsInsert 626, 'DESCONTO DE 50% EM PARQUES/ JOGOS/ CINEMAS/ TEATROS'
exec Umagnet.spArgumentsInsert 628, 'BENEFICIOS EXCLUSIVOS DO CARTAO'
exec Umagnet.spArgumentsInsert 455, 'AUMENTO DE LIMITE'
exec Umagnet.spArgumentsInsert 639, 'CONDICOES ESPECIAIS DE PARCELAMENTO NA LOJA'
exec Umagnet.spArgumentsInsert 638, 'CREDITO DE R$ 1,00 P/ PAGAMENTO DA FATURA NA LOJA'
exec Umagnet.spArgumentsInsert 640, 'DESCONTO EM MAIS DE 300 PRODUTOS NA LOJA'
exec Umagnet.spArgumentsInsert 625, 'PARCELAMENTO DE FATURA'
exec Umagnet.spArgumentsInsert 641, 'PROGRAMA DE INCENTIVO/RESGATE'
exec Umagnet.spArgumentsInsert 590, 'TROCA DE PONTOS POR ANUIDADE'

-- insere resultados
exec Umagnet.spResultInsert 1, 'RETIDO', 2
exec Umagnet.spResultInsert 2, 'INDECISO', 1
exec Umagnet.spResultInsert 3, 'CANCELADO SUSPENSO', 0
exec Umagnet.spResultInsert 4, 'CANCELADO DEFINITIVO', 0
exec Umagnet.spResultInsert 5, 'CANCELADO ADICIONAL', 0

-- insere ocupa��o
exec Umagnet.spOccupationsInsert 342, 1, 'PRC Titular Unificada'
exec Umagnet.spOccupationsInsert 343, 2, 'PRC Adicional Unificada'

-- insere motivos cancelamento
exec Umagnet.spReasonsInsert 1705, 'ATRASO/ NAO RECEBIMENTO DE FATURAS', 1
exec Umagnet.spReasonsInsert 1244, 'CANCELAMENTO JA SOLICITADO E NAO REALIZADO', 0
exec Umagnet.spReasonsInsert 1706, 'CANCELAMENTO SOLICITADO PELO GERENTE', 0
exec Umagnet.spReasonsInsert 1690, 'CARTAO NAO SOLICITADO', 1
exec Umagnet.spReasonsInsert 1581, 'CLIENTE EM ATRITO E NAO ACEITA ARGUMENTACAO', 1
exec Umagnet.spReasonsInsert 1693, 'DIFICULDADE FINANCEIRA/ CONTENCAO DE DESPESA', 0
exec Umagnet.spReasonsInsert 1703, 'INFORMACAO DIVERGENTE SOBRE O PRODUTO - AGENCIA OU OUTROS CANAIS', 1
exec Umagnet.spReasonsInsert 1695, 'LIMITE INADEQUADO', 0
exec Umagnet.spReasonsInsert 1696, 'MAU ATENDIMENTO CANAIS (AGENCIA, COBRANCA, CENTRAIS DE ATENDIMENTO)', 1
exec Umagnet.spReasonsInsert 1247, 'TAXA DE JUROS ALTAS', 0
exec Umagnet.spReasonsInsert 1570, 'ANUIDADE ALTA - CONTA ANTIGA (ACIMA DE 11 MESES)', 1
exec Umagnet.spReasonsInsert 1704, 'ANUIDADE ALTA - CONTA NOVA (CONTA ATE 11 MESES)', 1
exec Umagnet.spReasonsInsert 1593, 'AUTORIZACAO NEGADA / CARTAO BLOQUEADO POR FALCON', 0
exec Umagnet.spReasonsInsert 972, 'CONCORRENCIA', 0
exec Umagnet.spReasonsInsert 1596, 'DIFICULDADE DE DESBLOQUEAR', 1
exec Umagnet.spReasonsInsert 1597, 'DIFICULDADE DE NEGOCIAR O DEBITO/EFETUAR ACORDO', 1
exec Umagnet.spReasonsInsert 1600, 'LOJA DISTANTE', 0
exec Umagnet.spReasonsInsert 1241, 'MA VENDA DE SEGURO', 1
exec Umagnet.spReasonsInsert 1565, 'NAO IDENTIFICA BENEFICIOS NO PRODUTO', 1
exec Umagnet.spReasonsInsert 1603, 'NAO RECEBIMENTO DA 2A VIA DO CARTAO', 1
exec Umagnet.spReasonsInsert 43, 'NAO RECEBIMENTODE SENHA', 1
exec Umagnet.spReasonsInsert 1232, 'PROBLEMAS COM UTILIZACAO DO CHIPCARD', 0
exec Umagnet.spReasonsInsert 1605, 'TARIFA DE MANUTENCAO ALTA', 1
exec Umagnet.spReasonsInsert 1708, 'BAIXA ACEITACAO DO CARTAO', 0

-- insere os incentivos
exec Umagnet.spIncentivesInsert 739, 'DESCONTO TITULAR', 1
exec Umagnet.spIncentivesInsert 740, 'DESCONTO ADICIONAL', 1
exec Umagnet.spIncentivesInsert 738, 'TROCA DE PONTOS POR ANUIDADE', 0
exec Umagnet.spIncentivesInsert 744, 'ALTERACAO DE DIA DE VENCIMENTO', 0
exec Umagnet.spIncentivesInsert 746, 'PARCELAMENTO DE FATURA', 1
exec Umagnet.spIncentivesInsert 747, 'PARCELAMENTO EM ATE 8X SEM DESCONTO', 1
exec Umagnet.spIncentivesInsert 748, 'ALTERA��O DE LIMITE DE CR�DITO FINANCEIRAS', 1
exec Umagnet.spIncentivesInsert 742, 'ALTERACAO DE LIMITE DE CREDITO ITAUCARD', 1
exec Umagnet.spIncentivesInsert 750, 'CONVERSAO PRODUTO', 0

---------------------------------------------------------------------------------------------------------------
DECLARE	@BusinessObjectID		int
DECLARE	@SessionID				varchar(255)
DECLARE	@LogDate				datetime
DECLARE	@IvrID					varchar(15)
DECLARE	@IvrPortNumber			smallint
DECLARE	@ServerName				varchar(255)
DECLARE	@HasTransfer			INT
DECLARE	@HasShortMenu			bit
DECLARE	@ReturnMessage			varchar(255)
DECLARE	@MenuOptions			varchar(50)
DECLARE	@NumberOfVoiceBanners	tinyint
DECLARE @BicVoiceBanner			varchar(10)
DECLARE @BicOrg					varchar(3)
DECLARE	@Org					int
DECLARE @OfferCode				varchar(10)
DECLARE @CdnCode				int
DECLARE @RoutingPoint			int
DECLARE @IsUnconditional		int
DECLARE @Navigation				varchar(255)
DECLARE @TMU					int
DECLARE @BicShortMenuAccepted	int
DECLARE @BicTransfer			varchar(50)
DECLARE @ServiceID				int
DECLARE @Parameters				varchar(255)
DECLARE @OperatorID				varchar(255)
DECLARE @MessageCode			varchar(255)
DECLARE @MessageType			int
DECLARE @MessageResult			int
DECLARE @OfferResult			int
DECLARE @MessageResultAux		int
DECLARE @CallReasonID			int
DECLARE @CallReasonIDAux		int
DECLARE @CallReasonName			varchar(50)
DECLARE @Chpras					bigint
DECLARE	@cpf					bigint
DECLARE @Gender					char(1)
DECLARE @FormID					int
DECLARE @IsOther				int
DECLARE @IdConfig				int
DECLARE @Nickname				varchar(255)
DECLARE @OccupationID			int
DECLARE @OccupationIDAux		int
DECLARE @ReasonID				int
DECLARE @ReasonIDAux			int
DECLARE @ResultID				int
DECLARE @ResultIDAux			int
DECLARE @ResultType				int
DECLARE @IncentiveID			int
DECLARE @IncentiveIDAux			int
DECLARE @ArgumentID				int
DECLARE @ArgumentIDAux			int
DECLARE @UndueCode				int
DECLARE	@UndueCodeAux			int
DECLARE @IndicatorID			int
DECLARE @IndicatorIDAux			int
DECLARE @IndicatorName			varchar(50)
DECLARE @UserKey				varchar(255)
DECLARE	@TradingID				int
DECLARE @IsTransfer				int
DECLARE @AlertCode				varchar(30)
DECLARE @AlertType				varchar(20)
DECLARE @AlertCodeAux			int
DECLARE @AlertResult			int
DECLARE @IsAlert				int
DECLARE @CampaignKey			varchar(50)
DECLARE @TransmissionType		varchar(10)
DECLARE @CampaignAux			int

DECLARE	@AuxMenu				int
DECLARE	@HoraAtual				int
DECLARE	@TotalMenu				int
DECLARE	@AuxTotalMenu			int
DECLARE	@Hora					int
DECLARE	@TotalHora				int
DECLARE	@AuxTotalHora			int
DECLARE	@QtdHoras				int
DECLARE	@DateAux				datetime
DECLARE	@PctMenu				decimal(19,2)
DECLARE	@PctHora				decimal(19,2)
DECLARE	@PctOffer				decimal(19,2)
DECLARE	@CountTotNav1			int
DECLARE	@CountTotNav2			int
DECLARE	@CountTotNav3			int
DECLARE	@TotNav1				int
DECLARE	@TotNav2				int
DECLARE	@TotNav3				int
DECLARE @OperatorIDAux			int
DECLARE @CountMessage			int
DECLARE @MessageCodeAux			int
DECLARE @AuxOffer				int
DECLARE @AuxTotalOffer			int
DECLARE @TotalOffer				int
DECLARE @ProductID				int
DECLARE	@ProductIDAux			int
DECLARE @ProductStatus			int
DECLARE @ProductName			varchar(255)
DECLARE	@Search					int
DECLARE @ServiceCode			varchar(10)
DECLARE @ServiceCritical		varchar(10)
DECLARE @ServiceCodeAux			int
DECLARE @IsTrading				int
DECLARE @undue					int
DECLARE @TotalIndicators		int
DECLARE @IsComplete				int

SET	@LogDate = @DtInicial
SET	@DateAux = @LogDate
SET	@AuxMenu = 0
SET	@HoraAtual = 0
SET @ServerName = 'APP_SERVER'

WHILE @AuxMenu <= 15
BEGIN
	SELECT @PctMenu = 
	CASE @AuxMenu
		WHEN 0 THEN 40.00
		WHEN 1 THEN 3.59
		WHEN 2 THEN 5.53
		WHEN 3 THEN 1.76
		WHEN 4 THEN 6.94
		WHEN 5 THEN 2.87
		WHEN 6 THEN 4.96
		WHEN 7 THEN 1.26
		WHEN 8 THEN 0.77
		WHEN 9 THEN 4.75
		WHEN 10 THEN 9.36
		WHEN 11 THEN 1.38
		WHEN 12 THEN 3.26
		WHEN 13 THEN 7.20
		WHEN 14 THEN 3.78
		WHEN 15 THEN 2.59
	END
	
	SELECT @TotalMenu = @TotLigacoes * @PctMenu / 100.00
	SET	@AuxTotalMenu = @TotalMenu
	
	IF @AuxMenu = 0
	BEGIN
		SET	@MenuOptions = '1,2,3,4,5,6,7,8,9'
		SET	@HasShortMenu = 0
		SET	@HasTransfer = 1
	END
	ELSE
	BEGIN
		SELECT @MenuOptions = Menu FROM #Menu WHERE Id = @AuxMenu
		SET	@HasShortMenu = 1
		SELECT @HasTransfer = CASE WHEN RIGHT(Menu, 1) = '9' THEN 1 ELSE 0 END FROM #Menu WHERE Id = @AuxMenu
	END
	
	SET	@Hora = 0
	
	WHILE @TotalMenu > 0
	BEGIN
		SET	@QtdHoras = (@HoraAtual * -1) + @Hora
		
		SET	@PctHora = 
		CASE @Hora
			WHEN 0 THEN 1.99
			WHEN 1 THEN 0.98
			WHEN 2 THEN 0.95
			WHEN 3 THEN 1.04
			WHEN 4 THEN 2.27
			WHEN 5 THEN 1.70
			WHEN 6 THEN 2.02
			WHEN 7 THEN 4.97
			WHEN 8 THEN 5.96
			WHEN 9 THEN 8.91
			WHEN 10 THEN 7.94
			WHEN 11 THEN 6.23
			WHEN 12 THEN 4.29
			WHEN 13 THEN 4.77
			WHEN 14 THEN 5.76
			WHEN 15 THEN 8.94
			WHEN 16 THEN 5.96
			WHEN 17 THEN 2.16
			WHEN 18 THEN 2.98
			WHEN 19 THEN 4.09
			WHEN 20 THEN 7.18
			WHEN 21 THEN 3.77
			WHEN 22 THEN 3.25
			WHEN 23 THEN 1.89
		END
		
		SET	@TotalHora = @AuxTotalMenu * @PctHora / 100.00
		SET	@AuxTotalHora = @TotalHora
		
		SELECT @LogDate = DATEADD(hh, @QtdHoras, @DateAux)
		
		SET	@AuxOffer = 1
		
		SET	@TotNav1 = 0
		SET	@TotNav2 = 0
		SET	@TotNav3 = 0
		
		WHILE @TotalHora > 0
		BEGIN
			SET	@PctOffer = 
			CASE @AuxOffer
				WHEN 1 THEN 2.35
				WHEN 2 THEN 4.95
				WHEN 3 THEN 0.89
				WHEN 4 THEN 8.54
				WHEN 5 THEN 1.58
				WHEN 6 THEN 3.58
				WHEN 7 THEN 6.85
				WHEN 8 THEN 4.05
				WHEN 9 THEN 9.45
				WHEN 10 THEN 3.85
				WHEN 11 THEN 13.98
				WHEN 12 THEN 7.46
				WHEN 13 THEN 8.12
				WHEN 14 THEN 15.68
				WHEN 15 THEN 8.67
			END
			
			SET	@TotalOffer = @AuxTotalHora * @PctOffer / 100.00
			SET	@AuxTotalOffer = @TotalOffer
			
			
			SET	@TotNav1 = @TotalOffer * 12.85 / 100.00
			SET	@TotNav2 = @TotalOffer * 56.88 / 100.00
			SET	@TotNav3 = @TotalOffer * 30.27 / 100.00
						
			SET	@CountTotNav1 = 0
			SET	@CountTotNav2 = 0
			SET	@CountTotNav3 = 0
			
			WHILE @TotalOffer > 0
			BEGIN
				SELECT TOP 1 @BusinessObjectID = [BusinessObjectID]
				FROM [dbo].[UPSBusinessObjects]
				WHERE (0.001 * (1 + CONVERT(INT, 5 * RAND()))) >= CAST(CHECKSUM(NEWID(), BusinessObjectID) & 0x7fffffff AS FLOAT) / CAST (0x7fffffff AS INT)
				AND [BusinessObjectID] > 1
				
				IF @BusinessObjectID IS NULL
					SELECT TOP 1 @BusinessObjectID = [BusinessObjectID] FROM [dbo].[UPSBusinessObjects] WHERE [BusinessObjectID] > 1
				
				SELECT @SessionID = 'Uchannels.' + CAST(CONVERT(INT, RAND() * 200) + 1000 as varchar) + CAST(CONVERT(INT, RAND() * 899999) + 100000 as varchar) + CONVERT(VARCHAR,GETDATE(),112) + REPLACE(CONVERT(VARCHAR,GETDATE(),114),':','') FROM [dbo].[UPSBusinessObjects] WHERE [BusinessObjectID] = @BusinessObjectID
					
				SELECT @IvrPortNumber = CONVERT(INT, 100 * RAND()) + 1
				
				SELECT @IvrID = 
				CASE WHEN @IvrPortNumber BETWEEN 1 AND 10 THEN 'URA1'
					 WHEN @IvrPortNumber BETWEEN 11 AND 20 THEN 'URA2'
					 WHEN @IvrPortNumber BETWEEN 21 AND 30 THEN 'URA3'
					 WHEN @IvrPortNumber BETWEEN 31 AND 40 THEN 'URA4'
					 WHEN @IvrPortNumber BETWEEN 41 AND 50 THEN 'URA5'
					 WHEN @IvrPortNumber BETWEEN 51 AND 60 THEN 'URA6'
					 WHEN @IvrPortNumber BETWEEN 61 AND 70 THEN 'URA7'
					 WHEN @IvrPortNumber BETWEEN 71 AND 80 THEN 'URA8'
					 WHEN @IvrPortNumber BETWEEN 81 AND 90 THEN 'URA9'
					 WHEN @IvrPortNumber BETWEEN 91 AND 100 THEN 'URA10'
				END
				
				SET @NumberOfVoiceBanners = 1
				
				SELECT @BicVoiceBanner = 'VB00' + CONVERT(VARCHAR,CONVERT(INT, 10 * RAND()))
				
				SELECT @Org = CONVERT(VARCHAR,CONVERT(INT, 3 * RAND()) + 1)
				
				SET @BicOrg = 
				CASE 
					WHEN @Org = 1 THEN '057'
					WHEN @Org = 2 THEN '008'
					WHEN @Org = 3 THEN '004'
				END
				
				SELECT @OfferCode = 'OF' + CAST(@AuxOffer as varchar)
				
				SELECT @ReturnMessage = CASE WHEN @HasShortMenu = 0 THEN 'MNC' ELSE 'MNR' END + '&' + @MenuOptions + '&' + @BicVoiceBanner + '&' + @OfferCode
				
				-- loga os comandos
				INSERT INTO dbo.UdialCommandLog (BusinessObjectId,SessionId,BicMenu,LogDate,IvrId,IvrPortNumber,ServerName,ReturnMessage,BicVoiceBanner,HasTransfer,HasShortMenu,NumberOfVoiceBanners,BicOrg)
				VALUES(@BusinessObjectID,@SessionID,@MenuOptions,@LogDate,@IvrID,@IvrPortNumber,@ServerName,@ReturnMessage,@BicVoiceBanner,@HasTransfer,@HasShortMenu,@NumberOfVoiceBanners,@BicOrg)
					
				-- loga o comando de ofertas
				IF @OfferCode IS NOT NULL
				BEGIN
					IF @IsComplete <> 5
						INSERT INTO dbo.BicUdialCommandOfferLog(BusinessObjectId,SessionId,LogDate,ServerName,CampaignCode)
						VALUES(@BusinessObjectID,@SessionID,@LogDate,@ServerName,@OfferCode)
				END
				
				-- loga o comando de deriva��o
				IF (@HasTransfer = 1)
				BEGIN
					SELECT @CdnCode = CONVERT(INT, 10 * RAND()) + 1
					SET @RoutingPoint = 0
					
					IF CONVERT(INT, RAND() * 3) <> 0
					BEGIN
						IF CONVERT(INT, RAND() * 2) <> 0
							SET	@IsUnconditional = 1
						ELSE
							SET	@IsUnconditional = 0
					END
					ELSE
					BEGIN
						IF CONVERT(INT, RAND() * 8) <> 0
							SET	@IsUnconditional = 1
						ELSE
							SET	@IsUnconditional = 0
					END	
					
					INSERT INTO dbo.BicUdialCommandTransferLog(BusinessObjectId,SessionId,LogDate,ServerName,CdnCode,RoutingPoint,IsUnconditional)
					VALUES(@BusinessObjectID,@SessionID,@LogDate,@ServerName,@CdnCode,@RoutingPoint,@IsUnconditional)
				END
				
				IF @MenuOptions = '1,2,3,4,5,6,7,8,9'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '3,4,6,8'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '1,5,6,9'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '2,3,6,7,9'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 1
					END
				END
				ELSE IF @MenuOptions = '1,749,2429,7245,3'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '1,749,7245'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '2429,7245,9'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '1,2429,9'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 1
					END
				END
				ELSE IF @MenuOptions = '4,26423,6639,9'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '4,6639,9'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '26423,6639,9'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '4,9'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 1
					END
				END
				ELSE IF @MenuOptions = '2,824,244,5272,8'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '5272,8'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '244,5272'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '2,824,8'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 0
					END
				END
				ELSE IF @MenuOptions = '4,2644,22,0635,9'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '4,2644,9'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '22,0635,9'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '0635,9'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 1
					END
				END
				ELSE IF @MenuOptions = '5,265#,65*,8'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '5,65*,9'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '265#,9'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '5,265#,9'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 1
					END
				END
				ELSE IF @MenuOptions = '3,26422,23#,066#,9'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '26422,23#,9'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '23#,066#,9'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '3,066#,9'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 1
					END
				END
				ELSE IF @MenuOptions = '1,742,244,39,8'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '1,39,8'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '742,39'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '244,39,8'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 0
					END
				END
				ELSE IF @MenuOptions = '7,822#,2*,59,8'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '9'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '7,2*,9'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '822#,59,9'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 1
					END
				END
				ELSE IF @MenuOptions = '2,84*,232#,3522o2,9'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '84*,9'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '232#,3522o2'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '2,232#,9'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 1
					END
				END
				ELSE IF @MenuOptions = '5,749,2322,352*,8'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '2322'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '5,2322,352*'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '749,352*,8'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 0
					END
				END
				ELSE IF @MenuOptions = '3,83o#,239,9'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '83o#,9'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '3,239,9'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '9'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 1
					END
				END
				ELSE IF @MenuOptions = '5,232,3422*,9'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '232,9'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '5,232,9'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '3422*,9'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 1
					END
				END
				ELSE IF @MenuOptions = '2,267,242,527#,8'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '242,527#'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '2,267,242'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '527#,8'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 0
					END
				END
				ELSE IF @MenuOptions = '6,242,349,9'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '6,349,9'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '9'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 1
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '242,349,9'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 1
					END
				END
				ELSE IF @MenuOptions = '6,452,23#,349,8'
				BEGIN
					IF @CountTotNav1 < @TotNav1
					BEGIN
						SET	@Navigation = '23#'
						SET	@CountTotNav1 = @CountTotNav1 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav2 < @TotNav2
					BEGIN
						SET	@Navigation = '6,349'
						SET	@CountTotNav2 = @CountTotNav2 + 1
						SET @IsTransfer = 0
					END
					ELSE IF @CountTotNav3 < @TotNav3
					BEGIN
						SET	@Navigation = '349'
						SET	@CountTotNav3 = @CountTotNav3 + 1
						SET @IsTransfer = 0
					END
				END
				
				SELECT @TMU = CONVERT(INT, 200 * RAND()) + 150
				
				SET @BicShortMenuAccepted = CASE WHEN @MenuOptions <> '1,2,3,4,5,6,7,8,9' THEN 1 ELSE 0 END
				
				SELECT @BicTransfer = 'CDN00' + CONVERT(VARCHAR,CONVERT(INT, 9 * RAND()) + 1)
				
				SELECT @ServiceID = CONVERT(INT, 10 * RAND()) + 15
				
				SELECT @IsComplete = CONVERT(INT, RAND() * 5) + 1
				
				IF @IsComplete <> 5
				BEGIN
					-- loga a navega��o
					INSERT INTO dbo.UdialNavigationLog(BusinessObjectId,SessionId,BicNavigation,LogDate,BicShortMenuAccepted,IvrId,IvrPortNumber,ServerName,BicVoiceBanner,BicTransfer,BicIsCallBack,CallTime,BicOrg)
					VALUES(@BusinessObjectID,@SessionID,@Navigation,@LogDate,@BicShortMenuAccepted,@IvrID,@IvrPortNumber,@ServerName,@BicVoiceBanner,@BicTransfer,0,@TMU,@BicOrg)
				END
				
				IF @IsComplete <> 0
				BEGIN
					-- loga a navega��o de servi�os
					INSERT INTO dbo.BicUdialNavigationServiceLog(LogDate,SessionId,BusinessObjectId,IvrId,IvrPortNumber,ServiceId)
					VALUES(@LogDate,@SessionID,@BusinessObjectID,@IvrID,@IvrPortNumber,@ServiceID)
				END
				
				SELECT @Parameters = NEWID()
				
				IF @IsComplete <> 2
				BEGIN
					-- loga eventos do venda tudo
					INSERT INTO dbo.BicUdialVendaTudoLog(BusinessObjectId,MethodName,Parameters,Result,LogDate)
					VALUES(@BusinessObjectID,@Parameters,@Parameters,@Parameters,@LogDate)
				END
				
				-- logs do umagnet
				IF (@IsTransfer = 1)
				BEGIN
					SET	@OperatorIDAux = CONVERT(INT, RAND() * 150) + 1
					IF @OperatorIDAux IN (9, 18, 27, 32, 44, 50, 63, 70, 84, 87, 91, 110, 121, 126, 136, 142)
						SET	@OperatorID = 'OP' + CONVERT(VARCHAR,CONVERT(INT, 5 * RAND()) + 1001)
					ELSE IF @OperatorIDAux IN (4, 12, 15, 24, 30, 34, 98, 124, 139)
						SET	@OperatorID = 'OP' + CONVERT(VARCHAR,CONVERT(INT, 5 * RAND()) + 1006)
					ELSE IF @OperatorIDAux IN (6, 22, 37, 39, 45, 54, 58, 65, 72, 77, 81, 104, 112, 115, 119, 128, 134, 141, 150)
						SET	@OperatorID = 'OP' + CONVERT(VARCHAR,CONVERT(INT, 5 * RAND()) + 1011)
					ELSE IF @OperatorIDAux IN (3, 21, 26, 46, 61, 64, 66, 69, 76, 80, 88, 92, 97, 102, 103, 108, 113, 116, 123, 127, 129, 133, 140, 148)
						SET	@OperatorID = 'OP' + CONVERT(VARCHAR,CONVERT(INT, 5 * RAND()) + 1016)
					ELSE IF @OperatorIDAux IN (13, 17, 38, 43, 57, 73, 83, 90, 109, 125, 135)
						SET	@OperatorID = 'OP' + CONVERT(VARCHAR,CONVERT(INT, 5 * RAND()) + 1021)
					ELSE IF @OperatorIDAux IN (5, 33, 35, 75, 117, 149)
						SET	@OperatorID = 'OP' + CONVERT(VARCHAR,CONVERT(INT, 5 * RAND()) + 1026)
					ELSE IF @OperatorIDAux IN (11, 20, 23, 28, 31, 40, 47, 51, 53, 55, 59, 62, 67, 71, 74, 79, 82, 86, 93, 95, 96, 99, 100, 105, 107, 114, 118, 120, 130, 132, 138, 143, 144, 146, 147)
						SET	@OperatorID = 'OP' + CONVERT(VARCHAR,CONVERT(INT, 5 * RAND()) + 1031)
					ELSE IF @OperatorIDAux IN (1, 10, 60, 78, 89, 111, 122, 137)
						SET	@OperatorID = 'OP' + CONVERT(VARCHAR,CONVERT(INT, 5 * RAND()) + 1036)
					ELSE IF @OperatorIDAux IN (7, 14, 25, 42, 56, 68, 131)
						SET	@OperatorID = 'OP' + CONVERT(VARCHAR,CONVERT(INT, 5 * RAND()) + 1041)
					ELSE IF @OperatorIDAux IN (2, 8, 16, 19, 29, 36, 41, 48, 49, 52, 85, 94, 101, 106, 145)
						SET @OperatorID = 'OP' + CONVERT(VARCHAR,CONVERT(INT, 5 * RAND()) + 1046)
						
					-- loga o inicio de atendimento
					INSERT INTO dbo.UmagnetStartCallLog(BusinessObjectId,SessionId,LogDate,ServerName,OperatorId,LocalService,CellCode,HipercardMachineId,HipercardUserKey,BicOrg)
					VALUES (@BusinessObjectID,@SessionID,@LogDate,@ServerName,@OperatorID,'1',@BicTransfer,'0','0',@BicOrg)
					
					SET	@CountMessage = 1
					
					WHILE @CountMessage <= 3
					BEGIN
						IF @CountMessage = 1
						BEGIN
							IF @OfferCode IS NOT NULL
							BEGIN
								SET	@MessageCode = @OfferCode
								SET	@MessageType = 3
							END
							ELSE
							BEGIN
								SET	@MessageCodeAux = CONVERT(INT, 30 * RAND()) + 1
								IF @MessageCodeAux IN (3, 11, 15, 18, 23)
								BEGIN
									SET	@MessageCode = 'Alerta' + CAST(@MessageCodeAux as VARCHAR)
									SET	@MessageType = 1
								END
								ELSE IF @MessageCodeAux IN (1, 2, 4, 8, 9, 12, 17, 20, 22, 25, 26, 27, 30)
								BEGIN
									SET	@MessageCode = 'Relacionamento' + CAST(@MessageCodeAux as VARCHAR)
									SET	@MessageType = 2
								END
								ELSE IF @MessageCodeAux IN (6, 7, 14, 16, 24, 29)
								BEGIN
									SET	@MessageCode = 'Oferta' + CAST(@MessageCodeAux as VARCHAR)
									SET	@MessageType = 3
								END
								ELSE IF @MessageCodeAux IN (5, 10, 13, 19, 21, 28)
								BEGIN
									SET	@MessageCode = 'Promo��o' + CAST(@MessageCodeAux as VARCHAR)
									SET	@MessageType = 4
								END
							END
						END
						ELSE
						BEGIN
							SET	@MessageCodeAux = CONVERT(INT, 29 * RAND()) + 1
							IF @MessageCodeAux IN (3, 11, 15, 18, 23)
							BEGIN
								SET	@MessageCode = 'Alerta' + CAST(@MessageCodeAux as VARCHAR)
								SET	@MessageType = 1
							END
							ELSE IF @MessageCodeAux IN (1, 2, 4, 8, 9, 12, 17, 20, 22, 25, 26, 27, 30)
							BEGIN
								SET	@MessageCode = 'Relacionamento' + CAST(@MessageCodeAux as VARCHAR)
								SET	@MessageType = 2
							END
							ELSE IF @MessageCodeAux IN (6, 7, 14, 16, 24, 29)
							BEGIN
								SET	@MessageCode = 'Oferta' + CAST(@MessageCodeAux as VARCHAR)
								SET	@MessageType = 3
							END
							ELSE IF @MessageCodeAux IN (5, 10, 13, 19, 21, 28)
							BEGIN
								SET	@MessageCode = 'Promo��o' + CAST(@MessageCodeAux as VARCHAR)
								SET	@MessageType = 4
							END
							ELSE
							BEGIN
								SET	@MessageCode = 'Alerta' + CAST(@MessageCodeAux as VARCHAR)
								SET	@MessageType = 1
							END
						END
						
						IF @MessageType IS NULL
							SET @MessageType = 1
						
						-- loga as mensagens do in�cio de liga��o
						INSERT INTO dbo.UmagnetStartCallMessageLog(BusinessObjectId,SessionId,LogDate,ServerName,OperatorId,LocalService,CellCode,MessageCode,ProductId,HipercardMessageType,HipercardDeliveryOrder,BicOrg)
						VALUES(@BusinessObjectID,@SessionID,@LogDate,@ServerName,@OperatorID,'1',@BicTransfer,@MessageCode,@MessageCodeAux,@MessageType,NULL,@BicOrg)
						
						IF @MessageType = 3
						BEGIN
							IF @OfferCode IS NOT NULL
							BEGIN
								SET	@MessageResult = 
								CASE @OfferResult
									WHEN 2 THEN 3
									WHEN 3 THEN 4
									ELSE @OfferResult
								 END
							END
							ELSE
							BEGIN
								SET	@MessageResultAux = CONVERT(INT, 29 * RAND())
								IF @MessageResultAux IN (4, 17)
									SET	@MessageResult = 0
								ELSE IF @MessageResultAux IN (9, 14, 20, 27)
									SET	@MessageResult = 1
								ELSE IF @MessageResultAux IN (2, 6, 7, 11, 13, 19, 23, 26, 30)
									SET	@MessageResult = 3
								ELSE IF @MessageResultAux IN (1, 3, 5, 8, 10, 12, 15, 16, 18, 21, 22, 24, 25, 28, 29)
									SET	@MessageResult = 4
							END
						END
						ELSE
						BEGIN
							SET	@MessageResultAux = CONVERT(INT, 29 * RAND()) + 1
							IF @MessageResultAux IN (3, 11, 18, 26)
								SET	@MessageResult = 0
							ELSE IF @MessageResultAux IN (2, 8, 10, 12, 16, 21, 23, 25, 28, 30)
								SET	@MessageResult = 1
							ELSE IF @MessageResultAux IN (1, 4, 5, 6, 7, 9, 13, 14, 15, 17, 19, 20, 22, 24, 27, 29)
								SET	@MessageResult = 2
						END
						
						IF @MessageResult IS NULL
							SET @MessageResult = 0
						
						-- loga as mensagens do fim de atendimento
						INSERT INTO dbo.UmagnetEndCallMessageLog(BusinessObjectId,SessionId,LogDate,ServerName,OperatorId,LocalService,CellCode,MessageCode,MessageResult,ProductId,HipercardMessageType,BicNeedMoreQuestions,BicOrg)
						VALUES(@BusinessObjectID,@SessionID,@LogDate,@ServerName,@OperatorID,'1',@BicTransfer,@MessageCode,@MessageResult,NULL,@MessageType,1,@BicOrg)
						
						SET	@CountMessage = @CountMessage + 1
					END
					
					-- loga os tipos de mensagens da hipercard
					INSERT INTO dbo.HipercardUmagnetMessageTypeLog(BusinessObjectId,SessionId,LogDate,ServerName,OperatorId,Local,Cell,MessageCode,ProductCode,MessageType,Status)
					VALUES(@BusinessObjectID,@SessionID,@LogDate,@ServerName,@OperatorID,'1',@BicTransfer,@MessageCode,NULL,@MessageType,@MessageResult)
						
					
					IF @OfferCode IS NOT NULL
					BEGIN
						SET	@CallReasonID = 1
						SET	@CallReasonName = 'Vendas'
						
						-- loga os produtos da hipercard
						INSERT INTO dbo.HipercardUmagnetProductLog(BusinessObjectId,OperatorId,SessionId,Local,ProductStatus,Product,LogDate,ServerName)
						VALUES(@BusinessObjectID,@OperatorID,@SessionID,'1',@MessageResult,@MessageType,@LogDate,@ServerName)
					END
					ELSE
					BEGIN
						SET	@CallReasonIDAux = CONVERT(INT, 60 * RAND()) + 1
						IF @CallReasonIDAux IN (1, 4, 20, 27, 32, 33, 40, 47, 59, 61, 64, 71, 72, 81, 83, 90, 93, 99)
						BEGIN
							SET	@CallReasonID = 2
							SET	@CallReasonName = 'SAC'
						END
						ELSE IF @CallReasonIDAux IN (6, 22, 26, 45, 58, 68, 74, 88, 97)
						BEGIN
							SET	@CallReasonID = 3
							SET	@CallReasonName = 'Abandono'
						END
						ELSE IF @CallReasonIDAux IN (10, 79)
						BEGIN
							SET	@CallReasonID = 4
							SET	@CallReasonName = 'Reclama��es'
						END
						ELSE IF @CallReasonIDAux IN (18, 24, 37, 55, 70, 86)
						BEGIN
							SET	@CallReasonID = 5
							SET	@CallReasonName = 'Cobran�a de Inadimplente'
						END
						ELSE IF @CallReasonIDAux IN (7, 31, 49, 63, 75, 91, 100)
						BEGIN
							SET	@CallReasonID = 6
							SET	@CallReasonName = 'Alto atrito'
						END
						ELSE IF @CallReasonIDAux IN (3, 15, 17, 29, 34, 39, 44, 56, 60, 66, 73, 80, 89, 92, 98)
						BEGIN
							SET	@CallReasonID = 7
							SET	@CallReasonName = 'Atualiza��o de Cadastro'
						END
						ELSE IF @CallReasonIDAux IN (9, 46)
						BEGIN
							SET	@CallReasonID = 8
							SET	@CallReasonName = 'P�s-venda'
						END
						ELSE IF @CallReasonIDAux IN (19, 43, 78)
						BEGIN
							SET	@CallReasonID = 9
							SET	@CallReasonName = 'Informa��es'
						END
						ELSE IF @CallReasonIDAux IN (11, 25, 36, 48, 54, 62, 82)
						BEGIN
							SET	@CallReasonID = 10
							SET	@CallReasonName = 'Promo��es'
						END
						ELSE IF @CallReasonIDAux IN (12, 28, 38, 67, 95)
						BEGIN
							SET	@CallReasonID = 11
							SET	@CallReasonName = '2� via de Cart�o'
						END
						ELSE IF @CallReasonIDAux IN (2, 8, 16, 21, 41, 53, 69, 76, 85, 94)
						BEGIN
							SET	@CallReasonID = 12
							SET	@CallReasonName = '2� via de Boleto'
						END
						ELSE IF @CallReasonIDAux IN (13, 42, 52, 96)
						BEGIN
							SET	@CallReasonID = 13
							SET	@CallReasonName = '2� via de Fatura'
						END
						ELSE IF @CallReasonIDAux IN (5, 14, 23, 30, 35, 50, 51, 57, 65, 77, 84, 87)
						BEGIN
							SET	@CallReasonID = 14
							SET	@CallReasonName = 'Altera��o de Limite'
						END
					END
					
					SELECT @Nickname = NEWID()
						
					-- loga os nicknames da hipercard
					SELECT TOP 1 @Search = BusinessObjectId FROM dbo.HipercardUmagnetNickNameLog WHERE BusinessObjectId = @BusinessObjectID
					
					IF @Search IS NULL
					BEGIN
						INSERT INTO dbo.HipercardUmagnetNickNameLog(BusinessObjectId,OperatorId,SessionId,NickName,LogDate,ServerName)
						VALUES(@BusinessObjectID,@OperatorID,@SessionID,@Nickname,@LogDate,@ServerName)
					END
					
					IF @IsComplete <> 1
					BEGIN
						-- loga o fim de atendimento
						INSERT INTO dbo.UmagnetEndCallLog(BusinessObjectId,SessionId,LogDate,ServerName,OperatorId,LocalService,CellCode,CallTime,CallReasonId,HipercardMachineId,HipercardUserKey,HipercardOldSmile,HipercardNewSmile,BicOrg)
						VALUES(@BusinessObjectID,@SessionID,@LogDate,@ServerName,@OperatorID,'1',@BicTransfer,@TMU,@CallReasonID,'1','1',NULL,NULL,@BicOrg)
					END
					
					SELECT @Chpras = SUBSTRING([key],1,9) FROM dbo.UPSBusinessObjects WHERE BusinessObjectID = @BusinessObjectID
					
					EXEC dbo.spGeraCPF @cpf OUT
					
					SELECT @Gender = CASE WHEN CONVERT(INT, 2 * RAND()) + 1 = 1 THEN 'M' ELSE 'F' END
					
					SELECT @FormID = CONVERT(INT, 9 * RAND()) + 1
					
					SELECT @IsOther = CONVERT(INT, 2 * RAND())
					
					SELECT @IdConfig = CONVERT(INT, 3 * RAND()) + 1
					
					-- loga a pesquisa de demanda
					IF @IsComplete <> 3
					BEGIN
						INSERT INTO dbo.BicUmagnetCallReasonSelectLog(BusinessObjectID,SessionID,LogDate,ServerName,OperatorID,Chpras,CGCCPF,Gender,CallStartDate,FormID,ReasonID,ReasonDescription,ClassifyReasonID,IsOther,HasTransferCall,IdConfig,BicOrg)
						VALUES(@BusinessObjectID,@SessionID,@LogDate,@ServerName,@OperatorID,@Chpras,@cpf,@Gender,@LogDate,@FormID,@CallReasonID,@CallReasonName,@CallReasonID,@IsOther,@HasTransfer,@IdConfig,@BicOrg)
					END
				
					SET	@ServiceCodeAux = CONVERT(INT, 30 * RAND())
					IF @ServiceCodeAux IN (4, 17)
					BEGIN
						SET	@ServiceCode = 'SRV001'
						SET @ServiceCritical = 'Alto'
					END
					ELSE IF @ServiceCodeAux IN (9, 14, 20, 27)
					BEGIN
						SET	@ServiceCode = 'SRV002'
						SET @ServiceCritical = 'Medio'
					END
					ELSE IF @ServiceCodeAux IN (2, 6, 7, 11, 13, 19, 23, 26, 30)
					BEGIN
						SET	@ServiceCode = 'SRV003'
						SET @ServiceCritical = 'Moderado'
					END
					ELSE IF @ServiceCodeAux IN (1, 3, 5, 8, 10, 12, 15, 16, 18, 21, 22, 24, 25, 28, 29)
					BEGIN
						SET	@ServiceCode = 'SRV004'
						SET @ServiceCritical = 'Baixo'
					END
					
					IF @IsComplete <> 4
					BEGIN
						-- loga os servi�os do umagnet
						INSERT INTO dbo.BicUmagnetServiceLog(BusinessObjectId,SessionId,LogDate,ServerName,OperatorId,BicServiceCode,BicServiceCriticality,BicOrg)
						VALUES(@BusinessObjectID,@SessionID,@LogDate,@ServerName,@OperatorID,@ServiceCode,@ServiceCritical,@BicOrg)
					END
					
					SELECT @IsTrading = CONVERT(INT, 5 * RAND()) + 1
					
					IF @IsTrading = 1
					BEGIN
						SET @OccupationIDAux = CONVERT(INT, 2 * RAND()) + 1
						IF @OccupationIDAux = 1
							SET @OccupationID = 342
						ELSE
							SET @OccupationID = 343
						
						SET @ReasonIDAux = CONVERT(INT, 25 * RAND()) + 1
						
						INSERT INTO #Reasons
						SELECT ROW_NUMBER() OVER (ORDER BY ReasonID) AS Ordem, ReasonID 
						FROM Umagnet.Reasons
						
						SELECT @ReasonID = ReasonID FROM #Reasons WHERE Ordem = @ReasonIDAux
						
						IF @ReasonID IS NULL
							SET @ReasonID = 43
							
						SET @ResultIDAux = CONVERT(INT, 5 * RAND()) + 1
						
						INSERT INTO #Results
						SELECT ROW_NUMBER() OVER (ORDER BY ResultID) AS Ordem, ResultID, ResultType
						FROM Umagnet.Results
						
						SELECT @ResultID = ResultID, @ResultType = ResultType FROM #Results WHERE Ordem = @ResultIDAux
						
						IF @ResultID IS NULL
						BEGIN
							SET @ResultID = 1
							SET @ResultType = 2
						END
						
						SET @IncentiveIDAux = CONVERT(INT, 10 * RAND()) + 1
						
						INSERT INTO #Incentives
						SELECT ROW_NUMBER() OVER (ORDER BY IncentiveID) AS Ordem, IncentiveID 
						FROM Umagnet.Incentives
						
						SELECT @IncentiveID = IncentiveID FROM #Incentives WHERE Ordem = @IncentiveIDAux
						
						IF @IncentiveID IS NULL
							SET @IncentiveID = 739
							
						SET @ArgumentIDAux = CONVERT(INT, 10 * RAND()) + 1
						
						INSERT INTO #Arguments
						SELECT ROW_NUMBER() OVER (ORDER BY ArgumentID) AS Ordem, ArgumentID 
						FROM Umagnet.Arguments
						
						SELECT @ArgumentID = ArgumentID FROM #Arguments WHERE Ordem = @ArgumentIDAux
						
						IF @ArgumentID IS NULL
							SET @ArgumentID = 626
						
						-- loga o hist�rico de negocia��o
						INSERT INTO Umagnet.TradingHistory(BusinessObjectID,SessionID,HistoryDate,HistoryTime,OperatorID,OccupationID,ReasonID,ResultID,ResultType,IncentiveID,Channel,ProductName,Chpras,CPF,BicOrg)
						VALUES(@BusinessObjectID,@SessionID,CAST(@LogDate AS DATE),CAST(@LogDate AS TIME),@OperatorID,@OccupationID,@ReasonID,@ResultID,@ResultType,@IncentiveID,'Umagnet','Itaucard',@Chpras,@cpf,@BicOrg)
						
						SET @TradingID = SCOPE_IDENTITY()
						
						-- loga os argumentos de negocia��o
						INSERT INTO Umagnet.TradingHistoryArguments(TradingID,BusinessObjectID,SessionID,HistoryDate,HistoryTime,OperatorID,OccupationID,ReasonID,ArgumentID,BicOrg)
						VALUES(@TradingID,@BusinessObjectID,@SessionID,CAST(@LogDate AS DATE),CAST(@LogDate AS TIME),@OperatorID,@OccupationID,@ReasonID,@ArgumentID,@BicOrg)
						
						SET @undue = CONVERT(INT, 10 * RAND()) + 1
						
						IF @undue = 7
						BEGIN
							SET @UndueCodeAux = CONVERT(INT, 8 * RAND()) + 1
							IF @UndueCodeAux = 1 OR @UndueCodeAux > 8
								SET @UndueCode = 29
							ELSE IF @UndueCodeAux = 2
								SET @UndueCode = 145
							ELSE IF @UndueCodeAux = 3
								SET @UndueCode = 176
							ELSE IF @UndueCodeAux = 4
								SET @UndueCode = 159
							ELSE IF @UndueCodeAux = 5
								SET @UndueCode = 163
							ELSE IF @UndueCodeAux = 6
								SET @UndueCode = 158
							ELSE IF @UndueCodeAux = 7
								SET @UndueCode = 161
							ELSE IF @UndueCodeAux = 8
								SET @UndueCode = 170
								
							IF @UndueCode IS NULL
								SET @UndueCode = 29
							
							-- loga as indevidas
							INSERT INTO Umagnet.UndueHistory(BusinessObjectID,SessionID,HistoryDate,HistoryTime,OperatorID,UndueCod)
							VALUES(@BusinessObjectID,@SessionID,CAST(@LogDate AS DATE),CAST(@LogDate AS TIME),@OperatorID,@UndueCode)
							
							END
						END
						
						SET	@AlertCodeAux = CONVERT(INT, 30 * RAND())
						IF @AlertCodeAux IN (4, 17)
						BEGIN
							SET	@AlertCode = 'ALERT' + CAST(@AlertCodeAux AS VARCHAR)
							SET @AlertResult = 0
							SET @AlertType = 'ALTO ATRITO'
						END
						ELSE IF @AlertCodeAux IN (9, 14, 20, 27)
						BEGIN
							SET	@AlertCode = 'ALERT' + CAST(@AlertCodeAux AS VARCHAR)
							SET @AlertResult = 1
							SET @AlertType = 'SEM COMUNICA��O'
						END
						ELSE IF @AlertCodeAux IN (2, 6, 7, 11, 13, 19, 23, 26, 30)
						BEGIN
							SET	@AlertCode = 'ALERT' + CAST(@AlertCodeAux AS VARCHAR)
							SET @AlertResult = 2
							SET @AlertType = 'SEM CR�DITO'
						END
						ELSE IF @AlertCodeAux IN (1, 3, 5, 8, 10, 12, 15, 16, 18, 21, 22, 24, 25, 28, 29)
						BEGIN
							SET	@AlertCode = 'ALERT' + CAST(@AlertCodeAux AS VARCHAR)
							SET @AlertResult = 3
							SET @AlertType = 'PAGAMENTO EFETUADO'
						END
						
						SELECT @IsAlert = CONVERT(INT, 2 * RAND())
							
						-- loga os alertas de mensagem
						INSERT INTO Umagnet.AlertMessagesLog(BusinessObjectID,SessionID,LogDate,ServerName,OperatorID,Chpras,AlertCode,AlertDescription,AlertType,AlertResult,BicOrg,IsRelationshipAlert)
						VALUES(@BusinessObjectID,@SessionID,@LogDate,@ServerName,@OperatorID,@Chpras,@AlertCode,@AlertCode,@AlertType,@AlertResult,@BicOrg,@IsAlert)
				END
				
				SET @TotalIndicators = 4
				
				WHILE @TotalIndicators > 0
				BEGIN
					SELECT @UserKey = [KEY] FROM dbo.UPSBusinessObjects WHERE BusinessObjectID = @BusinessObjectID
					
					SET	@IndicatorIDAux = CONVERT(INT, 30 * RAND()) + 1
					IF @IndicatorIDAux IN (3, 11, 15, 18, 23)
					BEGIN
						SET	@IndicatorID = @IndicatorIDAux
						SET	@IndicatorName = 'Indicador' + CAST(@IndicatorIDAux as VARCHAR)
					END
					ELSE IF @IndicatorIDAux IN (1, 2, 4, 8, 9, 12, 17, 20, 22, 25, 26, 27, 30)
					BEGIN
						SET	@IndicatorID = @IndicatorIDAux
						SET	@IndicatorName = 'Indicador' + CAST(@IndicatorIDAux as VARCHAR)
					END
					ELSE IF @IndicatorIDAux IN (6, 7, 14, 16, 24, 29)
					BEGIN
						SET	@IndicatorID = @IndicatorIDAux
						SET	@IndicatorName = 'Indicador' + CAST(@IndicatorIDAux as VARCHAR)
					END
					ELSE IF @IndicatorIDAux IN (5, 10, 13, 19, 21, 28)
					BEGIN
						SET	@IndicatorID = @IndicatorIDAux
						SET	@IndicatorName = 'Indicador' + CAST(@IndicatorIDAux as VARCHAR)
					END
					
					-- loga os indicadores
					INSERT INTO dbo.BicUchannelsIndicatorsLog(UserID,UserKey,CPF,SessionID,LogDate,IndicatorID,IndicatorName)
					VALUES(@BusinessObjectID,@UserKey,@cpf,@SessionID,@LogDate,@IndicatorID,@IndicatorName)
					
					SET @TotalIndicators = @TotalIndicators - 1
				END
				
				SET @CampaignAux = CONVERT(INT, 30 * RAND()) + 1
				IF @CampaignAux IN (4, 17)
				BEGIN
					SET	@CampaignKey = 'CAMPAIGN' + CAST(@CampaignAux AS VARCHAR)
					SET @TransmissionType = 'EMAIL'
				END
				ELSE IF @CampaignAux IN (9, 14, 20, 27)
				BEGIN
					SET	@CampaignKey = 'CAMPAIGN' + CAST(@CampaignAux AS VARCHAR)
					SET @TransmissionType = 'SMS'
				END
				ELSE IF @CampaignAux IN (2, 6, 7, 11, 13, 19, 23, 26, 30)
				BEGIN
					SET	@CampaignKey = 'CAMPAIGN' + CAST(@CampaignAux AS VARCHAR)
					SET @TransmissionType = 'EMAIL'
				END
				ELSE IF @CampaignAux IN (1, 3, 5, 8, 10, 12, 15, 16, 18, 21, 22, 24, 25, 28, 29)
				BEGIN
					SET	@CampaignKey = 'CAMPAIGN' + CAST(@CampaignAux AS VARCHAR)
					SET @TransmissionType = 'SMS'
				END
				
				-- loga os envios de email
				INSERT INTO dbo.BicUchannelsSendLog(BusinessObjectID,LogDate,ServerName,CampaignKey,TransmissionType)
				VALUES(@BusinessObjectID,@LogDate,@ServerName,@CampaignKey,@TransmissionType)
			
				SET	@TotalOffer = @TotalOffer - 1
			END
			
			SET	@AuxOffer = @AuxOffer + 1
			SET	@TotalHora = @TotalHora - @AuxTotalOffer
		END
	
		SET	@Hora = @Hora + 1
		SET	@TotalMenu = @TotalMenu - @AuxTotalHora
	END
	
	SET	@AuxMenu = @AuxMenu + 1
END


DROP TABLE #Results
DROP TABLE #Reasons
DROP TABLE #Incentives
DROP TABLE #Arguments
DROP TABLE #Menu

END
GO


