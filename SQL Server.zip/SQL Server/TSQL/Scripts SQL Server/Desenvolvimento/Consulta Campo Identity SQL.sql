SELECT
    OBJECT_NAME(object_id) AS Tabela,
    c.name AS Coluna,
    t.name AS TipoDados
FROM sys.COLUMNS c
	INNER JOIN sys.types t ON t.system_type_id = c.system_type_id
	--And OBJECT_NAME(object_id) 
	--In (Select A.name From Sysobjects A
	--		Inner join SysColumns B on A.id=b.id
	--		and a.xtype = 'U' and b.name like '%CODEMP%')
WHERE is_identity = 'true'
ORDER BY Tabela, Coluna