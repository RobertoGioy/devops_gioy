Select line,* From Itens_Nota_Fiscal I
Inner join (
Select Row_Number() 
Over(partition by A.Codemp, A.Numnot, A.Sernot, A.Tipnot, A.Codope, A.Codcli, A.Codpro, A.Tippro, A.Induni, A.CodMod, A.Datent
Order by A.Codemp, A.Numnot, A.Sernot, A.Tipnot, A.Codope, A.Codcli, A.Codpro, A.Tippro, A.Induni, A.CodMod, A.Datent)as Line,
A.Codemp, A.Numnot, A.Sernot, A.Tipnot, A.Codope, A.Codcli, A.Codpro, A.Tippro, A.Induni, A.CodMod, A.Datent, A.Reg
From Itens_Nota_Fiscal A
Inner Join (
Select Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, Codpro, Tippro, Induni, CodMod, Datent
From Itens_Nota_Fiscal
Where Datent Between '2010-10-08' And '2010-10-19' And CodCli = 2
Group By Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, Codpro, Tippro, Induni, CodMod, Datent
Having COUNT(reg)>1) B On
A.Codemp=B.Codemp And A.Numnot=B.Numnot And A.Sernot=B.Sernot And A.Tipnot=B.Tipnot And A.Codope=B.Codope And A.Codcli=B.Codcli
And A.Codpro=B.Codpro And A.Tippro=B.Tippro And A.Induni=B.Induni And A.CodMod=B.CodMod And A.Datent=B.Datent
) Tb On
I.Codemp=Tb.Codemp And I.Numnot=Tb.Numnot And I.Sernot=Tb.Sernot And I.Tipnot=Tb.Tipnot And I.Codope=Tb.Codope And I.Codcli=Tb.Codcli
And I.Codpro=Tb.Codpro And I.Tippro=Tb.Tippro And I.Induni=Tb.Induni And I.CodMod=Tb.CodMod And I.Datent=Tb.Datent And I.Reg=Tb.Reg
Where Line = 2
Order By Line

Delete I From Itens_Nota_Fiscal I
Inner join (
Select Row_Number() 
Over(partition by A.Codemp, A.Numnot, A.Sernot, A.Tipnot, A.Codope, A.Codcli, A.Codpro, A.Tippro, A.Induni, A.CodMod, A.Datent
Order by A.Codemp, A.Numnot, A.Sernot, A.Tipnot, A.Codope, A.Codcli, A.Codpro, A.Tippro, A.Induni, A.CodMod, A.Datent)as Line,
A.Codemp, A.Numnot, A.Sernot, A.Tipnot, A.Codope, A.Codcli, A.Codpro, A.Tippro, A.Induni, A.CodMod, A.Datent, A.Reg
From Itens_Nota_Fiscal A
Inner Join (
Select Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, Codpro, Tippro, Induni, CodMod, Datent
From Itens_Nota_Fiscal
Where Datent Between '2010-10-08' And '2010-10-19' And CodCli = 2
Group By Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, Codpro, Tippro, Induni, CodMod, Datent
Having COUNT(reg)>1) B On
A.Codemp=B.Codemp And A.Numnot=B.Numnot And A.Sernot=B.Sernot And A.Tipnot=B.Tipnot And A.Codope=B.Codope And A.Codcli=B.Codcli
And A.Codpro=B.Codpro And A.Tippro=B.Tippro And A.Induni=B.Induni And A.CodMod=B.CodMod And A.Datent=B.Datent
) Tb On
I.Codemp=Tb.Codemp And I.Numnot=Tb.Numnot And I.Sernot=Tb.Sernot And I.Tipnot=Tb.Tipnot And I.Codope=Tb.Codope And I.Codcli=Tb.Codcli
And I.Codpro=Tb.Codpro And I.Tippro=Tb.Tippro And I.Induni=Tb.Induni And I.CodMod=Tb.CodMod And I.Datent=Tb.Datent And I.Reg=Tb.Reg
Where Line = 2
