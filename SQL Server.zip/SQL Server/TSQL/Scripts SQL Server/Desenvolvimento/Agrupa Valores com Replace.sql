SELECT	codpro,
		despro, 
		replace(replace(replace(replace((	select codemp as [text()] 
											from (	
													select * from empdca.dbo.Produtos (nolock)) A 
											where a.codpro = b.codpro and a.despro = b.despro
											FOR XML PATH ),'/',','),'<',''),'>',''),'row','') Empresas

from (	 
		select * from empdca.dbo.Produtos (nolock)) b
group by codpro,despro
order by codpro,despro