Select B.CodEmp As Revenda, B.CodRed As 'Centro De Custo', B.Valor As Planejado, 
       IsNull(Sum(A.ValBai),0) As Realizado, 
       IsNull(Sum(B.Valor-IsNull(A.ValBai,0)),0) As Diferenca
  From 
	  (Select CodEmp, CodRed, IsNull(Sum(ValBai),0) As ValBai 
	      From SL2000Lor.Dbo.Baixa_Cp Where DatBai 
			 Between '2010-08-01' And '2010-08-31' And TipLan = '0'
			     Group By CodEmp, CodRed) As A
  Right Join SL2000Lor.Dbo.Plan_Despesas B On A.CodEmp = B.CodEmp And A.CodRed = B.CodRed
Where B.DatMov = '2010-08-31' And B.Codred = 39017
Group By B.CodEmp, B.CodRed, B.Valor
