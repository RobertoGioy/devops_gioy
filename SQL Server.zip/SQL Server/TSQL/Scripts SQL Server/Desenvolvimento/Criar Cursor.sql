DECLARE @BusinessObjectID int

CREATE TABLE #SEGMENT (id int IDENTITY(1,1), segment char(4))

INSERT INTO #SEGMENT
SELECT SegmentValue FROM Uchannels.Segments ORDER BY 1

DECLARE INFCURSOR CURSOR FOR
SELECT BusinessObjectID FROM [Server].[BusinessObjects] ORDER BY 1

OPEN INFCURSOR
FETCH NEXT FROM INFCURSOR INTO @BusinessObjectID

WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE @SegmentID INT, @SegmentValue VARCHAR(10)
	
	SELECT @SegmentID = CONVERT(INT, RAND() * 57) + 1
	
	SELECT @SegmentValue = segment FROM #SEGMENT WHERE id = @SegmentID
	
	INSERT INTO [Server].[BusinessObjectInformations] (BusinessObjectID, InformationID, CategoricValue)
	VALUES (@BusinessObjectID, 534, @SegmentValue)

	FETCH NEXT FROM INFCURSOR INTO @BusinessObjectID
END

CLOSE INFCURSOR
DEALLOCATE INFCURSOR

DROP TABLE #SEGMENT

