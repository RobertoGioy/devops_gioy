Sp_Verifica_processo 'programname like ''%e171s2%'''


while 
Usp_Libera_Processos '260'


while 1 = 1
begin
waitfor delay '00:00:10'
exec sp_lp 260
end