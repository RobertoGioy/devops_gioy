
Update A Set A.MetaLitro=R.MetaLitro 
From Termo_Comodato A
Inner Join (
		Select A.Codemp,C.Numcom,C.Datinc,Sum(C.Qtdite*A.Litros) As MetaLitro From MetaLitro A
		Inner Join (
					Select A.Codemp,A.Numcom,A.Datinc,A.Codite,B.Codcat,A.Qtdite From Itens_Comodatos A
					Inner Join Embalagens B On A.Codemp=B.Codemp And A.Codite=B.Codemb And A.Tipite='E'
					Group By A.Codemp,A.Numcom,A.Datinc,A.Codite,B.Codcat,Qtdite
					) C On A.Codemp=C.Codemp And A.Codcat=C.Codcat
		Group By A.Codemp,C.Numcom,C.Datinc) R On A.Codemp=R.Codemp And A.Numcom=R.Numcom And A.Datped=R.Datinc






Update A Set A.MetaLitro=R.MetaLitro
From Comodatos A
Inner Join (
		Select A.Codemp,C.Numcom,C.Datinc,Sum(C.Qtdite*A.Litros) As MetaLitro From MetaLitro A
		Inner Join (
					Select A.Codemp,A.Numcom,A.Datinc,A.Codite,B.Codcat,A.Qtdite From Itens_Comodatos A
					Inner Join Embalagens B On A.Codemp=B.Codemp And A.Codite=B.Codemb And A.Tipite='E'
					Group By A.Codemp,A.Numcom,A.Datinc,A.Codite,B.Codcat,Qtdite
					) C On A.Codemp=C.Codemp And A.Codcat=C.Codcat
		Group By A.Codemp,C.Numcom,C.Datinc) R On A.Codemp=R.Codemp And A.Numcom=R.Numcom And A.Datinc=R.Datinc
