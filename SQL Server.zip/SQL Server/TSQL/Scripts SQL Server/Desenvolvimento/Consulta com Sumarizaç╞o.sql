
declare @cCodemp CHAR(3), @fNumMap FLOAT, @iTipped INT
set @cCodemp='614'
set @fNumMap='17062008004'
set @iTipped='0'
        
If (Select COUNT(*) from Mapas where Codemp = @cCodemp AND NumMap = @fNumMap and (not datcai is null or procar = 'S') and Tipped = @iTipped) = 0         
    BEGIN        
    DECLARE @iQtdPed int, @iCodven int, @iCodrot int, @dDatPro datetime, @wplavei varchar(10), @wufvei char(2), @wcodmot int      
        
    SET @wplavei = (SELECT Plavei  FROM Mapas WHERE Codemp = @cCodemp AND NumMap = @fNumMap and Tipped = @iTipped)          
    SET @wufvei  = (SELECT UfVei   FROM Mapas WHERE Codemp = @cCodemp AND NumMap = @fNumMap and Tipped = @iTipped)          
    SET @wcodmot = (SELECT Codmot  FROM Mapas WHERE Codemp = @cCodemp AND NumMap = @fNumMap and Tipped = @iTipped)          
    --EXCLUIR O MAPA          
    DELETE FROM Mapas WHERE Codemp = @cCodemp AND NumMap = @fNumMap and Tipped = @iTipped        
        
    SET @iQtdPed = (SELECT COUNT(Numped) FROM Pedido WHERE Codemp = @cCodemp AND NumMap = @fNumMap and Tipped = @iTipped)          
    SET @iCodven = (SELECT TOP 1 Codven  FROM Pedido WHERE Codemp = @cCodemp AND NumMap = @fNumMap and Tipped = @iTipped)          
    SET @iCodRot = (SELECT TOP 1 Codrot  FROM Pedido WHERE Codemp = @cCodemp AND NumMap = @fNumMap and Tipped = @iTipped)          
    SET @dDatPro = (SELECT MIN(Datped)   FROM Pedido WHERE Codemp = @cCodemp AND NumMap = @fNumMap and Tipped = @iTipped)          
        
    --INSERIR O MAPA COM O MESMO NUMERO          
    INSERT INTO Mapas (Codemp,NumMap,Tipped,DatGer,QtdPed,CodVen,CodRot,Plavei,UFVei,Codmot)         
    VALUES (@cCodemp,@fNumMap,@iTipped,@dDatPro,@iQtdPed,@iCodVen,@iCodRot,@wplavei,@wufvei,@wCodmot)          
            
    --EXCLUIR OS ITENS DO MAPA          
    DELETE FROM Itens_Mapa WHERE Codemp = @cCodemp AND NumMap = @fNumMap and Tipped = @iTipped        
        
    --INSERIR O ITENS DO MAPA           
    INSERT INTO Itens_Mapa (Codemp, NumMap, Pecodi, Stapro, Tipped, Nompro, Qtdpro, Valpro, Qtdbon, Qtdcon, Valbon)           
    SELECT Codemp, Nummap, Pecodi, Tippro, Tipped, MAX(Nompro), SUM(Qtdpro), SUM(Valpro), SUM(Qtdbon), SUM(Qtdcon), SUM(Valbon)    
    FROM    
    (SELECT Codemp, Nummap, Pecodi, Tippro, Tipped, MAX(Nompro) as Nompro,         
    (select isnull(case when tipoco in (Select Codigo from vs_TransVB) or tipoco in (Select Codigo from vs_TransC) then sum(Qtde) else 0 end,0))as Qtdpro,        
    (select isnull(case when tipoco in (Select Codigo from vs_TransV)  then sum(Valbru) else 0 end,0))as Valpro,        
    (select isnull(case when tipoco in (Select Codigo from vs_TransB)  then sum(Qtde)   else 0 end,0))as Qtdbon,        
    (select isnull(case when tipoco in (Select Codigo from vs_TransC)  then sum(Qtde)   else 0 end,0))as Qtdcon,        
    (select isnull(case when tipoco in (Select Codigo from vs_TransB)  then sum(Valbru) else 0 end,0))as Valbon        
    FROM Itens_Pedido         
    WHERE CodEmp = @cCodEmp AND NumMap = @fNumMap and Tipped = @iTipped        
    Group by Codemp, Nummap, Pecodi, Tippro, Tipped, Tipoco) as t    
    Group by Codemp, Nummap, Pecodi, Tippro, Tipped    
    END        