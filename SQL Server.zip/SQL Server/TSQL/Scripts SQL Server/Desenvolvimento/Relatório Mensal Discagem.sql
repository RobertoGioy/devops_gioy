USE db_discador_brisa
GO

SET LANGUAGE 'Brazilian'

DECLARE @DATINI DATE, @DATFIM DATE

SET @DATINI = '20140101'
SET @DATFIM = '20140801'


SELECT 
DATEPART(MONTH,d.dtinicio) [Mes Referencia],
Case When el.issucesso = 1 Then 'Cobradas' Else 'N�o Cobradas' End [Status],
COUNT(Distinct cdligacao) [QtdLigacao],
ROW_NUMBER() Over (Order by DATEPART(MONTH,d.dtinicio),Case When el.issucesso = 1 Then 'Cobradas' Else 'N�o Cobradas' End) Seq
INTO #Brisa
from db_discador_brisa.dbo.historico_ligacao d 
inner join db_discador_brisa.dbo.estado_ligacao el on d.cdestadoligacao = el.cdestadoligacao
inner join db_discador_brisa.dbo.parametro_estadoligacao pel on d.cdcampanha = pel.cdcampanha
where d.dtinicio >=@DATINI And d.dtinicio < @DATFIM
Group By DATEPART(MONTH,d.dtinicio),Case When el.issucesso = 1 Then 'Cobradas' Else 'N�o Cobradas' End
Order By Seq

SELECT 
Case When [Mes Referencia] = 1 Then 'Janeiro'
When [Mes Referencia] = 2 Then 'Fevereiro'
When [Mes Referencia] = 3 Then 'Mar�o'
When [Mes Referencia] = 4 Then 'Abril'
When [Mes Referencia] = 5 Then 'Maio'
When [Mes Referencia] = 6 Then 'Junho'
When [Mes Referencia] = 7 Then 'Julho'
When [Mes Referencia] = 8 Then 'Agosto'
When [Mes Referencia] = 9 Then 'Setembro'
When [Mes Referencia] = 10 Then 'Outubro'
When [Mes Referencia] = 11 Then 'Novembro'
Else 'Dezembro' End [Mes Referencia],
[Cobradas],
[N�o Cobradas],
SUM([N�o Cobradas]+[Cobradas]) [Total]
INTO ExportLigacoesBrisaMensal
 From (
Select
[Mes Referencia] [Mes Referencia], 
[Cobradas] [Cobradas],
[N�o Cobradas] [N�o Cobradas]
From (Select [Mes Referencia],[Status],[QtdLigacao] From #Brisa) A
PIVOT (Sum(QtdLigacao) FOR [Status]IN ([Cobradas],[N�o Cobradas]))P
)TOTAL
Group By 
[Mes Referencia],
[Cobradas],
[N�o Cobradas]



Select [Mes Referencia], [Cobradas], [N�o Cobradas], [Total] From db_discador_brisa.dbo.ExportLigacoesBrisaMensal




Drop table #Brisa
Drop table ExportLigacoesBrisaMensal