select @@servername

SET QUOTED_IDENTIFIER OFF 

DECLARE @CMD0 VARCHAR(MAX), @CMD1 VARCHAR(MAX), @CMD2 VARCHAR(MAX), @CMD3 VARCHAR(MAX), @CMD4 VARCHAR(MAX)

DECLARE @base sysname, @reg int, @tot int

create table #temp (Servidor Varchar(max), Base Varchar(max), empresa Varchar(max))


create table Master.dbo.Temp33 (Servidor Varchar(max), Base Varchar(max), Tabela Varchar(max), Campo Varchar(Max), QtdInf Int)


SET @CMD1 = 
"
		DECLARE @VAR1 SYSNAME, @VAR2 SYSNAME

		DECLARE CURSOR1 CURSOR FOR

		select name from sysobjects where  xtype = 'u'
		
		
		OPEN CURSOR1
		FETCH NEXT FROM CURSOR1 INTO @VAR1
		WHILE @@FETCH_STATUS = 0
			BEGIN


			DECLARE CURSOR2 CURSOR FOR

			select c.name from sysobjects o inner join syscolumns c on o.id = c.id where  o.xtype = 'u' and o.name = @var1 And Not O.Name Like '%trace_%' And Not O.Name Like '%SQL_%'
			
			OPEN CURSOR2
			FETCH NEXT FROM CURSOR2 INTO @VAR2
			WHILE @@FETCH_STATUS = 0
				BEGIN
				exec ( 'Insert Into Master.dbo.Temp33
				        select @@servername Servidor, DB_name() as Base, ''' + @var1 + ''' as Tabela , ''' + @var2 + ''' as Campo, count(1) as Qtde 
						from ' + @VAR1 + ' (nolock) where ' + @VAR2 + ' like (''%teste%'')')
				FETCH NEXT FROM CURSOR2 INTO @VAR2
				END
			CLOSE CURSOR2
			DEALLOCATE CURSOR2

	
			FETCH NEXT FROM CURSOR1 INTO @VAR1
			END
		CLOSE CURSOR1
		DEALLOCATE CURSOR1
		
		

		
"


set @tot = (select count(name) as Reg from sys.sysdatabases Where NOT NAME IN ('TEMPDB'))
				
set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases Where NOT NAME IN ('TEMPDB')) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
					EXEC (""" + @CMD1 + """) 
					")
	
	set @reg = @reg + 1
	end

Select * From Master.dbo.Temp33 Where QtdInf > 0


Drop Table Master.dbo.Temp33

Drop Table #temp            
            


