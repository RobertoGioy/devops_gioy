
CREATE FUNCTION fnSplit
(
	@String NVARCHAR(4000), 
	@Delimiter CHAR(1)
)
RETURNS @Results TABLE (value NVARCHAR(4000)) AS

BEGIN    
	DECLARE @INDEX INT    
	DECLARE @SLICE nvarchar(4000)

	SELECT @INDEX = 1      
	IF @String IS NULL RETURN
 
	WHILE @INDEX !=0        
	BEGIN  
		SELECT @INDEX = CHARINDEX(@Delimiter,@STRING)

		 IF @INDEX !=0              
			SELECT @SLICE = LEFT(@STRING,@INDEX - 1)            
		ELSE                
			SELECT @SLICE = @STRING

		INSERT INTO @Results(value) VALUES(@SLICE)

		SELECT @STRING = RIGHT(@STRING,LEN(@STRING) - @INDEX)

		IF LEN(@STRING) = 0 BREAK
	END    
	RETURN
END