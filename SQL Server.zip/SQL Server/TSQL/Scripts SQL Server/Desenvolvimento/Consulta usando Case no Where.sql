/*  
******* ULTIMA ATUALIZA��O 12/05/2010 *******  
*	       CARGA ATUALIZADA		            *  
*********************************************  
*/

DROP TABLE [#Nota_Fiscal]
DROP TABLE [#Itens_Nota_Fiscal]


CREATE TABLE [dbo].[#Nota_Fiscal] (
	[Codemp] [char](3) NOT NULL,
	[Numnot] [varchar](9) NOT NULL,
	[Sernot] [char](3) NOT NULL,
	[Tipnot] [char](1) NOT NULL,
	[Codope] [int] NOT NULL,
	[Pericm] [decimal](18, 2) NOT NULL,
	[Codcli] [int] NOT NULL,
	[Clifor] [char](1) NULL,
	[CodMod] INT NOT NULL,
	[Datnot] [datetime] NULL,
	[Datent] [datetime] NOT NULL,
	[Valbru] [decimal](18, 2) NULL,
	[Valdes] [decimal](18, 2) NULL,
	[Valliq] [decimal](18, 2) NULL,
	[Valvar] [decimal](18, 2) NULL,
	[Basicm] [decimal](18, 2) NULL,
	[Valicm] [decimal](18, 2) NULL,
	[Bassub] [decimal](18, 2) NULL,
	[Icmsub] [decimal](18, 2) NULL,
	[Valipi] [decimal](18, 2) NULL,
	[Valfre] [decimal](18, 2) NULL,
	[Valseg] [decimal](18, 2) NULL,
	[Valout] [decimal](18, 2) NULL,
	[Status] [char](1) NULL,
	[Observ] [char](100) NULL,
	[Valise] [decimal](18, 2) NULL,
	[Basipi] [decimal](18, 2) NULL,
	[Tipope] [int] NULL,
	[Tipoco] [int] NULL,
	[IseIpi] [decimal](18, 2) NULL,
	[OutIpi] [decimal](18, 2) NULL,
	[BasIss] [numeric](18, 2) NULL,
	[OutDes] [decimal](18, 2) NULL,
	CONSTRAINT [PK_Nota_Fiscal1] PRIMARY KEY CLUSTERED (
		[Codemp] ASC,
		[Numnot] ASC,
		[Sernot] ASC,
		[Tipnot] ASC,
		[Codope] ASC,
		[Pericm] ASC,
		[Codcli] ASC,
		[Codmod] ASC,
		[Datent] ASC
		) WITH (
		PAD_INDEX = OFF,
		STATISTICS_NORECOMPUTE = OFF,
		IGNORE_DUP_KEY = OFF,
		ALLOW_ROW_LOCKS = ON,
		ALLOW_PAGE_LOCKS = ON,
		FILLFACTOR = 90
		) ON [PRIMARY]
	) ON [PRIMARY]

CREATE TABLE [dbo].[#Itens_Nota_Fiscal] (
	[Codemp] [char](3) NOT NULL,
	[Numnot] [varchar](9) NOT NULL,
	[Sernot] [char](3) NOT NULL,
	[Tipnot] [char](1) NOT NULL,
	[Codope] [int] NOT NULL,
	[Codcli] [int] NOT NULL,
	[Codpro] [int] NOT NULL,
	[Tippro] [char](1) NOT NULL,
	[Reg] [int] IDENTITY(1, 1) NOT NULL,
	[Datent] [datetime] NULL,
	[Valbru] [decimal](18, 2) NULL,
	[Valdes] [decimal](18, 2) NULL,
	[Valliq] [decimal](18, 2) NULL,
	[Valipi] [decimal](18, 2) NULL,
	[Pericm] [decimal](18, 2) NULL,
	[Codtri] [char](3) NULL,
	[Univar] [decimal](18, 2) NULL,
	[Perred] [decimal](18, 2) NULL,
	[Status] [char](1) NULL,
	[Basicm] [decimal](18, 2) NULL,
	[Valicm] [decimal](18, 2) NULL,
	[Bassub] [decimal](18, 2) NULL,
	[Icmsub] [decimal](18, 2) NULL,
	[Extope] [int] NULL,
	[Valise] [decimal](18, 2) NULL,
	[Valout] [decimal](18, 2) NULL,
	[Basipi] [decimal](18, 2) NULL,
	[Valfre] [decimal](18, 2) NULL,
	[Valseg] [decimal](18, 2) NULL,
	[Tipope] [int] NULL,
	[Tipoco] [int] NULL,
	[Datexp] [smalldatetime] NULL,
	[IseIpi] [decimal](18, 2) NULL,
	[OutIpi] [decimal](18, 2) NULL,
	[CodMod] [int] NULL,
	[Pis] [numeric](18, 2) NULL,
	[Cofins] [numeric](18, 2) NULL,
	[CSocial] [numeric](18, 2) NULL,
	[DifAliq] [numeric](18, 2) NULL,
	[DifIPI] [numeric](18, 2) NULL,
	[DifST] [numeric](18, 2) NULL
	) ON [PRIMARY]

ALTER TABLE [dbo].[#Itens_Nota_Fiscal] ADD CONSTRAINT [PK_Itens_Nota_Fiscal1] PRIMARY KEY CLUSTERED (
	[Codemp] ASC,
	[Numnot] ASC,
	[Sernot] ASC,
	[Tipnot] ASC,
	[Codope] ASC,
	[Codcli] ASC,
	[Codpro] ASC,
	[Tippro] ASC,
	[Reg] ASC
	)
	WITH (
			PAD_INDEX = OFF,
			STATISTICS_NORECOMPUTE = OFF,
			IGNORE_DUP_KEY = OFF,
			ALLOW_ROW_LOCKS = ON,
			ALLOW_PAGE_LOCKS = ON,
			FILLFACTOR = 90
			) ON [PRIMARY]

INSERT INTO #Nota_Fiscal
SELECT Codemp,
	Numnot,
	Sernot,
	Tipnot,
	Codope,
	Pericm,
	Codcli,
	Clifor,
	CodMod,
	Datnot,
	Datent,
	Valbru,
	Valdes,
	Valliq,
	Valvar,
	Basicm,
	Valicm,
	Bassub,
	Icmsub,
	Valipi,
	Valfre,
	Valseg,
	Valout,
	STATUS,
	Observ,
	Valise,
	Basipi,
	Tipope,
	Tipoco,
	IseIpi,
	OutIpi,
	0,
	OutDes
FROM DC.DC.dbo.Nota_Fiscal WITH (NOLOCK)
WHERE CASE 
		WHEN tipnot = 'S'
			THEN datnot
		ELSE datent
		END BETWEEN '2013-01-01'
		AND '2013-12-31'
	AND codemp IN ('129')

INSERT INTO #itens_nota_fiscal
SELECT Codemp,
	Numnot,
	Sernot,
	Tipnot,
	Codope,
	Codcli,
	Codpro,
	Tippro,
	Datent,
	Valbru,
	Valdes,
	Valliq,
	Valipi,
	Pericm,
	Codtri,
	Univar,
	Perred,
	STATUS,
	Basicm,
	Valicm,
	Bassub,
	Icmsub,
	Extope,
	Valise,
	Valout,
	Basipi,
	Valfre,
	Valseg,
	Tipope,
	Tipoco,
	'2010-05-06',
	IseIpi,
	OutIpi,
	CodMod,
	Pis,
	Cofins,
	CSocial,
	DifAliq,
	DifIPI,
	DifST
FROM DC.DC.dbo.Itens_Nota_Fiscal WITH (NOLOCK)
WHERE CASE 
		WHEN tipnot = 'S'
			THEN datnot
		ELSE datent
		END BETWEEN '2013-01-01'
		AND '2013-12-31'
	AND codemp IN ('129')

DECLARE @ini DATETIME,
	@fin DATETIME

SET @ini = '2013-01-01'
SET @fin = '2013-12-31'

DELETE
FROM Fiscal2010
WHERE datent BETWEEN @ini
		AND @fin
	AND codemp IN ('129')

INSERT INTO Fiscal2010
SELECT a.Codemp,
	a.Numnot,
	a.Sernot,
	a.Tipnot,
	a.Codope,
	a.Pericm,
	a.Codcli,
	isnull(b.codpro, 0) AS CodPro,
	isnull(b.tippro, 0) AS TipPro,
	a.CodMod,
	a.CliFor,
	year(CASE 
			WHEN a.tipnot = 'S'
				THEN a.DatNot
			ELSE a.DatEnt
			END) AS Ano,
	month(CASE 
			WHEN a.tipnot = 'S'
				THEN a.DatNot
			ELSE a.DatEnt
			END) AS Mes,
	CASE 
		WHEN a.tipnot = 'S'
			THEN a.DatNot
		ELSE a.DatEnt
		END,
	sum(isnull(b.valbru, 0) - isnull(b.valdes, 0) + isnull(b.icmsub, 0) + isnull(b.valipi, 0) + isnull(b.difipi, 0) + isnull(b.difst, 0)) AS [Valor Cont�bil],
	sum(b.basicm) [ICMS - BASE CALCULO],
	sum(b.basipi) [IPI - BASE CALCULO],
	sum(b.valicm) [ICMS - IMPOSTO DEBIT.],
	sum(b.valipi) [IPI - IMPOSTO DEBIT.],
	sum(b.valise) [ICMS - ISENTA/N.TRIB.],
	CASE 
		WHEN sum(a.iseipi) <> 0
			THEN sum(b.iseipi)
		ELSE 0
		END [IPI - ISENTA/N.TRIB.],
	CASE 
		WHEN sum(a.outipi) <> 0
			THEN sum(b.outipi - b.valdes - b.icmsub)
		ELSE 0
		END [IPI - Outras]
FROM #Itens_Nota_Fiscal b WITH (NOLOCK)
INNER JOIN (
	SELECT a.*
	FROM #Nota_Fiscal a WITH (NOLOCK)
	LEFT JOIN (
		SELECT Codemp,
			Numnot,
			Sernot,
			Tipnot,
			Codope,
			Codcli,
			PerICM,
			CodMod,
			sum(ValBru - ValDes) AS ValorTotal
		FROM #Itens_Nota_Fiscal WITH (NOLOCK)
		GROUP BY Codemp,
			Numnot,
			Sernot,
			Tipnot,
			Codope,
			Codcli,
			PerICM,
			CodMod
		) b ON a.codemp = b.codemp
		AND a.numnot = b.numnot
		AND a.sernot = b.sernot
		AND a.tipnot = b.tipnot
		AND a.codope = b.codope
		AND a.codcli = b.codcli
		AND a.pericm = b.pericm
		AND a.codmod = b.codmod
	WHERE CASE 
			WHEN a.tipnot = 'S'
				THEN a.DatNot
			ELSE a.DatEnt
			END BETWEEN @ini
			AND @fin
		AND a.tipnot IN (
			'S',
			'E'
			)
		AND (
			a.STATUS <> 'C'
			OR a.STATUS IS NULL
			)
		AND a.valbru - a.valdes <> b.ValorTotal
	) a ON a.codemp = b.codemp
	AND a.numnot = b.numnot
	AND a.sernot = b.sernot
	AND a.tipnot = b.tipnot
	AND a.codope = b.codope
	AND a.codcli = b.codcli
	AND a.pericm = b.pericm
	AND a.codmod = b.codmod
	AND a.Datent = b.Datent
WHERE isnull(observ, '') <> 'PS'
	AND NOT a.sernot = 'R-Q'
GROUP BY a.Codemp,
	a.Numnot,
	a.Sernot,
	a.Tipnot,
	a.Codope,
	a.Pericm,
	a.Codcli,
	isnull(b.codpro, 0),
	isnull(b.tippro, 0),
	a.CliFor,
	a.CodMod,
	CASE 
		WHEN a.tipnot = 'S'
			THEN a.DatNot
		ELSE a.DatEnt
		END

UNION

SELECT a.Codemp,
	a.Numnot,
	a.Sernot,
	a.Tipnot,
	a.Codope,
	a.Pericm,
	a.Codcli,
	isnull(b.codpro, 0),
	isnull(b.tippro, 0),
	a.CodMod,
	a.CliFor,
	year(CASE 
			WHEN a.tipnot = 'S'
				THEN a.DatNot
			ELSE a.DatEnt
			END) AS Ano,
	month(CASE 
			WHEN a.tipnot = 'S'
				THEN a.DatNot
			ELSE a.DatEnt
			END) AS Mes,
	CASE 
		WHEN a.tipnot = 'S'
			THEN a.DatNot
		ELSE a.DatEnt
		END,
	sum(b.valbru - b.valdes) AS [Valor Cont�bil],
	sum(b.basicm) [ICMS - BASE CALCULO],
	sum(b.basipi) [IPI - BASE CALCULO],
	sum(b.valicm) [ICMS - IMPOSTO DEBIT.],
	sum(b.valipi) [IPI - IMPOSTO DEBIT.],
	sum(b.valise) [ICMS - ISENTA/N.TRIB.],
	CASE 
		WHEN sum(a.iseipi) <> 0
			THEN sum(b.iseipi)
		ELSE 0
		END [IPI - ISENTA/N.TRIB.],
	CASE 
		WHEN sum(a.outipi) <> 0
			THEN sum(b.outipi - b.valdes - b.icmsub)
		ELSE 0
		END [IPI - Outras]
FROM #Itens_Nota_Fiscal b WITH (NOLOCK)
INNER JOIN (
	SELECT a.*
	FROM #Nota_Fiscal a WITH (NOLOCK)
	LEFT JOIN (
		SELECT Codemp,
			Numnot,
			Sernot,
			Tipnot,
			Codope,
			Codcli,
			PerICM,
			CodMod,
			sum(ValBru - ValDes) AS ValorTotal
		FROM #Itens_Nota_Fiscal WITH (NOLOCK)
		GROUP BY Codemp,
			Numnot,
			Sernot,
			Tipnot,
			Codope,
			Codcli,
			PerICM,
			CodMod
		) b ON a.codemp = b.codemp
		AND a.numnot = b.numnot
		AND a.sernot = b.sernot
		AND a.pericm = b.pericm
		AND a.tipnot = b.tipnot
		AND a.codope = b.codope
		AND a.codcli = b.codcli
		AND a.codmod = b.codmod
	WHERE CASE 
			WHEN a.tipnot = 'S'
				THEN a.DatNot
			ELSE a.DatEnt
			END BETWEEN @ini
			AND @fin
		AND a.tipnot IN (
			'S',
			'E'
			)
		AND (
			a.STATUS <> 'C'
			OR a.STATUS IS NULL
			)
		AND a.valbru - a.valdes = b.ValorTotal
	) a ON a.codemp = b.codemp
	AND a.numnot = b.numnot
	AND a.sernot = b.sernot
	AND a.tipnot = b.tipnot
	AND a.codope = b.codope
	AND a.codcli = b.codcli
	AND a.pericm = b.pericm
	AND a.codmod = b.codmod
	AND a.Datent = b.Datent
WHERE isnull(observ, '') <> 'PS'
	AND NOT a.sernot = 'R-Q'
GROUP BY a.Codemp,
	a.Numnot,
	a.Sernot,
	a.Tipnot,
	a.Codope,
	a.Pericm,
	a.Codcli,
	isnull(b.codpro, 0),
	isnull(b.tippro, 0),
	a.CliFor,
	CASE 
		WHEN a.tipnot = 'S'
			THEN a.DatNot
		ELSE a.DatEnt
		END,
	a.codmod

UNION

SELECT a.Codemp,
	a.Numnot,
	a.Sernot,
	a.Tipnot,
	a.Codope,
	a.Pericm,
	a.Codcli,
	'0',
	'0',
	a.Codmod,
	a.CliFor,
	year(CASE 
			WHEN a.tipnot = 'S'
				THEN a.DatNot
			ELSE a.DatEnt
			END) AS Ano,
	month(CASE 
			WHEN a.tipnot = 'S'
				THEN a.DatNot
			ELSE a.DatEnt
			END) AS Mes,
	CASE 
		WHEN a.tipnot = 'S'
			THEN a.DatNot
		ELSE a.DatEnt
		END,
	sum(b.valbru - b.valdes) AS [Valor Cont�bil],
	sum(b.basicm) [ICMS - BASE CALCULO],
	sum(b.basipi) [IPI - BASE CALCULO],
	sum(b.valicm) [ICMS - IMPOSTO DEBIT.],
	sum(b.valipi) [IPI - IMPOSTO DEBIT.],
	sum(b.valise) [ICMS - ISENTA/N.TRIB.],
	sum(b.iseipi) [IPI - ISENTA/N.TRIB.],
	sum(b.outipi - b.valdes - b.icmsub) [IPI - Outras]
FROM #Nota_Fiscal b
INNER JOIN (
	SELECT a.*,
		'0' AS CodPro,
		'0' AS tipPro
	FROM #Nota_Fiscal a WITH (NOLOCK)
	WHERE NOT EXISTS (
			SELECT Codemp,
				Numnot,
				Sernot,
				Tipnot,
				Codope,
				Codcli,
				PerICM,
				codmod,
				sum(ValBru - ValDes) AS ValorTotal
			FROM #Itens_Nota_Fiscal b WITH (NOLOCK)
			WHERE a.codemp = b.codemp
				AND a.numnot = b.numnot
				AND a.sernot = b.sernot
				AND a.pericm = b.pericm
				AND a.tipnot = b.tipnot
				AND a.codope = b.codope
				AND a.codcli = b.codcli
				AND a.codmod = b.codmod
			GROUP BY Codemp,
				Numnot,
				Sernot,
				Tipnot,
				Codope,
				Codcli,
				PerICM,
				codmod
			)
		AND CASE 
			WHEN a.tipnot = 'S'
				THEN a.DatNot
			ELSE a.DatEnt
			END BETWEEN @ini
			AND @fin
		AND a.tipnot IN (
			'S',
			'E'
			)
		AND (
			a.STATUS <> 'C'
			OR a.STATUS IS NULL
			)
		AND isnull(observ, '') <> 'PS'
		AND sernot <> 'R-Q'
	) a ON a.codemp = b.codemp
	AND a.numnot = b.numnot
	AND a.sernot = b.sernot
	AND a.tipnot = b.tipnot
	AND a.codope = b.codope
	AND a.codcli = b.codcli
	AND a.pericm = b.pericm
	AND a.codmod = b.codmod
	AND a.Datent = b.Datent
GROUP BY a.Codemp,
	a.Numnot,
	a.Sernot,
	a.Tipnot,
	a.Codope,
	a.Pericm,
	a.Codcli,
	CASE 
		WHEN a.tipnot = 'S'
			THEN a.DatNot
		ELSE a.DatEnt
		END,
	a.CliFor,
	a.codmod


/*EXECUTAR O COMANDO ABAIXO PARA CONFERIR SE OS CADASTROS EST�O OK!

INSERT INTO clifor_fiscal (CodEmp, CodCliFor, DesCliFor, CliFor, CPFCNPJ)
Select CodEmp, CodCli, nomcli, 'C' CliFor, CgcCli
From DC.DC.Dbo.Clientes A With(Nolock) Where Not Exists (Select * From clifor_fiscal B Where A.Codemp=B.Codemp And A.codcli=B.CodCliFor) 

INSERT INTO clifor_fiscal (CodEmp, CodCliFor, DesCliFor, CliFor, CPFCNPJ)
Select CodEmp, Codfor, RazFor, 'F' CliFor, Cgcfor
From DC.DC.Dbo.Fornecedores A With(Nolock) Where Not Exists (Select * From clifor_fiscal B Where A.Codemp=B.Codemp And A.Codfor=B.CodCliFor) 

INSERT INTO clifor_fiscal (CodEmp, CodCliFor, DesCliFor, CliFor, CPFCNPJ)
Select CodEmp, CodCli, nomcli, 'C' CliFor, CgcCli
From DC.EMPDC.Dbo.Clientes A With(Nolock) Where Not Exists (Select * From clifor_fiscal B Where A.Codemp=B.Codemp And A.codcli=B.CodCliFor) 

INSERT INTO clifor_fiscal (CodEmp, CodCliFor, DesCliFor, CliFor, CPFCNPJ)
Select CodEmp, Codfor, RazFor, 'F' CliFor, Cgcfor
From DC.EMPDC.Dbo.Fornecedores A With(Nolock) Where Not Exists (Select * From clifor_fiscal B Where A.Codemp=B.Codemp And A.Codfor=B.CodCliFor) 


Insert Into PRODUTOS_FISCAL(CodItem, TipItem, DescItem, ClaFis)
Select * From (
Select Codpro, 'P' Tippro, Despro, Clafis From [172.17.6.102,1805].Atualiza_Cadastros.dbo.Produtos A With(NOLOCK) Where Codemp = 101
And Not Exists (Select * From PRODUTOS_FISCAL B With(NOLOCK) Where A.Codpro=B.CodItem )
)A
Where Exists (Select * From Fiscal2010 C With(NOLOCK) Where A.Codpro=C.Codpro And A.Tippro=C.Tippro )

Insert Into PRODUTOS_FISCAL(CodItem, TipItem, DescItem, ClaFis)
Select * From (
Select Codemb, 'E' Tippro, Desemb, Clafis From [172.17.6.102,1805].Atualiza_Cadastros.dbo.Embalagens A With(NOLOCK) Where Codemp = 101
And Not Exists (Select * From PRODUTOS_FISCAL B With(NOLOCK) Where A.Codemb=B.CodItem )
)A
Where Exists (Select * From Fiscal2010 C With(NOLOCK) Where A.Codemb=C.Codpro And A.Tippro=C.Tippro )


Insert Into PRODUTOS_FISCAL(CodItem, TipItem, DescItem, ClaFis)
Select * From (
Select Codvas, 'V' Tippro, Desvas, Clafis From [172.17.6.102,1805].Atualiza_Cadastros.dbo.Vasilhames A With(NOLOCK) Where Codemp = 101
And Not Exists (Select * From PRODUTOS_FISCAL B With(NOLOCK) Where A.Codvas=B.CodItem )
)A
Where Exists (Select * From Fiscal2010 C With(NOLOCK) Where A.Codvas=C.Codpro And A.Tippro=C.Tippro )


Insert Into PRODUTOS_FISCAL(CodItem, TipItem, DescItem, ClaFis)
Select * From (
Select Codpro, 'I' Tippro, Descricao, Clafis From [172.17.6.102,1805].Atualiza_Cadastros.dbo.Insumos A With(NOLOCK) Where Codemp = 101
And Not Exists (Select * From PRODUTOS_FISCAL B With(NOLOCK) Where A.Codpro=B.CodItem )
)A
Where Exists (Select * From Fiscal2010 C With(NOLOCK) Where A.Codpro=C.Codpro And A.Tippro=C.Tippro )


*/
	--select top 100 * from clifor_fiscal
