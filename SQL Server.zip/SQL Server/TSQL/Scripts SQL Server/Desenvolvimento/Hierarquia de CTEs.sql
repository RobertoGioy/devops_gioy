
Select Distinct A.Codpro,B.Despro From Itens_Nota_Fiscal A With(Nolock)
Inner Join [172.17.6.102\sqlsic1].Atualiza_Cadastros.dbo.Produtos  B With(Nolock)  On A.Codpro=B.Codpro
Where (B.Clafis='0' Or Clafis Is Null Or Clafis='') And A.Datent>='2009-01-01'
Order by A.Codpro,B.Despro



 With a (codpro) as
 
 (
 select  codpro from Itens_Nota_Fiscal With(Nolock) where datent >='2009-01-01'
 
 ), b (codpro,despro,clafis)as 
 (
 select codpro,despro,clafis from [172.17.6.102\sqlsic1].Atualiza_Cadastros.dbo.Produtos With(Nolock) Where (Clafis='0' Or Clafis Is Null Or Clafis='')
 )
 select Distinct A.Codpro,B.Despro,B.Clafis from a inner join b on A.Codpro=B.Codpro