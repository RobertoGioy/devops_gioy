SET QUOTED_IDENTIFIER OFF 

create table #temp (Servidor Varchar(max), Base Varchar(max), empresa Varchar(max))
create table #temp1 (Base1 Varchar(max))


DECLARE @base sysname, @reg int, @tot int, @CMD1 VARCHAR(MAX), @CMD2 VARCHAR(MAX), @CMD3 VARCHAR(MAX), @CMD4 VARCHAR(MAX)
, @CMD5 VARCHAR(MAX), @CMD6 VARCHAR(MAX), @CMD7 VARCHAR(MAX), @CMD8 VARCHAR(MAX), @CMD9 VARCHAR(MAX), @CMD10 VARCHAR(MAX)



set @tot = (select count(name) as Reg from sys.sysdatabases where not name in ('EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','DC','FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%'))

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where not name in ('EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','DC','FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%')) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
	IF not (select OBJECT_ID ('Mov_Estoque2')) IS NULL
	if (select count(*) from sysobjects o inner join syscolumns c on o.id = c.id where o.name = 'Config' and c.name = 'Terc' ) > 0
	exec('if (select count(*) from config where terc = ''C'') > 0
		INSERT into #temp1 SELECT ""[" + @base + "]"" ')
	")
	set @reg = @reg + 1
	end

update #temp1 set base1 = replace(replace(base1,'[',''),']','')

set @tot = (select count(name) as Reg from sys.sysdatabases where name in (select base1 from #Temp1) and not name in ('EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','DC','FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%'))

set @reg = 1

while @reg <= @tot
	begin
	set @base = (select name from (select row_number() over (order by name) as Reg, name from sys.sysdatabases where name in (select base1 from #Temp1) and not name in ('EMPDCA','EMPDCAB','Master','Distribution','TempDB','Model','MSDB','CENTRAL_AP','CENTRAL_AV','SL2000_BKP','DC','FRDCA','SLDCA','SLDCB','SLDCAB','DC_MKT','CENTRAL_FISCAL','CENTRAL_N_AP_CPA','CENTRAL_N_AV_CPA','KAV','HISTORICO') and not name like ('09%') and not name like ('10%') and not name like ('aa%') and not name like ('%barril%') and not name like ('20%')) as t where t.reg  = @reg)
	exec ("use [" + @base + "] 
	IF not (select OBJECT_ID ('Mov_Estoque2')) IS NULL 
			begin
				begin try
					if (select count(*) from syscomments where object_name(ID)='Grava_NF' And Text Like '%IF @wcodemp = ''350''%') > 0
      					INSERT into #temp Select Distinct Codemp, Cidemp, 'Diferente 350' As Estrutura From Empresas
      				else	
      					INSERT into #temp Select Distinct Codemp, Cidemp, 'Igual 350' As Estrutura From Empresas
				end try
				begin catch
       				INSERT into #temp SELECT distinct '(' + ERROR_MESSAGE() +') ' + @@servername as Servidor, ""[" + @base + "]"" as Base, '' as empresa
				end catch
			end	
	")
	
	set @reg = @reg + 1
	end
	
SELECT Servidor, Base, empresa FROM #temp
