--105,147,166,188,195,225,242,243,247,255,256,274,279,349,351,605,613,636,639,642,644,651,652,657,804,817,829,939,952,979

select Distinct ID_FILIAL
from NFEPRD_B11.dbo.nfe07_nota (nolock)
where stat in (100,101,102,110,124,301,302) And  dt_lista between '2000-01-01' and '2011-12-31'

----------------------Rodar este script na base NFEPRD_HISTORICO-------------------------------
insert into nfe07_nota
select (select max(id_nota) from nfe07_nota)+row_number() OVER(order by NF) as ID_NOTA,
ID_FILIAL, ID_LOTE, UF_DEST, NF, SERIE, DT_LISTA, DT_EMISSAO, TIPO, FLAG, FLAG_ERRO, CHAVE_ACESSO, PROTOCOLO, DT_RECIBO, XML_RETORNO, STAT, XML_ENVIO, XML_DANFE, IMPRIME_DANFE, DANFE_PRINT, ID_PORTARIA, DT_PORTARIA, NUMERO_NFE, SERIE_NFE, CNPJ_EMITENTE, CNPJ_DESTINATARIO, LOCAL_PRT_DANFE, IDENT_PRT_DANFE, NR_COP_DANFE, BANDEJA_DANFE, TP_IMP_DANFE, QTD_NFE_ITENS, TAM_NFE, ANO_INUT, NUMERO_NFE_FIM, DT_FINAL, LOCK_REG, DT_INC, DT_ALT, TP_AMBIENTE, MOD, VERSAO_SEFAZ, JUSTIF, COD_CLI_FIL, COD_CLI_EMP, LOCK_ID, AGRUPAMENTO, CANHOTO, TP_EMIS 
from NFEPRD_B11.dbo.nfe07_nota (nolock)
where stat in (100,101,102,110,124,301,302) and ID_FILIAL In (105) and dt_lista between '2000-01-01' and '2011-12-31'
order by NF

delete top(100000) from NFEPRD_B11.dbo.nfe07_nota where ID_FILIAL in (105) and dt_lista between '2000-01-01' and '2011-12-31'

delete a 
from NFEPRD_B11.dbo.nfp02_lista_log a 
where not exists (select * from NFEPRD_B11.dbo.nfp01_lista b where a.id_lista = b.id_lista)

delete a
from NFEPRD_B11.dbo.nfe32_lista_imp a 
where not exists (select * from NFEPRD_B11.dbo.nfp01_lista b where a.id_lista = b.id_lista)

delete a
from NFEPRD_B11.dbo.nfe08_lote a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where a.id_lote = b.id_lote and b.id_filial in (105))

delete a top(100000) 
from NFEPRD_B11.dbo.VW50_NFE a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW51_NFE_REF a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW52_NFE_DUP a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW53_NFE_REB a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW54_NFE_VOL a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW55_NFE_VOL_LAC a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW56_NFE_IMP  a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW57_NFE_COM a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW58_NFE_ANEXO a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW59_NFE_DEST  a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW60_DET a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW61_DET_DI a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW62_DET_DI_ADI a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW63_DET_MED a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW64_DET_ARM a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW65_DET_ICM a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW66_DET_IPI a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW67_DET_II a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW68_DET_PIS a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW69_DET_COF a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW70_DET_ISS a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW71_DET_COMB a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW72_DET_COMB_ICM a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW80_NFE_OBS_CONT a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW81_NFE_OBS_FISCO a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.VW82_NFE_PROC_REF a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

delete a top(100000) 
from NFEPRD_B11.dbo.NFP01_LISTA a 
where not exists (select * from NFEPRD_B11.dbo.nfe07_nota b where b.id_filial = a.cfg_un and b.nf = a.cfg_numero_nf and b.serie = a.cfg_serie_nf)
where a.CFG_UN in (105)

