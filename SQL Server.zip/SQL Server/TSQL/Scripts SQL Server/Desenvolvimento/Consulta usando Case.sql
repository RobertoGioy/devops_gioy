/*  
******* ULTIMA ATUALIZA��O 12/05/2010 *******  
*	       CARGA ATUALIZADA		            *  
*********************************************  
*/  
CREATE TABLE [dbo].[#Nota_Fiscal](
	[Codemp] [char](3) NOT NULL,
	[Numnot] [varchar](9) NOT NULL,
	[Sernot] [char](3) NOT NULL,
	[Tipnot] [char](1) NOT NULL,
	[Codope] [int] NOT NULL,
	[Pericm] [decimal](18, 2) NOT NULL,
	[Codcli] [int] NOT NULL,
	[Clifor] [char](1) NULL,
	[CodMod] int NOT NULL, 
	[Datnot] [datetime] NULL,
	[Datent] [datetime] NOT NULL,
	[Valbru] [decimal](18, 2) NULL,
	[Valdes] [decimal](18, 2) NULL,
	[Valliq] [decimal](18, 2) NULL,
	[Valvar] [decimal](18, 2) NULL,
	[Basicm] [decimal](18, 2) NULL,
	[Valicm] [decimal](18, 2) NULL,
	[Bassub] [decimal](18, 2) NULL,
	[Icmsub] [decimal](18, 2) NULL,
	[Valipi] [decimal](18, 2) NULL,
	[Valfre] [decimal](18, 2) NULL,
	[Valseg] [decimal](18, 2) NULL,
	[Valout] [decimal](18, 2) NULL,
	[Status] [char](1) NULL,
	[Observ] [char](100) NULL,
	[Valise] [decimal](18, 2) NULL,
	[Basipi] [decimal](18, 2) NULL,
	[Tipope] [int] NULL,
	[Tipoco] [int] NULL,
	[IseIpi] [decimal](18, 2) NULL,
	[OutIpi] [decimal](18, 2) NULL,
	[BasIss] [numeric](18, 2) NULL,
	[OutDes] [decimal](18, 2) NULL,
 CONSTRAINT [PK_Nota_Fiscal1] PRIMARY KEY CLUSTERED 
(
	[Codemp] ASC,
	[Numnot] ASC,
	[Sernot] ASC,
	[Tipnot] ASC,
	[Codope] ASC,
	[Pericm] ASC,
	[Codcli] ASC,
	[Codmod] ASC,
	[Datent] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[#Itens_Nota_Fiscal](
	[Codemp] [char](3) NOT NULL,
	[Numnot] [varchar](9) NOT NULL,
	[Sernot] [char](3) NOT NULL,
	[Tipnot] [char](1) NOT NULL,
	[Codope] [int] NOT NULL,
	[Codcli] [int] NOT NULL,
	[Codpro] [int] NOT NULL,
	[Tippro] [char](1) NOT NULL,
	[Reg] [int] IDENTITY(1,1) NOT NULL,
	[Datent] [datetime] NULL,
	[Valbru] [decimal](18, 2) NULL,
	[Valdes] [decimal](18, 2) NULL,
	[Valliq] [decimal](18, 2) NULL,
	[Valipi] [decimal](18, 2) NULL,
	[Pericm] [decimal](18, 2) NULL,
	[Codtri] [char](3) NULL,
	[Univar] [decimal](18, 2) NULL,
	[Perred] [decimal](18, 2) NULL,
	[Status] [char](1) NULL,
	[Basicm] [decimal](18, 2) NULL,
	[Valicm] [decimal](18, 2) NULL,
	[Bassub] [decimal](18, 2) NULL,
	[Icmsub] [decimal](18, 2) NULL,
	[Extope] [int] NULL,
	[Valise] [decimal](18, 2) NULL,
	[Valout] [decimal](18, 2) NULL,
	[Basipi] [decimal](18, 2) NULL,
	[Valfre] [decimal](18, 2) NULL,
	[Valseg] [decimal](18, 2) NULL,
	[Tipope] [int] NULL,
	[Tipoco] [int] NULL,
	[Datexp] [smalldatetime] NULL,
	[IseIpi] [decimal](18, 2) NULL,
	[OutIpi] [decimal](18, 2) NULL,
	[CodMod] [int] NULL,
	[Pis] [numeric](18, 2) NULL,
	[Cofins] [numeric](18, 2) NULL,
	[CSocial] [numeric](18, 2) NULL,
	[DifAliq] [numeric](18, 2) NULL,
	[DifIPI] [numeric](18, 2) NULL,
	[DifST] [numeric](18, 2) NULL
) ON [PRIMARY]

ALTER TABLE [dbo].[#Itens_Nota_Fiscal] ADD  CONSTRAINT [PK_Itens_Nota_Fiscal1] PRIMARY KEY CLUSTERED 
(
	[Codemp] ASC,
	[Numnot] ASC,
	[Sernot] ASC,
	[Tipnot] ASC,
	[Codope] ASC,
	[Codcli] ASC,
	[Codpro] ASC,
	[Tippro] ASC,
	[Reg] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 90) ON [PRIMARY]


insert into #Nota_Fiscal
select Codemp,Numnot,Sernot,Tipnot,Codope,Pericm,Codcli,Clifor,CodMod,Datnot,Datent,Valbru,Valdes,Valliq,Valvar,Basicm,Valicm,Bassub,Icmsub,Valipi,Valfre,Valseg,Valout,Status,Observ,Valise,Basipi,Tipope,Tipoco,IseIpi,OutIpi,0,OutDes
from DC.DC.dbo.Nota_Fiscal With (Nolock)
where case when tipnot = 'S' then datnot else datent end between '2013-01-01' and '2013-12-31' and codemp in (295,296,297,298,327,336,337,338,339,352,353,354,355,356,357,358,359,360,361,362)

insert into #itens_nota_fiscal
select Codemp,Numnot,Sernot,Tipnot,Codope,Codcli,Codpro,Tippro,Datent,Valbru,Valdes,Valliq,Valipi,Pericm,Codtri,Univar,Perred,Status,Basicm,Valicm,Bassub,Icmsub,Extope,Valise,Valout,Basipi,Valfre,Valseg,Tipope,Tipoco,'2010-05-06',IseIpi,OutIpi,CodMod,Pis,Cofins,CSocial,DifAliq,DifIPI,DifST
from DC.DC.dbo.Itens_Nota_Fiscal With (Nolock)
where case when tipnot = 'S' then datnot else datent end between '2013-01-01' and '2013-12-31' and codemp in (295,296,297,298,327,336,337,338,339,352,353,354,355,356,357,358,359,360,361,362)


declare @ini datetime, @fin datetime            
set @ini = '2013-01-01'            
set @fin = '2013-12-31'            
 
delete from Fiscal2010 where datent between @ini and @fin and codemp in (295,296,297,298,327,336,337,338,339,352,353,354,355,356,357,358,359,360,361,362)
insert into Fiscal2010            
select a.Codemp, a.Numnot, a.Sernot, a.Tipnot, a.Codope, a.Pericm, a.Codcli,isnull(b.codpro,0) as CodPro,isnull(b.tippro,0) as TipPro,
a.CodMod,a.CliFor,    
   year(case when a.tipnot = 'S' then a.DatNot else a.DatEnt end) as Ano, month(case when a.tipnot = 'S' then a.DatNot else a.DatEnt end) as Mes,
	case when a.tipnot = 'S' then a.DatNot else a.DatEnt end,            
  sum(isnull(b.valbru,0)-isnull(b.valdes,0)+isnull(b.icmsub,0)+isnull(b.valipi,0)+isnull(b.difipi,0)+isnull(b.difst,0)) as [Valor Cont�bil],            
  sum(b.basicm) [ICMS - BASE CALCULO],             
  sum(b.basipi) [IPI - BASE CALCULO],            
  sum(b.valicm) [ICMS - IMPOSTO DEBIT.],              
  sum(b.valipi) [IPI - IMPOSTO DEBIT.],             
  sum(b.valise) [ICMS - ISENTA/N.TRIB.],            
  case when sum(a.iseipi) <> 0 then sum(b.iseipi)             
   else 0 end [IPI - ISENTA/N.TRIB.],            
  case when sum(a.outipi) <> 0 then sum(b.outipi-b.valdes-b.icmsub)             
   else 0 end [IPI - Outras]            
from #Itens_Nota_Fiscal  b With (Nolock)
	inner join             
(            
select a.*            
 from #Nota_Fiscal a With (Nolock)            
   left join (select Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, PerICM, CodMod, sum(ValBru-ValDes) as ValorTotal            
        from #Itens_Nota_Fiscal With (Nolock)            
group by Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, PerICM, CodMod) b            
on a.codemp = b.codemp and a.numnot = b.numnot and a.sernot = b.sernot            
                   and a.tipnot = b.tipnot and a.codope = b.codope and a.codcli = b.codcli            
and a.pericm = b.pericm and a.codmod = b.codmod    
      where case when a.tipnot = 'S' then a.DatNot else a.DatEnt end between @ini and @fin            
         and a.tipnot in('S','E') and (a.Status <> 'C' or a.Status is null)            
and a.valbru-a.valdes<>b.ValorTotal) a on a.codemp = b.codemp and a.numnot = b.numnot and a.sernot = b.sernot            
                   and a.tipnot = b.tipnot and a.codope = b.codope and a.codcli = b.codcli and a.pericm = b.pericm            
     and a.codmod = b.codmod    
where isnull(observ,'') <> 'PS' and not a.sernot = 'R-Q'            
group by a.Codemp, a.Numnot, a.Sernot, a.Tipnot, a.Codope, a.Pericm, a.Codcli,isnull(b.codpro,0),isnull(b.tippro,0),a.CliFor,a.CodMod,            
   case when a.tipnot = 'S' then a.DatNot else a.DatEnt end    
UNION            
select a.Codemp, a.Numnot, a.Sernot, a.Tipnot, a.Codope, a.Pericm, a.Codcli,isnull(b.codpro,0),isnull(b.tippro,0),a.CodMod,a.CliFor,     
  year(case when a.tipnot = 'S' then a.DatNot else a.DatEnt end) as Ano, month(case when a.tipnot = 'S' then a.DatNot else a.DatEnt end) as Mes, case when a.tipnot = 'S' then a.DatNot else a.DatEnt end,            
  sum(b.valbru-b.valdes) as [Valor Cont�bil],            
  sum(b.basicm) [ICMS - BASE CALCULO],             
  sum(b.basipi) [IPI - BASE CALCULO],            
  sum(b.valicm) [ICMS - IMPOSTO DEBIT.],              
  sum(b.valipi) [IPI - IMPOSTO DEBIT.],             
  sum(b.valise) [ICMS - ISENTA/N.TRIB.],            
  case when sum(a.iseipi) <> 0 then sum(b.iseipi)             
  else 0 end [IPI - ISENTA/N.TRIB.],            
  case when sum(a.outipi) <> 0 then sum(b.outipi-b.valdes-b.icmsub)             
  else 0 end [IPI - Outras]            
from #Itens_Nota_Fiscal b With (Nolock) inner join             
(            
select a.*            
 from #Nota_Fiscal a With (Nolock)            
   left join (select Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, PerICM, CodMod, sum(ValBru-ValDes) as ValorTotal            
        from #Itens_Nota_Fiscal With (Nolock)             
group by Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, PerICM, CodMod) b            
on a.codemp = b.codemp and a.numnot = b.numnot and a.sernot = b.sernot            
and a.pericm = b.pericm            
                   and a.tipnot = b.tipnot and a.codope = b.codope and a.codcli = b.codcli            
and a.codmod = b.codmod    
      where case when a.tipnot = 'S' then a.DatNot else a.DatEnt end between @ini and @fin            
         and a.tipnot in('S','E') and (a.Status <> 'C' or a.Status is null)            
and a.valbru-a.valdes=b.ValorTotal) a on a.codemp = b.codemp and a.numnot = b.numnot and a.sernot = b.sernot            
                   and a.tipnot = b.tipnot and a.codope = b.codope and a.codcli = b.codcli and a.pericm = b.pericm            
and a.codmod = b.codmod    
where isnull(observ,'') <> 'PS' and not a.sernot = 'R-Q'            
group by a.Codemp, a.Numnot, a.Sernot, a.Tipnot, a.Codope, a.Pericm, a.Codcli,isnull(b.codpro,0),isnull(b.tippro,0),a.CliFor,            
   case when a.tipnot = 'S' then a.DatNot else a.DatEnt end, a.codmod            
UNION            
select a.Codemp, a.Numnot, a.Sernot, a.Tipnot, a.Codope, a.Pericm, a.Codcli,'0','0',a.Codmod,a.CliFor,            
  year(case when a.tipnot = 'S' then a.DatNot else a.DatEnt end) as Ano, month(case when a.tipnot = 'S' then a.DatNot else a.DatEnt end) as Mes, case when a.tipnot = 'S' then a.DatNot else a.DatEnt end,            
  sum(b.valbru-b.valdes) as [Valor Cont�bil],            
  sum(b.basicm) [ICMS - BASE CALCULO],             
  sum(b.basipi) [IPI - BASE CALCULO],            
  sum(b.valicm) [ICMS - IMPOSTO DEBIT.],              
  sum(b.valipi) [IPI - IMPOSTO DEBIT.],             
  sum(b.valise) [ICMS - ISENTA/N.TRIB.],            
  sum(b.iseipi) [IPI - ISENTA/N.TRIB.],            
  sum(b.outipi-b.valdes-b.icmsub) [IPI - Outras]            
from #Nota_Fiscal b inner join             
(            
select a.*,'0' as CodPro,'0' As tipPro            
 from #Nota_Fiscal a With (Nolock)            
   where not exists (select Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, PerICM, codmod, sum(ValBru-ValDes) as ValorTotal            
        from #Itens_Nota_Fiscal b With (Nolock)            
where a.codemp = b.codemp and a.numnot = b.numnot and a.sernot = b.sernot            
and a.pericm = b.pericm and a.tipnot = b.tipnot and a.codope = b.codope and a.codcli = b.codcli    
and a.codmod = b.codmod    
group by Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, PerICM, codmod)             
      and case when a.tipnot = 'S' then a.DatNot else a.DatEnt end between @ini and @fin            
         and a.tipnot in('S','E') and (a.Status <> 'C' or a.Status is null) and isnull(observ,'') <> 'PS' and sernot <> 'R-Q') a on a.codemp = b.codemp and a.numnot = b.numnot and a.sernot = b.sernot            
                   and a.tipnot = b.tipnot and a.codope = b.codope and a.codcli = b.codcli and a.pericm = b.pericm    
and a.codmod = b.codmod            
group by a.Codemp, a.Numnot, a.Sernot, a.Tipnot, a.Codope, a.Pericm, a.Codcli,case when a.tipnot = 'S' then a.DatNot else a.DatEnt end, a.CliFor, a.codmod            
   


--EXECUTAR O SCRIPT ABAIXO AP�S CONSOLIDAR AS EMPRESAS DE TODOS OS MESES DE 2010.


--TERMINAR DE EXECUTAR POIS CONTINUOU DANDO ERRO
insert into produtos_fiscal
select distinct codpro,'P',despro,isnull(clafis,'0') from DC.DC.dbo.produtos z With (Nolock)
where exists (
select * from Fiscal2010 a
where not exists (select * from produtos_fiscal b where a.codpro = b.coditem
and a.tippro = b.tipitem) and a.codemp = z.codemp and a.codpro = z.codpro and a.tippro = 'P')

insert into produtos_fiscal
select distinct codemb,'E',desemb,isnull(clafis,'0') from DC.DC.dbo.embalagens z With (Nolock)
where exists (
select * from Fiscal2010 a
where not exists (select * from produtos_fiscal b where a.codpro = b.coditem
and a.tippro = b.tipitem) and a.codemp = z.codemp and a.codpro = z.codemb and a.tippro = 'E')

insert into produtos_fiscal
select distinct codvas,'V',desvas,isnull(clafis,'0') from DC.DC.dbo.vasilhames z With (Nolock)
where exists (
select * from Fiscal2010 a
where not exists (select * from produtos_fiscal b where a.codpro = b.coditem
and a.tippro = b.tipitem) and a.codemp = z.codemp and a.codpro = z.codvas and a.tippro = 'V')

insert into produtos_fiscal
select distinct codpro,'I',descricao,isnull(clafis,'0') from DC.DC.dbo.insumos z With (Nolock)
where exists (
select * from Fiscal2010 a
where not exists (select * from produtos_fiscal b where a.codpro = b.coditem
and a.tippro = b.tipitem) and a.codemp = z.codemp and a.codpro = z.codpro and a.tippro = 'I')


insert into clifor_fiscal
select distinct z.codemp,z.codcli,nomcli,'C' as clifor,cgccli 
		from DC.DC.dbo.clientes z  With (Nolock)
where exists (select * from Fiscal2010 a 
where not exists (select * from clifor_fiscal b where a.codemp = b.codemp and a.codcli = b.codclifor
and a.clifor = b.clifor) and a.clifor = 'C'
and z.codemp = a.codemp and z.codcli = a.codcli)
UNION ALL
select distinct z.codemp,z.codfor,razfor,'F' as clifor,cgcfor 
		from DC.DC.dbo.fornecedores z  With (Nolock)
where exists (select * from Fiscal2010 a 
where not exists (select * from clifor_fiscal b where a.codemp = b.codemp and a.codcli = b.codclifor
and a.clifor = b.clifor) and a.clifor = 'F'
and z.codemp = a.codemp and z.codfor = a.codcli)

--Confer�ncia

declare @codemp char(3)        
     
declare reg cursor for
select distinct codemp from Fiscal2010 where codemp in (295,296,297,298,327,336,337,338,339,352,353,354,355,356,357,358,359,360,361,362) 
open reg
fetch next from reg into @codemp
while @@fetch_status = 0
begin
       
delete from conferencia_nf2010 where codemp = @Codemp       
IF NOT (SELECT OBJECT_ID('NFDC')) is null            
DROP TABLE NFDC            
            
if exists (select distinct codemp from conferencia_nf2010 where codemp = @codemp)            
Print 'Essa empresa j� foi conferida!'            
else            
BEGIN            

select * into NFDC from #Nota_Fiscal With (Nolock)            
where datent between '2013-01-01' and '2013-12-31' and codemp in (295,296,297,298,327,336,337,338,339,352,353,354,355,356,357,358,359,360,361,362)
and tipnot in('E','S') and (Status <> 'C' or Status is null) and isnull(observ,'') <> 'PS'            
and not sernot = 'R-Q'            
            
insert into conferencia_nf2010            
select a.codemp,a.numnot,a.tipnot,a.codope,a.codcli,a.clifor,a.datent,a.codmod,sum(a.valcont),sum(b.valbru)-sum(b.valdes)            
  from VS_FiscalAgr_2010 a             
    inner join NFDC b With (Nolock) on            
a.codemp = b.codemp and a.numnot = b.numnot and a.sernot = b.sernot and a.tipnot = b.tipnot            
and a.codope = b.codope and a.codcli = b.codcli and a.clifor = b.clifor            
and a.datent = b.datent and a.codmod = b.codmod          
where a.datent between '2013-01-01' and '2013-12-31' and a.codemp in (295,296,297,298,327,336,337,338,339,352,353,354,355,356,357,358,359,360,361,362)            
group by a.codemp,a.numnot,a.tipnot,a.codope,a.codcli,a.clifor,a.datent,a.codmod       
having sum(a.valcont)<>sum(b.valbru)-sum(b.valdes)            
END 

fetch next from reg into @codemp
end
close reg
deallocate reg

/*EXECUTAR O COMANDO ABAIXO PARA CONFERIR SE OS CADASTROS EST�O OK!

INSERT INTO clifor_fiscal (CodEmp, CodCliFor, DesCliFor, CliFor, CPFCNPJ)
Select CodEmp, CodCli, nomcli, 'C' CliFor, CgcCli
From DC.DC.Dbo.Clientes A With(Nolock) Where Not Exists (Select * From clifor_fiscal B Where A.Codemp=B.Codemp And A.codcli=B.CodCliFor) 

INSERT INTO clifor_fiscal (CodEmp, CodCliFor, DesCliFor, CliFor, CPFCNPJ)
Select CodEmp, Codfor, RazFor, 'F' CliFor, Cgcfor
From DC.DC.Dbo.Fornecedores A With(Nolock) Where Not Exists (Select * From clifor_fiscal B Where A.Codemp=B.Codemp And A.Codfor=B.CodCliFor) 

INSERT INTO clifor_fiscal (CodEmp, CodCliFor, DesCliFor, CliFor, CPFCNPJ)
Select CodEmp, CodCli, nomcli, 'C' CliFor, CgcCli
From DC.EMPDC.Dbo.Clientes A With(Nolock) Where Not Exists (Select * From clifor_fiscal B Where A.Codemp=B.Codemp And A.codcli=B.CodCliFor) 

INSERT INTO clifor_fiscal (CodEmp, CodCliFor, DesCliFor, CliFor, CPFCNPJ)
Select CodEmp, Codfor, RazFor, 'F' CliFor, Cgcfor
From DC.EMPDC.Dbo.Fornecedores A With(Nolock) Where Not Exists (Select * From clifor_fiscal B Where A.Codemp=B.Codemp And A.Codfor=B.CodCliFor) 


Insert Into PRODUTOS_FISCAL(CodItem, TipItem, DescItem, ClaFis)
Select * From (
Select Codpro, 'P' Tippro, Despro, Clafis From [172.17.6.102,1805].Atualiza_Cadastros.dbo.Produtos A With(NOLOCK) Where Codemp = 101
And Not Exists (Select * From PRODUTOS_FISCAL B With(NOLOCK) Where A.Codpro=B.CodItem )
)A
Where Exists (Select * From Fiscal2010 C With(NOLOCK) Where A.Codpro=C.Codpro And A.Tippro=C.Tippro )

Insert Into PRODUTOS_FISCAL(CodItem, TipItem, DescItem, ClaFis)
Select * From (
Select Codemb, 'E' Tippro, Desemb, Clafis From [172.17.6.102,1805].Atualiza_Cadastros.dbo.Embalagens A With(NOLOCK) Where Codemp = 101
And Not Exists (Select * From PRODUTOS_FISCAL B With(NOLOCK) Where A.Codemb=B.CodItem )
)A
Where Exists (Select * From Fiscal2010 C With(NOLOCK) Where A.Codemb=C.Codpro And A.Tippro=C.Tippro )


Insert Into PRODUTOS_FISCAL(CodItem, TipItem, DescItem, ClaFis)
Select * From (
Select Codvas, 'V' Tippro, Desvas, Clafis From [172.17.6.102,1805].Atualiza_Cadastros.dbo.Vasilhames A With(NOLOCK) Where Codemp = 101
And Not Exists (Select * From PRODUTOS_FISCAL B With(NOLOCK) Where A.Codvas=B.CodItem )
)A
Where Exists (Select * From Fiscal2010 C With(NOLOCK) Where A.Codvas=C.Codpro And A.Tippro=C.Tippro )


Insert Into PRODUTOS_FISCAL(CodItem, TipItem, DescItem, ClaFis)
Select * From (
Select Codpro, 'I' Tippro, Descricao, Clafis From [172.17.6.102,1805].Atualiza_Cadastros.dbo.Insumos A With(NOLOCK) Where Codemp = 101
And Not Exists (Select * From PRODUTOS_FISCAL B With(NOLOCK) Where A.Codpro=B.CodItem )
)A
Where Exists (Select * From Fiscal2010 C With(NOLOCK) Where A.Codpro=C.Codpro And A.Tippro=C.Tippro )


*/

--select top 100 * from clifor_fiscal