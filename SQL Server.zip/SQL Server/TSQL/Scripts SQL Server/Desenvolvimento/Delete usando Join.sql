use Umail_Master

declare @clientId int
declare @userId varchar(100)
set @clientId = 230
select * from Client where ClientId = @clientId
  
begin tran

use Umail_Master

select * from Client where ClientId = @clientId

use UmailNGZSecurity

delete t from dbo.aspnet_UsersInRoles t
       join UserProfile up on t.UserId = up.UserId and up.ClientId = @clientId

delete t from NGZUserFranchiseMappings t
       join UserProfile up on t.UserId = up.UserId and up.ClientId = @clientId

delete t from NGZUserMappings t
       join UserProfile up on t.UserId = up.UserId and up.ClientId = @clientId

delete t from dbo.aspnet_Membership t
       join UserProfile up on t.UserId = up.UserId and up.ClientId = @clientId
       
delete UserProfile where ClientId = @clientId

SELECT @userId = UserID from UserProfile where ClientId = @clientId
delete aspnet_Users from dbo.aspnet_Users where UserId = @userId
--t         join UserProfile up on t.UserId = up.UserId and up.ClientId = @clientId

use Umail_Master

delete campaign where clientId = @clientId
delete NGZClientTools where ClientId = @clientId
delete [NGZTrackingJobEventLog] where ClientId = @clientId
delete Client where ClientId = @clientId

--rollback tran
--commit tran
