USE TESTE_PROCS;
GO
--===================================================
-- LOOPS
-- 1. Gera os n�meros inteiros de 0 at� N
CREATE PROCEDURE STP_INTEIROS  @N INT = 100
AS BEGIN
DECLARE @CONT INT = 0;
--SET @CONT = 0;
WHILE @CONT <= @N
   BEGIN
   PRINT @CONT;
   SET @CONT = @CONT + 1; -- SET @CONT += 1
   END -- WHILE
PRINT 'FIM';
END -- PROCEDURE
GO
-- testando
EXEC STP_INTEIROS
EXEC STP_INTEIROS 50
------------------------------------------------------
-- 2. Crie a procedure STP_INTEIROS_DESC
-- Idem anterior mas deve mostrar os n�meros em ordem decrescente
CREATE PROCEDURE STP_INTEIROS_DESC  @N INT = 100
AS BEGIN
DECLARE @CONT INT;
SET @CONT = @N;		--<<<<<<
WHILE @CONT >= 0	--<<<<<<
   BEGIN
   PRINT @CONT;
   SET @CONT = @CONT - 1; -- SET @CONT -= 1  	--<<<<<<
   END -- WHILE
PRINT 'FIM';
END -- PROCEDURE
GO
-- testando
EXEC STP_INTEIROS_DESC
-----------------------------------------------------
-- 3. STP_PARES: Gera os n�meros pares de 0 at� N
CREATE PROCEDURE STP_PARES  @N INT = 100
AS BEGIN
DECLARE @CONT INT = 0;
--SET @CONT = 0;
WHILE @CONT <= @N
   BEGIN
   PRINT @CONT;
   -----------------------------------------------------
   SET @CONT = @CONT + 2; -- SET @CONT += 2  --<<<<<<<<<
   -----------------------------------------------------
   END -- WHILE
PRINT 'FIM';
END -- PROCEDURE
GO



-- testando
EXEC STP_PARES 9

-----------------------------------------------------
-- 4. STP_IMPARES: Gera os n�meros �mpares entre 0 e N
CREATE PROCEDURE STP_IMPARES  @N INT = 100
AS BEGIN
DECLARE @CONT INT = 1;
--SET @CONT = 1;
WHILE @CONT <= @N
   BEGIN
   PRINT @CONT;
   -----------------------------------------------------
   SET @CONT = @CONT + 2; -- SET @CONT += 2  --<<<<<<<<<
   -----------------------------------------------------
   END -- WHILE
PRINT 'FIM';
END -- PROCEDURE
GO
-- testando
EXEC STP_IMPARES
----------------------------------------------------
-- 5. Calcula a soma dos n�meros de 1 at� N
-- Exemplo: Se N = 5 deve calcular 1+2+3+4+5 = 15
CREATE PROCEDURE STP_SOMA @N INT
AS BEGIN
DECLARE @SOMA INT, @CONT INT;
SET @SOMA = 0;
SET @CONT = 1;
WHILE @CONT <= @N
   BEGIN
   SET @SOMA = @SOMA + @CONT;
   SET @CONT = @CONT + 1;
   END
PRINT 'SOMA = ' + CAST( @SOMA AS VARCHAR(10) );
END
GO
-- testando
EXEC STP_SOMA 5

----------------------------------------------------
-- 6. Calcula o FATORIAL de N
-- Exemplo: Se N = 5 deve calcular 1*2*3*4*5 = 120
CREATE PROCEDURE STP_FAT @N INT
AS BEGIN
DECLARE @FAT INT, @CONT INT;
SET @FAT = 1;     --<<<<<<<<<
SET @CONT = 1;
WHILE @CONT <= @N
   BEGIN
   SET @FAT = @FAT * @CONT; --<<<<<<<<<
   SET @CONT = @CONT + 1;
   END
PRINT 'Fatorial = ' + CAST( @FAT AS VARCHAR(10) );
END
GO
-- testando
EXEC STP_FAT 5
------------------------------------------------------
-- 7. Criar procedure STP_TABUADAS que imprima as tabuadas do 1 ao 10
-- Precisa utilizar Loops encadeados. O resultado esperado �:
/*
TABUADA DO 1
1 x 1 = 1
1 x 2 = 2
1 x 3 = 3
1 x 4 = 4
1 x 5 = 5
1 x 6 = 6
1 x 7 = 7
1 x 8 = 8
1 x 9 = 9
1 x 10 = 10
----------------------
TABUADA DO 2
2 x 1 = 2
2 x 2 = 4
2 x 3 = 6
2 x 4 = 8
2 x 5 = 10
...
...
*/
CREATE PROCEDURE STP_TABUADAS
AS BEGIN
DECLARE @T INT, @N INT;
SET @T = 1;
-- Loop das tabuadas
WHILE @T <= 10
   BEGIN
   ------------------------------------------------
   PRINT 'TABUADA DO ' + CAST( @T AS CHAR(2) ) ;
   PRINT ''
    
    SET @N = 1;
	WHILE @N <= 10
      BEGIN  
      PRINT CAST( @T AS CHAR(2) ) + ' x ' +
            CAST( @N AS CHAR(2) ) + ' = ' +
            CAST( @T * @N AS CHAR(3) );
      SET @N = @N + 1;
      END 
   ------------------------------------------------
   SET @T = @T + 1;
   END -- WHILE @T
END -- PROCEDURE

-- Testando
EXEC STP_TABUADAS 

