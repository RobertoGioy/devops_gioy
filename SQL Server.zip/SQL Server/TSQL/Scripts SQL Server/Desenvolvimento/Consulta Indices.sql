SELECT 
	 RTRIM(@@SERVERNAME) + ' - ' +RTRIM(DB_NAME()) [Servidor_Base]
	,RTRIM(s.name) + '.' + Rtrim(t.name) [Tabela] 
	,sy.rows [Registros]
	FROM sys.tables t
	INNER JOIN sys.schemas s on t.schema_id = s.schema_id
	INNER JOIN sys.indexes i on i.object_id = t.object_id
	INNER JOIN sys.sysindexes sy on sy.id = t.object_id And I.index_id=sy.indid
	INNER JOIN sys.index_columns ic on ic.object_id = t.object_id
	INNER JOIN sys.columns c on c.object_id = t.object_id and
			ic.column_id = c.column_id
	WHERE i.index_id > 0    
	AND i.type in (1, 2) -- clustered & nonclustered only
	AND i.is_primary_key = 0 -- do not include PK indexes
	AND i.is_unique_constraint = 0 -- do not include UQ
	AND i.is_disabled = 0
	AND i.is_hypothetical = 0
	AND ic.key_ordinal > 0
	AND c.name = 'FileGuid'
	ORDER BY ic.key_ordinal