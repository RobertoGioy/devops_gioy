--DEMO  TOP 10 DEVELOPER FEATURES  SQL 2008


--DEMO Filtered Index

Select * From dbo.Contact2

CREATE NONCLUSTERED INDEX IDX_Contact2_EmailPromotion ON dbo.Contact2 (EmailPromotion)
INCLUDE (ContactID, FirstName, EmailAddress)
WHERE EmailPromotion = 2

Select ContactID, FirstName, EmailAddress
From dbo.Contact2
Where EmailPromotion = 2



--DROP INDEX DBO.Contact2.IDX_Contact2_EmailPromotion


--==========================================================================
CREATE TABLE Teste2 (Id int Identity(1,1), nome varchar(10));
GO
DECLARE @i int = 0, @j int = 100000

WHILE @i < @j
BEGIN
	INSERT Teste2 (nome) VALUES(REPLICATE('a', 10))
	SET @i += 1
END

SELECT * FROM dbo.Teste2
WHERE Id = 15000

Select * From sys.dm_db_missing_index_details

Select Demographics FRom Sales.Individual
Where ContactID = 5429

sp_helpindex 'Sales.Individual'

sp_helpindex 'Production.Product'

Select * From Production.Product As p
Inner Join Production.ProductDescription As D ON (p.ProductID = D.ProductDescriptionID)
Where SafetyStockLevel = 800


Select * Into dbo.Product1 FROM Production.Product

Select * Into dbo.Product2 FROM Production.Product

Select * From dbo.Product1 AS p1
left join dbo.Product2 as p2 on (p1.productid = p2.productid)
where p1.productnumber = 'BE-2349'
and p2.DaystoManufacture = 1


--=================================================================================


DECLARE @RC int
DECLARE @Categoryname varchar(50)
DECLARE @MatchingRows int
DECLARE @ErrorString varchar(128)
DECLARE @ErrorNumber int

-- TODO: Set parameter values here.

SET @Categoryname = 'Bikes'

EXECUTE @RC = [AdventureWorks].[dbo].[P_DisplayProductDetails] 
   @Categoryname
  ,@MatchingRows OUTPUT
  ,@ErrorString OUTPUT
  ,@ErrorNumber OUTPUT

SELECT  @MatchingRows, @ErrorString, @ErrorNumber

--======================================================================================



CREATE Procedure P_DisplayProductDetails
(@Categoryname varchar(50) = NULL,
 @MatchingRows int = NULL OUTPUT,
 @ErrorString varchar(128) = NULL OUTPUT,
 @ErrorNumber int = NULL OUTPUT)
as

BEGIN TRY

            -- Append a % so our callers don't have to know exact subcategory names
  if @CategoryName is null
   select @CategoryName = '%'
  else
   select @CategoryName = @CategoryName + '%'

--  Use a rank function to rank data by List Price over subcategory name
--  The DENSE_RANK assigns consecutive rank values

  SELECT  Production.Product.ProductID, 
     Production.Product.Name AS ProductName, 
     Production.ProductCategory.Name AS CategoryName, 
     Production.ProductSubcategory.Name AS SubcategoryName,
     Production.Product.ListPrice,
DENSE_RANK() over (Partition by 
Production.ProductSubcategory.Name ORDER BY 
   Production.Product.ListPrice DESC) as PriceRank
  FROM  Production.Product 
  INNER JOIN Production.ProductSubcategory 
ON Production.Product.ProductSubcategoryID = 
Production.ProductSubcategory.ProductSubcategoryID 
  INNER JOIN Production.ProductCategory 
ON Production.ProductSubcategory.ProductCategoryID = 
Production.ProductCategory.ProductCategoryID
  WHERE  Production.ProductCategory.Name like @CategoryName
  ORDER BY Production.ProductCategory.Name  

  select @MatchingRows = @@ROWCOUNT
 
 return 0

END TRY



BEGIN CATCH

-- LOG THE ERROR � WE MAY WANT TO SKIP THIS STEP WHILE DEBUGGING ! 
 insert dbo.Application_Error_Log (UserName, errorNumber, 
                                        errorSeverity, errorState, errorMessage)
 values (suser_sname(), ERROR_NUMBER(),ERROR_SEVERITY(), 
              ERROR_STATE(), ERROR_MESSAGE())  

 
SELECT @ErrorNumber = ERROR_NUMBER(),
   @ErrorString = ERROR_MESSAGE()
   
 RAISERROR (@ErrorString, 16,1)


END CATCH

--==================================================================================


CREATE TABLE [dbo].[Departamentos](
[DeptHID] [hierarchyID] Primary Key,
[DeptId] [int] NULL,
[DeptNome] [varchar](50) NULL,
[DeptChefe] [varchar](50) NULL
)

/* Insere um departamento raiz na hierarquia da empresa */
INSERT INTO Departamentos (DeptHID,DeptId,DeptNome,DeptChefe)
VALUES (hierarchyid::GetRoot(), 1, 'TI', 'Elano')

/* Seleciona a data e certifica que o dado foi inserido */
SELECT DeptHID.ToString(), * FROM Departamentos

GO

CREATE PROCEDURE InsertDepartamento(
@OrgId as Int, --Id do departamento imediatamente superior ao depto inserido
@DeptId as Int,
@DeptNome varchar(50),
@DeptChefe varchar(50)
)
AS
Begin
	Declare @OrgHID as hierarchyId
	Declare @LastSupervisedOrg as hierarchyId
	Select @OrgHID = DeptHID From Departamentos Where DeptId = @OrgID --Buscar o ID Hierarquico do Depto pai
	--Maior numero de deptHID, desde que o registro seja um filho do depto pai,
	Select @LastSupervisedOrg = MAX(DeptHID) from Departamentos 
		Where DeptHID.GetAncestor(1) = @OrgHID
		/*
			OrgHID - ID Hierarquico do depto superior (Ex: TI), 
			GetDescendant pega um c�digo de descendente que esteja entre os 2 parametros
			como o segundo � nulo, pega um codigo de descendente que seja superior ao fornecido
			"mas o fornecido � o MAX" Sim! Porque assim, com o GetDescendant, se obtem
			um a mais do que esta gravado na tabela, � inserido um registro com um c�digo acima do que esta na tabela
		*/
	Insert Into Departamentos Values 
	(@OrgHID.GetDescendant(@LastSupervisedOrg,Null),@DeptId,@DeptNome,@DeptChefe)
	return @@RowCount
End


EXEC InsertDepartamento 1,2,'Desenvolvimento','Nilmar'
EXEC InsertDepartamento 1,3,'Rede','Lucio'
EXEC InsertDepartamento 1,4,'Operacional','Luisao'
EXEC InsertDepartamento 1,5,'Portais','Felipe' 
EXEC InsertDepartamento 2,6,'Windows/Web','Maicon'
EXEC InsertDepartamento 2,7,'As400','Josue'
EXEC InsertDepartamento 3,8,'Suporte','Juan'
EXEC InsertDepartamento 3,9,'Roteadores','Miranda'

-- seleciona os dados para ter certeza que foram inseridos
Select DeptHID.ToString(), * From Departamentos

-- Buscar o N� raiz
Select DeptHID.ToString(), * From Departamentos
Where DeptHID = hierarchyid::GetRoot()


-- Ancestral
-- N�o sei o ID Hierarquico dele, s� sei o id do departamento
Declare @OrgHid as HierarchyId
Select @OrgHID = DeptHID From Departamentos Where DeptId = 6
Select DeptHid.ToString(), * From Departamentos
	--Procurando o departamento especifico que � o ancestral 2 niveis acima do depto. 6
	Where DeptHID = @OrgHID.GetAncestor(2) -- 2 niveis acima
	--Where DeptHID = @OrgHID.GetAncestor(2) -- 1 nivel acima
	
-- Ordena��o
Select depthid.ToString(), * From Departamentos order by DeptHID

-- Descendentes
Select DeptHID.ToString(), * From Departamentos 
Where DeptHID.IsDescendantOf(0x58)=1
-- N�o se prende a 1 nivel s�, mostra os descendentes em qualquer nivel da hierarquia


--===============================================================================================



USE AdventureWorks
GO

--drop table dbo.contact
--drop table dbo.contact2

SELECT * INTO dbo.Contact  FROM Person.Contact
SELECT * INTO dbo.Contact2  FROM Person.Contact

SELECT * FROM Contact C INNER JOIN Contact2 C2
ON C.ContactID=C2.ContactID
AND C.LastName= 'Adams'

exec sp_helpindex Contact
exec sp_helpindex Contact2

sp_help Contact

SELECT * FROM Contact
SELECT * FROM Contact

DROP TABLE Contact
DROP TABLE Contact2

--==========================================================================


--Novas funcionalidades T-SQL

--Declara��o de valor direto
DECLARE @i int = 1;

--Operadores Compostos
SET @i += 1

SELECT @i

CREATE TABLE #TESTE2 (COL1 INT, COL2 VARCHAR(10))

--Insert passando v�rios valores
INSERT #TESTE2 VALUES(@i, 'Teste'),(@i+1, 'Teste2'),(@i+2, 'Teste3')
	
SELECT * FROM #TESTE2

--Uso do bloco TRY...CATCH
BEGIN TRY
    SELECT 1/0
END TRY
BEGIN CATCH
    SELECT 
        ERROR_NUMBER()		AS ErrorNumber,
        ERROR_MESSAGE()		AS ErrorMessage,
        ERROR_SEVERITY()	AS Severidade;
END CATCH


WITH Sales_CTE (SalesPersonID, NumberOfOrders, MaxDate)
AS
(
    SELECT SalesPersonID, COUNT(*), MAX(OrderDate)
    FROM Sales.SalesOrderHeader
    GROUP BY SalesPersonID
)
SELECT E.EmployeeID, OS.NumberOfOrders, OS.MaxDate,
    E.ManagerID, OM.NumberOfOrders, OM.MaxDate
FROM HumanResources.Employee AS E
    JOIN Sales_CTE AS OS
    ON E.EmployeeID = OS.SalesPersonID
    LEFT OUTER JOIN Sales_CTE AS OM
    ON E.ManagerID = OM.SalesPersonID
ORDER BY E.EmployeeID;
GO
 ;

MERGE Destino	AS D
USING Origem	AS O
	ON (D.ID = O.ID)
WHEN MATCHED
	THEN UPDATE SET D.nome = A.nome
WHEN NOT MATCHED
	THEN INSERT VALUES(A.ID, A.Sobrenome)
WHEN NOT MATCHED BY SOURCE
	THEN DELETE;
	
	

--Criando um Tipo de Dados Tabela (TVP)
IF OBJECT_ID('TesteTVP') IS NULL
	DROP TYPE TesteTVP
GO
CREATE TYPE TesteTVP AS TABLE
(Id int,Nome varchar(10));
GO
--Criando Procedure que usa (TVP)
IF OBJECT_ID('dbo.usp_TesteTVP') IS NOT NULL
	DROP PROC dbo.usp_TesteTVP
GO
CREATE PROCEDURE dbo.usp_TesteTVP (@TVP TesteTVP READONLY)
AS
SET NOCOUNT ON

CREATE TABLE #Teste (Id int, Nome varchar(10), Data Date)

INSERT #Teste (Id, Nome, Data)
	SELECT *, GetDate()
	FROM @TVP
	
SELECT * FROM @TVP

SELECT * FROM #Teste
GO
--Inserir linhas na tabela (TVP)
DECLARE @TVP AS TesteTVP

INSERT @TVP (Id, Nome) VALUES (1, 'Nilton'), (2, 'Carlos')

--Executando a SP para inserir os dados na tabela TMP
EXEC dbo.usp_TesteTVP @TVP





--DEMO: SNAPSHOT ISOLATION LEVEL
USE master;
GO

ALTER DATABASE AdventureWorks
SET READ_COMMITTED_SNAPSHOT OFF;
GO

USE AdventureWorks;
GO

--DROP TABLE DBO.TESTE

CREATE TABLE Teste (idx int Identity(1,1), valor int);

INSERT INTO Teste VALUES (10);
INSERT INTO Teste VALUES (20);
INSERT INTO Teste VALUES (30);

SELECT * FROM Teste

BEGIN TRANSACTION
           UPDATE Teste SET valor = 11
           WHERE valor = 10
IF @@ERROR > 0
  --ROLLBACK TRANSACTION 
ELSE
  --COMMIT TRANSACTION
 
 SELECT * FROM Teste
 
 
 
USE master;
GO
 
ALTER DATABASE AdventureWorks
SET ALLOW_SNAPSHOT_ISOLATION ON;
GO

USE AdventureWorks;
GO

SET TRANSACTION ISOLATION LEVEL SNAPSHOT

BEGIN TRANSACTION
         UPDATE Teste SET valor = 21
         WHERE valor = 20
IF @@ERROR > 0
  --ROLLBACK TRANSACTION 
ELSE
  --COMMIT TRANSACTION


SELECT * FROM Teste



SELECT TOP 10 [sql_handle], qt.text
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS qt


-- Pivot table with one row and five columns
SELECT 'AverageCost' AS Cost_Sorted_By_Production_Days, 
[0], [1], [2], [3], [4]
FROM
(SELECT DaysToManufacture, StandardCost 
    FROM Production.Product) AS SourceTable
PIVOT
(
AVG(StandardCost)
FOR DaysToManufacture IN ([0], [1], [2], [3], [4])
) AS PivotTable;



USE AdventureWorks;
GO
SELECT SalesQuota, SUM(SalesYTD) 'TotalSalesYTD', GROUPING(SalesQuota) AS 'Grouping'
FROM Sales.SalesPerson
GROUP BY SalesQuota WITH ROLLUP;
GO


USE AdventureWorks;
GO
SELECT	T.[Group]			AS N'Region', 
		T.CountryRegionCode AS N'Country',
		S.Name				AS N'Store', 
		H.SalesPersonID,
		SUM(TotalDue)		AS N'Total Sales' 
FROM Sales.Customer C
    INNER JOIN Sales.Store S
        ON C.CustomerID  = S.CustomerID 
    INNER JOIN Sales.SalesTerritory T
        ON C.TerritoryID  = T.TerritoryID 
    INNER JOIN Sales.SalesOrderHeader H
        ON S.CustomerID = H.CustomerID
WHERE	T.[Group] = N'Europe'
		AND T.CountryRegionCode IN(N'DE', N'FR')
		AND H.SalesPersonID IN(284, 286, 289)
		AND SUBSTRING(S.Name,1,4)IN(N'Vers', N'Spa ')
GROUP BY ROLLUP(
    T.[Group], 
    T.CountryRegionCode, 
    S.Name, 
    H.SalesPersonID)
ORDER BY	T.[Group], 
			T.CountryRegionCode, 
			S.Name, 
			H.SalesPersonID;
			
			
--Management Studio Improvements

DECLARE @i int = 0, @j int = 1000;

WHILE @i < @j
BEGIN
	SET @i += 1
END



