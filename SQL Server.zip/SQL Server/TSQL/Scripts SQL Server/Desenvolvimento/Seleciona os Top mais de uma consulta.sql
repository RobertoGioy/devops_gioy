declare @LogDateStart datetime
declare @LogDateEnd datetime
declare @Total decimal(19,2)

set @LogDateStart = '20120313'
set @LogDateEnd = '20120322'

SELECT	@Total = COUNT(BusinessObjectID)
FROM	Udial.CommandOfferLog WITH(NOLOCK)
WHERE	LogDate BETWEEN @LogDateStart AND DATEADD(DD, 1, @LogDateEnd)
		
CREATE TABLE #TempTable 
( 
	id int IDENTITY(1,1),
	offer varchar(50),
	total int,
	percentual decimal(19,9)
) 

INSERT INTO #TempTable(offer, total, percentual)
SELECT  OfferName, 
		COUNT(BusinessObjectID) AS Total,
		COUNT(BusinessObjectID) / @Total AS Percentual
FROM Udial.CommandOfferLog WITH(NOLOCK)
WHERE LogDate BETWEEN @LogDateStart AND DATEADD(DD, 1, @LogDateEnd)
GROUP BY OfferName
ORDER BY Total DESC

SELECT	'Offers' = 
		CASE 
			WHEN id <= 5 THEN Offer
			ELSE 'Outros'
		END,
		SUM(Total) AS Total,
		SUM(Percentual) AS Percentual,
		@Total AS GroupTotal
FROM ( SELECT id,Offer,Total,Percentual FROM #TempTable) AS Q
GROUP BY 
	CASE 
		WHEN id <= 5 THEN Offer
		ELSE 'Outros'
	END
			
			

--select      top 5 convert(varchar,(id)) as Menu, 
--        Total
--FROM #TempTable
--where id in (select top 5 id from #TempTable order by Total desc)
--UNION
--select      'Outros' as Menu, 
--        sum(Total) as Total
--FROM #TempTable
--where id not in (select top 5 id from #TempTable order by Total)

Drop table #TempTable
