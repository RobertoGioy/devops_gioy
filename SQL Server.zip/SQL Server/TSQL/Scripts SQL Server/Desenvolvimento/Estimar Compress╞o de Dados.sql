exec sp_estimate_data_compression_savings 'Server', 'BusinessObjects', null, null, 'row'

exec sp_estimate_data_compression_savings 'Server', 'BusinessObjects', null, null, 'page'