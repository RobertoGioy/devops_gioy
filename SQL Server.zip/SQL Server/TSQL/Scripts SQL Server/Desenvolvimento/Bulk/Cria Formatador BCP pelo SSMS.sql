/*
	AUTHOR:			JOS� ROBERTO
	DESCRIPTION:	COMANDO BCP PARA GERAR O FORMATADOR DE UMA TABELA
*/

/* Exemplo de cria��o de formatador */
declare @sql varchar(8000)
select @sql = 'bcp UnearDatabaseServerDev.Udial.OlapDeliveredOfferLog format nul -w -f C:\OlapDeliveredOfferLog-c.fmt -S BSPODBS02 -U userdb -P pwd@db'
exec master..xp_cmdshell @sql
GO