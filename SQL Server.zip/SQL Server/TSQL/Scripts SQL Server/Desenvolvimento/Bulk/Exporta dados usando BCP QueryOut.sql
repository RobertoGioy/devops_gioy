Create Table #BusinessObjectId 
(
BusinessObjectId Int
)
Create Clustered index idx_#BusinessObjectId  ON #BusinessObjectId  (BusinessObjectId )

--
Insert Into #BusinessObjectId 
Select distinct BusinessObjectId 
From EmailDeliveryLog With (Nolock) Where InsertedDate Between '20130701' And '20140731' and [Status] = -1

--

Create Table #BusinessObjectId2 
(
BusinessObjectId Int,
InsertedDate DateTime
)
Create Clustered index idx_#BusinessObjectId2  ON #BusinessObjectId2  (BusinessObjectId )

--
Insert Into #BusinessObjectId2
SELECT 
	edl.BusinessObjectId, MAX(edl.InsertedDate)InsertedDate
FROM 
	EmailDeliveryLog edl WITH(NOLOCK)
JOIN #BusinessObjectId bo On bo.BusinessObjectId=edl.BusinessObjectId
Join Campaign Ca On Ca.CampId=edl.CampaignID
Where ca.Status = 'ENCERRADA'
Group By edl.BusinessObjectId

--
Drop Table #BusinessObjectId

--
SELECT 
	edl.BusinessObjectId, edl.email AS email, edl.CampaignID, edl.Status, edl.InsertedDate, ca.CampSubject
INTO #BusinessObjectId_Final
FROM 
	EmailDeliveryLog edl WITH(NOLOCK)
Join #BusinessObjectId2 bo2 On edl.BusinessObjectId=bo2.BusinessObjectId And edl.InsertedDate=bo2.InsertedDate
Join Campaign Ca On Ca.CampId=edl.CampaignID

--
Select * Into Dba_Perfmon.dbo.BusinessObjectId_Final From #BusinessObjectId_Final

--
Drop Table #BusinessObjectId_Final

--
Select Count(1) From Dba_Perfmon.dbo.BusinessObjectId_Final 
Select Count(Distinct Email) From Dba_Perfmon.dbo.BusinessObjectId_Final 

Select Email From Dba_Perfmon.dbo.BusinessObjectId_Final 
Group By Email
Having COUNT(1) >1

Select Top 10 * From Dba_Perfmon.dbo.BusinessObjectId_Final  Where Email = 'camilatuf@gmail.com'

select BusinessObjectId, email, a.CampId, a.CampSubject, b.Status, InsertedDate from umailng_ipiranga.dbo.Campaign a
inner join (Select businessobjectid, email, max(campaignid) as campaignid, status, inserteddate
		From Dba_Perfmon.dbo.BusinessObjectId_Final  Where Email = 'camilatuf@gmail.com'
			group by BusinessObjectId, email, Status, InsertedDate) b on a.CampId = b.campaignid


Select Count(1) From Dba_Perfmon.dbo.BusinessObjectId_Final 

Select Count(Distinct Email) From Dba_Perfmon.dbo.BusinessObjectId_Final 

Select *
Into Dba_Perfmon.dbo.BusinessObjectId_Final2 From (
select  email, a.CampId, a.CampSubject,  inserteddate from umailng_ipiranga.dbo.Campaign a
inner join (Select email, max(campaignid) as campaignid, MAX(InsertedDate) as inserteddate
		From Dba_Perfmon.dbo.BusinessObjectId_Final  --Where Email = 'camilatuf@gmail.com'
			group by email) b on a.CampId = b.campaignid
)A

Select Count(1) From Dba_Perfmon.dbo.BusinessObjectId_Final 
Select Count(1) From Dba_Perfmon.dbo.BusinessObjectId_Final2
Use DBA_PerfMon
exec master..xp_cmdshell  'bcp "Select * From DBA_PerfMon.dbo.BusinessObjectId_Final2 for xml auto, root(''rows''), elements" queryout "C:\Levantamento Ipiranga.xml" -S192.168.10.103 -Uproducao\clodoaldo.santos -T -w -r -t','NO_OUTPUT' 

exec master..xp_cmdshell  'bcp "Select * From DBA_PerfMon.dbo.BusinessObjectId_Final2" queryout "C:\Levantamento Ipiranga.csv" -S192.168.10.103 -Uproducao\clodoaldo.santos -T -c -t'

--bcp "select * from BaseOrigem.dbo.TabelaOrigem" queryout UsuariosMagazineLuiza.txt -S. -T -c -t""" -r|/"


Select * Into UmailNG_Ipiranga.dbo.Levantamento_Final_Ipiranga From DBA_PerfMon.dbo.BusinessObjectId_Final2