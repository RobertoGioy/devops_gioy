/*
	AUTHOR:			JOS� ROBERTO
	DESCRIPTION:	COMANDO BCP PARA GERAR O FORMATADOR DE UMA TABELA
*/

bcp UnearDatabaseServerDev.Udial.OlapDeliveredOfferLog format nul -w -f C:\OlapDeliveredOfferLog-c.fmt -S BSPODBS02 -U userdb -P pwd@db