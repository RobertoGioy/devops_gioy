CREATE DATABASE CAP_10
GO
USE CAP_10

CREATE TABLE PESSOA 
(
	COD INT, 
	NOME VARCHAR(50)
)
GO

--HABILITAR OPENROWSET COM SURFACE AREA CONFIGURATION!!!
EXEC sp_configure 'show advanced option', '1';
reconfigure
--*****-
exec sp_configure 'Ad Hoc Distributed Queries',1
reconfigure

exec sp_configure 'xp_cmdshell',1
reconfigure

--OPENROWSET(DRIVER, STRING DE CONEX�O, SELECT)
--==================================================================
-- EXCEL
SELECT * FROM OPENROWSET('Microsoft.Jet.OLEDB.4.0', 
'Excel 8.0;Database=C:\DADOS\PESSOA.XLS', 
'SELECT COD, NOME FROM [NOMES$]') 

--IMPORTAR DADOS
INSERT INTO PESSOA
SELECT * FROM OPENROWSET('Microsoft.Jet.OLEDB.4.0', 
'Excel 8.0;Database=C:\DADOS\PESSOA.XLS', 
'SELECT COD, NOME FROM [NOMES$]') 

SELECT * FROM PESSOA

--EXPORTAR DADOS
INSERT INTO OPENROWSET('Microsoft.Jet.OLEDB.4.0', 
'Excel 8.0;Database=C:\DADOS\PESSOA.XLS', 
'SELECT COD, NOME FROM [NOMES$]') 
SELECT * FROM PESSOA

--==================================================================
-- MS-ACCESS
--CREATE VIEW VIE_PEDIDOS_ACCESS
--AS
SELECT *
   FROM OPENROWSET('Microsoft.Jet.OLEDB.4.0',
      'C:\Dados\Pedidos2000.mdb';
      'admin';'',PEDIDOS) 

--SELECT * FROM VIE_PEDIDOS_ACCESS
--
SELECT P.*, C.NOME
   FROM OPENROWSET('Microsoft.Jet.OLEDB.4.0',
      'C:\Dados\Pedidos2000.mdb';
      'admin';'',PEDIDOS) P
   JOIN PEDIDOS.DBO.CLIENTES C ON P.CODCLI = C.CODCLI

CREATE TABLE TIPOPRODUTO (COD_TIPO INT PRIMARY KEY, TIPO VARCHAR(30))

INSERT INTO TIPOPRODUTO
SELECT *
   FROM OPENROWSET('Microsoft.Jet.OLEDB.4.0',
      'C:\Dados\Pedidos2000.mdb';
      'admin';'',TIPOPRODUTO) 

SELECT * FROM TIPOPRODUTO
    
--==================================================================
-- DBF (DBASE)
SELECT *  FROM 
OPENROWSET('MSDASQL','Driver={Microsoft dBASE Driver (*.dbf)}; DefaultDir=c:\DADOS\PEDIDOSDBF;SourceType=DBF',
'select * from clientes.dbf')

SELECT *  FROM 
OPENROWSET('Microsoft.Jet.OLEDB.4.0',
          'DBASE IV;Database=C:\Dados\PedidosDBF',
          'SELECT * FROM PEDIDOS.DBF')

--http://www.connectionstrings.com -> STRINGS DE CONEX�O
--==============================================================
/*
CRIE UM ARQUIVO CHAMADO BULK_INSERT.TXT COM O SEGUINTE CONTE�DO

1;CARLOS MAGNO P SOUZA;1959.11.12
2;SONIA REGINA;1964.7.1
3;PEDRO PAULO;1994.2.5
4;MARIA LUIZA;1997.10.29

*/
--DROP TABLE TESTE_BULK_INSERT
CREATE TABLE TESTE_BULK_INSERT
( CODIGO		INT, 
  NOME		VARCHAR(40),
  DATA_NASCIMENTO DATETIME )

SET DATEFORMAT YMD

BULK INSERT TESTE_BULK_INSERT
   FROM 'c:\DADOS\bulk_insert.txt'
   WITH
     (
        FIELDTERMINATOR =';',
        ROWTERMINATOR = '\n'
      )

SELECT * FROM TESTE_BULK_INSERT

DECLARE @xmlDoc xml
SET @xmlDoc = (SELECT ID_PRODUTO, DESCRICAO, PRECO_VENDA
               FROM   PEDIDOS.DBO.PRODUTOS
               FOR XML AUTO)
PRINT CAST( @xmlDoc AS VARCHAR(8000) )

-- Exportar para arquivo texto
exec xp_cmdshell 'bcp "Select * from pedidos.dbo.produtos" queryout "c:\produtos.txt" -c -T'
exec xp_cmdshell 'dir c:\*.txt'

exec xp_cmdshell 'bcp "Select * from pedidos.dbo.produtos" queryout "c:\produtos.csv" -c -T -t ;'
exec xp_cmdshell 'dir c:\*.csv'

/*
-c : Caracteres de 1 byte
-T : Utiliza login do Windows
-t : Especifica o delimitador de campo
*/
--=================================================================                       
EXEC SP_HELPSERVER     

-- Usando login do Windows
--EXEC sp_dropserver 'p5_02'

EXEC SP_ADDLINKEDSERVER '2P5_02'

EXEC SP_HELPSERVER     

SELECT * FROM [2P5_02].PEDIDOS.DBO.CLIENTES

SELECT P.NUM_PEDIDO, P.DATA_EMISSAO, C.NOME 
FROM PEDIDOS.DBO.PEDIDOS P 
     JOIN [2P5_02].PEDIDOS.DBO.CLIENTES C
     ON P.CODCLI = C.CODCLI

EXEC SP_HELPSERVER 

EXEC SP_DROPSERVER '2P5_02'    

EXEC SP_HELPSERVER 

-- Usando login do SQL

EXEC SP_ADDLINKEDSERVER '2P5_INSTRUTOR'

EXEC SP_ADDLINKEDSRVLOGIN @RmtSrvName = '2P5_INSTRUTOR',
                          @UseSelf = 'false',
                          @rmtUser = 'sa',
                          @rmtPassword = 'Imp@ct@'
                          

SELECT P.NUM_PEDIDO, P.DATA_EMISSAO, C.NOME 
FROM PEDIDOS.DBO.PEDIDOS P 
     JOIN [2P5_INSTRUTOR].PEDIDOS.DBO.CLIENTES C
     ON P.CODCLI = C.CODCLI

UPDATE [2P5_INSTRUTOR].PEDIDOS.DBO.PRODUTOS
SET PRECO_VENDA = 2*PRECO_CUSTO

SELECT * FROM [2P5_INSTRUTOR].PEDIDOS.DBO.PRODUTOS


/* Configura��o para poder funcionar transa��o remota
Verificar se o servi�o  "Distribute Transaction Coordinator" est� rodando
running on both database server computer and client computers
1.      "Administrative Tools > Services"
2.      "Distribute Transaction Coordinator" precisa estar rodando

3.      "Administrative Tools > Component Services"
4.      "Component Services > Computers > My Computer" 
        (demora um pouco para abrir)
	4.1.      Click direito em "My Computer", "Properties"
	4.2.      Selecione "MSDTC"
	4.3.      Clique em "Security Configuration"
	4.4.      Ligue as op��es 
				"Network DTC Access", 
				"Allow Remote Client",
				"Allow Inbound/Outbound", 
				"Enable TIP" 
5.      O servi�o ser� reiniciado
6.      O servidor precisar� ser reiniciado

Fa�a o mesmo na m�quina cliente

*/

--exec sp_helpserver

SET XACT_ABORT ON 
--NECESS�RIO PARA A TRANSA��O DISTRIBU�DA -> ELE CONTROLA ROLLBACK NO REMOTO
BEGIN DISTRIBUTED TRAN

SELECT @@TRANCOUNT

UPDATE [2P5_INSTRUTOR].PEDIDOS.DBO.PRODUTOS
SET PRECO_VENDA = PRECO_CUSTO

SELECT * FROM [2P5_INSTRUTOR].PEDIDOS.DBO.PRODUTOS

ROLLBACK

EXEC SP_DROPLINKEDSRVLOGIN [P45_INSTRUTOR], NULL
 
EXEC SP_DROPSERVER [P45_INSTRUTOR]



