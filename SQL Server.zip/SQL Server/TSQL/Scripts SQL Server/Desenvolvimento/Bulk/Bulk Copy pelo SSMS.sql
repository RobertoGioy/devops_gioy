
/* Exemplo de bulk copy de exporta��o baseado em T-SQL */
declare @sql varchar(8000)
select @sql = 'bcp "select * from UmailNG_Americanas.dbo.TrackingLog where logdate >= ''2014-01-01'' and logdate < ''2014-06-01''" queryout c:\TrackingLog_2014.txt -c -t, -T -S DDBS01'
exec master..xp_cmdshell @sql
GO

/* Exemplo de bulk copy de importa��o */
declare @sql varchar(8000)
select @sql = 'bcp UmailNG_Americanas.dbo.TrackingLogNew in c:\TrackingLog_2014.txt -c -t, -T -S DDBS01'
exec master..xp_cmdshell @sql
GO

/* Exemplo de cria��o de formatador */
declare @sql varchar(8000)
select @sql = 'bcp ItaucardServerDev.Udial.NavigationLog format nul -T -N -f arquivo-n.fmt'
exec master..xp_cmdshell @sql
GO

/* Exemplo de cria��o de formatador em xml */
declare @sql varchar(8000)
select @sql = 'bcp AdventureWorks2012.HumanResources.Department format nul -c -x -f Department-c..xml �t, -T'
exec master..xp_cmdshell @sql
GO
