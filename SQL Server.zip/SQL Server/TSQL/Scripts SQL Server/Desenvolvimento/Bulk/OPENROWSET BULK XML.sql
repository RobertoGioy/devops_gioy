-- declare XML variable
DECLARE @InputXML XML

-- import file from disk
SELECT @InputXML = CAST(x AS XML)
FROM OPENROWSET(BULK 'C:\Temp\EntityData.xml', SINGLE_BLOB) AS T(x)

-- parse XML using XQuery and insert into the table    
INSERT INTO FinanceirasManagerDev.dbo.Resources (id, specialkey, name, description, versionid, createdate)
    SELECT 
        resources.value('(Id)[1]', 'int'),
        resources.value('(SpecialKey)[1]', 'varchar(255)'),
        resources.value('(Name)[1]', 'varchar(255)'),
        resources.value('(Description)[1]', 'varchar(255)'),
        resources.value('(VersionId)[1]', 'int'),
        resources.value('(Date)[1]', 'varchar(30)')
    FROM @InputXML.nodes('Resource') AS X(resources)