/*Udial.CommandLog*/
DECLARE @MaxLogID	BIGINT
DECLARE @MaxDate	DATETIME
DECLARE @Days		INT

SELECT @MaxLogID = MAX(LogID) FROM Udial.CommandLog

SELECT @MaxDate = DATEADD(DD, 1, MAX(LogDate)) FROM Udial.CommandLog WHERE DATEPART(DW,LogDate) = 7

SELECT @Days = DATEDIFF(DD, '2011-05-01', @MaxDate)

BULK INSERT Udial.CommandLog
FROM 'D:\BCP\Files\Dia\01052011_Domingo\Domingo_CommandLog.txt'
WITH (
FIRSTROW = 1,
FIELDTERMINATOR = '\t',
FORMATFILE = 'D:\BCP\FormatFiles\CommandLog-c.fmt'
);

UPDATE Udial.CommandLog
SET LogDate = DATEADD(DD, @Days, LogDate)
WHERE LogID > @MaxLogID
GO
