/*
Drop Table Clientes_Conf_Import
Drop Table #ClientesConf
*/
Create Table Clientes_Conf_Import
	(
	Campo1 Varchar (max),
	Campo2 Varchar (max),
	Campo3 Varchar (max),
	Campo4 Varchar (max),
	Campo5 Varchar (max),
	Campo6 Varchar (max),
	Campo7 Varchar (max)
	)

--Sp_addlinkedserver 'FRSRVBDSQL12\SQL12'
BULK INSERT Clientes_Conf_Import
   FROM 'C:\CadSefaz_SAFI mar 13.txt'
   WITH 
      (
         FIELDTERMINATOR ='�',
         ROWTERMINATOR ='\n'
      )


GO

CREATE TABLE #ClientesConf(
	[ClientesConf_Inscr] [char](18) NOT NULL,
	[ClientesConf_CNPJ] [char](16) NOT NULL,
	[ClientesConf_DataAbertura] [datetime] NULL,
	[ClientesConf_DataCancelamento] [datetime] NULL,
	[ClientesConf_CodSituacao] [int] NULL
)


GO


Insert Into #ClientesConf
Select  Campo2 INSCRICAO,
		Campo1 CNPJ,
		Convert
		(Datetime,
		(
        Reverse(Substring(reverse(Campo4),1,4)) 
		+'-'+
		Replace(Reverse(Substring(reverse(Campo4),6,2)),'/','0')
		+'-'+
		Right('0'+Rtrim(Replace(Substring(Campo4,1,2),'/','')),2)
		)
		) DATA_ABERTURA,
        Convert
		(Datetime,
		(
        Reverse(Substring(reverse(Campo5),1,4)) 
		+'-'+
		Replace(Reverse(Substring(reverse(Campo5),6,2)),'/','0')
		+'-'+
		Right('0'+Rtrim(Replace(Substring(Campo5,1,2),'/','')),2)
		)
		) DATA_CANCELAMENTO,
		Campo6 BLOQUEIO
From Clientes_Conf_Import Where Campo2 <> 'Total'


GO
DELETE FROM [FRSRVBDSQL12\SQL12].DW_R.DBO.CLIENTESCONF_HISTORICO
GO
INSERT INTO [FRSRVBDSQL12\SQL12].DW_R.DBO.CLIENTESCONF_HISTORICO(CLIENTESCONF_INSCR, CLIENTESCONF_CNPJ, CLIENTESCONF_DATACANCELAMENTO, CLIENTESCONF_CODSITUACAO, CLIENTESCONF_DATAIMPORTACAO)
SELECT CLIENTESCONF_INSCR, CLIENTESCONF_CNPJ, CLIENTESCONF_DATACANCELAMENTO, CLIENTESCONF_CODSITUACAO, GETDATE()CLIENTESCONF_DATAIMPORTACAO
FROM [FRSRVBDSQL12\SQL12].DW_R.DBO.CLIENTESCONF

DELETE FROM [FRSRVBDSQL12\SQL12].DW_R.DBO.CLIENTESCONF




INSERT INTO [FRSRVBDSQL12\SQL12].DW_R.DBO.ClientesConf
Select 
ClientesConf_Inscr, 
ClientesConf_CNPJ, 
Case 
	When ClientesConf_DataCancelamento<ClientesConf_DataAbertura 
	Then NULL
	Else ClientesConf_DataCancelamento 
End ClientesConf_DataCancelamento , 
ClientesConf_CodSituacao
From #ClientesConf A
GROUP BY  ClientesConf_Inscr, 
ClientesConf_CNPJ, 
Case 
	When ClientesConf_DataCancelamento<ClientesConf_DataAbertura 
	Then NULL
	Else ClientesConf_DataCancelamento 
End, ClientesConf_CodSituacao
--Where Not Exists 
--		(Select * From [FRSRVBDSQL12\SQL12].DW_R.DBO.ClientesConf B 
--		    Where A.[ClientesConf_Inscr]=B.[ClientesConf_Inscr]
--			And A.[ClientesConf_CNPJ]=B.[ClientesConf_CNPJ])

Drop table #ClientesConf
Drop Table Clientes_Conf_Import