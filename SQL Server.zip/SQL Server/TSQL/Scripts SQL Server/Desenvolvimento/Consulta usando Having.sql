Select * From Nota_Fiscal A
Inner Join 
(Select 
		Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, CodMod, Datent
		From Nota_Fiscal
		Where Datent Between '2009-06-18' And '2009-06-18' 
		Group By Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, CodMod, Datent
		Having COUNT(Numnot)>1
) B 
On A.Codemp=B.Codemp And A.Numnot=B.Numnot And A.Sernot=B.Sernot And A.Tipnot=B.Tipnot And
   A.Codope=B.Codope And A.Codcli=B.Codcli And A.Codmod=B.Codmod And A.Datent=B.Datent
Where A.Pericm = 27



Delete A From Nota_Fiscal A
Inner Join 
(Select 
		Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, CodMod, Datent
		From Nota_Fiscal
		Where Datent Between '2009-06-18' And '2009-06-18'
		Group By Codemp, Numnot, Sernot, Tipnot, Codope, Codcli, CodMod, Datent
		Having COUNT(Numnot)>1
) B 
On A.Codemp=B.Codemp And A.Numnot=B.Numnot And A.Sernot=B.Sernot And A.Tipnot=B.Tipnot And
   A.Codope=B.Codope And A.Codcli=B.Codcli And A.Codmod=B.Codmod And A.Datent=B.Datent
Where A.Pericm = 27