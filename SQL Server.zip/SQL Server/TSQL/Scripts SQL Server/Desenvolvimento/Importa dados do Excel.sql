/*
sp_Configure 'show advanced options','1'
Reconfigure
sp_Configure 'Ad Hoc Distributed Queries','1'
Reconfigure
Sp_AddLinkedServer FRSRVDES01
*/

Insert Into FRSRVDES01.T_EMP128_C_JESON.dbo.[DePara_NF_Parametro]
(Codemp, Tipo, Campo,Valor)
SELECT Codemp, Tipo, Campo, 
Case When Valor Is Null Then 0 Else Valor End
FROM 
OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0','Data Source=C:\Importa.xlsx;Extended Properties=Excel 8.0')...
[Pasta1$]




Insert Into FRSRVDES01.T_EMP128_C_JESON.dbo.[DePara_NF]
SELECT IdDePara,Codemp,IdTipo,Antigo,Novo,DataCadastro,Ativo
FROM 
OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0','Data Source=C:\Importa.xlsx;Extended Properties=Excel 8.0')...
[Pasta1$]



Insert Into FRSRVDES01.T_EMP128_C_JESON.dbo.[DePara_NF]
SELECT IdDePara,Codemp,Tipo,Antigo,Novo,GETDATE(),Ativo
FROM 
OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0','Data Source=C:\Importa.xlsx;Extended Properties=Excel 8.0')...
[Embalagens$]


Insert Into FRSRVDES01.T_EMP128_C_JESON.dbo.[DePara_NF]
SELECT IdDePara,Codemp,Tipo,Antigo,Novo,GETDATE(),Ativo
FROM 
OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0','Data Source=C:\Importa.xlsx;Extended Properties=Excel 8.0')...
[Vasilhames$]