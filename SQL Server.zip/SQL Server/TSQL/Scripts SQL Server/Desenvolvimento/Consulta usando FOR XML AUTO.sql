--****************************************INSERE TABELAS SEM CODEMP E SEM IDENTITY****************************************--

DECLARE @VAR0 SYSNAME, @VAR1 VARCHAR(MAX), @VAR2 VARCHAR(MAX), @VAR3 VARCHAR(MAX), @VAR4 VARCHAR(MAX)
DECLARE CURSOR1 CURSOR FOR


Select Name From SysObjects 
Where (
      Not Name In (Select Object_Name(Object_Id) From Sys.Identity_Columns) And 
      Not Name Like '%Temp%'          And Not Name Like '%Transacoes%' And 
      Not Name Like '%Ocorrencias%'   And Not Name Like '%SYS%'        And 
      Not Name Like '%SYS%'      And 
      Not Name In (Select Object_Name(Id) From SysColumns Where Name = 'Codemp'))     
And Xtype = 'U' 

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR0
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @VAR2 = 'INSERT INTO ' + @VAR0 + ' (' + (SELECT STUFF( (SELECT ', ' + RTRIM(NAME)
    FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) =  @VAR0 FOR XML PATH('')), 1, 2, '' ) ) + ')'
    SET @VAR3 = 'SELECT ' + ' ' + (SELECT STUFF( (SELECT ', ' + RTRIM(NAME)
    FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) =  @VAR0 FOR XML PATH('')), 1, 2, '' ) ) +
    ' FROM DC_180210_PC.DBO.' + @VAR0 + '(NOLOCK)'
		
	PRINT @VAR2
	PRINT @VAR3
	PRINT 'Go'
	
	FETCH NEXT FROM CURSOR1 INTO @VAR0
END
CLOSE CURSOR1
DEALLOCATE CURSOR1
--************************************************************************************************************************--


--****************************************INSERE TABELAS SEM CODEMP E COM IDENTITY****************************************--

DECLARE @VAR0 SYSNAME, @VAR1 VARCHAR(MAX), @VAR2 VARCHAR(MAX), @VAR3 VARCHAR(MAX), @VAR4 VARCHAR(MAX)
DECLARE CURSOR1 CURSOR FOR

Select Name From SysObjects 
Where (
      Name In (Select Object_Name(Object_Id) From Sys.Identity_Columns) And 
      Not Name Like '%Temp%'          And Not Name Like '%Transacoes%' And 
      Not Name Like '%Ocorrencias%'   And Not Name Like '%SYS%'        And 
      Not Name Like '%SYS%'      And 
      Not Name In (Select Object_Name(Id) From SysColumns Where Name = 'Codemp'))     
And Xtype = 'U' 

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR0
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @VAR1 = 'SET IDENTITY_INSERT ' + @VAR0 + ' ON'
	SET @VAR2 = 'INSERT INTO ' + @VAR0 + ' (' + (SELECT STUFF( (SELECT ', ' + RTRIM(NAME)
    FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) =  @VAR0 FOR XML PATH('')), 1, 2, '' ) ) + ')'
    SET @VAR3 = 'SELECT ' + ' ' + (SELECT STUFF( (SELECT ', ' + RTRIM(NAME)
    FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) =  @VAR0 FOR XML PATH('')), 1, 2, '' ) ) +
    ' FROM DC_180210_PC.DBO.' + @VAR0 +'(NOLOCK)'
	SET @VAR4 = 'SET IDENTITY_INSERT ' + @VAR0 + ' OFF'
	
	PRINT @VAR1
	PRINT @VAR2
	PRINT @VAR3
	PRINT @VAR4
	PRINT 'Go'
	
	FETCH NEXT FROM CURSOR1 INTO @VAR0
END
CLOSE CURSOR1
DEALLOCATE CURSOR1

--************************************************************************************************************************--



--****************************************INSERE TABELAS COM CODEMP E SEM IDENTITY****************************************--

DECLARE @VAR0 SYSNAME, @VAR1 VARCHAR(MAX), @VAR2 VARCHAR(MAX), @VAR3 VARCHAR(MAX), @VAR4 VARCHAR(MAX)
DECLARE CURSOR1 CURSOR FOR

Select Name From SysObjects 
Where (
      Not Name In (Select Object_Name(Object_Id) From Sys.Identity_Columns) And 
      Not Name Like '%Temp%'          And Not Name Like '%Transacoes%' And 
      Not Name Like '%Ocorrencias%'   And Not Name Like '%SYS%'        And 
      Name In (Select Object_Name(Id) From SysColumns Where Name = 'Codemp'))     
And Xtype = 'U'


OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR0
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @VAR2 = 'INSERT INTO ' + @VAR0 + ' (' + (SELECT STUFF( (SELECT ', ' + RTRIM(NAME)
    FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) =  @VAR0 FOR XML PATH('')), 1, 2, '' ) ) + ')'
    SET @VAR3 = 'SELECT ' + ' ' + (SELECT STUFF( (SELECT ', ' + RTRIM(NAME)
    FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) =  @VAR0 FOR XML PATH('')), 1, 2, '' ) ) +
    ' FROM DC_180210_PC.DBO.' + @VAR0 + '(NOLOCK) WHERE CODEMP = ''270'''
		
	PRINT @VAR2
	PRINT @VAR3
	PRINT 'Go'
	
	FETCH NEXT FROM CURSOR1 INTO @VAR0
END
CLOSE CURSOR1
DEALLOCATE CURSOR1

--************************************************************************************************************************--



--****************************************INSERE TABELAS COM CODEMP E COM IDENTITY****************************************--

DECLARE @VAR0 SYSNAME, @VAR1 VARCHAR(MAX), @VAR2 VARCHAR(MAX), @VAR3 VARCHAR(MAX), @VAR4 VARCHAR(MAX)
DECLARE CURSOR1 CURSOR FOR

Select Name From SysObjects 
Where (
      Name In (Select Object_Name(Object_Id) From Sys.Identity_Columns) And 
      Not Name Like '%Temp%'          And Not Name Like '%Transacoes%' And 
      Not Name Like '%Ocorrencias%'   And Not Name Like '%SYS%'        And 
      Not Name Like '%SYS%'      And 
      Name In (Select Object_Name(Id) From SysColumns Where Name = 'Codemp'))     
And Xtype = 'U'


OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR0
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @VAR1 = 'SET IDENTITY_INSERT ' + @VAR0 + ' ON'
	SET @VAR2 = 'INSERT INTO ' + @VAR0 + ' (' + (SELECT STUFF( (SELECT ', ' + RTRIM(NAME)
    FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) =  @VAR0 FOR XML PATH('')), 1, 2, '' ) ) + ')'
    SET @VAR3 = 'SELECT ' + ' ' + (SELECT STUFF( (SELECT ', ' + RTRIM(NAME)
    FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) =  @VAR0 FOR XML PATH('')), 1, 2, '' ) ) +
    ' FROM DC_180210_PC.DBO.' + @VAR0 + '(NOLOCK) WHERE CODEMP = ''270'''
	SET @VAR4 = 'SET IDENTITY_INSERT ' + @VAR0 + ' OFF'
	
	PRINT @VAR1
	PRINT @VAR2
	PRINT @VAR3
	PRINT @VAR4
	PRINT 'Go'
	
	FETCH NEXT FROM CURSOR1 INTO @VAR0
END
CLOSE CURSOR1
DEALLOCATE CURSOR1

--**********************************************************************************************************************--

--****************************************APAGA TABELAS COM CODEMP******************************************************--

DECLARE @VAR1 SYSNAME
DECLARE CURSOR1 CURSOR FOR

select s1.name from sysobjects s1 inner join syscolumns s2 on s1.id=s2.id 
where s1.xtype='U' and s2.name='Codemp' order by s1.name

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1
WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT 'DELETANDO TABELA --> '+@VAR1
	EXEC ('DELETE FROM  '+@VAR1+ ' WHERE CODEMP=''270''')
	FETCH NEXT FROM CURSOR1 INTO @VAR1
END
CLOSE CURSOR1
DEALLOCATE CURSOR1



/*

Select * From Usuarios
Insert Into Usuarios
Select * From SL2000ACT.dbo.Usuarios where nome = 'Suporte'
Insert Into Logins
Select * From SL2000ACT.dbo.Logins where Login = 'Suporte'
*/
