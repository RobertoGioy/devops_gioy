SELECT SUBSTRING ((
       SELECT ',' + s.Name
       FROM Sales.SalesReason  s
       ORDER BY s.Name
       FOR XML PATH(''))
,2,200000 ) AS NAME