-- select * from empresas

disable trigger all on database
go
DECLARE @VAR1 VARCHAR(MAX),@VAR2 VARCHAR(MAX)
DECLARE CURSOR1 CURSOR FOR

SELECT COMANDO,COMANDO2 FROM (
select	s.name as TABELA, s2.name as COLUNA, 
'IF OBJECT_ID(''CK_CODEMP_'+s.name+''') IS NOT NULL ALTER TABLE dbo.'+s.name+' DROP CONSTRAINT CK_CODEMP_'+s.name as COMANDO,
'ALTER TABLE dbo.'+s.name+' ADD CONSTRAINT CK_CODEMP_'+s.name+' CHECK (CODEMP IN (''190''))'  as COMANDO2
from sysobjects s inner join syscolumns s2  on s.id = s2.id
where s.xtype='U' and s2.name = 'CODEMP' 
) TABELA WHERE COMANDO2 IS NOT NULL	 order by COMANDO,COMANDO2

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1, @VAR2
WHILE @@FETCH_STATUS = 0
BEGIN
	EXEC (@VAR1)
	EXEC (@VAR2)
	FETCH NEXT FROM CURSOR1 INTO @VAR1, @VAR2
END
CLOSE CURSOR1
DEALLOCATE CURSOR1
go

enable trigger all on database



   
