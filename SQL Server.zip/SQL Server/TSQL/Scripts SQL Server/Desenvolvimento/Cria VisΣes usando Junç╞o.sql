create view [dbo].[Balanco_Dados]
as
select CodEmp, Indice, Codigo, Data, Tipmet, sum(Valor) as Valor, Perc 
from 
(
select '210' as Codemp, Indice, Codigo, Data, Tipmet, sum(Valor) as Valor, Perc 
from FIN210_BARLEY.dbo.Balanco_Dados Where CodEmp in ('210')
group by Indice, Codigo, Data, Tipmet, Perc 
union all
select '210' as Codemp, Indice, Codigo, Data, Tipmet, sum(Valor) as Valor, Perc 
from FIN210_BARLEY.dbo.Balanco_Dados Where CodEmp = '214'
group by Indice, Codigo, Data, Tipmet, Perc 
) a 
group by CodEmp, Indice, Codigo, Data, Tipmet, Perc 


GO

create view [dbo].[Balanco_Desp]
as
Select CodEmp, CodRed, Data, Tiplan, Tipo, CodEst, Sum(Valor) as Valor, sum(Efetuar) as Efetuar, CodOrc, TipCon 
From
(
select '210' as CodEmp, CodRed, Data, Tiplan, Tipo, CodEst, Sum(Valor) as Valor, sum(Efetuar) as Efetuar, CodOrc, TipCon 
from FIN210_BARLEY.dbo.Balanco_Desp
Where CodEmp in ('210')
group by CodRed, Data, Tiplan, Tipo, CodEst, CodOrc, TipCon 
union all
select '210' as CodEmp, CodRed, Data, Tiplan, Tipo, CodEst, Sum(Valor) as Valor, sum(Efetuar) as Efetuar, CodOrc, TipCon 
from FIN210_BARLEY.dbo.Balanco_Desp
Where CodEmp = '214'
group by CodRed, Data, Tiplan, Tipo, CodEst, CodOrc, TipCon 
) a 
group by CodEmp, CodRed, Data, Tiplan, Tipo, CodEst, CodOrc, TipCon 

 
GO

create view [dbo].[Balanco_Desp_Orc]
as
select CodEmp, Data, CodEst, sum(Valor) as Valor, Efetuar, Codred, CodOrc 
from
(
select '210' as CodEmp, Data, CodEst, sum(Valor) as Valor, Efetuar, Codred, CodOrc 
from FIN210_BARLEY.dbo.Balanco_Desp_Orc where CodEmp in ('210')
group by Data, CodEst, Efetuar, Codred, CodOrc
union all
select '210' as CodEmp, Data, CodEst, sum(Valor) as Valor, Efetuar, Codred, CodOrc 
from FIN210_BARLEY.dbo.Balanco_Desp_Orc where CodEmp = '214'
group by Data, CodEst, Efetuar, Codred, CodOrc
) a 
group by CodEmp, Data, CodEst, Efetuar, Codred, CodOrc


GO

create view [dbo].[Balanco_DespInc] 
as
select CodEmp, Codred, Data, Tiplan, Tipo, CodEst, sum(Valor) as Valor, Sum(Efetuar) as Efetuar, CodOrc, TipCon 
from 
(
select '210' as CodEmp, Codred, Data, Tiplan, Tipo, CodEst, sum(Valor) as Valor, Sum(Efetuar) as Efetuar, CodOrc, TipCon 
from FIN210_BARLEY.dbo.Balanco_DespInc
Where CodEmp in ('210')
Group by Codred, Data, Tiplan, Tipo, CodEst, CodOrc, TipCon 
union all
select '210' as CodEmp, Codred, Data, Tiplan, Tipo, CodEst, sum(Valor) as Valor, Sum(Efetuar) as Efetuar, CodOrc, TipCon 
from FIN210_BARLEY.dbo.Balanco_DespInc
Where CodEmp = '214'
Group by Codred, Data, Tiplan, Tipo, CodEst, CodOrc, TipCon 
) a
Group by CodEmp, Codred, Data, Tiplan, Tipo, CodEst, CodOrc, TipCon 


GO

create view [dbo].[Balanco_Efetuar]
as
select CodEmp, Codigo, Data, Tiplan, sum(Valor) as Valor 
from 
(
select '210' as CodEmp, Codigo, Data, Tiplan, sum(Valor) as Valor 
from FIN210_BARLEY.dbo.Balanco_Efetuar where codemp in ('210')
group by Codigo, Data, Tiplan
union all
select '210' as CodEmp, Codigo, Data, Tiplan, sum(Valor) as Valor 
from FIN210_BARLEY.dbo.Balanco_Efetuar where codemp = '214'
group by Codigo, Data, Tiplan
) a 
group by CodEmp, Codigo, Data, Tiplan

 
GO

create view [dbo].[Balanco_Efetuarcont]
as
select CodEmp, Codigo, Data, Tiplan, sum(Valor) as Valor 
From
(
select '210' as CodEmp, Codigo, Data, Tiplan, sum(Valor) as Valor 
from FIN210_BARLEY.dbo.Balanco_Efetuarcont where CodEmp in ('210')
group by Codigo, Data, Tiplan
union all 
select '210' as CodEmp, Codigo, Data, Tiplan, sum(Valor) as Valor 
from FIN210_BARLEY.dbo.Balanco_Efetuarcont where CodEmp = '214'
group by Codigo, Data, Tiplan
)a 
group by CodEmp, Codigo, Data, Tiplan

GO

create view [dbo].[Balanco_Estoque]
as
select CodEmp, Datmov, CodGru, SubGru, Tiplan, DesGru, Dessgru, sum(QtdAnt) as QtdAnt, sum(ValAnt) as ValAnt, sum(QtdCom) as QtdCom, sum(ValCom) as ValCom, sum(QEnBon) as QEnBon, 
sum(QtdVen) as QtdVen, sum(ValVen) as ValVen, sum(QSaBon) as QSaBon, sum(QtdQue) as QtdQue, sum(ValQue) as ValQue, sum(QTroca) as QTroca, sum(QtdAtu) as QtdAtu, sum(ValAtu) as ValAtu, 
sum(Qtdcha) as Qtdcha, sum(Valcha) as Valcha, sum(Qtdvaa) as Qtdvaa, sum(Valvaa) as Valvaa, sum(Comqta) as Comqta, sum(Comvaa) as Comvaa, sum(Qtdent) as Qtdent, sum(Valent) as Valent, 
sum(Qtdsai) as Qtdsai, sum(Valsai) as Valsai, sum(Qtdchf) as Qtdchf, sum(Valchf) as Valchf, sum(Qtdvaf) as Qtdvaf, sum(Valvaf) as Valvaf, sum(Comqtf) as Comqtf, sum(Comvaf) as Comvaf, 
sum(EntEmp) as EntEmp, sum(SaiBic) as SaiBic, sum(SaiEmp) as SaiEmp, sum(SalTrA) as SalTrA, sum(SalPaA) as SalPaA, sum(SalPrA) as SalPrA, sum(SalTrF) as SalTrF, sum(SalPaF) as SalPaF, 
sum(SalPrF) as SalPrF, sum(SalEmA) as SalEmA, sum(SalPoA) as SalPoA, sum(SalEmF) as SalEmF, sum(SalPoF) as SalPoF, sum(TTGeral) as TTGeral, sum(TTValor) as TTValor 
from
(
select '210' as CodEmp, Datmov, CodGru, SubGru, Tiplan, DesGru, Dessgru, sum(QtdAnt) as QtdAnt, sum(ValAnt) as ValAnt, sum(QtdCom) as QtdCom, sum(ValCom) as ValCom, sum(QEnBon) as QEnBon, 
sum(QtdVen) as QtdVen, sum(ValVen) as ValVen, sum(QSaBon) as QSaBon, sum(QtdQue) as QtdQue, sum(ValQue) as ValQue, sum(QTroca) as QTroca, sum(QtdAtu) as QtdAtu, sum(ValAtu) as ValAtu, 
sum(Qtdcha) as Qtdcha, sum(Valcha) as Valcha, sum(Qtdvaa) as Qtdvaa, sum(Valvaa) as Valvaa, sum(Comqta) as Comqta, sum(Comvaa) as Comvaa, sum(Qtdent) as Qtdent, sum(Valent) as Valent, 
sum(Qtdsai) as Qtdsai, sum(Valsai) as Valsai, sum(Qtdchf) as Qtdchf, sum(Valchf) as Valchf, sum(Qtdvaf) as Qtdvaf, sum(Valvaf) as Valvaf, sum(Comqtf) as Comqtf, sum(Comvaf) as Comvaf, 
sum(EntEmp) as EntEmp, sum(SaiBic) as SaiBic, sum(SaiEmp) as SaiEmp, sum(SalTrA) as SalTrA, sum(SalPaA) as SalPaA, sum(SalPrA) as SalPrA, sum(SalTrF) as SalTrF, sum(SalPaF) as SalPaF, 
sum(SalPrF) as SalPrF, sum(SalEmA) as SalEmA, sum(SalPoA) as SalPoA, sum(SalEmF) as SalEmF, sum(SalPoF) as SalPoF, sum(TTGeral) as TTGeral, sum(TTValor) as TTValor 
from FIN210_BARLEY.dbo.Balanco_Estoque
where CodEmp in ('210')
group by Datmov, CodGru, SubGru, Tiplan, DesGru, Dessgru
union all
select '210' as CodEmp, Datmov, CodGru, SubGru, Tiplan, DesGru, Dessgru, sum(QtdAnt) as QtdAnt, sum(ValAnt) as ValAnt, sum(QtdCom) as QtdCom, sum(ValCom) as ValCom, sum(QEnBon) as QEnBon, 
sum(QtdVen) as QtdVen, sum(ValVen) as ValVen, sum(QSaBon) as QSaBon, sum(QtdQue) as QtdQue, sum(ValQue) as ValQue, sum(QTroca) as QTroca, sum(QtdAtu) as QtdAtu, sum(ValAtu) as ValAtu, 
sum(Qtdcha) as Qtdcha, sum(Valcha) as Valcha, sum(Qtdvaa) as Qtdvaa, sum(Valvaa) as Valvaa, sum(Comqta) as Comqta, sum(Comvaa) as Comvaa, sum(Qtdent) as Qtdent, sum(Valent) as Valent, 
sum(Qtdsai) as Qtdsai, sum(Valsai) as Valsai, sum(Qtdchf) as Qtdchf, sum(Valchf) as Valchf, sum(Qtdvaf) as Qtdvaf, sum(Valvaf) as Valvaf, sum(Comqtf) as Comqtf, sum(Comvaf) as Comvaf, 
sum(EntEmp) as EntEmp, sum(SaiBic) as SaiBic, sum(SaiEmp) as SaiEmp, sum(SalTrA) as SalTrA, sum(SalPaA) as SalPaA, sum(SalPrA) as SalPrA, sum(SalTrF) as SalTrF, sum(SalPaF) as SalPaF, 
sum(SalPrF) as SalPrF, sum(SalEmA) as SalEmA, sum(SalPoA) as SalPoA, sum(SalEmF) as SalEmF, sum(SalPoF) as SalPoF, sum(TTGeral) as TTGeral, sum(TTValor) as TTValor 
from FIN210_BARLEY.dbo.Balanco_Estoque
where CodEmp = '214'
group by Datmov, CodGru, SubGru, Tiplan, DesGru, Dessgru
)a
group by CodEmp, Datmov, CodGru, SubGru, Tiplan, DesGru, Dessgru



 
GO

create view [dbo].[Balanco_Pedido]
as
select CodEmp, CodTip, CodCat, Tiplan, Data, sum(ValVen) as Valven 
from
(
select '210' as CodEmp, CodTip, CodCat, Tiplan, Data, sum(ValVen) as Valven 
from FIN210_BARLEY.dbo.Balanco_Pedido
Where CodEmp in ('210')
group by CodTip, CodCat, Tiplan, Data
union all
select '210' as CodEmp, CodTip, CodCat, Tiplan, Data, sum(ValVen) as Valven 
from FIN210_BARLEY.dbo.Balanco_Pedido
Where CodEmp = '214'
group by CodTip, CodCat, Tiplan, Data
) a 
group by CodEmp, CodTip, CodCat, Tiplan, Data

 
GO

create view [dbo].[Balanco_Transp]
as
select CodEmp, DatMov, Placa, TipoFrete, Sum(Valor) as Valor, Tiplan 
from
(
select '210' as CodEmp, DatMov, Placa, TipoFrete, Sum(Valor) as Valor, Tiplan 
from FIN210_BARLEY.dbo.Balanco_Transp where codemp in ('210')
group by DatMov, Placa, TipoFrete, Tiplan 
union all
select '210' as CodEmp, DatMov, Placa, TipoFrete, Sum(Valor) as Valor, Tiplan 
from FIN210_BARLEY.dbo.Balanco_Transp where codemp in ('214')
group by DatMov, Placa, TipoFrete, Tiplan 
)Bl 
group by CodEmp,DatMov, Placa, TipoFrete, Tiplan 


GO


