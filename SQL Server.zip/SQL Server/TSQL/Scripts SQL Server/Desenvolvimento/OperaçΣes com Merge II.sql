CREATE TABLE #Tabela1 ( Nome VARCHAR (100)


                                       , Cadastro DATETIME

                                       , Alteracao DATETIME

                                       , Ativo BIT)

INSERT #Tabela1

VALUES ('Andressa', GETDATE(), NULL, 1),

            ('Joao', GETDATE(), NULL, 1),

            ('Maria', GETDATE(), NULL, 1),

            ('Ana', GETDATE(), NULL, 1)


CREATE TABLE #Tabela2 ( Nome VARCHAR(100)

                                       , Twitter VARCHAR(100))

INSERT #Tabela2

VALUES ('Andressa','@dre_martins'),

            ('Marieta','@Marieta'),

            ('Joaquim','@Joaquim'),

            ('Jos�','@jose')



SELECT * FROM #Tabela1

SELECT * FROM #Tabela2


MERGE #Tabela1 AS Destino
USING #Tabela2 AS Origem
ON Destino.Nome = Origem.Nome
----H� registro no destino e na origem
--WHEN MATCHED
--THEN UPDATE SET Ativo = 0, Alteracao = GETDATE();

----Quando n�o h� registro no destino e h� na origem
--WHEN NOT MATCHED
--THEN INSERT (Nome, Cadastro, Ativo) VALUES (Origem.Nome, Getdate(),1);

----Quando  h� registro no destino mas n�o h� na origem e que sejam diferente de Jo�o
--WHEN NOT MATCHED BY SOURCE AND Destino.Nome <>'Joao'
--THEN UPDATE SET Ativo = NULL, Alteracao = GETDATE();


SELECT * FROM #Tabela1
SELECT * FROM #Tabela2




/************************************************/


MERGE 
   Dim_Erro_Notas_Numnot AS Destino
USING 
   fato_erro_notas AS Origem
ON 
       Destino.Id = Origem.Id
   AND Origem.Data Between '2014-02-01' And '2014-03-01'
WHEN MATCHED THEN 
			UPDATE SET
			  Destino.[Categoria Produto] = Origem.Destip
			, Destino.[CFOP] = Origem.Codope
			, Destino.[Cliente ou Forncedor] = Origem.Clifor
			, Destino.[Codigo Tipo Produto] = Origem.Codtip
			, Destino.[CST] = Origem.Codtri
			, Destino.[Descricao Produto] = Origem.Codtri
			, Destino.[Numero Nota Fiscal] = Origem.Numnot
			, Destino.[Oper COFINS] = Origem.Tipopecof
			, Destino.[Oper ICMS] = Origem.Tipope
			, Destino.[Oper IPI] = Origem.Tipopeipi
			, Destino.[Oper PIS] = Origem.Tipopepis
			, Destino.[Oper ST] = Origem.Tipopepis
			, Destino.[Tipo da Nota] = Origem.Tipnot
			, Destino.[Tipo Observacao] = Origem.Tipobs
			, Destino.[Data] = Origem.Data
WHEN NOT MATCHED THEN 
   INSERT ([Id],[Categoria Produto],[CFOP],[Cliente ou Forncedor],[Codigo Tipo Produto],[CST],[Descricao Produto],[Numero Nota Fiscal],[Oper COFINS],[Oper ICMS],[Oper IPI],[Oper PIS],[Oper ST],[Tipo da Nota],[Tipo Observacao],[Data]) 
   VALUES (Id,Destip,Codope,Clifor,Codtip,Codtri,Codtri,Numnot,Tipopecof,Tipope,Tipopeipi,Tipopepis,Tipopepis,Tipnot,Tipobs,Data);