/*
	AUTHOR:			JOS� ROBERTO
	DESCRIPTION:	ALTERA O SCHEMA DE UM OBJETO NO BANCO DE DADOS
*/

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE [TABLE_NAME] =	'BicUchannelsAuthorizerPOSLog' AND [TABLE_TYPE] = 'BASE TABLE')
BEGIN
	PRINT 'Altering table [dbo].[BicUchannelsAuthorizerPOSLog] FOR SCHEMA [Uchannels]...'
	ALTER SCHEMA [Uchannels] TRANSFER [dbo].[BicUchannelsAuthorizerPOSLog]
END
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE [TABLE_NAME] =	'BicUdialCardNumberLog' AND [TABLE_TYPE] = 'BASE TABLE')
BEGIN
	PRINT 'Altering table [dbo].[BicUdialCardNumberLog] FOR SCHEMA [Udial]...'
	ALTER SCHEMA [Udial] TRANSFER [dbo].[BicUdialCardNumberLog]
END
GO

