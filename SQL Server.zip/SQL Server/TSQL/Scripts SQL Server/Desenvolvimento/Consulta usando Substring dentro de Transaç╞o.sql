select * from c_custocont order by codest

select substring(codest,1,16)+'.'+substring(codest,17,10) from c_custocont 

where substring(codest,17,1) <> '.' and len(codred) = 10

order by codest

select * into a_c_custocont from c_custocont

begin tran

update c_custocont set codest = substring(codest,1,16)+'.'+substring(codest,17,10) 

where substring(codest,17,1) <> '.' and len(codred) = 10

commit
