--ENCRYPTBYPASSPHRASE - DECRYPTBYPASSPHRASE

/*
IF (DATABASEPROPERTY('SecureDB','version') > 0)
BEGIN
USE MASTER
ALTER DATABASE SecureDB SET single_user WITH ROLLBACK IMMEDIATE
DROP DATABASE SecureDB
END

GO

USE MASTER
GO
CREATE DATABASE SecureDB
GO

USE SecureDB
GO

CREATE TABLE dbo.Cliente
(CodigoCliente INT NOT NULL IDENTITY(1,1)
,Nombres VARCHAR(100) NOT NULL
,TarjetaCredito VARBINARY(128))

GO

INSERT INTO dbo.Cliente (Nombres, TarjetaCredito)
VALUES ('Frank Lampard', ENCRYPTBYPASSPHRASE('EstaEsMiFraseSecreta','1111-1111-1111-1111'))

GO

SELECT CodigoCliente, Nombres, TarjetaCredito
FROM dbo.Cliente

GO

SELECT CodigoCliente, Nombres, CONVERT(VARCHAR(50),
DECRYPTBYPASSPHRASE('EstaNoEsMiFraseSecreta',TarjetaCredito))
FROM dbo.Cliente

GO

SELECT CodigoCliente, Nombres, CONVERT(VARCHAR(50), DECRYPTBYPASSPHRASE('EstaEsMiFraseSecreta',TarjetaCredito))
FROM dbo.Cliente

*/


DECLARE @v_Usuario SYSNAME
SET @v_Usuario = 'Usuario1'
INSERT INTO dbo.Cliente (Nombres, TarjetaCredito)
VALUES ('Fernando Torres', ENCRYPTBYPASSPHRASE('EstaEsMiFraseSecreta','2222-2222-2222-2222',1,@v_Usuario))

GO

SELECT CodigoCliente, Nombres, TarjetaCredito
FROM dbo.Cliente

GO

DECLARE @v_Usuario SYSNAME
SET @v_Usuario = 'Usuario1'
SELECT CodigoCliente, Nombres, CONVERT(VARCHAR(50), DECRYPTBYPASSPHRASE('EstaEsMiFraseSecreta',TarjetaCredito,1,@v_Usuario))
FROM dbo.Cliente