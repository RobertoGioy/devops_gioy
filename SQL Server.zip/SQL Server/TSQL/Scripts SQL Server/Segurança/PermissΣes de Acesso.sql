
-- Criacao da role b�sica
CREATE ROLE [db_basic] AUTHORIZATION dbo
GO


-- Permissao de execucao para a regra
GRANT EXECUTE ON SCHEMA::dbo TO [db_basic]
GO


-- Permissao de Leitura para a regra
SP_ADDROLEMEMBER db_datareader, [db_basic]
GO


-- Permissao de acesso (conexao) para o Usuario ou Grupo
SP_GRANTDBACCESS 'userdb'
GO

SP_GRANTDBACCESS 'Corp\Projetos'
GO


-- Adicionar Usuario ou Grupo na regra
SP_ADDROLEMEMBER [db_basic], 'userdb'
GO

SP_ADDROLEMEMBER [db_basic], 'Corp\Projetos'
GO
