USE CPED_GP;
SELECT s.name
FROM sys.schemas s
WHERE s.principal_id = USER_ID('Programador');

ALTER AUTHORIZATION ON SCHEMA::db_owner TO dbo;


SELECT s.name
FROM sys.schemas s
WHERE s.principal_id = USER_ID('dbo')


ALTER AUTHORIZATION ON SCHEMA::db_owner TO dbo;