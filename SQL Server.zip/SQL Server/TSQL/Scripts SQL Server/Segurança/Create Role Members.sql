CREATE ROLE [db_advanced] AUTHORIZATION [dbo];

CREATE ROLE [db_basic] AUTHORIZATION [dbo];

EXECUTE sp_addrolemember @rolename = N'db_datareader', @membername = N'db_advanced';

EXECUTE sp_addrolemember @rolename = N'db_datareader', @membername = N'db_basic';

EXECUTE sp_addrolemember @rolename = N'db_datawriter', @membername = N'db_advanced';

EXECUTE sp_addrolemember @rolename = N'db_datawriter', @membername = N'db_basic';

EXECUTE sp_addrolemember @rolename = N'db_ddladmin', @membername = N'db_advanced';


EXECUTE sp_addrolemember @rolename = N'db_basic', @membername = N'userdb';

EXECUTE sp_addrolemember @rolename = N'db_basic', @membername = N'CORP\Produtos';

EXECUTE sp_addrolemember @rolename = N'db_advanced', @membername = N'CORP\Projetos';
