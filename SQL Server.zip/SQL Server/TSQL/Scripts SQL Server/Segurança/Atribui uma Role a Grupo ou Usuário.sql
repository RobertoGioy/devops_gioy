/*
	Author:			Roberto Silva
	Description:	Atribui uma role a um grupo ou usu�rio.
	Create Date:	2011-01-03
*/

-- Permissao de acesso (conexao) para o Usuario ou Grupo
EXEC sys.sp_grantdbaccess @loginame = [userdb]
GO

-- Adicionar Usuario ou Grupo na regra
EXEC sys.sp_addrolemember @rolename = db_datareader, @membername = [userdb]
EXEC sys.sp_addrolemember @rolename = db_datawriter, @membername = [userdb]
GO
