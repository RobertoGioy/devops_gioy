/*USE MASTER
declare @spid varchar(5)

DECLARE CURSOR1 CURSOR FOR

Select A.session_id
FROM sys.dm_db_session_space_usage A
JOIN sys.dm_exec_sessions B  ON A.session_id = B.session_id
JOIN sys.dm_exec_connections C ON C.session_id = B.session_id
CROSS APPLY sys.dm_exec_sql_text(C.most_recent_sql_handle) As D
WHERE A.session_id > 0 And A.session_id <> @@SPID
And login_name In ('Teste.Suporte')
OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @spid
WHILE @@FETCH_STATUS = 0
	BEGIN
	exec ('kill ' + @spid)
	FETCH NEXT FROM CURSOR1 INTO @spid
	END
CLOSE CURSOR1
DEALLOCATE CURSOR1
*/
USE MASTER
GO
IF EXISTS (SELECT * FROM sys.server_principals WHERE name = N'Teste.Suporte')
DROP LOGIN [Teste.Suporte] 
GO
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'Teste.Suporte')
CREATE LOGIN [Teste.Suporte] WITH PASSWORD=N'#Une@r2014#' MUST_CHANGE, DEFAULT_DATABASE=[master], CHECK_EXPIRATION=ON, CHECK_POLICY=ON


USE msdb
GO


IF EXISTS (SELECT * FROM sys.database_principals WHERE name = N'Teste.Suporte')
DROP USER [Teste.Suporte] 
GO	
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'Teste.Suporte')
CREATE USER [Teste.Suporte] FOR LOGIN [Teste.Suporte] WITH DEFAULT_SCHEMA=[dbo]
GO

EXEC sp_addrolemember N'AcessoSuporte_MSDB', N'Teste.Suporte'

GO

USE DBA_PerfMon
GO
CREATE ROLE [AcessoSuporte_MSDB] AUTHORIZATION [dbo] 
GO 

GRANT VIEW DEFINITION ON SCHEMA::[dbo] TO [AcessoSuporte_MSDB];
GRANT EXECUTE TO [AcessoSuporte_MSDB]; 
GRANT SELECT TO [AcessoSuporte_MSDB];
GRANT SHOWPLAN TO [AcessoSuporte_MSDB];

IF EXISTS (SELECT * FROM sys.database_principals WHERE name = N'Teste.Suporte')
DROP USER [Teste.Suporte] 
	
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'Teste.Suporte')
CREATE USER [Teste.Suporte] FOR LOGIN [Teste.Suporte] WITH DEFAULT_SCHEMA=[dbo]

EXEC sp_addrolemember N'AcessoSuporte_MSDB', N'Teste.Suporte'

GO

DECLARE @VAR1 SYSNAME
DECLARE CURSOR1 CURSOR FOR

SELECT
B.name
From sys.database_mirroring A Inner Join sys.sysdatabases B On A.database_id=B.dbid where NOT b.NAME IN ('DBA_PerfMon','tempdb', 'master', 'model', 'msdb', 'ReportServer', 'ReportServerTempDB', 'UmailNG_ScriptClean') 
AND COALESCE(A.mirroring_role,1) <> 2 AND DATABASEPROPERTY(B.name,'IsOffline') = 0 AND DATABASEPROPERTY(B.name,'IsInRecovery') = 0 AND DATABASEPROPERTY(B.name,'IsSuspect') = 0
AND DATABASEPROPERTY(B.name,'IsReadOnly') = 0

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1
WHILE @@FETCH_STATUS = 0
BEGIN
EXEC ('
USE ['+ @VAR1 + ']

IF EXISTS (SELECT * FROM sys.database_principals WHERE name = N''Teste.Suporte'')
DROP USER [Teste.Suporte] 
	
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N''Teste.Suporte'')
CREATE USER [Teste.Suporte] FOR LOGIN [Teste.Suporte] WITH DEFAULT_SCHEMA=[dbo]

EXEC sp_addrolemember N''AcessoSuporte'', N''Teste.Suporte''

	
	')
	FETCH NEXT FROM CURSOR1 INTO @VAR1
END
CLOSE CURSOR1
DEALLOCATE CURSOR1

GO

Use master
GO

GRANT VIEW SERVER STATE TO [Teste.Suporte]
GO
GRANT VIEW SERVER STATE TO [Rafael.Muniz]
GO
GRANT VIEW SERVER STATE TO [Braulio.Gouveia]
GO