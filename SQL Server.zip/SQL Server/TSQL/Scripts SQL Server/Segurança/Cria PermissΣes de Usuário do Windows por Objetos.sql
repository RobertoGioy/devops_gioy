
/*
	Author:			Roberto Silva
	Description:	Cria as permiss�es de usu�rios do dom�nio.
	Create Date:	2011-01-03
	Observation:	Configurar o usu�rio a conceder permiss�o antes de rodar. Copiar o resultado em outra query e rodar.
*/

DECLARE @user	varchar(255)
DECLARE @Schema varchar(255)
SET @user = 'CORP\willian'

SELECT 'GRANT EXECUTE ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.procedures p inner join sys.schemas s on p.schema_id = s.schema_id
UNION
SELECT 'GRANT EXECUTE ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.synonyms p inner join sys.schemas s on p.schema_id = s.schema_id
UNION
SELECT 'GRANT SELECT ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.views p inner join sys.schemas s on p.schema_id = s.schema_id
UNION
SELECT 'GRANT INSERT ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.tables p inner join sys.schemas s on p.schema_id = s.schema_id
UNION 
SELECT 'GRANT DELETE ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.tables p inner join sys.schemas s on p.schema_id = s.schema_id
UNION 
SELECT 'GRANT UPDATE ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.tables p inner join sys.schemas s on p.schema_id = s.schema_id
UNION 
SELECT 'GRANT SELECT ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.tables p inner join sys.schemas s on p.schema_id = s.schema_id
UNION 
SELECT 'GRANT VIEW DEFINITION ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.tables p inner join sys.schemas s on p.schema_id = s.schema_id
UNION 
SELECT 'GRANT ALTER ON [' + @Schema + '].[' + [name] + '] TO [' + @user + ']' as SCRIPT
FROM sys.tables where schema_id = schema_id('' + @Schema + '')
UNION
SELECT 'GRANT CREATE TABLE TO [' + @user + ']' as SCRIPT
UNION
SELECT 'GRANT CREATE PROCEDURE TO [' + @user + ']' as SCRIPT
ORDER BY [SCRIPT]