/*
	Author:			Roberto Silva
	Description:	Cria as permiss�es de usu�rios do SQL Server.
	Create Date:	2011-01-03
	Observation:	Configurar o usu�rio a conceder permiss�o antes de rodar. Copiar o resultado em outra query e rodar.
	Usado no ambiente do Ita�
*/

DECLARE @user	varchar(255)
DECLARE @Schema varchar(255)
SET @user = 'ae'

SELECT 'GRANT EXECUTE ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.procedures p inner join sys.schemas s on p.schema_id = s.schema_id
UNION
SELECT 'GRANT EXECUTE ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.synonyms p inner join sys.schemas s on p.schema_id = s.schema_id
UNION
SELECT 'GRANT SELECT ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.views p inner join sys.schemas s on p.schema_id = s.schema_id
UNION
SELECT 'GRANT INSERT ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.tables p inner join sys.schemas s on p.schema_id = s.schema_id
UNION 
SELECT 'GRANT DELETE ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.tables p inner join sys.schemas s on p.schema_id = s.schema_id
UNION 
SELECT 'GRANT UPDATE ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.tables p inner join sys.schemas s on p.schema_id = s.schema_id
UNION 
SELECT 'GRANT SELECT ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.tables p inner join sys.schemas s on p.schema_id = s.schema_id
UNION 
SELECT 'GRANT VIEW DEFINITION ON [' + s.name + '].[' + p.name + '] TO [' + @user + ']' as SCRIPT
FROM sys.tables p inner join sys.schemas s on p.schema_id = s.schema_id
ORDER BY [SCRIPT]