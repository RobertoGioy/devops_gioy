DECLARE @VAR1 SYSNAME
DECLARE CURSOR1 CURSOR FOR

SELECT
B.name
From sys.database_mirroring A Inner Join sys.sysdatabases B On A.database_id=B.dbid where NOT b.NAME IN ('DBA_PerfMon','tempdb', 'master', 'model', 'msdb', 'ReportServer', 'ReportServerTempDB', 'UmailNG_ScriptClean') 
AND COALESCE(A.mirroring_role,1) <> 2 AND DATABASEPROPERTY(B.name,'IsOffline') = 0 AND DATABASEPROPERTY(B.name,'IsInRecovery') = 0 AND DATABASEPROPERTY(B.name,'IsSuspect') = 0
AND DATABASEPROPERTY(B.name,'IsReadOnly') = 0

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1
WHILE @@FETCH_STATUS = 0
BEGIN
EXEC ('
    USE ['+ @VAR1 + ']
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N''AcessoSuporte'' AND type = ''R'')	
CREATE ROLE [AcessoSuporte] AUTHORIZATION [dbo] 

DECLARE @VAR113 SYSNAME
DECLARE CURSOR113 CURSOR FOR
Select Distinct A.name From sys.schemas A 
Inner JOin Sys.tables B On A.[schema_id]=B.[schema_id]
OPEN CURSOR113
FETCH NEXT FROM CURSOR113 INTO @VAR113
WHILE @@FETCH_STATUS = 0
BEGIN
EXEC (''GRANT VIEW DEFINITION ON SCHEMA::[''+ @VAR113 + ''] TO [AcessoSuporte];'')
	FETCH NEXT FROM CURSOR113 INTO @VAR113
END
CLOSE CURSOR113
DEALLOCATE CURSOR113
GRANT DELETE TO [AcessoSuporte];
GRANT EXECUTE TO [AcessoSuporte]; 
GRANT INSERT TO [AcessoSuporte];
GRANT SELECT TO [AcessoSuporte];
GRANT UPDATE TO [AcessoSuporte];

	
	')
	FETCH NEXT FROM CURSOR1 INTO @VAR1
END
CLOSE CURSOR1
DEALLOCATE CURSOR1



/*
DECLARE @VAR1 SYSNAME
DECLARE CURSOR1 CURSOR FOR

SELECT
B.name
From sys.database_mirroring A Inner Join sys.sysdatabases B On A.database_id=B.dbid where NOT b.NAME IN ('DBA_PerfMon','tempdb', 'master', 'model', 'msdb', 'ReportServer', 'ReportServerTempDB', 'UmailNG_ScriptClean') 
AND COALESCE(A.mirroring_role,1) <> 2 AND DATABASEPROPERTY(B.name,'IsOffline') = 0 AND DATABASEPROPERTY(B.name,'IsInRecovery') = 0 AND DATABASEPROPERTY(B.name,'IsSuspect') = 0
AND DATABASEPROPERTY(B.name,'IsReadOnly') = 0

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @VAR1
WHILE @@FETCH_STATUS = 0
BEGIN
PRINT ('
    USE ['+ @VAR1 + ']
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N''AcessoSuporte'' AND type = ''R'')	
CREATE ROLE [AcessoSuporte] AUTHORIZATION [dbo] 
GRANT VIEW DEFINITION ON SCHEMA::[dbo] TO [AcessoSuporte];
GRANT DELETE TO [AcessoSuporte];
GRANT EXECUTE TO [AcessoSuporte]; 
GRANT INSERT TO [AcessoSuporte];
GRANT SELECT TO [AcessoSuporte];
GRANT UPDATE TO [AcessoSuporte];

	
	')
	FETCH NEXT FROM CURSOR1 INTO @VAR1
END
CLOSE CURSOR1
DEALLOCATE CURSOR1

*/