

Create Table ##UsuarioOrfao
(
SERVIDOR NVarchar(100),
BASE_DE_DADOS NVarchar(100),
USUARIO_ORFAO NVarchar(100)
)



EXEC Sp_msforeachdb'
IF (
		Select COUNT(*) From sys.database_mirroring A
		Inner Join sys.sysdatabases B On A.database_id=B.dbid
		where b.NAME  = ''?''
		AND COALESCE(A.mirroring_role,1) <> 2
	) > 0
BEGIN
Insert Into ##UsuarioOrfao
SELECT 
@@SERVERNAME SERVIDOR,
''?'' BASE_DE_DADOS,
U.NAME USUARIO_ORFAO
FROM
    master..syslogins l
RIGHT JOIN 
    [?]..sysusers u 
ON l.sid = u.sid
WHERE   
    l.sid IS NULL
AND issqlrole <> 1
AND isapprole <> 1
--AND sysadmin <> 1
AND ( u.name <> ''INFORMATION_SCHEMA'' AND u.name <> ''MS_DataCollectorInternalUser'' AND u.name <> ''guest'' AND u.name <> ''dbo'' AND u.name <> ''sys'' AND u.name <> ''system_function_schema'')
END
'
GO


Select * From ##UsuarioOrfao
Order by USUARIO_ORFAO

GO
Drop Table ##UsuarioOrfao

