--Administradores=======================================================================================================
if not exists (select * from master.dbo.syslogins where loginname = N'Clelia')
BEGIN
	exec sp_addlogin N'Clelia', null, 'master', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'Marcelo')
BEGIN
	exec sp_addlogin N'Marcelo',null, 'master', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'Fernando')
BEGIN
	exec sp_addlogin N'Fernando',null, 'master', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'Andre')
BEGIN
	exec sp_addlogin N'Andre',null, 'master', @@language
END
GO


exec sp_addsrvrolemember N'Clelia', sysadmin
GO
exec sp_addsrvrolemember N'Marcelo', sysadmin
GO
exec sp_addsrvrolemember N'Fernando', sysadmin
GO
exec sp_addsrvrolemember N'Andre', sysadmin
GO


--Genericos=============================================================================================================
if not exists (select * from master.dbo.syslogins where loginname = N'monit_user')
BEGIN
	exec sp_addlogin N'monit_user','CED83E1020E', 'msdb', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'etl_user')
BEGIN
	exec sp_addlogin N'etl_user','332641CE3E12', 'msdb', @@language
END
GO


exec sp_addsrvrolemember N'etl_user', bulkadmin
GO



--Aplicativos============================================================================================================
if not exists (select * from master.dbo.syslogins where loginname = N'user_carros')  --DB_WebMotors
BEGIN
	exec sp_addlogin N'user_carros','user_carros', 'msdb', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'user_manutencoes') --DB_Manutencoes
BEGIN
	exec sp_addlogin N'user_manutencoes','user_manutencoes', 'msdb', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'user_motos')   --DB_Motos
BEGIN
	exec sp_addlogin N'user_motos','user_motos', 'msdb', @@language
END
GO


if not exists (select * from master.dbo.syslogins where loginname = N'user_promocoes') --DB_Promocoes
BEGIN
	exec sp_addlogin N'user_promocoes','user_promocoes', 'msdb', @@language
END
GO


if not exists (select * from master.dbo.syslogins where loginname = N'user_promocoes') --Conteudo2, WmPublicador, WmEstatisticas
BEGIN
	exec sp_addlogin N'api_userwm','api_userwm', 'msdb', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'user_rss')  --Conteudo2
BEGIN
	exec sp_addlogin N'user_rss','user_rss', 'msdb', @@language
END
GO


if not exists (select * from master.dbo.syslogins where loginname = N'news_api')   --Newsletter
BEGIN
	exec sp_addlogin N'news_api','news_api', 'msdb', @@language
END
GO


if not exists (select * from master.dbo.syslogins where loginname = N'user_see')   --DB_SEE
BEGIN
	exec sp_addlogin N'user_see','user_see', 'msdb', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'user_expurgo')   --WmExpurgo  (sistema expurgo de fotos)
BEGIN
	exec sp_addlogin N'user_expurgo','user_expurgo', 'msdb', @@language
END
GO



--Desenvolvedores =======================================================================================================
Use master
go

if not exists (select * from master.dbo.syslogins where loginname = N'Auda')
BEGIN
	exec sp_addlogin N'Auda', null, 'master', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'Claudia')
BEGIN
	exec sp_addlogin N'Claudia', null, 'master', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'Anderson')
BEGIN
	exec sp_addlogin N'Anderson', null, 'master', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'Arthur')
BEGIN
	exec sp_addlogin N'Arthur', null, 'master', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'Badan')
BEGIN
	exec sp_addlogin N'Badan', null, 'master', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'Mauricio')
BEGIN
	exec sp_addlogin N'Mauricio', null, 'master', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'Rogerio')
BEGIN
	exec sp_addlogin N'Rogerio', null, 'master', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'Vinicios')
BEGIN
	exec sp_addlogin N'Vinicios', null, 'master', @@language
END
GO


if not exists (select * from master.dbo.syslogins where loginname = N'arthur.alessio')
BEGIN
	exec sp_addlogin N'arthur.alessio', null, 'master', @@language
END
GO

if not exists (select * from master.dbo.syslogins where loginname = N'eduardo.moraes')
BEGIN
	exec sp_addlogin N'eduardo.moraes', null, 'master', @@language
END
GO



/*#ATEN��O############################################################################
--Solicitar que os Usu�rios alterem a senha no primeiro login, executando a procedure:

   exec sp_password 'oldpassword', 'newpassword'


*/
