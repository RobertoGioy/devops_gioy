CREATE PROCEDURE CopyPermissions
@OldUser sysname, @NewUser sysname
AS
EXEC sp_configure 'allow updates', 1
RECONFIGURE WITH OVERRIDE

DECLARE @uid int
DECLARE @rid int

SELECT @uid = uid
FROM sysusers
WHERE name = @OldUser

SELECT @rid = uid
FROM sysusers
WHERE name = @NewUser

DELETE syspermissions
WHERE grantee = @rid

INSERT syspermissions
SELECT id, @rid, grantor,
actadd, actmod,
seladd, selmod,
updadd, updmod,
refadd, refmod
FROM syspermissions
WHERE grantee = @uid

EXEC sp_configure 'allow updates', 0
RECONFIGURE WITH OVERRIDE
GO
