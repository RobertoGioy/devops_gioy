SELECT
 'CREATE LOGIN ' + QUOTENAME(NAME) +
 CASE
  WHEN TYPE_DESC LIKE 'WINDOWS%' THEN ' FROM WINDOWS'
 ELSE ' WITH PASSWORD = ' + 
  SYS.FN_VarBinToHexStr(CAST(LOGINPROPERTY(NAME,'PasswordHash') As VARBINARY(MAX))) + ' HASHED' +
  ' , SID = ' + SYS.FN_VarBinToHexStr(CAST(SID As VARBINARY(MAX))) + ' , '
 END +
 
 CASE
  WHEN TYPE_DESC LIKE 'WINDOWS%' THEN ' WITH '
 ELSE '' END +
 
 'DEFAULT_DATABASE = ' + default_database_name + ', ' + 
    'DEFAULT_LANGUAGE = ' + default_language_name
FROM SYS.server_principals
WHERE TYPE_DESC IN ('SQL_LOGIN')--,'WINDOWS_LOGIN','WINDOWS_GROUP')


--select top 10 * FROM SYS.server_principals

--SELECT state_desc + ' ' + permission_name + ' TO ' +
--QUOTENAME(Name) COLLATE Latin1_General_CI_AS_KS_WS,
--p.permission_name,
--p.state_desc, s.name
--FROM sys.server_permissions p
--INNER JOIN sys.server_principals s ON
--p.grantee_principal_id = s.principal_id
