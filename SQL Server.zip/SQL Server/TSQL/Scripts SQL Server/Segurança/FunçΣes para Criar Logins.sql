
--Fun��es para criptografia da Senha do Usu�rio
select pwdencrypt('Teste') --criptografa Senha  - usar no insert
select pwdcompare('Teste', pwdencrypt('Teste')) as respvalid --compara o texto recebido com o criptografado





--SCRIPT PARA TESTE DE LOGIN

CREATE TABLE t_Usuarios(
	usercod int identity(1,1) primary key not null,
	usernome varchar(100) null,
	usersenha varbinary(100) null,
	usertipo int NULL
)ON [PRIMARY]
GO


CREATE PROCEDURE p_UsuariosInclusao
	@usuario varchar(50),
	@senha varchar(10),
	@tipo int
as
	Insert into t_usuarios(usernome, usertipo,usersenha) values(@usuario,@tipo,pwdencrypt('Teste'))

GO

alter PROCEDURE p_UsuariosLogon
	@usuario varchar(50),
	@senha varchar(10)
AS

 Select pwdcompare(@senha,usersenha) as respValid, Usercod, Usernome, Usertipo
 From t_usuarios 
 Where usernome = @usuario and pwdcompare(@senha,usersenha) = 1
GO


Grant exec on p_UsuariosLogon to etl_user


exec p_UsuariosLogon 'Clelia','aA1234'