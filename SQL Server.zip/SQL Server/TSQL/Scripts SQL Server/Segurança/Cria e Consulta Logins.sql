USE [REV443_GP]
GO
CREATE LOGIN [ConsultaAud_TI] WITH PASSWORD = 0x0100360e51b5a11163e2aeb753a63ed02171af502fcf44eeab08 HASHED , SID = 0xa6a001931da70a459840a1ba20b93e2e , DEFAULT_DATABASE = master, DEFAULT_LANGUAGE = us_english

GO
ALTER LOGIN [ConsultaAud_TI] WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF

GO
CREATE USER [ConsultaAud_TI] FOR LOGIN [ConsultaAud_TI]

GO
EXEC sp_addrolemember N'db_datareader', N'ConsultaAud_TI'

GO
exec sp_change_users_login 'auto_fix','ConsultaAud_TI'


SELECT Db_Name() AS DB_Name,
case prin.name when 'dbo' then prin.name + ' ('+ (select SUSER_SNAME(owner_sid) from master.sys.databases where name ='?') + ')' else prin.name end AS UserName,
prin.type_desc AS LoginType,
isnull(USER_NAME(mem.role_principal_id),'') AS AssociatedRole ,create_date,modify_date
FROM sys.database_principals prin
LEFT OUTER JOIN sys.database_role_members mem ON prin.principal_id=mem.member_principal_id
WHERE prin.sid IS NOT NULL and prin.sid NOT IN (0x00) and
prin.is_fixed_role <> 1 AND prin.name NOT LIKE '##%'
And case prin.name when 'dbo' then prin.name + ' ('+ (select SUSER_SNAME(owner_sid) from master.sys.databases where name ='?') + ')' else prin.name end = 'ConsultaAud_TI'
