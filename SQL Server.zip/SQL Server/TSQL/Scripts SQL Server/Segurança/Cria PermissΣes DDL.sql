
-- Criacao da role b�sica
CREATE ROLE [db_advanced] AUTHORIZATION dbo
GO


-- Permissao de execucao para a regra
GRANT EXECUTE ON SCHEMA::dbo TO [db_advanced]
GO


-- Permissao de Leitura para a regra
SP_ADDROLEMEMBER db_datareader, [db_advanced]
GO

-- Permissao de Escrita para a regra
SP_ADDROLEMEMBER db_datawriter, [db_advanced]
GO

-- Permissao de DDL para a regra
SP_ADDROLEMEMBER db_ddladmin, [db_advanced]
GO


-- Permissao de acesso (conexao) para o Usuario ou Grupo
SP_GRANTDBACCESS 'Corp\Projetos'
GO


-- Adicionar Usuario ou Grupo na regra
SP_ADDROLEMEMBER [db_advanced], 'Corp\Projetos'
GO