/*
	Author:			Roberto Silva
	Description:	Cria as permiss�es de usu�rios do dom�nio.
	Create Date:	2011-01-03
	Observation:	Configurar o usu�rio a conceder permiss�o antes de rodar. Copiar o resultado em outra query e rodar.
*/

DECLARE @user varchar(255)
SET @user = 'CORP\Projetos'


SELECT 'USE [' + DB_NAME() + ']'
UNION ALL
SELECT 'GRANT SELECT TO [' + @user + ']'
UNION ALL
SELECT 'GRANT EXECUTE TO [' + @user + ']'
UNION ALL
SELECT 'GRANT INSERT TO [' + @user + ']'
UNION ALL
SELECT 'GRANT DELETE TO [' + @user + ']'
UNION ALL
SELECT 'GRANT UPDATE TO [' + @user + ']'
UNION ALL
SELECT 'GRANT ALTER TO [' + @user + ']'
UNION ALL
SELECT 'GRANT CREATE TABLE TO [' + @user + ']'
UNION ALL
SELECT 'GRANT CREATE PROCEDURE TO [' + @user + ']'
UNION ALL
SELECT 'GRANT CREATE VIEW TO [' + @user + ']'
UNION ALL
SELECT 'GRANT VIEW DEFINITION TO [' + @user + ']'
