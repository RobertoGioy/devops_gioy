
Create Table ##UsuarioOrfao
(
SERVIDOR NVarchar(100),
BASE_DE_DADOS NVarchar(100),
USUARIO_ORFAO NVarchar(100)
)



EXEC Sp_msforeachdb'
IF (
		Select COUNT(*) From sys.database_mirroring A
		Inner Join sys.sysdatabases B On A.database_id=B.dbid
		where b.NAME  = ''?''
		AND COALESCE(A.mirroring_role,1) <> 2
	) > 0
BEGIN
Insert Into ##UsuarioOrfao
SELECT 
@@SERVERNAME SERVIDOR,
''?'' BASE_DE_DADOS,
U.NAME USUARIO_ORFAO
FROM
    master..syslogins l
RIGHT JOIN 
    [?]..sysusers u 
ON l.sid = u.sid
WHERE   
    l.sid IS NULL
AND issqlrole <> 1
AND isapprole <> 1
--AND sysadmin <> 1
AND ( u.name <> ''INFORMATION_SCHEMA'' AND u.name <> ''guest'' AND u.name <> ''dbo'' AND u.name <> ''sys'' AND u.name <> ''system_function_schema'')
END
'


GO


DECLARE @DB SYSNAME, @USRO SYSNAME
DECLARE CURSOR1 CURSOR FOR

SELECT BASE_DE_DADOS,USUARIO_ORFAO FROM ##USUARIOORFAO

OPEN CURSOR1
FETCH NEXT FROM CURSOR1 INTO @DB, @USRO

WHILE @@FETCH_STATUS = 0
BEGIN
    
    
    
    EXEC ('
		USE ['+@DB +']
		IF (Select COUNT(*) From Master..syslogins Where Name = '''+@USRO+''') >0
		Begin
		Exec Sp_Change_users_login ''Auto_Fix'',''' +@USRO+'''
		End
		Else
		Begin
		Exec Sp_Change_users_login ''Auto_Fix'',['''+@USRO+''']
		End
    
		')
    
    
    FETCH NEXT FROM CURSOR1 INTO @DB, @USRO
END

CLOSE CURSOR1
DEALLOCATE CURSOR1

GO

DROP TABLE ##UsuarioOrfao