DECLARE @LOGINNAME VARCHAR(MAX)
Set @loginName = 'Consulta_JDavid'
If Exists 
(select loginname from master.dbo.syslogins where name = @loginName) 
Begin 
PRINT ('ALTER LOGIN [' + @loginName + '] WITH PASSWORD=N''R4Jn%kehf9'',CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF')
End 