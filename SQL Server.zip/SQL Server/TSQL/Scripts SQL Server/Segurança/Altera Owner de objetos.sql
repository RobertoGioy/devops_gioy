--altera owner de procedures e tabelas
sp_changeobjectowner 'programador.sp_Relpospasta','dbo'