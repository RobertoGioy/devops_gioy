declare @tb sysname, @col sysname, @cmd varchar(max),@tbant sysname  
       declare @tbsys table (Tabela sysname,CmdCampos varchar(max))  
/*  
set @serv1 = '[@SERVIDOR1]'  
set @base1 = '[@BASE1]'  
set @serv2 = '[@SERVIDOR2]'  
set @base2 = '[@BASE2]'  
*/  
set @cmd = ''  
  
declare reg cursor for 
select s3.name, s4.name from [172.17.6.153\CON].[DC].dbo.sysindexkeys s1  
        inner join [172.17.6.153\CON].[DC].dbo.sysindexes s2 on s1.id = s2.id and s1.indid =s2.indid          
        inner join [172.17.6.153\CON].[DC].dbo.sysobjects s3 on s1.id = s3.id   
        inner join [172.17.6.153\CON].[DC].dbo.syscolumns s4 on s4.id = s3.id and s1.colid = s4.colid   
             where s2.status <> 0 and s3.name in 
			 ('Abastecimento','Abate_Comis','Abertura','AbrevPed','AcreNota','Agencias','Ajudantes','Ajuste_Contribuicao_Cofins','Ajuste_Contribuicao_Pis','Ajuste_Credito_Cofins','Ajuste_Credito_Pis','Apropria','Apropria_Antecipadas','Apropria_Cliente','Apropria_CP','Apuracao','Apuracao_Contribuicao_Cofins','Apuracao_Contribuicao_Pis','Apuracao_Credito_Cofins','Apuracao_Credito_Pis','Apuracao_Pis_Cofins','ApuracaoEstadual','Avaliacao_Dados','Avaliacao_Frota','Baixa_CL','Baixa_CP','Baixa_CP2','Baixa_Dpl','Baixa_LivCai','Baixa_Sobf','BaixaProposta','Balanco_Dados','Balanco_Desp','Balanco_Desp_Orc','Balanco_DespInc','Balanco_DespItens','Balanco_Efetuar','Balanco_EfetuarCont','Balanco_Estoque','Balanco_Inad','Balanco_InadBI','Bancos','Boleto','C_Corrente','C_Transp_N','Cadcontajudante','CadContFrete','CadContFrete_Mapa','Cadcontmotorista','CadcontObsPadrao','Cadcontpropvei','Caixa_Dados','Calendario','calendario_bancario','Canais','CapCargas','Cargos','Carteiras','Categoria','CfgNFe','CFOPXImpostosVendas','ChequesTransf','CidadeEntrega','Clientes','CliXFat','ClixPosto','clixvend','Combustivel','Comissao','Comodatos','ComodatosHistorico','Config','CONFIG_CNAB','ContratoAS_DADOSNF','ContratoAS_DescontoAS','ContratoAS_GrpClientes','ContratoAS_GrpClientesDesc','Contratos','ContRequisicao','Contribuicao_Pis_Cofins','controle_creditos_cofins','controle_creditos_pis','CP_ClienteXNivel','Creditos_Decorrentes','Cupom','DadosAdicionaisNF','Demais_Docto_PIS_COFINS','Descarga','Despesas','Destinos','Detalhe_Apuracao_Cofins','Detalhe_Apuracao_Pis','Detalhe_Contribuicao_Cofins','Detalhe_Contribuicao_Pis','Duplicata','Duplicata_Mov_fatura','DuplicataHistorico','Efetuar','Embalagens','empresa_consolida','Empresas','Empresas_Historico','Encerra','Entra_Estoque','Entregas','Entregas_Itens','Equipe_Venda','Espelho_estoque','Est_Posto','Est_Posto_Itens','EstadoComodato','Estoque_Fiscal','Estoque_Pecas','EstoqueDiario','EstoqueDiarioFecha','ExportaCheques','Fab_veiculos','Faturas','Fec_Bancaria','Fec_Caixa','Fec_Despesas','Fec_Estoque','Fec_Impostos','Fec_Metas','Fec_Pedido','Fec_Provisoes','Fec_Receita_Transporte','Fecha_Estoque','FechaBalancete','Fechadia_Estoque','Form_PagtoClientes','Form_PagtoClientes_Analise','Form_PagtoClientes_Logins','Form_PrecoClientes','Forma_Pagto','Fornecedores','Fretes','Frota_Custo_Mapa','Frota_Custo_Motorista','Frota_DestinoPerfilCarga','Frota_Entrada_Peca','Frota_Estoque','Frota_Grupo_Peca','Frota_Peca','Frota_Peca_Veiculo','Frota_PerfilCarga','Funcionarios','Gerencial_Impostos','GP_Produtos','Grupo_canais','Grupo_Imob','Grupo_Mod3','Grupo_Pecas','GrupoBonificacao','GrupoBonificacaoXProduto','HistBloc','HistDescarga','HistItensPedido','Historico_Clientes','Historico_Embalagens','Historico_Fornecedores','Historico_Insumos','Historico_Participante','Historico_Produtos','Historico_Vasilhames','HistPedido','Imob_Item','Importa_RHxCP','Importacao','ImportaCheque','imposto_cp','Informacao_Complementar','InformacaoAdicionalAjusteAP','Insumos','Investimentos','Itens_Comodatos','Itens_Despesas','Itens_do_Objetivo','Itens_Estoque_Pecas','Itens_Fretes','Itens_Grupo_Mod3','Itens_Mapa','Itens_Montagem','Itens_Objetivo','Itens_Objetivo_Clientes','Itens_Preventiva','Itens_Tabela','Itens_Tabela_Temp','Itens_Tip_Veiculos','LancInfoDeclaratoria','LanCont','LiberaRota','Livro_caixa_fat','LivroCaixa','LoteChequesImp','Mapas','Maquina_ECF','Marca_Invest','Marcas','Marcas_Cliente','Marcas_Pneus','MetaLitro','MetaReceb','Metas_Inad','Metas_Vendas','Mod_Veiculos','Moedas_Diario','Moedas_DiarioGTV','Montagem','Mot_saida','Motorista','Mov_Bancaria','Mov_Estoque','Mov_Estoque_Manutencao','Mov_Estoque2','Mov_Faturas','Mov_Trafego','Movim_Livro','Movim_Produtos','Nivel','Notas_Diversas','NovaSenha','NovaSenhaInstrucao','Objetivo','Objetivo_Clientes','ObrigacaoICMS','Observacao_Fiscal','Parametros','Parametros_cnab','Pastas','PDF_Caixa_Atrasado','PDF_Caixa_Email','PDF_Caixa_Reaberto','PDF_CP','Pecas','Pedido','PedidoBloqueadoJustificativa','PedidoExtensao','Pis_Cofins','Pis_Cofins_Historico','Plan_Despesas','Plan_DespesasItens','Plan_MovFinan','Plan_Vendas','Pneus','Portaria','Posicoes','Preventiva','Processo_referenciado_PIS','Produto_ClientexNivel','Produto_NatRec','Produto_Tipo_BcCred','Produtos','Produtos_Acessorias','Proposta','Proposta_Encerradas','Proposta_Investimentos','Proposta_Investimentos_Itens','Proposta_Log','Proposta_Log_Ressarc','Proposta_Metas','Proposta_Produtos','Proposta_Produtos_Itens','Proposta_Ressarc','Proposta_Status','Proposta_Tipos','Proposta_Tipos_Grupos','Proposta_Verbas','Proprietario_Cliente','Quilometragens','Regiao','Reparos','Replicacao_Conferencia','Requisicao','RN_Itens_Mapas_Excluidos','RN_Mapas_Excluidos','RN_Mapas_Roteirizados','Sabor','Saldo_Banco','Saldo_Caixa','saldo_estoque','SaldosCont','SeqVeiculos','SobraFalta','SobraFalta_fat','Subordinacao','Tabela_IPI','Tabela_Manutencao','Tabela_Preco','Tabela_Preco_Retorno','Tabela_Preco_Retorno_Itens','Tabela_Preco_Temp','Tanques','Termo_Comodato','Tip_veiculos','Tipo','Tipo_Controle','TipoAuxiliar','Tipos_Manutencao','TiposBloqueios','Trafego','Transacao','TransacaoXProduto','Transportadora','Unidade_Medida','Valor_EmbVas','VasEmb_Remessa','Vasilhames','Veiculos','VendaBonificacao','Vendedores','Vida_Util','Itens_pedido','FEC_DEPRECIACAO','Ocorrencias_Revendas','Ocorrencias_Acu_Revendas','Itens_Nota_Fiscal_Cpl','Nota_Fiscal','Itens_Nota_Fiscal','Nota_Fiscal_CPL','RessarcimentoIcmST','Nota_Fiscal_Exp','Contrato_Parceria','Contrato_Parceria_Itens','Notas_Fiscais_JustiTrans','Nat_Transacao','SERASA_CONSULTAS','SERASA_STATUSCLIENTE')
			  
        order by s3.name, s1.colid   
  
           
open reg  
fetch next from reg into @tb,@col  
set @tbant = @tb  
while @@fetch_status = 0  
 begin  
  if @tbant <> @tb  
   begin  
    set @cmd = ''  
    set @tbant = @tb  
   end  
     
  set @cmd = @cmd + 'a.' + @col + ' = b.' + @col+ ''+' AND '  
  
  insert into @tbsys select @tb,@cmd  
  
  fetch next from reg into @tb,@col  
  
 end  
  
close reg  
deallocate reg  
	
select
'insert into [172.17.6.153\CON].[DC].dbo.'+tabela+'
select * from [172.17.6.153\CON].[DC].dbo.'+tabela+' a where not exists (select * from dbo.'+tabela+' b   
where '+substring (max(cmdcampos),1,len(max(cmdcampos))-3)+') And A.Codemp = ''368'''   
from @tbsys group by tabela order by tabela