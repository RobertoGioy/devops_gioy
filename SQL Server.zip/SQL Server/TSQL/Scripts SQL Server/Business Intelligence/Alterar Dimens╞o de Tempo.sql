
Select 'Select * From ' +Rtrim(name) From SysObjects Where Xtype = 'U' And Name Like '%Tempo%'
GO
USE DW
GO
Insert Into dim_tempo_dre(Data, Mes, Ano)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2012','2013')) Data, Mes, 2013 Ano
From dim_tempo_dre Where Ano = 2012
GO

Insert Into dim_tempo_geral(Mes, Ano)
Select Mes, 2013 Ano
From dim_tempo_geral Where Ano = 2011
GO

Insert Into dim_tempo(Data, Dia, Mes, Ano, Diasemana)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Dia, Mes, 2013 Ano, Diasemana
From dim_tempo Where Ano = 2011

Update dim_tempo Set Diasemana = 'A' Where Ano = 2013 And DiaSemana = 'S�BADO '
GO

Update dim_tempo Set Diasemana = 'A' Where Ano = 2013 And DiaSemana = 'S�BADO '
GO

Update dim_tempo Set Diasemana = 'S�BADO' Where Ano = 2013 And DiaSemana = 'QUARTA'
GO
Update dim_tempo Set Diasemana = 'QUARTA' Where Ano = 2013 And DiaSemana = 'DOMINGO'
GO
Update dim_tempo Set Diasemana = 'DOMINGO' Where Ano = 2013 And DiaSemana = 'QUINTA'
GO
Update dim_tempo Set Diasemana = 'QUINTA' Where Ano = 2013 And DiaSemana = 'SEGUNDA'
GO
Update dim_tempo Set Diasemana = 'SEGUNDA' Where Ano = 2013 And DiaSemana = 'SEXTA'
GO
Update dim_tempo Set Diasemana = 'SEXTA' Where Ano = 2013 And DiaSemana = 'TER�A'
GO
Update dim_tempo Set Diasemana = 'TER�A' Where Ano = 2013 And DiaSemana = 'A'

GO
USE DW_C
GO
Insert Into Tempo_MesAno_FimMes(Data, Mes, Ano)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Mes, 2013 Ano
From Tempo_MesAno_FimMes Where Ano = 2011

GO

Insert Into QuatroColunas_TempoSaldoFinal(Data, Mes, Ano, Dia)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Mes, 2013 Ano, Dia
From QuatroColunas_TempoSaldoFinal Where Ano = 2011
GO

Insert Into QuatroColunas_Mensal_TempoSaldoFinal(Data, Mes, Ano)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Mes, 2013 Ano
From QuatroColunas_Mensal_TempoSaldoFinal Where Ano = 2011
GO

Insert Into Tempo(Data, Mes, Ano, Dia)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Mes, 2013 Ano, Dia
From Tempo Where Ano = 2011
GO

Insert Into Tempo_MesAno(Data, Mes, Ano)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Mes, 2013 Ano
From Tempo_MesAno Where Ano = 2011


GO
USE DW_R
GO

Insert Into QuatroColunas_TempoSaldoFinal(Data, Mes, Ano, Dia)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Mes, 2013 Ano, Dia
From QuatroColunas_TempoSaldoFinal Where Ano = 2011
GO


Insert Into Tempo_ConfFis_RevXCentral(Data, Mes, Ano, Dia)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Mes, 2013 Ano, Dia
From Tempo_ConfFis_RevXCentral Where Ano = 2011
GO


Insert Into Tempo20(Data, Mes, Ano, Dia, SemAno, SemMes)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Mes, 2013 Ano, Dia, SemAno, SemMes
From Tempo20 Where Ano = 2011
GO


Insert Into Tempo_MesAno(Data, Mes, Ano)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Mes, 2013 Ano
From Tempo_MesAno Where Ano = 2011


GO


Insert Into Tempo_MesAno_Vencimento(Data, Mes, Ano)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Mes, 2013 Ano
From Tempo_MesAno_Vencimento Where Ano = 2011
GO


Insert Into Tempo(Mes, Ano, Dia, SemAno, SemMes)
Select Mes, 2013 Ano, Dia, SemAno, SemMes
From Tempo Where Ano = 2011
GO

USE DW_CONTABIL
GO



Insert Into dim_tempo_mensal(Data, Mes, Ano)
Select Convert(Datetime,Replace(convert(Varchar(10),Data,121),'2011','2013')) Data, Mes, 2013 Ano
From dim_tempo_mensal Where Ano = 2011
