--00:00:18
SELECT ID,DESTIP,CODOPE,CLIFOR,CODTIP,CODTRI,DESPRO,NUMNOT,TIPOPECOF,TIPOPE,TIPOPEIPI,TIPOPEPIS,TIPOPEST,TIPNOT,TIPOBS,DATA
INTO #FATO_ERRO_NOTAS 
FROM FATO_ERRO_NOTAS WHERE DATA BETWEEN '2013-02-01' AND '2013-03-31'


--00:00:00
IF EXISTS (
		SELECT *
		FROM sys.indexes
		WHERE object_id = OBJECT_ID(N'[dbo].[Dim_Erro_Notas_Numnot]')
			AND NAME = N'NonClusteredColumnStoreIndex_Dim_Erro_Notas_Numnot'
		)
	DROP INDEX [NonClusteredColumnStoreIndex_Dim_Erro_Notas_Numnot] ON [Dim_Erro_Notas_Numnot]


IF EXISTS (
		SELECT *
		FROM sys.indexes
		WHERE object_id = OBJECT_ID(N'[dbo].[#fato_erro_notas]')
			AND NAME = N'NonClusteredColumnStoreIndex_#fato_erro_notas'
		)
	DROP INDEX [NonClusteredColumnStoreIndex_#fato_erro_notas] ON [#fato_erro_notas]



--00:00:07
CREATE NONCLUSTERED COLUMNSTORE INDEX [NonClusteredColumnStoreIndex_#fato_erro_notas] ON [dbo].[#FATO_ERRO_NOTAS]
(
	Id,Destip,Codope,Clifor,Codtip,Codtri,Despro,Numnot,Tipopecof,Tipope,Tipopeipi,Tipopepis,Tipopest,Tipnot,Tipobs,Data
)WITH (DROP_EXISTING = OFF)


--00:03:07
MERGE 
   Dim_Erro_Notas_Numnot AS Destino
USING 
   #FATO_ERRO_NOTAS AS Origem
ON 
       Destino.Id = Origem.Id
WHEN MATCHED THEN 
			UPDATE SET
			  Destino.[Categoria Produto] = Origem.Destip
			, Destino.[CFOP] = Origem.Codope
			, Destino.[Cliente ou Forncedor] = Origem.Clifor
			, Destino.[Codigo Tipo Produto] = Origem.Codtip
			, Destino.[CST] = Origem.Codtri
			, Destino.[Descricao Produto] = Origem.Despro
			, Destino.[Numero Nota Fiscal] = Origem.Numnot
			, Destino.[Oper COFINS] = Origem.Tipopecof
			, Destino.[Oper ICMS] = Origem.Tipope
			, Destino.[Oper IPI] = Origem.Tipopeipi
			, Destino.[Oper PIS] = Origem.Tipopepis
			, Destino.[Oper ST] = Origem.Tipopest
			, Destino.[Tipo da Nota] = Origem.Tipnot
			, Destino.[Tipo Observacao] = Origem.Tipobs
			, Destino.[Data] = Origem.Data
WHEN NOT MATCHED THEN 
   INSERT ([Id],[Categoria Produto],[CFOP],[Cliente ou Forncedor],[Codigo Tipo Produto],[CST],[Descricao Produto],[Numero Nota Fiscal],[Oper COFINS],[Oper ICMS],[Oper IPI],[Oper PIS],[Oper ST],[Tipo da Nota],[Tipo Observacao],[Data]) 
   VALUES (Id,Destip,Codope,Clifor,Codtip,Codtri,Despro,Numnot,Tipopecof,Tipope,Tipopeipi,Tipopepis,Tipopest,Tipnot,Tipobs,Data);


--00:01:18
CREATE NONCLUSTERED COLUMNSTORE INDEX [NonClusteredColumnStoreIndex_Dim_Erro_Notas_Numnot] ON [dbo].[Dim_Erro_Notas_Numnot]
(
	[Id],[Categoria Produto],[CFOP],[Cliente ou Forncedor],[Codigo Tipo Produto],[CST],[Descricao Produto],[Numero Nota Fiscal],[Oper COFINS],[Oper ICMS],[Oper IPI],[Oper PIS],[Oper ST],[Tipo da Nota],[Tipo Observacao],[Data]
)WITH (DROP_EXISTING = OFF)
