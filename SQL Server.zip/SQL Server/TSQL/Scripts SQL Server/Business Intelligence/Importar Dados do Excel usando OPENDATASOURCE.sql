/**********************************************************************************************************************************************************/
--INSERE TABELA IMOB_GRUPO_
Go
Set Identity_Insert Imob_Grupo_ On
Go
Insert Into IMOB_GRUPO_(Grupo_id,Grupo_Codemp, Grupo_Codigo, Grupo_Descr, Grupo_PercDepr, Grupo_Os, Grupo_Deprecia, Grupo_Dtinc, Natbccred_Codigo, Pridentbem_Codigo)
SELECT ROW_NUMBER() Over(Partition by codempresa order by codempresa) As Id,CodEmpresa, CodGrupo, Descri��o, Deprecia��o, OS, Deprecia, DataCadastro, CodBCCredito, CodIdentBem 
         FROM OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0',
           'Data Source=C:\Dados - 128BTV - completo para importa��o.xlsx;Extended Properties=Excel 8.0')...[Grupo$]
				  WHERE CodEmpresa = '128'
Go
Set Identity_Insert Imob_Grupo_ Off
Go
Select * From Imob_Grupo_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_PRAQ_
Go
Set Identity_Insert IMOB_PRAQ_ On
Go
Insert Into IMOB_PRAQ_(praq_id, grupo_id, praq_codemp, praq_ctadebimob, praq_ctacredimob, praq_ctacreddepr, praq_ctaicmscprazo, praq_ctaicmslprazo, praq_ctapiscprazo, praq_ctapislprazo, praq_ctacofinscprazo, praq_ctacofinslprazo)
SELECT ROW_NUMBER() Over(Partition by codempresa order by codempresa) As Praq_Id,
       ROW_NUMBER() Over(Partition by codempresa order by codempresa) As Grupo_Id,
	     	CodEmpresa, A_DebImob, A_CredImob, A_CredDeprec, A_IcmsCPrazo, A_IcmsLPrazo, A_PisCPrazo, A_PisLPrazo, A_CofCPrazo, A_CofLPrazo
			 FROM OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0',
			   'Data Source=C:\Dados - 128BTV - completo para importa��o.xlsx;Extended Properties=Excel 8.0')...[Grupo$]
				  WHERE CodEmpresa = '128'
Go
Set Identity_Insert IMOB_PRAQ_ Off
Go
Select * From IMOB_PRAQ_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_PRBX_
Go
Set Identity_Insert IMOB_PRBX_ On
Go
Insert Into IMOB_PRBX_(prbx_id, grupo_id, prbx_codemp, prbx_ctacredimob, prbx_ctadebcusto, prbx_ctadebdepr, prbx_ctacredicmscprazo, prbx_ctacredicmslprazo, prbx_ctacredpiscprazo, prbx_ctacredpislprazo, prbx_ctacredcofinscprazo, prbx_ctacredcofinslprazo)
SELECT ROW_NUMBER() Over(Partition by codempresa order by codempresa) As Prbx_Id,
       ROW_NUMBER() Over(Partition by codempresa order by codempresa) As Grupo_Id,
	     	Codempresa, B_CredImob, B_DebCCusto, B_DebDepr, B_CredIcmsCPrazo, B_CredIcmsLPrazo, B_CredPisCPrazo, B_CredPisLPrazo, B_CredCodCPrazo, B_CredCodLPrazo
			 FROM OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0',
			   'Data Source=C:\Dados - 128BTV - completo para importa��o.xlsx;Extended Properties=Excel 8.0')...[Grupo$]
				  WHERE CodEmpresa = '128'
Go
Set Identity_Insert IMOB_PRBX_ Off
Go
Select * From IMOB_PRBX_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_PRTR_
Go
Set Identity_Insert IMOB_PRTR_ On
Go
Insert Into IMOB_PRTR_(prtr_id, grupo_id, prtr_codemp, prtr_ctacredimob, prtr_ctadebtransf, prtr_ctadebdepr, prtr_ctacredicmscprazo, prtr_ctacredicmslprazo, prtr_ctacredpiscprazo, prtr_ctacredpislprazo, prtr_ctacredcofinscprazo, prtr_ctacredcofinslprazo)
SELECT ROW_NUMBER() Over(Partition by codempresa order by codempresa) As Prtr_Id,
       ROW_NUMBER() Over(Partition by codempresa order by codempresa) As Grupo_Id,
	     	Codempresa, T_CredImob, T_DebTransf, T_DebDepr, T_CredIcmsCPrazo, T_CredIcmsLPrazo, T_CredPisCPrazo, T_CredPisLPrazo, T_CredCodCPrazo, T_CredCodLPrazo
			 FROM OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0',
			   'Data Source=C:\Dados - 128BTV - completo para importa��o.xlsx;Extended Properties=Excel 8.0')...[Grupo$]
				  WHERE CodEmpresa = '128'
Go
Set Identity_Insert IMOB_PRTR_ Off
Go
Select * From IMOB_PRTR_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_LOCAL_
Go
Set Identity_Insert IMOB_LOCAL_ On
Go
Insert Into IMOB_LOCAL_(local_id, local_codemp, local_codigo, local_descr, local_ctadebdepr, local_dtinc)
SELECT ROW_NUMBER() Over(Partition by codempresa order by codempresa) As Local_Id,
	     CodEmpresa, CodLocal, Descri��o, ContaDebDepr, DataCadastro
			 FROM OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0',
			   'Data Source=C:\Dados - 128BTV - completo para importa��o.xlsx;Extended Properties=Excel 8.0')...[Local$]
				  WHERE CodEmpresa = '128'
Go
Set Identity_Insert IMOB_LOCAL_ Off
Go
Select * From IMOB_LOCAL_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_CCUSTO_
Go
Set Identity_Insert IMOB_CCUSTO_ On
Go
Insert Into IMOB_CCUSTO_(ccusto_id, ccusto_codemp, ccusto_codigo, ccusto_descr, ccusto_dtinc)
SELECT ROW_NUMBER() Over(Partition by codempresa order by codempresa) As Ccusto_Id,
	     CodEmpresa, CodCCusto, Descri��o, DataCadastro
			 FROM OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0',
			   'Data Source=C:\Dados - 128BTV - completo para importa��o.xlsx;Extended Properties=Excel 8.0')...[Ccusto$]
				  WHERE CodEmpresa = '128'
Go
Set Identity_Insert IMOB_CCUSTO_ Off
Go
Select * From IMOB_CCUSTO_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_ITEM_
Go
Set Identity_Insert IMOB_ITEM_ On
go
Alter Table IMOB_ITEM_ NoCheck Constraint All
Go
Insert Into IMOB_ITEM_(item_id, item_codemp, item_codigo, grupo_id, ccusto_id, local_id, descrbem_id, descrsuc_id, item_dtaaqu, item_modal, item_creicm, item_crepis, item_crecof, item_valdutil, item_valcicmutil, item_nparicmrem, item_valcpisutil, item_nparpisrem, item_valccofutil, item_nparcofrem, item_tipomerc, item_vinculo, item_tipmovbem, item_valbru, item_txdepr, item_tiplan, item_codfor, item_indemit, item_dtemi, item_sernot, item_numnot, item_numseq, item_codpro, item_qtde, item_status, item_aliqicms, item_percrbc, item_valicm, item_valicmsT, item_valicmfrete, item_valdifaliq, item_valparicm, item_dtaapr, item_nparcicm, item_dtsuspciap, item_qtdparaprant, item_dtrevsusp, item_qtdparaprrev, item_obser, item_valmobra, item_valprest, item_placa, item_imagem, item_dtaprpis, item_valbaspis, item_percpis, item_valpis, item_qtdparpis, item_valparpis, item_dtsusppis, item_qtdparaprantpis, item_dtrevsusppis, item_qtdparaprrevpis, item_dtaprcof, item_valbascof, item_perccof, item_valcof, item_qtdparcof, item_valparcof, item_dtsuspcof, item_qtdparaprantcof, item_dtrevsuspcof, item_qtdparaprrevcof, item_doc, item_dtencerramento, item_numos, item_dtfabricacao, item_dtbaixa, origembem_codigopis, usobem_codigopis, stpis_codigo, origembem_codigocof, usobem_codigocof, stcof_codigo, item_deprecaceleracao, item_valfrete)
SELECT ROW_NUMBER() Over(Partition by codempresa order by codempresa) As Item_Id,
	     CodEmpresa, Codigo, CodGrupo, CodCCusto, CodLocal, CodDescri��o, CodDescSucinta, DataAquisi��o, CodModalidade, Cr�ditoDeICMS, Cr�ditoDePIS, Cr�ditoDeCofins, DeprecJaUsada, CredICMSJaUsado, ParcICMSRemanescente, CredPISJaUsado, ParcPISRemanescente, CredCofJaUsado, ParcCofRemanescente, TipoMercadoria, Vinculo, TipoMovBem, Valor, Deprec, TipoLan�amento, CodFornecedor, IndEmitente, 
	       DataEmiss�o, 
	       S�rie, NumNota, NumSequencia, CodProduto, Quantidade, Status, AliqICMS, RBC, Icms, IcmsST, IcmsFrete, ICmsDifAliq, ValorParcela, 
	       DataAproveitamento, 
	       NumParcelasIcms, 
	       Case When DataSuspens�oCIAPIcms='' Then NULL Else DataSuspens�oCIAPIcms End, QtdParcAprovAnt, 
	       Case When DataRevers�oIcms='' Then NULL Else DataRevers�oIcms End, 
	       QtdParcAprovPos, Observa��o, ValorM�oDeObra, ValorPrestServi�o, Placa, Imagem, 
	       Case When DataAprovPIS='' Then NULL Else DataAprovPIS End, 
	       BasePis, PercPIS, ValPIS, QtdParcPIS, ValParcPIS, 
	       Case When DataSuspens�oPIS='' Then NULL Else DataSuspens�oPIS End, 
	       QtdParcAprovAntPIS, 
	       Case When DataRevers�oPIS='' Then NULL Else DataRevers�oPIS End, 
	       QtdParcAprovPosPIS, 
	       Case When DataAprovCofins='' Then NULL Else DataAprovCofins End, 
	       BaseCofins, PercCofins, ValCofins, QtdParcCofins, valrParcCofins, 
	       Case When DataSuspens�oCofins='' Then NULL Else DataSuspens�oCofins End, 
	       QtdParcAprovAntCofins, 
	       Case When DataRevers�oCofins='' Then NULL Else DataRevers�oCofins End, 
	       QtdParcAprovPosCofins, ImagemDocumento, 
	       Case When DataEncerramentoOS='' Then NULL Else DataEncerramentoOS End, 
	       NumOS, 
	       Case When DataFabrica��o='' Then NULL Else DataFabrica��o End, 
	       Case When DataBaixa='' Then NULL Else DataBaixa End, 
	       C�dOrigemBemPIS, C�dUsoBemPIS, CodSubstitui��oTribut�riaPIS, C�dOrigemBemCOFINS, C�dUsoBemCOFINS, CodSubstitui��oTribut�riaCOFINS, QtdTurnosDeUso, ValorFrete
			 FROM OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0',
			   'Data Source=C:\Dados - 128BTV - completo para importa��o.xlsx;Extended Properties=Excel 8.0')...[Bens$]
				  WHERE CodEmpresa = '128'
Go
Set Identity_Insert IMOB_ITEM_ Off
Go
Alter Table IMOB_ITEM_ Check Constraint All
Go
Select * From IMOB_ITEM_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_DESCRBEM_
Go
Set Identity_Insert IMOB_DESCRBEM_ On
go
Alter Table IMOB_DESCRBEM_ NoCheck Constraint All
Go
Insert Into IMOB_DESCRBEM_(descrbem_id, descrbem_codemp, descrbem_codigo, descrbem_descr, descrbem_dtinc, descrbem_codcat, descrbem_codoriginal, descrbem_tipo)
SELECT ROW_NUMBER() Over(Partition by codempresa order by codempresa) As Descrbem_id,
	     CodEmpresa, CodImobilizado, Descri��o, DataCadastro, CodCategoria, CodOriginal, Tipo
			 FROM OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0',
			   'Data Source=C:\Dados - 128BTV - completo para importa��o.xlsx;Extended Properties=Excel 8.0')...[Imobilizado$]
				  WHERE CodEmpresa = '128'
Go
Set Identity_Insert IMOB_DESCRBEM_ Off
Go
Alter Table IMOB_DESCRBEM_ Check Constraint All
Go
Select * From IMOB_DESCRBEM_


/**********************************************************************************************************************************************************/


--INSERE TABELA IMOB_DESCRSUC_
Go
Set Identity_Insert IMOB_DESCRSUC_ On
go
Alter Table IMOB_DESCRSUC_ NoCheck Constraint All
Go
Insert Into IMOB_DESCRSUC_(descrsuc_id, descrsuc_codemp, descrsuc_codigo, descrsuc_descr, descrsuc_dtinc)
SELECT ROW_NUMBER() Over(Partition by CodEmpresa order by CodEmpresa) As Descrsuc_id,
	     CodEmpresa, CodDescri��o, Descri��o, DataCadastro
			 FROM OPENDATASOURCE('Microsoft.ACE.OLEDB.12.0',
			   'Data Source=C:\Dados - 128BTV - completo para importa��o.xlsx;Extended Properties=Excel 8.0')...[Descri��oSucinta$]
				  WHERE CodEmpresa = '128'
Go
Set Identity_Insert IMOB_DESCRSUC_ Off
Go
Alter Table IMOB_DESCRSUC_ Check Constraint All
Go
Select * From IMOB_DESCRSUC_
