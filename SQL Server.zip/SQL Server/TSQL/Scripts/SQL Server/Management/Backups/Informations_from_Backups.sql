
/*
	Author:			Beto
	Description:	Query information from backups
	Objects:		msdb.dbo.backupset, msdb.dbo.backupmediafamily
*/

SELECT 
	s.database_name AS dbname,
	m.physical_device_name AS physical_name,
	CONVERT(NUMERIC(10,2), s.backup_size / 1048576) AS backup_size_mb,
	CONVERT(NUMERIC(10,2), s.compressed_backup_size / 1048576) AS compressed_backup_size_mb,
	CONVERT(NUMERIC(10,2), 100 - ((s.compressed_backup_size / 1048576 * 100) / (s.backup_size / 1048576))) AS compressed_percentual,
	s.backup_start_date,
	s.backup_finish_date,
	CAST(s.first_lsn AS VARCHAR(50)) AS first_lsn,
	CAST(s.last_lsn AS VARCHAR(50)) AS last_lsn,
	CASE s.[type]
		WHEN 'D' THEN 'Full'
		WHEN 'I' THEN 'Differential'
		WHEN 'L' THEN 'Transaction Log'
	END AS BackupType,
	s.server_name,
	s.recovery_model
FROM 
	msdb.dbo.backupset s
	INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id
--WHERE 
--	s.database_name = DB_NAME() -- Remove this line for all the database
ORDER BY 
	backup_start_date DESC, 
	backup_finish_date
GO