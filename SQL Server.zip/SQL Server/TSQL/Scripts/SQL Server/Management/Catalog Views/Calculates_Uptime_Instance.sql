
/*
	Author:			Beto
	Description:	Calculates uptime of SQL instance
	Objects:		sys.sysdatabases
*/

USE [master]
GO

DECLARE @start_time DATETIME, @current_time DATETIME

SET @start_time = (SELECT crdate FROM sys.sysdatabases WHERE name = 'tempdb' )
SET @current_time = GETDATE()

DECLARE @dif_DD INT, @dif_HH INT, @dif_MI INT

SET @dif_MI = (SELECT DATEDIFF(MINUTE, @start_time, @current_time))
SET @dif_DD = (@dif_MI / 60 / 24)
SET @dif_MI = @dif_MI - (@dif_DD * 60) * 24
SET @dif_HH = (@dif_MI / 60)
SET @dif_MI = @dif_MI - (@dif_HH * 60)

PRINT 
	'SERVICO DO SQL SERVER INICIADO A: ' + 
	CONVERT(VARCHAR, @dif_DD) + ' DIAS ' + 
	CONVERT(VARCHAR, @dif_HH) + ' HORAS ' + 
	CONVERT(VARCHAR, @dif_MI) + ' MINUTOS.' 
GO