
/*
	Author:			Beto
	Description:	Check what has changed in the database after 18 hours
	Objects:		sys.objects
*/

SELECT 
	name, 
	TYPE, 
	type_desc, 
	create_date, 
	modify_date 
FROM 
	sys.objects 
WHERE 
	TYPE IN ('U','V','PK','F','D','P') 
	AND modify_date >= DATEADD(HOUR,18,CAST((CAST(GETDATE() - 1 AS VARCHAR(12)))AS SMALLDATETIME)) 
ORDER BY 
	modify_date 