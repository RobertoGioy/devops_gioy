
/*
	Author:			Beto
	Description:	Identifies tables with or without Primary Key
	Objects:		sysobjects, sysusers, sysindexes
*/

-- without Primary Key
SELECT 
	u.name AS username, 
	o.name AS tablename
FROM 
	sysobjects o INNER JOIN sysusers u ON o.uid = u.uid
WHERE 
	o.xtype = 'U'
	
	AND NOT EXISTS (SELECT i.name FROM sysindexes i WHERE o.id = i.id AND (i.status & 2048)<>0)
GO

-- with Primary Key
SELECT 
	u.name AS username, 
	o.name AS tablename, 
	i.name AS pkname
FROM 
	sysobjects o 
	INNER JOIN sysindexes i ON o.id = i.id 
	INNER JOIN sysusers u ON o.uid = u.uid
WHERE 
	(i.status & 2048)<>0
	AND o.xtype = 'U' 
GO