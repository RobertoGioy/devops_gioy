
/*
	Author:			Beto
	Description:	Undocumented procedures
	Objects:		sys.xp_dirtree, dbo.xp_create_subdir, xp_fileexist, xp_subdirs
*/

-- Retorna todos os subdiretorios existentes dentro do diretorio passado como parametro.
EXECUTE master.sys.xp_dirtree 'C:\'
GO

-- Retorna todos os subdiretorios de nivel 1 existentes dentro do diretorio passado como parametro.
EXECUTE master..xp_subdirs 'C:\'
GO

-- Verifica se um arquivo ou diretorio existe
EXECUTE master..xp_fileexist 'C:\BackupHA\DB_COMPANY.bak'
GO

-- Usada para criar o diretorio no servidor local ou compartilhamento na rede.
EXEC master.dbo.xp_create_subdir 'C:\Beto'
GO

-- Retorna a lista de todos os providers OLEDB
EXEC master.sys.xp_enum_oledb_providers
GO

-- Retorna a lista de arquivos no Log de erro do SQL com a data da ultima modificacao
EXECUTE master.sys.xp_enumerrorlogs
GO

-- Retorna a lista dos grupos do Windows e suas descricoes
EXECUTE master.sys.xp_enumgroups
GO

-- Retorna a lista dos discos (unidades) e da quantidade de espaco livre (em MB) para cada um deles
EXECUTE master.sys.xp_fixeddrives
GO

-- Retorna o conteudo dos arquivos de log de erro do SQL
EXECUTE master.sys.xp_readerrorlog 1
GO