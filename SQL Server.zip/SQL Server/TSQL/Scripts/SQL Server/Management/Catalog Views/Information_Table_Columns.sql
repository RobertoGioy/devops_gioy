
/*
	Author:			Beto
	Description:	Information about table columns
	Objects:		sys.columns
*/

USE [DB_REPLICATION]
GO
SELECT
	name AS column_name,  
    TYPE_NAME(system_type_id) AS column_type, 
    max_length,
    collation_name,
    is_nullable
FROM 
	sys.columns sc
WHERE 
	sc.object_id = OBJECT_ID('[dbo].[TBU_CATEGORY]');