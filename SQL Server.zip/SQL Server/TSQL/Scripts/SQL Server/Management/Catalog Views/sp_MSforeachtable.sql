
/*
	Author:			Beto
	Description:	Actions in all tables of the database
	Objects:		sp_MSforeachtable
*/

USE [DB_REPLICATION]
GO

-- ADD COLUMN
EXEC sp_MSforeachtable 'ALTER TABLE ? Add data_da_criacao DATETIME DEFAULT  GETDATE();';
GO

EXEC sp_MSforeachtable 
@command1= '
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=PARSENAME("?",2) AND TABLE_NAME=PARSENAME("?",1) AND COLUMN_NAME="CATEGORY_ID")
BEGIN
    IF (SELECT COUNT(*) FROM ? WHERE CATEGORY_ID = 1) > 0
    BEGIN
        SELECT * FROM ? WHERE CATEGORY_ID = 1
    END
END'