
/*
	Author:			Beto
	Description:	Identifies user permissions
	Objects:		fn_my_permissions
*/

USE [DB_REPLICATION]
GO

-- PERMISSIONS IN DATABASE
EXECUTE AS LOGIN = 'jrgioy'  --<------- Digite aqui o nome do usuario !!
SELECT * FROM fn_my_permissions(NULL, 'DATABASE') ORDER BY subentity_name, permission_name; 
REVERT;
GO

-- PERMISSIONS IN SERVER
EXECUTE AS LOGIN = 'jrgioy'; --<------- Digite aqui o nome do usuario !!
SELECT * FROM fn_my_permissions(NULL, 'SERVER'); 
GO

-- PERMISSIONS IN OBJECTS
SELECT * FROM fn_my_permissions('[dbo].[TBU_CATEGORY]', 'OBJECT') 
ORDER BY subentity_name, permission_name; 
GO