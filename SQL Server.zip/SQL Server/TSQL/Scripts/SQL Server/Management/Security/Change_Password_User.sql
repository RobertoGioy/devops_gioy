
/*
	Author:			Beto
	Description:	Last change password of users
	Procedure:		sys.sql_logins
*/

USE [master]
GO
SELECT	
	[name], [sid], [create_date], [modify_date], [password_hash], [is_disabled]
FROM	
	sys.sql_logins
WHERE	
	[name] = 'sa'
GO

-- Changes user password
EXECUTE sp_password @old = null, @new = '123456', @loginame = 'sa'
GO

