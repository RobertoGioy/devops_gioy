Declare @option Varchar (128);

Set @option = 'db_status';

If @option = 'traceflag'
Begin
	Set Nocount On;

	-- DBCC TRACESTATUS (-1)
	-- DBCC TRACEON (1204, 1222, 3226, 3605, 3042, -1)
	-- DBCC TRACESTATUS (-1)

	Create Table #dba_traceflag (
		[checklist] Varchar (20) Default 'traceflag'
	  ,	[server]	Sysname Default Convert (Sysname, ServerProperty ('ComputerNamePhysicalNetBios'))
	  , [instance]	Sysname Default @@ServerName
	  ,	[traceflag] Int
	  , [status]	Int
	  , [global]	Int
	  , [session]	Int
	  , [message]	Varchar (20) Default 'Habilitado'
	  , [logdate]	Datetime Default Getdate ()
	);

	Insert Into #dba_traceflag ([traceflag], [status], [global], [session]) 
	Exec sp_executesql N'DBCC TRACESTATUS (-1)';

	Select	[checklist], [server], [instance], [traceflag], [status], [global], [session], [message], [logdate]
	From	#dba_traceflag;

	Drop Table #dba_traceflag;
End

If @option = 'protocolos'
Begin
	Set Nocount On;

	/*
	 *	-- Endpoint state
	 *	0 = STARTED, listening and processing requests
	 *	1 = STOPPED, listening, but not processing requests
	 *	2 = DISABLED, not listening
	 *
	 *  -- HowTo Started or Stopped endpoint
	 *	ALTER ENDPOINT [endpoint_name] STATE = {STOPPED | STARTED}
	 *
	 *	-- Other endpoints DMVs
	 *	sys.database_mirroring_endpoints
	 *	sys.tcp_endpoints
	 *	sys.http_endpoints
	 *	sys.via_endpoints
	 *	sys.service_broker_endpoints
	 *	sys.soap_endpoints
	 *	sys.endpoint_webmethods
	 */

	Select	
		'Protocolos Habilitados' As checklist 
		,	Convert (Sysname, ServerProperty ('ComputerNamePhysicalNetBios')) As [server]
		,	@@Servername As [instance]
		, [name]
		, [endpoint_id]
		, [protocol]
		, [protocol_desc]
		, [type]
		, [type_desc]
		, [state]
		, [state_desc]
		, [is_admin_endpoint]
	From	
		sys.endpoints;

	Select	
		@@Servername As [instance]
		, [auth_scheme]
		, [net_transport]
		, [protocol_version]
		, [endpoint_id]
		, [net_transport]
		, Count (session_id) As Conexoes
	From	
		sys.dm_exec_connections
	Group By 
		[auth_scheme]
	  , [net_transport]
	  , [protocol_version]
	  , [endpoint_id]
	  , [net_transport];
End

If @option = 'start_sql'
Begin
	Set Nocount On;

	Declare @start_sql Datetime, @porta_sql Int, @ip_sql Varchar (48);
	Declare @cluster_name Varchar (128);
	Declare @years Int, @days Int, @hours Int, @minutes Int, @seconds Int, @secdiff Int

	Select Top 1 @ip_sql = local_net_address, @porta_sql = local_tcp_port From sys.dm_exec_connections;

	If (Select ServerProperty ('IsHadrEnabled')) = 1
		Select	@start_sql = login_time 
		From	sys.dm_exec_sessions 
		Where	login_name = 'NT\AUTHORITY_SYSTEM' And program_name = 'Microsoft� Windows� Operation System' And status = 'running';
	Else
		Select	@start_sql = login_time 
		From	sys.dm_exec_sessions
		Where	session_id = 1;

	Create Table #cluster_name (cluster_name Varchar (128));

	If (Select ServerProperty ('IsClustered')) = 1 Or (Select ServerProperty ('IsHadrEnabled')) = 1
	Begin
		Insert Into #cluster_name
		Exec master.dbo.xp_cmdshell 'powershell.exe "get-wmiobject -class ''"MSCluster_Cluster"'' -namespace ''"root\mscluster"'' | select -ExpandProperty name"';

		Delete #cluster_name Where cluster_name Is Null;

		Set @cluster_name = (Select Top 1 Upper (cluster_name) from #cluster_name);
	End
	Else
		Set @cluster_name = 'Standalone'

	Select	@secdiff = Datediff (Second, @start_sql, Getdate ())
		  , @years = @secdiff / 31536000
		  , @secdiff = @secdiff % 31536000
		  , @days = @secdiff / 86400
		  , @secdiff = @secdiff % 86400
		  , @hours = @secdiff / 3600
		  , @secdiff = @secdiff % 3600
		  , @minutes = @secdiff / 60
		  , @seconds = @secdiff % 60
	
	Select
		'start sql' As checklist
	  , @cluster_name As cluster
	  , Convert (Sysname, ServerProperty ('ComputerNamePhysicalNetBios')) As [server]
	  , @@Servername As [instance]
	  , @ip_sql As [IP SQL]			-- ConnectionProperty ('local_net_address')
	  , @porta_sql As [TCP Port]	-- ConnectionProperty ('local_tcp_port')
	  , @start_sql As [SQL Started]
	  , Rtrim (Convert (Char, @years)) + ' Anos, ' + Rtrim (Convert (Char, @days)) + ' Dias, ' + Rtrim (Convert (Char, @hours)) + ' Horas, ' + Rtrim (Convert (Char, @minutes)) + ' Minutos, ' + Rtrim (Convert (Char, @seconds)) + ' Segundos' As [upTime]
	  , ServerProperty ('ProductVersion') As [SQL Version]
	  , ServerProperty ('Edition') As Edition
	  , Case ServerProperty ('IsClustered') When 0 Then 'No' When 1 Then 'Yes' End As IsClustered
	  , Case ServerProperty ('IsHadrEnabled') When 0 Then 'No' When 1 Then 'Yes' End As IsAlwaysOn
	  , ServerProperty ('ProductID') As productID
	  , ServerProperty ('SqlSortOrder') As [sql order]
	  , ServerProperty ('ResourceLastUpdateDateTime') As [last resource update]
	  , Getdate () As logdate;

	  Drop Table #cluster_name;
End

If @option = 'db_status'
Begin
	Set Nocount On;

	Select	'Status Databases' As checklist
		  , Convert (Sysname, ServerProperty ('ComputerNamePhysicalNetBios')) As [server]
		  , @@Servername As [instance]
		  , name As [DB_Name]
		  , database_id As [DB_ID]
		  , create_date As [Create Date]
		  , compatibility_level As [Compatibility]
		  , collation_name As [Collation]
		  , user_access_desc As [User Access]
		  , DATABASEPROPERTYEX (name, 'Updateability') As Updateability
		  , state_desc AS [Status]
		  , recovery_model_desc As [Recovery Model]
		  , snapshot_isolation_state_desc As [Snapshot Isolation]
		  , page_verify_option_desc As [Page Verify]
		  , log_reuse_wait_desc As [Log Reuse Wait]
		  , Case is_read_only When 0 Then 'Nao' Else 'Sim' End As [Read Only]
		  , Case is_auto_shrink_on When 0 Then 'Nao' Else 'Sim' End As [Auto Shrink]
		  , Case is_auto_create_stats_on When 0 Then 'Nao' Else 'Sim' End As [Auto Create Stats]
		  , Case is_auto_update_stats_on When 0 Then 'Nao' Else 'Sim' End As [Auto Update Stats]
		  , Case is_broker_enabled When 0 Then 'Nao' Else 'Sim' End As [Broker Enabled]
		  , Case is_cdc_enabled When 0 Then 'Nao' Else 'Sim' End As [CDC Enabled]
		  , Case is_fulltext_enabled When 0 Then 'Nao' Else 'Sim' End As [Fulltext Enabled]
		  , Case is_published When 0 Then 'Nao' Else 'Sim' End As [Published]
		  , Case is_subscribed When 0 Then 'Nao' Else 'Sim' End As [Subscribed]
		  , Case is_distributor When 0 Then 'Nao' Else 'Sim' End As [Distributor]
		  , Case is_encrypted When 0 Then 'Nao' Else 'Sim' End As [Encrypted]
	From	sys.databases
End