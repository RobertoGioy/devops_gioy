/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR OS DISCOS E MOUNT POINTS
 */

--<01>-- CONSULTAR TAMANHO DOS DISCOS FISICOS E PERCENTUAL LIVRE
USE [master]

DECLARE @hr INT, @fso INT, @drive CHAR (1), @odrive INT
DECLARE @totalSize VARCHAR (20)
DECLARE @MB BIGINT = 1048576;

CREATE TABLE #Drives (
	drive CHAR (1) PRIMARY KEY
,	freeSpace INT NULL
,	totalSize INT NULL
);
INSERT INTO #Drives (drive, freeSpace)
EXEC xp_fixeddrives

EXEC @hr = sp_OACreate 'Scripting.FileSystemObject', @fso OUT;
IF @hr <> 0 EXEC sp_OAGetErrorInfo @fso

DECLARE Drive_Cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT drive FROM #Drives ORDER BY drive

OPEN Drive_Cursor
FETCH NEXT FROM Drive_Cursor INTO @drive

WHILE @@FETCH_STATUS = 0
BEGIN
	EXEC @hr = sp_OAMethod @fso, 'GetDrive', @odrive OUT, @drive;
	IF @hr <> 0 EXEC sp_OAGetErrorInfo @fso;
	EXEC @hr = sp_OAGetProperty @odrive, 'TotalSize', @totalSize OUT;
	IF @hr <> 0 EXEC sp_OAGetErrorInfo @fso;

	UPDATE #Drives SET totalSize = @totalSize / @MB WHERE drive = @drive;

	FETCH NEXT FROM Drive_Cursor INTO @drive
END

CLOSE Drive_Cursor;
DEALLOCATE Drive_Cursor;

EXEC @hr = sp_OADestroy @fso;
IF @hr <> 0 EXEC sp_OAGetErrorInfo @fso;

SELECT * FROM #Drives;
DROP TABLE #Drives;
GO

--<02>-- CONSULTAR TAMANHO DOS DISCOS FISICOS E QUANTO O SQL SERVER OCUPA DE CADA DISCO.
USE [master]

CREATE TABLE #DBSpace (
	name SYSNAME
,	filepath VARCHAR (400)
,	size VARCHAR (10)
,	drive VARCHAR (30)
);

CREATE TABLE #DiskSpace (
	drive CHAR (1)
,	size_mb INT
,	used_mb INT
,	free_mb INT
,	free_perc VARCHAR (100)
,	used_perc VARCHAR (100)
,	used_sql_mb INT
,	report_date SMALLDATETIME
);

EXEC sp_MSforeachdb '
USE ?
INSERT INTO #DBSpace
SELECT DB_NAME(), filename, CONVERT (VARCHAR (8),size / 128), name FROM sysfiles';

DECLARE @hr INT, @fso INT, @total_mb INT, @total_space INT, @free_mb INT, @percentage INT, @size FLOAT, @sql_drive_size INT
DECLARE @drive CHAR (1), @fso_method VARCHAR (255)

SET @total_mb = 0;
EXEC @hr = sp_OACreate 'Scripting.FileSystemObject', @fso OUT;

CREATE TABLE #space (drive CHAR (1), mbfree INT);
INSERT INTO #space 
EXEC xp_fixeddrives

DECLARE Drive_Cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT drive, mbfree FROM #space

OPEN Drive_Cursor
FETCH NEXT FROM Drive_Cursor INTO @drive, @free_mb

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @fso_method = 'Drives("' + @drive + ':").TotalSize';
	SELECT @sql_drive_size = SUM (CONVERT (INT,size)) FROM #DBSpace WHERE SUBSTRING (filepath, 1, 1) = @drive;

	EXEC @hr = sp_OAMethod @fso, @fso_method, @size OUTPUT;
	SET @total_mb = @total_mb + (@size / 1048576);

	INSERT INTO #DiskSpace VALUES (
		@drive
	,	@total_mb
	,	@total_mb - @free_mb
	,	@free_mb
	,	CONVERT (VARCHAR, 100 * ROUND (@free_mb,2) / ROUND (@total_mb,2))
	,	CONVERT (VARCHAR, 100 - (100 * (ROUND (@free_mb,2) / ROUND (@total_mb,2))))
	,	@sql_drive_size
	,	GETDATE ()
	);

	FETCH NEXT FROM Drive_Cursor INTO @drive, @free_mb
END

CLOSE Drive_Cursor;
DEALLOCATE Drive_Cursor;

SELECT * FROM #DiskSpace;
DROP TABLE #DBSpace, #DiskSpace, #space;
GO

--<03>-- LISTAR OS MOUNT POINTS (LUNS) APRESENTANDO CAPACIDADE, ESPACO OCUPADO E LIVRE.
USE [master]

DECLARE @stmt VARCHAR (400);

SET @stmt = 'powershell.exe -c "Get-WmiObject -ComputerName ' + QUOTENAME (@@SERVERNAME, '''') + ' -Class Win32_Volume -Filter '' DriveType = 3'' | select name,capacity,freespace | foreach{$_.name+''|''+$_.capacity/1048576+''%''+$_.freespace/1048576+''*''}"';

CREATE TABLE #Output (Line VARCHAR (255));

INSERT INTO #Output
EXEC xp_cmdshell @stmt;

WITH CTE AS (
	SELECT
		@@SERVERNAME AS Instancia
	,	RTRIM (LTRIM (SUBSTRING (Line, 1, CHARINDEX ('|', Line) - 1))) AS Drive
	,	ROUND (CAST (RTRIM (LTRIM (SUBSTRING (Line, CHARINDEX ('|', Line) + 1, (CHARINDEX ('%', Line) - 1) - CHARINDEX ('|', Line)))) AS FLOAT), 0) AS Total_mb
	,	ROUND (CAST (RTRIM (LTRIM (SUBSTRING (Line, CHARINDEX ('%', Line) + 1, (CHARINDEX ('*', Line) - 1) - CHARINDEX ('%', Line)))) AS FLOAT), 0) AS livre_mb
	FROM
		#Output
	WHERE
		Line LIKE '[A-Z][:]%'
)
SELECT
	Instancia
,	Drive
,	Total_mb
,	CAST (Total_mb - livre_mb AS float) AS Ocupado_mb
,	livre_mb
,	CAST ((livre_mb / Total_mb) * 100.0 AS DECIMAL (10,2)) AS livre_percent
FROM
	CTE
ORDER BY
	Drive
OPTION (RECOMPILE);

DROP TABLE #Output;
GO

--<04>-- LISTAR DISCOS E MOUNT POINTS COM ESPACO LIVRE USANDO POWERSHELL.
USE [master]

DECLARE @xml_as_string VARCHAR (MAX)
DECLARE @percentage XML
DECLARE @xml TABLE (theXml VARCHAR (2000), theOrder INT IDENTITY (1,1) PRIMARY KEY)

INSERT INTO @xml (theXml)
EXEC xp_cmdshell '@Powershell -noprofile -command "Get-counter -counter ''\LogicalDisk(*)\% Free Space'' | select -expand countersamples | select @(Name=''Disk''; e={$_.IntanceName}}, @{Name=''%FreeSapce''; e={''{0:n2}'' -f $_.CookedValue}}|ConvertTo-XML -As string"'

SELECT	@xml_as_string = COALESCE (@xml_as_string,'') + theXml
FROM	@xml
WHERE	theXml IS NOT NULL
ORDER BY theOrder

SELECT @percentage = @xml_as_string;

SELECT
	MAX (CASE WHEN Attribute='Disk' THEN Value ELSE '' END) AS [Disk]
,	CAST (MAX (CASE WHEN Attribute='%FreeSpace' THEN Value ELSE '' END) AS NUMERIC (9,2)) AS [% Free Space]
FROM 
   (SELECT
		[property].value ('(./text())[1]', 'VARCHAR (128)') AS [Value]
	,	[property].value ('@Name', 'VARCHAR (128)') AS [Attribute]
	,	DENSE_RANK () OVER (ORDER BY [object]) AS unique_object
	FROM
		@percentage.nodes ('Objects/Object') AS B ([object])
		CROSS APPLY B.[object].nodes ('./Property') AS C ([property])
	) Powershell
GROUP BY
	unique_object
GO