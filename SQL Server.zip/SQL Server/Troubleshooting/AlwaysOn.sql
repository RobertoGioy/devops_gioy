/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR INSTANCIAS ALWAYSON.
 */

USE [master]
GO

--<01>-- COLETAR INFORMACOES DO CLUSTER.
SELECT * FROM sys.dm_hadr_cluster WITH (NOLOCK)
GO

--<02>-- COLETAR INFORMACOES DOS NODES.
SELECT
	hcm.member_name
  , hinm.instance_name
  , hcm.member_type_desc
  , hcm.member_state_desc
  , hcm.number_of_quorum_votes
  , agr.[endpoint_url]
  , agr.availability_mode_desc
  , agr.failover_mode_desc
  , agr.[session_timeout]
  , agr.primary_role_allow_connections_desc
  , agr.secondary_role_allow_connections_desc
  , agr.create_date
  , agr.modify_date
  , agr.[backup_priority]
  , agr.read_only_routing_url
FROM
	sys.dm_hadr_cluster_members hcm
	LEFT JOIN sys.dm_hadr_instance_node_map hinm	ON (UPPER (hcm.member_name) LIKE UPPER (hinm.node_name))
	LEFT JOIN sys.availability_replicas agr			ON (UPPER (hinm.instance_name) LIKE UPPER (agr.replica_server_name))
GO

--<03>-- COLETAR INFORMACOES GERAIS DOS AVAILABILITIES GROUPS.
SELECT 
	ag.name
  , agl.dns_name
  , aglipa.ip_address
  , aglipa.state_desc
  , ags.primary_replica
  , ags.primary_recovery_health_desc
  , ags.synchronization_health_desc
FROM
	sys.availability_groups ag
	INNER JOIN sys.availability_group_listeners agl					ON (ag.group_id = agl.group_id)
	INNER JOIN sys.availability_group_listener_ip_addresses aglipa	ON (agl.listener_id = aglipa.listener_id)
	INNER JOIN sys.dm_hadr_availability_group_states ags			ON (ag.group_id = ags.group_id)
GO

--<04>-- COLETAR INFORMACOES DE STATUS DAS REPLICAS DOS AVAILABILITIES GROUPS.
SELECT 
	arcn.group_name
  , arcn.node_name
  , arcn.replica_server_name
  , arcs.join_state_desc
  , ars.role_desc
  , ars.operational_state_desc
  , ars.connected_state_desc
  , ars.recovery_health_desc
  , ars.synchronization_health_desc
  , ars.last_connect_error_timestamp
  , ars.last_connect_error_number
  , ars.last_connect_error_description
FROM
	sys.dm_hadr_availability_replica_cluster_nodes arcn
	INNER JOIN sys.dm_hadr_availability_replica_cluster_states arcs ON (UPPER (arcn.replica_server_name) LIKE UPPER (arcs.replica_server_name))
	INNER JOIN sys.dm_hadr_availability_replica_states ars			ON (arcs.replica_id = ars.replica_id)
ORDER BY
	arcn.replica_server_name
GO

--<05>-- COLETAR INFORMACOES DE STATUS DAS BASES DAS REPLICAS DOS AVAILABILITIES GROUPS.
SELECT
	drcs.database_name
  , ars.role_desc
  , ars.connected_state_desc
  , drs.synchronization_state_desc
  , total_queue = (drs.log_send_queue_size + drs.redo_queue_size)
  , drs.log_send_queue_size
  , drs.redo_queue_size
  , drs.log_send_rate
  , drs.redo_rate
  , drs.low_water_mark_for_ghosts
  , drs.last_sent_time
  , drs.last_received_time
  , drs.last_hardened_time
  , drs.last_redone_time
  , drs.synchronization_health_desc
  , ar.availability_mode_desc
  , ar.failover_mode_desc
  , drs.database_state_desc
  , ars.recovery_health_desc
  , drs.is_local
  , drs.is_primary_replica
  , ar.primary_role_allow_connections_desc
  , drcs.is_failover_ready
  , drcs.is_pending_secondary_suspend
  , drcs.is_database_joined
FROM
	sys.dm_hadr_database_replica_cluster_states drcs
	INNER JOIN sys.availability_replicas ar					ON (drcs.replica_id = ar.replica_id)
	INNER JOIN sys.dm_hadr_availability_replica_states ars	ON (ar.replica_id = ars.replica_id)
	LEFT JOIN sys.dm_hadr_database_replica_states drs		ON (drcs.group_database_id = drs.group_database_id AND drcs.replica_id = drs.replica_id)
ORDER BY
	total_queue DESC
  , drcs.database_name
GO