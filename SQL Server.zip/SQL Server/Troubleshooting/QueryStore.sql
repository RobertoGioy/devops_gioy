USE Master;

WITH Query_Multplans AS (
    SELECT COUNT(*) AS cnt, q.query_id
    FROM sys.query_store_query_text as qt
    JOIN sys.query_store_query as q ON qt.query_text_id = q.query_text_id
    JOIN sys.query_store_plan as p ON p.query_id = q.query_id
    GROUP BY q.query_id
    HAVING COUNT(plan_id) > 1
)
SELECT q.query_id, object_name(object_id) as [proc], query_sql_text, plan_id, p.query_plan as plan_Xml,
p.last_compile_start_time, p.last_execution_time
FROM Query_Multplans AS qm 
JOIN sys.query_store_query as q ON qm.query_id = q.query_id
JOIN sys.query_store_plan as p ON p.query_id = q.query_id
JOIN sys.query_store_query_text qt ON qt.query_text_id = q.query_text_id
ORDER BY query_id, plan_id;

SELECT
    SUM(qrs.count_executions) * AVG(qrs.avg_logical_io_reads) as est_logical_reads,
    SUM(qrs.count_executions) as sum_executions,
    AVG(qrs.avg_logical_io_reads) as avg_logical_io_reads,
    SUM(qsq.count_compiles) as sum_compiles
    (SELECT TOP 1 qsqt.query_sql_text FROM sys.query_store_query_text qsqt WHERE qsqt.query_text_id = MAX(qsq.query_text_id)) as query_text,
    TRY_CONVERT(XML, (SELECT TOP 1 qsp2.query_plan FROM sys.query_store_plan qsp2 WHERE qsp2.query_id = qsq.query_id ORDER BY qsp2.plan_id DESC)) AS query_plan,
    object_name (qsq.object_id) as ObjectName
FROM sys.query_store_query qsq
JOIN sys.query_store_plan qsp ON qsq.query_id = qsp.query_id
CROSS APPLY (SELECT TRY_CONVERT(XML, qsp.query_plan) as query_plan_xml) as qpx
JOIN sys.query_store_runtime_stats qrs ON qsp.plan_id = qrs.plan_id
JOIN sys.query_store_runtime_stats_interval qrsi ON qrs.runtime_stats_interval_id = qrsi.runtime_stats_interval_id
WHERE qsp.query_plan LIKE '%<MissingIndexes>%'
AND qrsi.start_time >= DATEADD(HH, -24, sysdatetime())