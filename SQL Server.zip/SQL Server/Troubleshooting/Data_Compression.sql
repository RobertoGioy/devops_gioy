/*
 *	AUTHOR: BETO GIOY
 *	ACTION: COMPRESSAO DE TABELAS E BACKUP
 */

--<01>-- EXEMPLO DE COMPRESSAO DE TABELA POR LINHAS.
USE [AdventureWorks2014]
GO

EXECUTE sp_spaceused 
	@objname = 'Sales.CreditCard'
  , @updateusage = 'TRUE';
GO

/*
	Neste caso, o SQL Server transforma internamente, todas as colunas em tipo de dados vari�vel

	Sem compressao: 1496 (data) + 832 (index) = 2328 KB
	Com compressao: 0984 (data) + 528 (index) = 1512 KB => ganho de 35%
*/

EXECUTE sp_estimate_data_compression_savings 
	@schema_name = 'Sales'
  , @object_name = 'CreditCard'
  , @index_id = NULL
  , @partition_number = NULL
  , @data_compression = 'ROW';
GO

-- Comando de compressao por linha
ALTER TABLE [Sales].[CreditCard] REBUILD PARTITION = ALL WITH (DATA_COMPRESSION = ROW);
GO

--<02>-- EXEMPLO DE COMPRESSAO DE TABELA POR PAGINAS.
USE [AdventureWorks2014]
GO

EXECUTE sp_spaceused 
	@objname = 'Sales.CreditCard'
  , @updateusage = 'TRUE';
GO

/*
	Neste caso, o SQL Server alem de comprimir os registros, comprime tambem as paginas de dados
	Por exemplo: em colunas de grande numero de dados de mesmo valor

	Sem compressao: 1496 (data) + 832 (index) = 2328 KB
	Com compressao: 0736 (data) + 456 (index) = 1192 KB => ganho de 49%
*/

EXECUTE sp_estimate_data_compression_savings 
	@schema_name = 'Sales'
  , @object_name = 'CreditCard'
  , @index_id = NULL
  , @partition_number = NULL
  , @data_compression = 'PAGE';
GO

-- Comando de compressao por pagina
ALTER TABLE [Sales].[CreditCard] REBUILD PARTITION = ALL WITH (DATA_COMPRESSION = PAGE);
GO

-- comando para tirar a compressao da tabela
ALTER TABLE [Sales].[CreditCard] REBUILD PARTITION = ALL WITH (DATA_COMPRESSION = NONE);
GO

--<03>-- CRIANDO TABELA COM COMPRESSAO DE DADOS.
CREATE TABLE [dbo].[EXEMPLO] (
	ID INT IDENTITY (1,1) NOT NULL
  , NAME VARCHAR (128) NOT NULL
) WITH (DATA_COMPRESSION = PAGE);
GO

--<03>-- COMPRESSAO DE BACKUP.
BACKUP DATABASE [AdventureWorks2014]
TO DISK = 'C:\BACKUP\AdventureWorks2014_BKP.BAK'
WITH FORMAT, COMPRESSION
GO

-- Neste caso o SQL Server le mais paginas em menor tempo reduzindo o tempo de backup, mas consome mais recurso de CPU.