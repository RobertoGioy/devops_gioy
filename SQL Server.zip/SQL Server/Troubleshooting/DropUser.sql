USE Master
GO

SET NOCOUNT ON;

DECLARE @nomedb SYSNAME
DECLARE @nuser INT
DECLARE @readonly CHAR(1)
DECLARE @str NVARCHAR(400)
DECLARE @userAdm VARCHAR(30)

DECLARE @tbUser TABLE (id INT IDENTITY(1,1),
    UserAdm VARCHAR(30));

INSERT INTO @tbUser
    (UserAdm)
SELECT name
FROM sys.server_principals
WHERE name LIKE '%GIOY'

DECLARE usuarios CURSOR FOR SELECT UserAdm
FROM @tbUser
OPEN usuarios
FETCH NEXT FROM usuarios INTO @UserAdm

WHILE (@@FETCH_STATUS <> -1)
BEGIN
    IF (@@FETCH_STATUS <> -2)
    BEGIN
        DECLARE databases CURSOR FOR SELECT name
        FROM master.sys.databases
        OPEN databases
        FETCH NEXT FROM databases INTO @nomedb

        WHILE (@@FETCH_STATUS <> -1)
        BEGIN
            IF (@@FETCH_STATUS <> -2)
            BEGIN
                IF DATABASEPROPERTY(@nomedb, 'IsReadOnly') = 1
                BEGIN
                    SET @str = 'ALTER DATABASE ' + @nomedb + ' SET READ_WRITE WITH ROLLBACK IMMEDIATE'
                    EXEC sp_executesql @str;
                    SET @readOnly = 'T'
                END

                -- EXCLUI SCHEMAS DO USER DO BANCOS DE DADOS
                SELECT @str = 'SELECT @nuser=COUNT(name) FROM ' + @nomedb + '.sys.schemas WHERE name = ''' + @UserAdm + ''''
                EXEC sp_executesql @str, N'@nuser INT OUTPUT', @nuser OUTPUT;

                IF @nuser = 1
                BEGIN
                    SELECT @str = 'USE ' + @nomedb + '; ALTER USER [' + @UserAdm + '] WITH DEFAULT_SCHEMA=[dbo]'
                    EXEC sp_executesql @str;
                    SELECT @str = 'USE ' + @nomedb + '; DROP SCHEMA [' + @UserAdm + ']'
                    EXEC sp_executesql @str;
                END

                SET @nuser = 0;

                -- RETIRA OWNER DO USER DO BANCO DE DADOS
                SELECT @str = 'SELECT @nuser=COUNT(sp.name) FROM master.sys.databases d
                    INNER JOIN sys.server_principals sp ON d.owner_sid = sp.sid
                    WHERE sp.name = ''' + @UserAdm + ''' AND d.name = ' + @nomedb + ''
                EXEC sp_executesql @str, N'@nuser INT OUTPUT', @nuser OUTPUT;

                IF @nuser = 1
                BEGIN
                    SELECT @str = 'USE ' + @nomedb + '; EXEC sp_changedbowner [sa]'
                    EXEC sp_executesql @str;
                END

                SET @nuser = 0;

                -- EXCLUI USER DO BANCO DE DADOS
                SELECT @str = 'SELECT @nuser=COUNT(name) FROM ' + @nomedb + '..sysusers WHERE name = ''' + @UserAdm + ''''
                EXEC sp_executesql @str, N'@nuser INT OUTPUT', @nuser OUTPUT;

                IF @nuser = 1
                BEGIN
                    SELECT @str = 'USE ' + @nomedb + '; DROP USER [' + @UserAdm + ']'
                    EXEC sp_executesql @str;
                END

                SET @nuser = 0;

                -- RETORNA BASE EM READ_ONLY APÓS EXCLUIR USER
                IF @readOnly = 'T'
                BEGIN
                    SELECT @str = 'ALTER DATABASE ' + @nomedb + ' SET READ_ONLY WITH ROLLBACK IMMEDIATE'
                    EXEC sp_executesql @str;
                END
                SET @readOnly = 'F';
            END

            FETCH NEXT FROM databases INTO @nomedb
        END
                
        DEALLOCATE databases;

        -- EXCLUI LOGIN DA INSTANCIA
        PRINT 'REMOVENDO O LOGIN [' + @UserAdm + ']';
        SET @str = 'DROP LOGIN [' + @UserAdm + ']'
        EXEC sp_executesql @str;
    END

    FETCH NEXT FROM usuarios INTO @UserAdm   
END 

DEALLOCATE usuarios;
