/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR QUERIES E PROCEDURES
 */

--<01>-- CAPTURAR O PLANO DE EXECUCAO DA CONSULTA E CRIAR O COMANDO PARA LIMPAR O PLANO DO CACHE.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';			--> DATABASE NAME
DECLARE @procname SYSNAME = 'uspGetManagerEmployees';	--> PROCEDURE NAME
DECLARE @stmt NVARCHAR (MAX)

SET @stmt = N'
SELECT
	DB_NAME (ST.[dbid]) AS database_name
,	CP.refcounts 
,	CP.usecounts
,	CP.pool_id
,	CP.objtype
,	QP.query_plan
,	CP.plan_handle
,	ST.[text]
,	''DBCC FREEPROCCACHE (0x'' + CONVERT (VARCHAR (MAX), CP.plan_handle, 2) + '');'' AS Command
FROM
	sys.dm_exec_cached_plans CP
	CROSS APPLY sys.dm_exec_query_plan (CP.plan_handle) QP
	CROSS APPLY sys.dm_exec_sql_text (CP.plan_handle) ST
WHERE
	ST.[objectid] IN (SELECT object_id FROM ' + @dbname + '.sys.objects WHERE name = ''' + @procname + ''')
	AND ST.[dbid] = DB_ID (''' + @dbname + ''')
OPTION (RECOMPILE);'

EXEC sp_executesql @stmt;
GO

--<02>-- VERIFICAR INFORMACOES DAS PROCEDURES (NUMERO DE EXECUCOES, PLANO E TEMPO DE EXECUCAO).
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';			--> DATABASE NAME
DECLARE @procname SYSNAME = 'uspGetManagerEmployees';	--> PROCEDURE NAME | NULL

IF @procname IS NULL SET @procname = '%%' ELSE SET @procname = '%' + @procname + '%';

SELECT
	DB_NAME (PS.database_id) AS databaseName
,	SCH.name AS schemaName
,	P.name AS procedureName
,	PS.type_desc
,	PS.cached_time
,	PS.last_execution_time
,	P.create_date
,	P.modify_date
,	PS.execution_count
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_Time
,	REPLICATE ('0', 2 - LEN (PS.last_elapsed_time / 1000000 / 3600)) + CAST ((PS.last_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.last_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.last_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.last_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.last_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Last_Time
,	REPLICATE ('0', 2 - LEN (PS.min_elapsed_time / 1000000 / 3600)) + CAST ((PS.min_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.min_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.min_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.min_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.min_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Min_Time
,	REPLICATE ('0', 2 - LEN (PS.max_elapsed_time / 1000000 / 3600)) + CAST ((PS.max_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.max_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.max_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.max_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.max_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Max_Time
,	REPLICATE ('0', 2 - LEN (PS.total_worker_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_worker_time /PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_worker_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_worker_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_CPU_Time
,	REPLICATE ('0', 2 - LEN (PS.last_worker_time / 1000000 / 3600)) + CAST ((PS.last_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.last_worker_time / 1000000 % 3600) / 60)) + CAST (((PS.last_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.last_worker_time / 1000000 % 3600) % 60)) + CAST (((PS.last_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Last_CPU_Time
,	REPLICATE ('0', 2 - LEN (PS.min_worker_time / 1000000 / 3600)) + CAST ((PS.min_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.min_worker_time / 1000000 % 3600) / 60)) + CAST (((PS.min_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.min_worker_time / 1000000 % 3600) % 60)) + CAST (((PS.min_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Min_CPU_Time
,	REPLICATE ('0', 2 - LEN (PS.max_worker_time / 1000000 / 3600)) + CAST ((PS.max_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.max_worker_time / 1000000 % 3600) / 60)) + CAST (((PS.max_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.max_worker_time / 1000000 % 3600) % 60)) + CAST (((PS.max_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Max_CPU_Time
,	PS.total_logical_reads / PS.execution_count AS AVG_logical_reads
,	PS.total_logical_reads
,	PS.last_logical_reads
,	PS.min_logical_reads
,	PS.max_logical_reads
,	PS.total_physical_reads / PS.execution_count AS AVG_physical_reads
,	PS.total_physical_reads
,	PS.last_physical_reads
,	PS.min_physical_reads
,	PS.max_physical_reads
,	PS.total_logical_writes / PS.execution_count AS AVG_logical_writes
,	PS.total_logical_writes
,	PS.last_logical_writes
,	PS.min_logical_writes
,	PS.max_logical_writes
,	PS.plan_handle
,	PS.[sql_handle]
,	QP.query_plan
,	ST.[text]
FROM
	sys.dm_exec_procedure_stats PS
	INNER JOIN sys.procedures P				ON (PS.[object_id] = P.[object_id])
	INNER JOIN sys.schemas SCH				ON (P.[schema_id] = SCH.[schema_id])
	INNER JOIN sys.dm_exec_cached_plans CP	ON (PS.plan_handle = CP.plan_handle)
	CROSS APPLY sys.dm_exec_query_plan (CP.plan_handle) QP
	CROSS APPLY sys.dm_exec_sql_text (CP.plan_handle) ST
WHERE
	PS.database_id = DB_ID (@dbname)
	AND P.name LIKE @procname
ORDER BY
	databaseName
,	procedureName
OPTION (RECOMPILE);
GO

--<03>-- CHECAR A EXECUCAO DOS COMANDOS DE UMA PROCEDURE PASSO A PASSO, DO ULTIMO PLANO DE EXECUCAO EM CACHE.
USE [AdventureWorks2014]

DECLARE @procedure SYSNAME = 'uspGetManagerEmployees';	--> PROCEDURE NAME
DECLARE @objectid INT;
DECLARE @planhandle VARBINARY (50);

SET @objectid = (SELECT OBJECT_ID (@procedure));

USE [master]

SELECT
	@planhandle = CP.plan_handle
FROM
	sys.dm_exec_cached_plans CP
	CROSS APPLY sys.dm_exec_query_plan (CP.plan_handle) QP
	CROSS APPLY sys.dm_exec_sql_text (CP.plan_handle) ST
WHERE
	ST.[objectid] = @objectid;

SELECT
	DB_NAME (ST.[dbid]) AS database_name
,	QS.statement_start_offset
,	QS.statement_end_offset
,	ISNULL (SUBSTRING (ST.[text], QS.statement_start_offset / 2, (CASE WHEN QS.statement_end_offset = -1 THEN LEN (CONVERT (NVARCHAR (MAX), ST.[text])) * 2 ELSE QS.statement_end_offset END - QS.statement_start_offset) / 2), '') AS command
,	QS.creation_time
,	QS.last_execution_time
,	QS.execution_count
,	QS.total_rows / QS.execution_count AS AVG_rows
,	QS.total_rows
,	QS.last_rows
,	QS.min_rows
,	QS.max_rows
,	REPLICATE ('0', 2 - LEN (QS.total_elapsed_time / QS.execution_count / 1000000 / 3600)) + CAST ((QS.total_elapsed_time / QS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.total_elapsed_time / QS.execution_count / 1000000 % 3600) / 60)) + CAST (((QS.total_elapsed_time / QS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.total_elapsed_time / QS.execution_count / 1000000 % 3600) % 60)) + CAST (((QS.total_elapsed_time / QS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_Time
,	REPLICATE ('0', 2 - LEN (QS.last_elapsed_time / 1000000 / 3600)) + CAST ((QS.last_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.last_elapsed_time / 1000000 % 3600) / 60)) + CAST (((QS.last_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.last_elapsed_time / 1000000 % 3600) % 60)) + CAST (((QS.last_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Last_Time
,	REPLICATE ('0', 2 - LEN (QS.min_elapsed_time / 1000000 / 3600)) + CAST ((QS.min_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.min_elapsed_time / 1000000 % 3600) / 60)) + CAST (((QS.min_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.min_elapsed_time / 1000000 % 3600) % 60)) + CAST (((QS.min_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Min_Time
,	REPLICATE ('0', 2 - LEN (QS.max_elapsed_time / 1000000 / 3600)) + CAST ((QS.max_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.max_elapsed_time / 1000000 % 3600) / 60)) + CAST (((QS.max_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.max_elapsed_time / 1000000 % 3600) % 60)) + CAST (((QS.max_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Max_Time
,	REPLICATE ('0', 2 - LEN (QS.total_worker_time / QS.execution_count / 1000000 / 3600)) + CAST ((QS.total_worker_time / QS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.total_worker_time / QS.execution_count / 1000000 % 3600) / 60)) + CAST (((QS.total_worker_time / QS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.total_worker_time / QS.execution_count / 1000000 % 3600) % 60)) + CAST (((QS.total_worker_time / QS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_CPU_Time
,	REPLICATE ('0', 2 - LEN (QS.last_worker_time / 1000000 / 3600)) + CAST ((QS.last_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.last_worker_time / 1000000 % 3600) / 60)) + CAST (((QS.last_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.last_worker_time / 1000000 % 3600) % 60)) + CAST (((QS.last_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Last_CPU_Time
,	REPLICATE ('0', 2 - LEN (QS.min_worker_time / 1000000 / 3600)) + CAST ((QS.min_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.min_worker_time / 1000000 % 3600) / 60)) + CAST (((QS.min_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.min_worker_time / 1000000 % 3600) % 60)) + CAST (((QS.min_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Min_CPU_Time
,	REPLICATE ('0', 2 - LEN (QS.max_worker_time / 1000000 / 3600)) + CAST ((QS.max_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.max_worker_time / 1000000 % 3600) / 60)) + CAST (((QS.max_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.max_worker_time / 1000000 % 3600) % 60)) + CAST (((QS.max_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Max_CPU_Time
,	QS.total_logical_reads / QS.execution_count AS AVG_logical_reads
,	QS.total_logical_reads
,	QS.last_logical_reads
,	QS.min_logical_reads
,	QS.max_logical_reads
,	QS.total_physical_reads / QS.execution_count AS AVG_physical_reads
,	QS.total_physical_reads
,	QS.last_physical_reads
,	QS.min_physical_reads
,	QS.max_physical_reads
,	QS.total_logical_writes / QS.execution_count AS AVG_logical_writes
,	QS.total_logical_writes
,	QS.last_logical_writes
,	QS.min_logical_writes
,	QS.max_logical_writes
,	CAST (TQP.query_plan AS xml) AS query_plan
,	QS.plan_handle
,	QS.[sql_handle]
FROM
	sys.dm_exec_query_stats QS
	CROSS APPLY sys.dm_exec_sql_text (QS.plan_handle) ST
	CROSS APPLY sys.dm_exec_text_query_plan (QS.plan_handle, QS.statement_start_offset, QS.statement_end_offset) TQP
WHERE
	QS.plan_handle = @planhandle
OPTION (RECOMPILE);
GO

--<04>-- LISTAR TODAS AS PROCEDURES QUE POSSUEM DETERMINADO TEXTO EM SEU CORPO.
USE [master]

EXEC sp_MSforeachdb	'
SELECT 
	''?'', name, [text]
FROM
	?.dbo.syscomments C
	INNER JOIN ?.dbo.sysobjects O ON (C.[id] = O.[id])
WHERE
	CHARINDEX (''sp_xml_'',[text]) > 0
OPTION (RECOMPILE);';
GO

--<05>-- LISTAR AS PROCEDURES QUE USAM PROCEDIMENTO INTERNO SP_XML_PREPAREDOCUMENT E NAO USAM SP_XML_REMOVEDOCUMENT.

--	A PROCEDURE SP_XML_PREPAREDOCUMENT USA MEMORIA INTERNA DO SQL SERVER E PRECISA DA SP_XML_REMOVEDOCUMENT PARA DESALOCAR ESTA MEMORIA.
--	UM DOCUMENTO ANALISADO E ARMAZENADO NO CACHE INTERNO DO SQL SERVER.
--	O ANALISADOR MSXML USA 1/8 DA MEMORIA TOTAL DISPONIVEL (A MENOR: MEMTOLEAVE OU BUFFER MANAGER) PARA O SQL SERVER.
USE [master]

CREATE TABLE ##TB_OBJNAME (dbname VARCHAR (96), objectID INT, objname VARCHAR (96), definition VARCHAR (MAX));
CREATE TABLE #database (databaseID INT, databaseName VARCHAR (128));

INSERT INTO #database
SELECT database_id, name FROM sys.databases WHERE database_id > 4 AND [state] = 0;

DECLARE @db VARCHAR (128), @stmt VARCHAR (MAX)

DECLARE TB_CURSOR CURSOR LOCAL FOR (SELECT databaseName FROM #database)
OPEN TB_CURSOR
FETCH NEXT FROM TB_CURSOR INTO @db

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @stmt = '
	USE [' + @db + '];
	INSERT INTO ##TB_OBJNAME
	SELECT
		DB_NAME () AS dbname
	,	[object_id] AS objectID
	,	OBJECT_NAME ([object_id]) AS objname
	,	definition
	FROM
		[' + @db + '].sys.sql_modules
	WHERE
		definition LIKE ''%SP_XML_PREPAREDOCUMENT%''';

	EXEC (@stmt);

	FETCH NEXT FROM TB_CURSOR INTO @db
END

CLOSE TB_CURSOR;
DEALLOCATE TB_CURSOR;

SELECT * FROM ##TB_OBJNAME; --> LISTA TODAS AS PROCEDURES QUE POSSUEM A CHAMADA PARA SP_XML_PREPAREDOCUMENT
SELECT						--> LISTA TODAS AS PROCEDURES QUE POSSUEM A CHAMADA PARA SP_XML_PREPAREDOCUMENT E NAO POSSUEM CHAMADA PARA SP_XML_REMOVEDOCUMENT
	dbname, objname
FROM
	##TB_OBJNAME
WHERE
	[definition] NOT LIKE '%SP_XML_REMOVEDOCUMENT%'

DROP TABLE ##TB_OBJNAME, #database;
GO

--<06>-- PESQUISAR CONSULTAS PREPARADAS E AD-HOC QUE MAIS CONSOMEM PLAN CACHE.
USE [master]

SELECT TOP (50)
	ST.[text]
,	CP.cacheobjtype
,	CP.objtype
,	CP.size_in_bytes / 1024 AS plan_size_mb
FROM
	sys.dm_exec_cached_plans CP
	CROSS APPLY sys.dm_exec_sql_text(CP.plan_handle) ST
WHERE
	CP.cacheobjtype = N'Compiled Plan'
	AND CP.objtype IN (N'Adhoc', N'Prepared')
	AND CP.usecounts = 1
ORDER BY
	plan_size_mb DESC
OPTION (RECOMPILE);
GO

--<07>-- CONSULTAR AS ESTATISTICAS DAS PROCEDURES EM CACHE.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';		--> DATABASE NAME

SELECT TOP (100)	--> POR NUMERO DE EXECUCOES
	P.name AS procedureName
,	PS.execution_count
,	ISNULL (PS.execution_count / DATEDIFF (MM, PS.cached_time, GETDATE ()), 0) AS calls_minute
,	REPLICATE ('0', 2 - LEN (PS.total_worker_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_worker_time /PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_worker_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_worker_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_CPU_Time
,	REPLICATE ('0', 2 - LEN (PS.total_worker_time / 1000000 / 3600)) + CAST ((PS.total_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / 1000000 % 3600) / 60)) + CAST (((PS.total_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / 1000000 % 3600) % 60)) + CAST (((PS.total_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Total_CPU_Time
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_Time
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Total_Time
,	PS.cached_time
FROM
	sys.procedures P
	INNER JOIN sys.dm_exec_procedure_stats PS ON (P.[object_id] = PS.[object_id])
WHERE
	PS.database_id = DB_ID (@dbname)
ORDER BY
	PS.execution_count DESC
OPTION (RECOMPILE);

SELECT TOP (25)		--> POR MEDIA DE TEMPO
	P.name AS procedureName
,	PS.execution_count
,	ISNULL (PS.execution_count / DATEDIFF (MM, PS.cached_time, GETDATE ()), 0) AS calls_minute
,	REPLICATE ('0', 2 - LEN (PS.total_worker_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_worker_time /PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_worker_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_worker_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_CPU_Time
,	REPLICATE ('0', 2 - LEN (PS.total_worker_time / 1000000 / 3600)) + CAST ((PS.total_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / 1000000 % 3600) / 60)) + CAST (((PS.total_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / 1000000 % 3600) % 60)) + CAST (((PS.total_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Total_CPU_Time
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_Time
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Total_Time
,	PS.cached_time
FROM
	sys.procedures P
	INNER JOIN sys.dm_exec_procedure_stats PS ON (P.[object_id] = PS.[object_id])
WHERE
	PS.database_id = DB_ID (@dbname)
ORDER BY
	AVG_Time DESC
OPTION(RECOMPILE);

SELECT TOP (25)		--> POR MEDIA DE TEMPO COM VARIACAO DO TEMPO DE EXECUCAO
	P.name AS procedureName
,	PS.execution_count
,	ISNULL (PS.execution_count / DATEDIFF (MM, PS.cached_time, GETDATE ()), 0) AS calls_minute
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_Time
,	REPLICATE ('0', 2 - LEN (PS.last_elapsed_time / 1000000 / 3600)) + CAST ((PS.last_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.last_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.last_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.last_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.last_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Last_Time
,	REPLICATE ('0', 2 - LEN (PS.min_elapsed_time / 1000000 / 3600)) + CAST ((PS.min_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.min_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.min_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.min_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.min_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Min_Time
,	REPLICATE ('0', 2 - LEN (PS.max_elapsed_time / 1000000 / 3600)) + CAST ((PS.max_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.max_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.max_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.max_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.max_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Max_Time
,	PS.cached_time
FROM
	sys.procedures P
	INNER JOIN sys.dm_exec_procedure_stats PS ON (P.[object_id] = PS.[object_id])
WHERE
	PS.database_id = DB_ID (@dbname)
ORDER BY
	AVG_Time DESC
OPTION(RECOMPILE);

SELECT TOP (25)		--> POR CUSTO DE CPU
	P.name AS procedureName
,	PS.execution_count
,	ISNULL (PS.execution_count / DATEDIFF (MM, PS.cached_time, GETDATE ()), 0) AS calls_minute
,	REPLICATE ('0', 2 - LEN (PS.total_worker_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_worker_time /PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_worker_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_worker_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_CPU_Time
,	REPLICATE ('0', 2 - LEN (PS.total_worker_time / 1000000 / 3600)) + CAST ((PS.total_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / 1000000 % 3600) / 60)) + CAST (((PS.total_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_worker_time / 1000000 % 3600) % 60)) + CAST (((PS.total_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Total_CPU_Time
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_Time
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Total_Time
,	PS.cached_time
FROM
	sys.procedures P
	INNER JOIN sys.dm_exec_procedure_stats PS ON (P.[object_id] = PS.[object_id])
WHERE
	PS.database_id = DB_ID (@dbname)
ORDER BY
	Total_Time DESC
OPTION(RECOMPILE);

SELECT TOP (25)		--> POR TOTAL DE LEITURAS LOGICAS (PODE INDICAR PRESSAO DE MEMORIA)
	P.name AS procedureName
,	PS.execution_count
,	ISNULL (PS.execution_count / DATEDIFF (MM, PS.cached_time, GETDATE ()), 0) AS calls_minute
,	PS.total_logical_reads / PS.execution_count AS AVG_logical_reads
,	PS.total_logical_reads
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_Time
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Total_Time
,	PS.cached_time
FROM
	sys.procedures P
	INNER JOIN sys.dm_exec_procedure_stats PS ON (P.[object_id] = PS.[object_id])
WHERE
	PS.database_id = DB_ID (@dbname)
ORDER BY
	PS.total_logical_reads
OPTION (RECOMPILE);

SELECT TOP (25)		--> POR TOTAL DE LEITURAS FISICAS (PODE INDICAR PRESSAO DE I/O OU DE MEMORIA)
	P.name AS procedureName
,	PS.execution_count
,	ISNULL (PS.execution_count / DATEDIFF (MM, PS.cached_time, GETDATE ()), 0) AS calls_minute
,	PS.total_physical_reads / PS.execution_count AS AVG_physical_reads
,	PS.total_physical_reads
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_Time
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Total_Time
,	PS.cached_time
FROM
	sys.procedures P
	INNER JOIN sys.dm_exec_procedure_stats PS ON (P.[object_id] = PS.[object_id])
WHERE
	PS.database_id = DB_ID (@dbname)
ORDER BY
	PS.total_physical_reads DESC
OPTION (RECOMPILE);

SELECT TOP (25)		--> POR TOTAL DE ESCRITAS LOGICAS (PODE INDICAR PRESSAO DE I/O OU DE MEMORIA)
	P.name AS procedureName
,	PS.execution_count
,	ISNULL (PS.execution_count / DATEDIFF (MM, PS.cached_time, GETDATE ()), 0) AS calls_minute
,	PS.total_logical_writes / PS.execution_count AS AVG_logical_writes
,	PS.total_logical_writes
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / PS.execution_count / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / PS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / PS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_Time
,	REPLICATE ('0', 2 - LEN (PS.total_elapsed_time / 1000000 / 3600)) + CAST ((PS.total_elapsed_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) / 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((PS.total_elapsed_time / 1000000 % 3600) % 60)) + CAST (((PS.total_elapsed_time / 1000000 % 3600) % 60) AS VARCHAR) AS Total_Time
,	PS.cached_time
FROM
	sys.procedures P
	INNER JOIN sys.dm_exec_procedure_stats PS ON (P.[object_id] = PS.[object_id])
WHERE
	PS.database_id = DB_ID (@dbname)
ORDER BY
	PS.total_logical_writes DESC
OPTION (RECOMPILE);
GO

--<08>-- LISTAR AS CONSULTAS EM CACHE COM MAIOR CONSUMO MEDIO DE I/O.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';		--> DATABASE NAME

SELECT TOP (50)
	OBJECT_NAME (ST.[objectid], ST.[dbid]) AS procedureName
,	(QS.total_logical_reads + QS.total_logical_writes) / QS.execution_count AS AVG_IO
,	QS.execution_count
,	SUBSTRING (ST.[text], QS.statement_start_offset / 2, (CASE WHEN QS.statement_end_offset = -1 THEN LEN (CONVERT (NVARCHAR (MAX), ST.[text])) * 2 ELSE QS.statement_end_offset END - QS.statement_start_offset) / 2) AS query_text
FROM
	sys.dm_exec_query_stats QS
	CROSS APPLY sys.dm_exec_sql_text (QS.sql_handle) ST
WHERE
	ST.[dbid] = DB_ID (@dbname)
ORDER BY
	AVG_IO DESC
OPTION (RECOMPILE);
GO