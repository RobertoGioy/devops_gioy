/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR A SEGURANCA DO SQL SERVER.
 */

--<01>-- CRIAR LOGIN E ATRIBUIR UMA SERVER ROLE A ESTE LOGIN.
USE [master]

DECLARE 
	@login	SYSNAME
,	@pwd	VARCHAR (20)
,	@auth	BIT
,	@role	SYSNAME
,	@stmt	NVARCHAR (MAX)

SET @login	= 'gioy';
SET @pwd	= 'Teste123';
SET @auth	= 1;				-- 0 = WINDOWS AUTHENTICATION | 1 = SQL AUTHENTICATION
SET @role	= 'sysadmin';		-- SYSADMIN, BULKADMIN, DBCREATOR, DISKADMIN, PROCESSADMIN, SECURITYADMIN, SERVERADMIN, SETUPADMIN

/*
 * SYSADMIN:		PODE EXECUTAR QUALQUER ATIVIDADE NO SERVIDOR.
 * SERVERADMIN:		PODE ALTERAR AS OPCOES DE CONFIGURACAO DE TODO O SERVIDOR E DESLIGAR O SERVIDOR.
 * SECURITYADMIN:	PODE GERENCIAR LOGONS E SUAS PROPRIEDADES, TANTO A NIVEL DE SERVIDOR QUANTO DE BANCO DE DADOS.
 * PROCESSADMIN:	PODE ENCERRAR OS PROCESSOS EM EXECUCAO EM UMA INSTANCIA DO SQL SERVER.
 * SETUPADMIN:		PODE ADICIONAR OU REMOVER SERVIDORES VINCULADOS USANDO INSTRUCOES T-SQL. PARA USAR SSMS PRECISA SER SYSADMIN.
 * BULKADMIN:		PODE EXECUTAR INSTRUCOES BULK INSERT.
 * DISKADMIN:		PODE GERENCIAR ARQUIVOS EM DISCO.
 * DBCREATOR:		PODE CRIAR, ALTERAR, DESCARTAR E RESTAURAR QUALQUER BANCO DE DADOS.
 */
IF (@auth = 1)
	SET @stmt = '
	IF NOT EXISTS (SELECT * FROM sys.servers_principals WHERE name = N''' + @login + ''')
		CREATE LOGIN [' + @login + '] WITH PASSWORD = N''' + @pwd + ''', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF;'
ELSE
	SET @stmt = '
	IF NOT EXISTS (SELECT * FROM sys.servers_principals WHERE name = N''' + @login + ''')
		CREATE LOGIN [' + @login + '] WITH PASSWORD = N''' + @pwd + ''', DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english];'

SET @stmt = @stmt + '
	EXEC sp_addsrvrolemember N''' + @login + ''', N''' + @role + ''';'

EXECUTE sp_executesql @stmt;

-- OUTRA FORMA DE CRIAR LOGIN E USARO PROCEDIMENTO ARMAZENADO SP_ADDLOGIN.
IF NOT EXISTS (SELECT * FROM sys.syslogins WHERE name = @login)
	EXEC sp_addlogin
		@loginame		= @login
	,	@passwd			= @pwd
	,	@defdb			= 'master'
	,	@deflanguage	= @@LANGUAGE;
GO

--<02>-- CRIAR USUARIO NA BASE DE DADOS E ATRIBUIR DATABASE ROLE A ESTE USUARIO.
USE [master]

DECLARE @login SYSNAME,	@user SYSNAME, @dbname SYSNAME,	@role SYSNAME, @stmt NVARCHAR (MAX)

SET @dbname = 'AdventureWorks2014';
SET @login	= 'gioy';
SET @user	= 'gioy';
SET @role	= 'ddl_admin';	-- DB_OWNER, DB_SECURITYADMIN, DB_ACCESSADMIN, DB_BACKUPOPERATOR, DB_DDLADMIN, DB_DATAWRITER, DB_DATAREADER, DB_DENYDATAWRITER, DB_DENYDATAREADER

/*
 * DB_OWNER:			PODE EXECUTAR TODAS AS ATIVIDADES DE CONFIGURACAO E MANUTENCAO DO BANCO DE DADOS, E, TAMBEM PODE EXCLUIR O BANCO DE DADOS.
 * DB_SECURITYADMIN:	PODE GERENCIAR PERMISSOES E MODIFICAR ACESSO EM ROLES.
 * DB_ACCESSADMIN:		PODE ADICIONAR OU REMOVER ACESSO AO BANCO DE DADOS PARA LOGINS DO WINDOWS, GRUPOS DO WINDOWS E LOGIN DO SQL SERVER.
 * DB_BACKUPOPERATOR:	PODE FAZER BACKUP DO BANCO DE DADOS.
 * DB_DDLADMIN:			PODE EXECUTAR QUALQUER COMANDO DDL (DATA DEFINITION LANGUAGE).
 * DB_DATAWRITER:		PODE ADICIONAR, EXCLUIR E ALTERAR DADOS EM TODAS AS TABELAS DE USUARIO DO BANCO DE DADOS.
 * DB_DATAREADER:		PODE LER OS DADOS EM TODAS AS TABELAS DE USUARIO DO BANCO DE DADOS.
 * DB_DENYDATAWRITER:	NAO PODE ADICIONAR, EXCLUIR E ALTERAR DADOS EM TODAS AS TABELAS DE USUARIO DO BANCO DE DADOS.
 * DB_DENYDATAREADER:	NAO PODE LER OS DADOS EM TODAS AS TABELAS DE USUARIO DO BANCO DE DADOS.
 */
SET @stmt = '
USE [' + @dbname + '];
IF NOT EXISTS (SELECT * FROM sys.databases_principals WHERE name = N''' + @user + ''')
	CREATE USER [' + @user + '] FOR LOGIN [' + @login + '] WITH DEFAULT_SCHEMA=[dbo];
	EXEC sp_addrolemember N''' + @role + ''', N''' + @user + ''';
GO'

EXECUTE sp_executesql @stmt;

-- OUTRA FORMA DE CRIAR USUARIO E USAR O PROCEDIMENTO ARMAZENADO SP_ADDUSER.
IF NOT EXISTS (SELECT * FROM sys.sysusers WHERE name = @user)
	EXECUTE sp_adduser
		@loginame	= @login
	,	@name_in_db = @user
	,	@grpname	= @role
GO

--<03>-- EXCLUIR O LOGIN DO SERVIDOR SQL SERVER.
USE [master]

DECLARE @login SYSNAME = 'gioy'

DECLARE login_cursor CURSOR LOCAL FOR
SELECT name FROM sys.databases WHERE is_read_only = 0

DECLARE @dbname SYSNAME, @stmt VARCHAR (560)

OPEN login_cursor
FETCH NEXT FROM login_cursor INTO @dbname

WHILE (@@FETCH_STATUS <> -1)
BEGIN
	SET @stmt = 'USE [' + @dbname + ']; DROP SCHEMA [' + @login + ']; DROP USER [' + @login + '];';
	EXEC (@stmt);

	PRINT 'Executed: ' + @stmt;

	FETCH NEXT FROM login_cursor INTO @dbname
END

CLOSE login_cursor;
DEALLOCATE login_cursor;

-- REMOVE A ENTRADA DE LOGON DO SQL SERVER PARA UM USUARIO OU GRUPO DO WINDOWS.
EXEC sp_revokelogin @loginame = @login;

-- FORNECE INFORMACOES SOBRE LOGONS E OS USUARIOS ASSOCIADOS A ELES EM CADA BANCO DE DADOS.
EXEC sp_helplogins @login;

-- REMOVE UM LOGIN DO SQL SERVER
EXEC sp_droplogin @loginame = @login;

-- VERIFICA AS PERMISSOES DE UM LOGIN
EXEC sp_helprotect 
	@name			= NULL		-- OBJECT NAME
,	@username		= @login	-- LOGIN NAME
,	@grantorname	= NULL		-- GRANTOR NAME
GO

--<04>-- VERIFICAR SE USUARIO POSSUI SCHEMA PROPRIO E MONTAR COMANDO PARA EXCLUIR SCHEMA.
USE [master]

-- COPIAR RESULTADO, SE HOUVER
EXEC sp_MSforeachdb 'USE [?]; SELECT ''USE '' + DB_NAME () + ''; '' + ''DROP SCHEMA '' + name FROM sys.schemas WHERE name = ''gioy''';

-- LISTA SCHEMA OBJETOS
EXEC sp_MSforeachdb
'USE [?];
SELECT
	DB_NAME () dbname
,	ss.name schema
,	so.name objectname
FROM
	sys.objects so JOIN sys.schemas ss ON (so.schema_id = ss.schema_id)
WHERE
	ss.name IN (''gioy'')';

-- LISTA CONEXOES DO USUARIO QUE ESTAO ABERTAS
SELECT
	ec.session_id
,	DB_NAME (et.dbid) dbname
,	es.login_name
,	es.[status]
,	es.total_elapsed_time
,	es.last_request_end_time
,	es.login_time
,	es.[host_name]
,	es.host_process_id
,	es.[program_name]
,	et.[text]
FROM
	sys.dm_exec_connections ec
	JOIN sys.dm_exec_sessions es ON (ec.session_id = es.session_id)
	CROSS APPLY sys.dm_exec_sql_text(ec.most_recent_sql_handle) et
WHERE
	es.login_name = 'gioy'
OPTION (RECOMPILE);

/*
	SE A BASE ESTIVE EM READ_ONLY USAR OS COMANDOS ABAIXO:

	USE MASTER
	GO
	ALTER DATABASE DBMM51 SET RESTRICTED_USER WITH ROLLBACK IMMEDIATE
	ALTER DATABASE DBMM51 SET READ_WRITE

	USE DBMM51
	GO
	DROP SCHEMA [gioy];
	DROP USER [gioy];
	ALTER DATABASE DBMM51 SET READ_ONLY
	ALTER DATABASE DBMM51 SET MULTI_USER
*/
GO

--<05>-- LISTAR AS INFORMACOES DO TIPO DE LOGIN E ROLES ASSOCIADAS.
USE [AdventureWorks2014]

DECLARE @login SYSNAME = NULL	--> LOGIN | NULL

IF @login IS NULL SET @login = '%%' ELSE SET @login = '%' + @login + '%';

SELECT
	[login_type]	= CASE SP.[type] WHEN 'U' THEN 'WINDOWS' WHEN 'S' THEN 'SQLSERVER' WHEN 'G' THEN 'WINDOWS GROUP' END
,	server_login	= SP.name
,	server_role		= SP2.name
,	database_user	= DBP.name
,	database_role	= DBP2.name
FROM
	sys.server_principals SP
	INNER JOIN sys.database_principals DBP		ON (SP.[sid] = DBP.[sid])
	INNER JOIN sys.database_role_members DBRM	ON (DBP.principal_id = DBRM.member_principal_id)
	INNER JOIN sys.database_principals DBP2		ON (DBRM.role_principal_id = DBP2.principal_id)
	LEFT JOIN sys.server_role_members SRM		ON (SP.principal_id = SRM.member_principal_id)
	LEFT JOIN sys.server_principals SP2			ON (SRM.role_principal_id = SP2.principal_id)
WHERE
	SP.name LIKE @login
ORDER BY
	[login_type]
,	server_login
OPTION (RECOMPILE);
GO

--<06>-- LISTAR AS PERMISSOES DAS ROLES E DOS USUARIOS ATRELADOS A ELAS.
USE [AdventureWorks2014]

SET NOCOUNT ON;

WITH CTERoles AS (
	SELECT 
		DP.principal_id
	,	DP.name
	,	DP.create_date
	,	DP.modify_date
	FROM
		sys.database_principals DP
	WHERE
		DP.[type] IN ('R')
		AND DP.is_fixed_role = 0
		AND DP.owning_principal_id = 1
		AND DP.principal_id <> 0
)
SELECT DISTINCT
	R.name AS rolename
,	R.create_date
,	R.modify_date
,	P.[permission_name]
,	P.state_desc
FROM
	CTERoles R
	INNER JOIN sys.database_permissions P ON (R.principal_id = P.grantee_principal_id)
OPTION (RECOMPILE);

WITH CTERoles AS (
	SELECT 
		DP.principal_id
	,	DP.name
	,	DP.create_date
	,	DP.modify_date
	FROM
		sys.database_principals DP
	WHERE
		DP.[type] IN ('R')
		AND DP.is_fixed_role = 0
		AND DP.owning_principal_id = 1
		AND DP.principal_id <> 0
)
SELECT
	R.name AS rolename
,	DP.name AS username
,	DP.type_desc
,	DP.default_schema_name
,	DP.create_date
,	DP.modify_date
,	P.[permission_name]
,	P.state_desc
FROM
	CTERoles R
	INNER JOIN sys.database_role_members DRM	ON (R.principal_id = DRM.role_principal_id)
	INNER JOIN sys.database_principals DP		ON (DP.principal_id = DRM.member_principal_id)
	INNER JOIN sys.database_permissions P		ON (DP.principal_id = P.grantee_principal_id)
OPTION (RECOMPILE);
GO

--<07>-- LISTAR AS PERMISSOES DAS ROLES POR OBJETOS EM UMA BASE DE DADOS.
USE [AdventureWorks2014]

SELECT
	role_name = RP.name
,	user_type = RP.type_desc
,	permission_type = PM.class_desc
,	PM.[permission_name]
,	PM.state_desc
,	object_type = CASE WHEN (OBJ.type_desc IS NULL) OR (OBJ.type_desc = 'SYSTEM_TABLE') THEN PM.class_desc ELSE OBJ.type_desc END
,	[object_name] = ISNULL (SS.name, OBJECT_NAME (PM.major_id))
FROM
	sys.database_principals RP
	INNER JOIN sys.database_permissions PM	ON (RP.principal_id = PM.grantee_principal_id)
	LEFT JOIN sys.schemas SS				ON (PM.major_id = SS.[schema_id])
	LEFT JOIN sys.objects OBJ				ON (PM.major_id = OBJ.[object_id])
WHERE
	RP.type_desc = 'DATABASE ROLE'
	AND PM.class_desc <> 'DATABASE'
ORDER BY
	RP.name
,	RP.type_desc
,	PM.class_desc
OPTION (RECOMPILE);
GO

--<08>-- LISTAR OS USUARIOS E OS TIPOS DE PERMISSOES NAS BASES DE DADOS.
USE [master]

DECLARE @dataname SYSNAME = 'AdventureWorks2014'	--> DATABASE NAME | NULL
DECLARE @username SYSNAME = NULL					--> USER NAME | NULL

IF @dataname IS NULL SET @dataname = '%%' ELSE SET @dataname = '%' + @dataname + '%';
IF @username IS NULL SET @username = '%%' ELSE SET @username = '%' + @username + '%';

DECLARE @DBUsers TABLE (
	dbName			SYSNAME
,	userName		SYSNAME
,	loginType		SYSNAME
,	associatedRole	VARCHAR (MAX)
,	create_date		DATETIME
,	modify_date		DATETIME
);

INSERT @DBUsers
EXEC sp_MSforeachdb '
USE [?]
SELECT
	''?'' AS dbName
,	CASE DP.name
		WHEN ''dbo'' THEN DP.name + '' ('' + (SELECT SUSER_NAME (owner_sid) FROM master.sys.databases WHERE name = ''?'') + '')''
		ELSE DP.name
	END AS userName
,	dp.type_desc AS loginType
,	ISNULL (RM.role_principal_id,'''') AS associatedRole
,	DP.create_date
,	DP.modify_date
FROM
	sys.database_principals DP
	LEFT OUTER JOIN sys.database_role_members RM ON (DP.principal_id = RM.member_principal_id)
WHERE
	DP.[sid] IS NOT NULL
	AND DP.[sid] NOT IN (0x00)
	AND DP.is_fixed_role <> 1
	AND DP.name NOT LIKE ''##%'''

SELECT
	dbName
,	userName
,	loginType
,	create_date
,	modify_date
,	STUFF ((SELECT ',' + CONVERT (VARCHAR (500), associatedRole) FROM @DBUsers user2 WHERE user1.dbName = user2.dbName AND user1.userName = user2.userName FOR XML PATH ('')), 1, 1, '') AS permissions_user	
FROM
	@DBUsers user1
WHERE
	user1.dbName LIKE @dataname
	AND user1.userName LIKE @username
GROUP BY
	dbName
,	userName
,	loginType
,	create_date
,	modify_date
ORDER BY
	dbName
,	userName
OPTION (RECOMPILE);
GO

--<09>-- LISTAR AS PERMISSOES POR OBJETOS DE UM USUARIO NA BASE DE DADOS.
USE [master]

DECLARE @dataname SYSNAME = 'AdventureWorks2014'	--> DATABASE NAME | NULL
DECLARE @username SYSNAME = NULL					--> USER NAME | NULL

IF @dataname IS NULL SET @dataname = '%%' ELSE SET @dataname = '%' + @dataname + '%';
IF @username IS NULL SET @username = '%%' ELSE SET @username = '%' + @username + '%';

DECLARE @DBUsers TABLE (
	dbName				SYSNAME
,	[schema]			VARCHAR (50)
,	[object]			VARCHAR (128)
,	permission_type		VARCHAR (128)
,	[permission_name]	VARCHAR (128)
,	permission_state	VARCHAR (128)
,	state_desc			VARCHAR (128)
,	permissionsql		VARCHAR (MAX)
,	userName			SYSNAME
,	loginType			SYSNAME
,	associatedRole		VARCHAR (MAX)
,	create_date			DATETIME
,	modify_date			DATETIME
);

INSERT @DBUsers
EXEC sp_MSforeachdb '
SELECT 
	DISTINCT ''?''
,	S.name
,	O.name
,	DP.[type]
,	DP.[permission_name]
,	DP.[state]
,	DP.state_desc
,	DP.state_desc + '' '' + DP.[permission_name] + '' ON ['' + S.name + ''].['' + O.name + ''] TO ['' + PR.name + '']'' COLLATE LATIN1_General_CI_AS
,	CASE PR.name
		WHEN ''dbo'' THEN PR.name + '' ('' + (SELECT DISTINCT SUSER_SNAME (owner_sid) FROM master.sys.databases WHERE name = ''?'') + '')''
		ELSE PR.name
	END
,	PR.type_desc
,	ISNULL (USER_NAME (DRM.role_principal_id), '''')
,	PR.create_date
,	PR.modify_date
FROM
	sys.database_permissions DP
	LEFT JOIN sys.objects O							ON (DP.major_id = O.[object_id])
	LEFT JOIN sys.schemas S							ON (O.[schema_id] = S.[schema_id])
	LEFT JOIN sys.database_principals PR			ON (DP.grantee_principal_id = PR.principal_id)
	LEFT OUTER JOIN sys.database_role_members DRM	ON (PR.principal_id = DRM.member_principal_id)
WHERE
	PR.[sid] IS NOT NULL
	AND PR.[sid] NOT IN (0x00)
	AND PR.is_fixed_role <> 1
	AND PR.name NOT LIKE ''##%''
ORDER BY
	1, 2, 3, 5'

SELECT
	dbName
,	userName
,	loginType
,	create_date
,	modify_date
,	[schema]
,	[object]
,	permission_type
,	[permission_name]
,	permission_state
,	state_desc
,	permissionsql
,	STUFF ((SELECT DISTINCT ',' + CONVERT (VARCHAR (500), associatedRole) FROM @DBUsers user2 WHERE user1.dbName = user2.dbName AND user1.userName = user2.userName FOR XML PATH ('')), 1, 1, '') AS permission_user
FROM
	@DBUsers user1
WHERE
	user1.dbName LIKE @dataname
	AND user1.userName LIKE @username
GROUP BY
	dbName
,	userName
,	loginType
,	create_date
,	modify_date
,	[schema]
,	[object]
,	permission_type
,	[permission_name]
,	permission_state
,	state_desc
,	permissionsql
ORDER BY
	user1.dbName
,	user1.userName
OPTION (RECOMPILE);
GO

--<10>-- LISTAR AS ROLES DOS USUARIOS NAS BASES DE DADOS.
USE [master]

DECLARE @user VARCHAR (50) = 'gioy'		--> USER NAME | NULL

IF @user IS NULL SET @user = '%%' ELSE SET @user = '%' + @user + '%';

CREATE TABLE #Users ([sid] VARBINARY (100) NULL, login_name SYSNAME);
CREATE TABLE #Acesso (userid VARCHAR (128), server_login VARCHAR (128), database_role VARCHAR (128), databasename VARCHAR (128));

DECLARE @stmt NVARCHAR (MAX)

SET @stmt = '
INSERT INTO #Users
SELECT L.[sid], L.loginname FROM syslogins L WHERE loginname LIKE ''' + @user + '''

INSERT INTO #Acesso
SELECT
	SU.name
,	U.login_name
,	SUG.name
,	''?''
FROM
	[?].dbo.sysusers SU
	LEFT OUTER JOIN #Users U ON (SU.[sid] = U.[sid])
	LEFT OUTER JOIN ([?].dbo.sysmembers SM INNER JOIN [?].dbo.sysusers SUG ON (SM.groupuid = SUG.[uid])) ON (SU.[uid] = SM.memberuid)
WHERE
	SU.hasdbaccess = 1
	AND SU.name <> ''dbo''
	AND SU.name LIKE ''' + @user + ''' '

EXEC sp_MSforeachdb @stmt;

SELECT DISTINCT userid, server_login, databasename, database_role FROM #Acesso ORDER BY userid, databasename;

DROP TABLE #Acesso;
DROP TABLE #Users;
GO