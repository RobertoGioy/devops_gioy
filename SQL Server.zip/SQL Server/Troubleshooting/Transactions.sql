/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR AS TRANSACOES ATIVAS.
 */

--<01>-- LISTAR AS TRANSACOES ATIVAS POR TEMPO DE EXECUCAO.
USE [master]

SELECT
	DB_NAME (R.database_id) AS database_name
,	R.session_id
,	AT.name AS command
,	CASE AT.transaction_type
		WHEN 1 THEN 'LEITURA E GRAVACAO'
		WHEN 2 THEN 'LEITURA'
		WHEN 3 THEN 'SISTEMICA'
		WHEN 4 THEN 'DISTRIBUIDA'
	END AS transaction_type
,	R.open_transaction_count
,	AT.transaction_begin_time
,	CASE AT.transaction_state
		WHEN 0 THEN 'EM PROCESSO DE ABERTURA'
		WHEN 1 THEN 'ABERTA MAS NAO INICIADA'
		WHEN 2 THEN 'ATIVA'
		WHEN 3 THEN 'ENCERRADA'
		WHEN 4 THEN 'TRANSACAO DISTRIBUIDA CONFIRMADA'
		WHEN 5 THEN 'AGUARDANDO RESOLUCAO'
		WHEN 6 THEN 'CONFIRMADA'
		WHEN 7 THEN 'EM PROCESSO DE REVERSAO'
		WHEN 8 THEN 'REVERTIDA'
	END AS transaction_state
,	CASE AT.dtc_state
		WHEN 0 THEN 'SEM DTC'
		WHEN 1 THEN 'ATIVA'
		WHEN 2 THEN 'PREPARADA'
		WHEN 3 THEN 'CONFIRMADA'
		WHEN 4 THEN 'ANULADA'
		WHEN 5 THEN 'RECUPERADA'
	END AS DTCState
,	QP.query_plan
FROM
	sys.dm_exec_requests R
	INNER JOIN sys.dm_tran_active_transactions AT ON (R.transaction_id = AT.transaction_id)
	CROSS APPLY sys.dm_exec_query_plan(R.plan_handle) QP
ORDER BY
	AT.transaction_begin_time
OPTION (RECOMPILE);
GO

--<02>-- LISTAR AS SESSOES COM TRANSACAO ABERTA.
USE [master]

SELECT
	database_name
,	spid
,	login_time
,	open_tran = SUM (open_tran)
,	cmd
,	[status]
,	nt_username
,	[program_name]
,	hostname
,	time_sec = DATEDIFF (SS, login_time, GETDATE ())
FROM (
	SELECT
		DB_NAME (P.dbid) AS database_name
	,	P.spid
	,	P.login_time
	,	P.open_tran
	,	P.cmd
	,	P.[status]
	,	P.nt_username
	,	P.[program_name]
	,	P.hostname
	FROM
		sys.sysprocesses P
) TB
WHERE
	open_tran > 0
GROUP BY
	database_name
,	spid
,	login_time
,	nt_username
,	[program_name]
,	hostname
,	cmd
,	[status]
ORDER BY
	login_time
OPTION (RECOMPILE);

--> DBCC INPUTBUFFER(spid) -- COLOCAR O SPID DESEJADO PARA CAPTURAR O COMANDO EXECUTADO.
GO

--<03>-- TESTAR USO DE TRANSACOES DISTRIBUIDAS. (FORMA DE VALIDAR DTC)
USE [master]

DECLARE @remoteServer SYSNAME = 'MSTPROD1'
DECLARE @stmt VARCHAR (255)

BEGIN DISTRIBUTED TRANSACTION

SET @stmt = 'SELECT TOP 1 * FROM ' + @remoteServer + 'master.sys.databases '
EXEC sp_executesql @stmt

COMMIT TRANSACTION

/*
--> TRATATIVA PARA CASOS ONDE A BASE FICA EM SUSPECT DEVIDO FALHA DE DTC

sp_configure 'show advanced options', 1
GO
RECONFIGURE
GO
sp_configure 'in-doubt xact resolution', 2	--> 0 = No action, 1 = presume commit, 2 = presume abort
GO
RECONFIGURE
GO
sp_configure 'show advanced options', 0
GO
RECONFIGURE
GO

*/
GO