Use Master;
GO

CREATE SERVER AUDIT [Audit_Logon] TO FILE
(
    FILEPATH=N'X:\Audit\',
    MAXSIZE = 200 MB,
    MAX_ROLLOVER_FILES = 30,
    RESERVE_DISK_SPACE = OFF
)
WITH (
    QUEUE_DELAY = 1000,
    ON_FAILURE = CONTINUE
);
ALTER SERVER AUDIT [Audit_Logon] WITH (STATE = ON);
GO

USE [DBNAME]
GO
CREATE DATABASE AUDIT SPECIFICATION [dbAuditSpec]
FOR SERVER AUDIT [Audit_Logon]
ADD (EXECUTE ON DATABASE::[DBNAME] BY [public]),
ADD (DELETE ON DATABASE::[DBNAME] BY [public]),
ADD (INSERT ON DATABASE::[DBNAME] BY [public]),
ADD (UPDATE ON DATABASE::[DBNAME] BY [public]),
ADD (SELECT ON DATABASE::[DBNAME] BY [public])
WITH (STATE = ON);
GO

--  LEITURA DO AUDIT
EXEC xp_cmdshell 'dir X:\Audit\';

SELECT * FROM sys.fn_get_audit_file ('X:\Audit\filename*.sqlaudit', default, default);