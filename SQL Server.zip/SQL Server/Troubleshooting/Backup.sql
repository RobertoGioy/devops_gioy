/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR BACKUPS E RESTORES
 */

--<01>-- CONSULTAR AS INFORMACOES DOS BACKUPS EFETUADOS.
USE [master]

DECLARE @banco SYSNAME = 'AdventureWorks2014';

SELECT TOP (30)		--> RESULTADO CONSOLIDADO
	BS.machine_name
,	BS.server_name
,	BS.[user_name]
,	BS.database_version
,	BS.database_name
,	BS.recovery_model
,	BS.collation_name
,	CONVERT (BIGINT, BS.backup_size / 1048576) AS backup_size_mb
,	CONVERT (BIGINT, BS.compressed_backup_size / 1048576) AS compressed_backup_size_mb
,	CONVERT (NUMERIC(20,2), (CONVERT (FLOAT, BS.backup_size) / CONVERT (FLOAT, BS.compressed_backup_size))) AS compression_ratio
,	BS.backup_start_date
,	BS.backup_finish_date
,	DATEDIFF (SS, BS.backup_start_date, BS.backup_finish_date) AS backup_elapse_time
FROM
	msdb..backupset BS
WHERE
	DATEDIFF (SS, BS.backup_start_date, BS.backup_finish_date) > 0
	AND BS.backup_size > 0
	AND BS.[type] = 'D'	--> D = FULL,	I = DIFERENCIAL,	L = TRANSACTION LOG
	AND BS.database_name = DB_NAME (DB_ID (@banco))
ORDER BY
	BS.backup_finish_date DESC
OPTION(RECOMPILE);

SELECT TOP (100)	--> RESULTADO DETALHADO
	ROW_NUMBER () OVER (PARTITION BY BS.backup_start_date ORDER BY BS.backup_set_id) AS NumArquivo
,	BS.server_name
,	BS.[user_name]
,	BS.database_version
,	BS.database_name
,	BS.recovery_model
,	BS.collation_name
,	BF.physical_device_name
,	CONVERT (BIGINT, BS.backup_size / 1048576) AS backup_size_mb
,	CONVERT (BIGINT, BS.compressed_backup_size / 1048576) AS compressed_backup_size_mb
,	BS.backup_start_date
,	BS.backup_finish_date
,	BS.first_lsn
,	BS.last_lsn
,	CASE BS.[type]
		WHEN 'D' THEN 'FULL'
		WHEN 'I' THEN 'DIFFERENCIAL'
		WHEN 'L' THEN 'TRANSACTION LOG'
	END AS backup_type
FROM
	msdb..backupset BS
	INNER JOIN msdb..backupmediafamily BF ON (BS.media_set_id = BF.media_set_id)
WHERE
	BS.database_name = DB_NAME (DB_ID (@banco))
	AND BS.[type] = 'D'	--> D = FULL,	I = DIFERENCIAL,	L = TRANSACTION LOG
ORDER BY
	BS.backup_start_date DESC
,	BS.backup_finish_date
OPTION (RECOMPILE);
GO

--<02>-- COPIAR BACKUPS NA REDE USANDO ROBOCOPY.
USE [master]

DECLARE @dbname SYSNAME
DECLARE @Origem NVARCHAR (400), @Destino NVARCHAR (400), @Source NVARCHAR (400), @Destination NVARCHAR (400)
DECLARE @File NVARCHAR (100), @Log NVARCHAR (100), @stmt VARCHAR (MAX), @OK BIT, @Day TINYINT

SET @Origem = 'F:\BACKUP\';
SET @Destino = '\\192.168.210.197\BACKUP\';
SET @File = '';
SELECT @Day = DATEPART (DW, GETDATE ());

IF @Day = 1	-- EFETUA COPIAS AOS DOMINGOS
BEGIN
	DECLARE CopyCursor CURSOR LOCAL FOR
	SELECT name FROM sys.databases WHERE name LIKE 'DB%' ORDER BY 1

	OPEN CopyCursor
	FETCH NEXT FROM CopyCursor INTO @dbname

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @Source = @Origem + @dbname + '\';
		SET @Destination = @Destino + @dbname + '\';
		SET @Log = @dbname + CONVERT (VARCHAR, GETDATE (), 112) + '.txt';

		SET @stmt = 'ROBOCOPY ' + @Source + @File + ' ' + @Destination + @File + ' /COPY:DAT /LOG+:' + @Source + @Log;

		EXEC @OK = xp_cmdshell @stmt

		FETCH NEXT FROM CopyCursor INTO @dbname
	END

	CLOSE CopyCursor;
	DEALLOCATE CopyCursor;
END
GO