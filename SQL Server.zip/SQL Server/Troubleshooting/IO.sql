/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR RECURSOS DE I/O.
 */

--<01>-- CAPTURAR ERROS DE DISK I/O.
USE [master]

DECLARE @field_name VARCHAR(30), @tmp VARCHAR(30)

IF (@@VERSION LIKE '%6.5%') OR (@@VERSION LIKE '%7.0%') BEGIN
	SELECT @field_name = 'suid'
	SELECT @tmp = 'suser_name (' + @field_name + ')'
END
ELSE BEGIN
	SELECT @field_name = 'sid'
	SELECT @tmp = 'suser_name (' + @field_name + ')'
END

SELECT 'Total I/O Errors' = @@TOTAL_ERRORS;
SELECT 'Physical I/O Usage';

EXECUTE ('
SELECT
	"Server Login Name" = SUBSTRING (' + @tmp + ', 1, 15)
,	P.spid
,	CONVERT (VARCHAR(30), P.[status]) AS [status]
,	CASE CHARINDEX (CHAR(0), CONVERT (CHAR(16), P.cmd))
		WHEN 0 THEN CONVERT (CHAR(16), P.cmd)
		ELSE CONVERT (CHAR(16), SUBSTRING (P.cmd, 1, CHARINDEX (CHAR(0), CONVERT (CHAR(16), P.cmd)) -1))
	END AS CMD
,	P.physical_io
FROM
	sys.sysprocesses P
ORDER BY
	' + @field_name + ' COMPUTE SUM (P.physical_io) BY ' + @field_name + ' COMPUTE SUM (P.physical_io)'
);
GO

--<02>-- CAPTURAR REQUISICOES DE I/O COM MAIS DE 15 SEGUNDOS DESCRITOS NO LOG DE ERRO
USE [master]

CREATE TABLE #IOWarningResults (logdate DATETIME, processInfo SYSNAME, logText NVARCHAR(1000));

INSERT INTO #IOWarningResults
EXEC xp_readerrorlog 0, 1, N'taking longer than 15 seconds';
INSERT INTO #IOWarningResults
EXEC xp_readerrorlog 1, 1, N'taking longer than 15 seconds';
INSERT INTO #IOWarningResults
EXEC xp_readerrorlog 2, 1, N'taking longer than 15 seconds';
INSERT INTO #IOWarningResults
EXEC xp_readerrorlog 3, 1, N'taking longer than 15 seconds';
INSERT INTO #IOWarningResults
EXEC xp_readerrorlog 4, 1, N'taking longer than 15 seconds';

SELECT * FROM #IOWarningResults ORDER BY logdate DESC;

DROP TABLE #IOWarningResults;
GO

--<03>-- CONSULTAR O NIVEL DE LATENCIA (MS) DE LEITURA E ESCRITA NOS DISCOS. VALORES ACIMA DE 20-25 MS E PROBLEMA.
USE [master]

SELECT 
	T.Drive
,	CASE WHEN T.total_reads = 0 THEN 0 ELSE (T.total_io_stall_read_ms / T.total_reads) END AS read_latency
,	CASE WHEN T.total_io_stall_write_ms = 0 THEN 0 ELSE (T.total_io_stall_write_ms / t.total_writes) END AS write_latency
,	CASE WHEN T.total_reads = 0 AND T.total_writes = 0 THEN 0 ELSE T.total_io_stall / (T.total_reads + T.total_writes) END AS overall_latency
,	CASE WHEN T.total_reads = 0 THEN 0 ELSE (T.total_bytes_read / T.total_reads) END AS avg_bytes_read
,	CASE WHEN T.total_io_stall_write_ms = 0 THEN 0 ELSE (T.total_bytes_written / T.total_writes) END AS avg_bytes_write
,	CASE WHEN T.total_reads = 0 AND T.total_writes = 0 THEN 0 ELSE (T.total_bytes_read + T.total_bytes_written) / (T.total_reads + T.total_writes) END AS avg_bytes_transfer
FROM (
	SELECT 
		LEFT (UPPER (MF.physical_name), 2) AS Drive
	,	SUM (VFS.num_of_reads) AS total_reads
	,	SUM (VFS.io_stall_read_ms) AS total_io_stall_read_ms
	,	SUM (VFS.num_of_writes) AS total_writes
	,	SUM (VFS.io_stall_write_ms) AS total_io_stall_write_ms
	,	SUM (VFS.num_of_bytes_read) AS total_bytes_read
	,	SUM (VFS.num_of_bytes_written) AS total_bytes_written
	,	SUM (VFS.io_stall) AS total_io_stall
	FROM
		sys.dm_io_virtual_file_stats(NULL, NULL) VFS
		INNER JOIN sys.master_files MF ON (VFS.database_id = MF.database_id AND VFS.[file_id] = MF.[file_id])
	GROUP BY
		LEFT (UPPER (MF.physical_name), 2)
) AS T
ORDER BY
	overall_latency
OPTION (RECOMPILE);
GO

--<04>-- CALCULAR A MEDIA DE LATENCIA (MS) DE ESCRITA E LEITURA (INPUT/OUTPUT), POR ARQUIVO DE DADOS E LOG.
USE [master]

/*
 * AJUDA A DETERMINAR QUAIS ARQUIVOS DO BANCO DE DADOS POSSUI MAIOR GARGALO DE I/O
 * AJUDA A DECIDIR SE DETERMINADAS LUNS EST�O SOBRECARREGADAS
 */
SELECT
	DB_NAME (VFS.database_id) AS database_name
,	CAST (VFS.io_stall_read_ms / (1.0 + VFS.num_of_reads) AS NUMERIC(10,1)) AS avg_read_stall_ms
,	CAST (VFS.io_stall_write_ms / (1.0 + VFS.num_of_writes) AS NUMERIC(10,1)) AS avg_write_stall_ms
,	CAST ((VFS.io_stall_read_ms + VFS.io_stall_write_ms) / (VFS.num_of_reads + VFS.num_of_writes) AS NUMERIC(10,1)) AS avg_io_stall_ms
,	CONVERT (DECIMAL(18,2), MF.size / 128.0) AS file_size_mb
,	MF.physical_name
,	MF.type_desc
,	VFS.io_stall_read_ms
,	VFS.num_of_reads
,	VFS.io_stall_write_ms
,	VFS.num_of_writes
,	VFS.io_stall_read_ms + VFS.io_stall_write_ms AS io_stall
,	VFS.num_of_reads + VFS.num_of_writes AS total_io
FROM
	sys.dm_io_virtual_file_stats (NULL, NULL) VFS
	INNER JOIN sys.master_files MF ON (VFS.database_id = MF.database_id AND VFS.[file_id] = MF.[file_id])
ORDER BY
	avg_io_stall_ms DESC
OPTION (RECOMPILE);
GO

--<05>-- COLETAR AS ESTATISTICAS DE I/O DA BASE DE DADOS.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

SELECT
	DB_NAME (VFS.database_id) AS database_name
,	DF.name AS logical_name
,	VFS.[file_id]
,	DF.physical_name
,	VFS.num_of_reads
,	VFS.num_of_writes
,	VFS.io_stall_read_ms
,	VFS.io_stall_write_ms
,	CAST (100. * (VFS.io_stall_read_ms / (VFS.io_stall_read_ms + VFS.io_stall_write_ms)) AS DECIMAL(10,2)) AS io_stall_read_pct
,	CAST (100. * (VFS.io_stall_write_ms / (VFS.io_stall_write_ms + VFS.io_stall_read_ms)) AS DECIMAL(10,2)) AS io_stall_write_pct
,	(VFS.num_of_reads + VFS.num_of_writes) AS total_io
,	CAST (VFS.num_of_bytes_read / 1048576.0 AS DECIMAL(10,2)) AS reads_mb
,	CAST (VFS.num_of_bytes_written / 1048576.0 AS DECIMAL(10,2)) AS writes_mb
,	CAST (100. * (VFS.num_of_reads / (VFS.num_of_reads + VFS.num_of_writes)) AS DECIMAL(10,2)) AS reads_pct
,	CAST (100. * (VFS.num_of_writes / (VFS.num_of_writes + VFS.num_of_reads)) AS DECIMAL(10,2)) AS writes_pct
,	CAST (100. * (VFS.num_of_bytes_read / (VFS.num_of_bytes_read + VFS.num_of_bytes_written)) AS DECIMAL(10,2)) AS read_bytes_pct
,	CAST (100. * (VFS.num_of_bytes_written / (VFS.num_of_bytes_written + VFS.num_of_bytes_read)) AS DECIMAL(10,2)) AS write_bytes_pct
FROM
	sys.dm_io_virtual_file_stats(DB_ID(@dbname), NULL) VFS
	INNER JOIN sys.database_files DF ON	(VFS.[file_id] = DF.[file_id])
OPTION (RECOMPILE);
GO

--<06>-- LISTAR AS TOP 10 SESSOES COM MAIOR ALOCACAO DE PAGINAS.
USE [master]

SELECT TOP (10)
	SU.session_id
,	DB_NAME (ER.database_id) AS database_name
,	ES.[host_name]
,	ES.login_name
,	ES.[program_name]
,	((SU.user_objects_alloc_page_count + SU.internal_objects_alloc_page_count) * 1.0/128) AS mb_alocado
,	ST.[text]
,	QP.query_plan
,	ER.plan_handle
FROM
	sys.dm_db_session_space_usage SU
	INNER JOIN sys.dm_exec_sessions ES		ON (SU.session_id = ES.session_id)
	INNER JOIN sys.dm_exec_connections EC	ON (ES.session_id = EC.session_id)
	INNER JOIN sys.dm_exec_requests ER		ON (SU.session_id = ER.session_id AND EC.session_id = ER.session_id)
	CROSS APPLY sys.dm_exec_sql_text (EC.most_recent_sql_handle) ST
	CROSS APPLY sys.dm_exec_query_plan (ER.plan_handle) QP
WHERE
	ER.group_id > 1
	AND (SU.user_objects_alloc_page_count + SU.internal_objects_alloc_page_count) * 1.0/128 > 100	-- OCUPAM MAIS DE 100 MB
ORDER BY
	mb_alocado DESC
OPTION (RECOMPILE);
GO

--<07>-- LISTAR A UTILIZACAO DE I/0 POR BASE DE DADOS.
USE [master]

SET NOCOUNT ON;

WITH IO_Statistics AS (
	SELECT
		DB_NAME (VFS.database_id) AS database_name
	,	CAST (SUM ((VFS.num_of_reads + VFS.num_of_writes) / 1048576) AS DECIMAL(12,2)) AS io_mb
	FROM
		sys.dm_io_virtual_file_stats (NULL, NULL) VFS
	GROUP BY
		DB_NAME (VFS.database_id)
)
SELECT
	ROW_NUMBER () OVER (ORDER BY S.io_mb DESC) AS io_rank
,	S.database_name
,	S.io_mb
,	CAST (S.io_mb / SUM (S.io_mb) OVER () * 100.0 AS DECIMAL(12,2)) AS io_pct
FROM
	IO_Statistics S
ORDER BY
	io_rank
OPTION (RECOMPILE);
GO