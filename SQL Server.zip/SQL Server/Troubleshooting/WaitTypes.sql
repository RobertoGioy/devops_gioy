/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR WAIT TYPES.
 */

--<01>-- COLETAR AS ESTATISTICAS DOS WAIT TYPES DESDE A ULTIMA REINICIALIZACAO DO SQL SERVER.
USE [master]

SET NOCOUNT ON;

WITH [Waits] AS (
	SELECT
		wait_type				= WS.wait_type
	,	wait_time_sec			= WS.wait_time_ms / 1000.0
	,	resource_sec			= (WS.wait_time_ms - WS.signal_wait_time_ms) / 1000.0
	,	signal_wait_time_sec	= WS.signal_wait_time_ms / 1000.0 
	,	waiting_tasks_count		= WS.waiting_tasks_count
	,	wait_time_pct			= 100.0 * WS.wait_time_ms / SUM (WS.wait_time_ms) OVER ()
	,	row_num					= ROW_NUMBER () OVER (ORDER BY WS.wait_time_ms DESC)
	FROM
		sys.dm_os_wait_stats WS WITH(NOLOCK)
	WHERE
		WS.wait_type NOT IN (
		N'BROKER_EVENTHANDLER', N'BROKER_RECEIVE_WAITFOR', N'BROKER_TASK_STOP',
		N'BROKER_TO_FLUSH',	N'BROKER_TRANSMITTER', N'CHECKPOINT_QUEUE',
		N'CHKPT', N'CLR_AUTO_EVENT', N'CLR_MANUAL_EVENT', N'CLR_SEMAPHORE',
		N'DBMIRROR_DBM_EVENT', N'DBMIRROR_EVENTS_QUEUE', N'DBMIRROR_WORKER_QUEUE',
		N'DBMIRRORING_CMD', N'DIRTY_PAGE_POOL', N'DISPATCHER_QUEUE_SEMAPHORE',
		N'EXECSYNC', N'FSAGENT', N'FT_IFTS_SCHEDULER_IDLE_WAIT', N'FT_IFSHC_MUTEX',
		N'HADR_CLUSAPI_CALL', N'HADR_FILESTREAM_IOMGR_IOCOMPLETION', N'HADR_LOGCAPTURE_WAIT',
		N'HADR_NOTIFICATION_DEQUEUE', N'HADR_TIMER_TASK', N'HADR_WORK_QUEUE', N'KSOURCE_WAKEUP',
		N'LAZYWRITER_SLEEP', N'LOGMGR_QUEUE', N'ONDEMAND_TASK_QUEUE', N'PWAIT_ALL_COMPONENTS_INITIALIZED',
		N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP', N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP',
		N'REQUEST_FOR_DEADLOCK_SEARCH', N'RESOURCE_QUEUE', N'SERVER_IDLE_CHECK', N'SLEEP_BPOOL_FLUSH',
		N'SLEEP_DBSTARTUP', N'SLEEP_DCOMSTARTUP', N'SLEEP_MASTERDBREADY', N'SLEEP_MASTERMDREADY',
		N'SLEEP_MASTERUPGRADED', N'SLEEP_MSDBSTARTUP', N'SLEEP_SYSTEMTASK',
		N'SLEEP_TASK', N'SLEEP_TEMPDBSTARTUP', N'SNI_HTTP_ACCEPT', N'SP_SERVER_DIAGNOSTIC_SLEEP',
		N'SQLTRACE_BUFFER_FLUSH', N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',
		N'SQLTRACE_WAIT_ENTRIES', N'WAIT_FOR_RESULTS', N'WAITFOR', N'WAITFOR_TASKSHUTDOWN',
		N'WAIT_XTP_HOST_WAIT', N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG', N'WAIT_XTP_CKPT_CLOSE',
		N'XE_DISPATCHER_WAIT', N'XE_DISPATCHER_JOIN', N'XE_TIMER_EVENT')
	AND WS.waiting_tasks_count > 0
)
SELECT 
	wait_type = W1.wait_type
,	wait_time_sec			= CAST (MAX (W1.wait_time_sec) AS DECIMAL(16,2))
,	resource_sec			= CAST (MAX (W1.resource_sec) AS DECIMAL(16,2))
,	signal_wait_time_sec	= CAST( MAX (W1.signal_wait_time_sec) AS DECIMAL(16,2))
,	waiting_tasks_count		= MAX (W1.waiting_tasks_count)
,	wait_type_pct			= CAST(MAX (W1.wait_time_pct) AS DECIMAL(5,2))
,	avg_wait_sec			= CAST ((MAX (W1.wait_time_pct) / MAX (W1.waiting_tasks_count)) AS DECIMAL(16,4))
,	avg_resource_sec		= CAST ((MAX (W1.resource_sec) / MAX (W1.waiting_tasks_count)) AS DECIMAL(16,4))
,	avg_signal_sec			= CAST ((MAX (W1.signal_wait_time_sec) / MAX (W1.waiting_tasks_count)) AS DECIMAL(16,4))
FROM
	Waits W1 INNER JOIN Waits W2 ON (W1.row_num = W2.row_num)
GROUP BY
	W1.row_num
HAVING
	SUM (W2.wait_time_pct) - MAX (W1.wait_time_pct) < 99	--PERCENTAGE THRESHOLD
OPTION (RECOMPILE);

/*
 * SIGNAL WAITS ACIMA DE 10-15% GERALMENTE E UM SINAL DE CONFIRMACAO DE PRESSAO DE CPU.
 * https://msdn.microsoft.com/pt-br/library/ms179984.aspx
 */

SELECT
	CAST (100.0 * SUM (WS.signal_wait_time_ms) / SUM (WS.wait_time_ms) AS NUMERIC(20,2)) AS [% Signal (CPU) Waits]
,	CAST (100.0 * SUM (WS.wait_time_ms - WS.signal_wait_time_ms) / SUM (WS.wait_time_ms) AS NUMERIC(20,2)) AS [% Resource Waits]
FROM
	sys.dm_os_wait_stats WS WITH (NOLOCK)
WHERE
	WS.wait_type NOT IN (
	N'BROKER_EVENTHANDLER', N'BROKER_RECEIVE_WAITFOR', N'BROKER_TASK_STOP',
	N'BROKER_TO_FLUSH',	N'BROKER_TRANSMITTER', N'CHECKPOINT_QUEUE',
	N'CHKPT', N'CLR_AUTO_EVENT', N'CLR_MANUAL_EVENT', N'CLR_SEMAPHORE',
	N'DBMIRROR_DBM_EVENT', N'DBMIRROR_EVENTS_QUEUE', N'DBMIRROR_WORKER_QUEUE',
	N'DBMIRRORING_CMD', N'DIRTY_PAGE_POOL', N'DISPATCHER_QUEUE_SEMAPHORE',
	N'EXECSYNC', N'FSAGENT', N'FT_IFTS_SCHEDULER_IDLE_WAIT', N'FT_IFSHC_MUTEX',
	N'HADR_CLUSAPI_CALL', N'HADR_FILESTREAM_IOMGR_IOCOMPLETION', N'HADR_LOGCAPTURE_WAIT',
	N'HADR_NOTIFICATION_DEQUEUE', N'HADR_TIMER_TASK', N'HADR_WORK_QUEUE', N'KSOURCE_WAKEUP',
	N'LAZYWRITER_SLEEP', N'LOGMGR_QUEUE', N'ONDEMAND_TASK_QUEUE', N'PWAIT_ALL_COMPONENTS_INITIALIZED',
	N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP', N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP',
	N'REQUEST_FOR_DEADLOCK_SEARCH', N'RESOURCE_QUEUE', N'SERVER_IDLE_CHECK', N'SLEEP_BPOOL_FLUSH',
	N'SLEEP_DBSTARTUP', N'SLEEP_DCOMSTARTUP', N'SLEEP_MASTERDBREADY', N'SLEEP_MASTERMDREADY',
	N'SLEEP_MASTERUPGRADED', N'SLEEP_MSDBSTARTUP', N'SLEEP_SYSTEMTASK',
	N'SLEEP_TASK', N'SLEEP_TEMPDBSTARTUP', N'SNI_HTTP_ACCEPT', N'SP_SERVER_DIAGNOSTIC_SLEEP',
	N'SQLTRACE_BUFFER_FLUSH', N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',
	N'SQLTRACE_WAIT_ENTRIES', N'WAIT_FOR_RESULTS', N'WAITFOR', N'WAITFOR_TASKSHUTDOWN',
	N'WAIT_XTP_HOST_WAIT', N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG', N'WAIT_XTP_CKPT_CLOSE',
	N'XE_DISPATCHER_WAIT', N'XE_DISPATCHER_JOIN', N'XE_TIMER_EVENT')
OPTION (RECOMPILE);
GO

--<02>-- CONSULTAR BLOQUEIOS ATIVOS (LOCKS) POR BASE DE DADOS.
USE [master]

SELECT
	db.name AS database_name
,	tl.request_session_id
,	wt.blocking_session_id
,	OBJECT_NAME (p.[object_id]) AS blocked_object_name
,	tl.resource_type
,	st1.[text] AS requesting_text
,	st2.[text] AS blocking_text
,	tl.request_mode
FROM
	sys.dm_tran_locks tl
	INNER JOIN sys.databases db				ON (tl.resource_database_id = db.database_id)
	INNER JOIN sys.dm_os_waiting_tasks wt	ON (tl.lock_owner_address = wt.resource_address)
	INNER JOIN sys.partitions p				ON (p.hobt_id = tl.resource_associated_entity_id)
	INNER JOIN sys.dm_exec_connections ec1	ON (tl.request_session_id = ec1.session_id)
	INNER JOIN sys.dm_exec_connections ec2	ON (wt.blocking_session_id = ec2.session_id)
	CROSS APPLY sys.dm_exec_sql_text(ec1.most_recent_sql_handle) st1
	CROSS APPLY sys.dm_exec_sql_text(ec2.most_recent_sql_handle) st2
OPTION (RECOMPILE);
GO

--<03>-- CONSULTAR WAIT TYPES GLOBAIS E COMPARAR COM OS WAIT TYPES DO MOMENTO.
USE [master]

SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#ignorable_waits') IS NOT NULL
	DROP TABLE #ignorable_waits;

CREATE TABLE #ignorable_waits (wait_type NVARCHAR(256) PRIMARY KEY);

INSERT INTO #ignorable_waits (wait_type) VALUES ('REQUESTS_FOR_DEADLOCK_SEARCH');
INSERT INTO #ignorable_waits (wait_type) VALUES ('SQLTRACE_INCREMENTAL_FLUSH_SLEEP');
INSERT INTO #ignorable_waits (wait_type) VALUES ('SQLTRACE_BUFFER_FLUSH');
INSERT INTO #ignorable_waits (wait_type) VALUES ('LAZYWRITER_SLEEP');
INSERT INTO #ignorable_waits (wait_type) VALUES ('XE_TIMER_EVENT');
INSERT INTO #ignorable_waits (wait_type) VALUES ('XE_DISPATCHER_WAIT');
INSERT INTO #ignorable_waits (wait_type) VALUES ('FT_IFTS_SCHEDULER_IDLE_WAIT');
INSERT INTO #ignorable_waits (wait_type) VALUES ('LOGMGR_QUEUE');
INSERT INTO #ignorable_waits (wait_type) VALUES ('CHECKPOINT_QUEUE');
INSERT INTO #ignorable_waits (wait_type) VALUES ('BROKER_TO_FLUSH');
INSERT INTO #ignorable_waits (wait_type) VALUES ('BROKER_TASK_STOP');
INSERT INTO #ignorable_waits (wait_type) VALUES ('BROKER_EVENTHANDLER');
INSERT INTO #ignorable_waits (wait_type) VALUES ('SLEEP_TASK');
INSERT INTO #ignorable_waits (wait_type) VALUES ('WAITFOR');
INSERT INTO #ignorable_waits (wait_type) VALUES ('DBMIRROR_DBM_MUTEX');
INSERT INTO #ignorable_waits (wait_type) VALUES ('DBMIRROR_EVENTS_QUEUE');
INSERT INTO #ignorable_waits (wait_type) VALUES ('DBMIRRORING_CMD');
INSERT INTO #ignorable_waits (wait_type) VALUES ('DISPATCHER_QUEUE_SEMAPHORE');
INSERT INTO #ignorable_waits (wait_type) VALUES ('BROKER_RECEIVE_WAITFOR');
INSERT INTO #ignorable_waits (wait_type) VALUES ('CLR_AUTO_EVENT');
INSERT INTO #ignorable_waits (wait_type) VALUES ('CLR_MANUAL_EVENT');
INSERT INTO #ignorable_waits (wait_type) VALUES ('DIRTY_PAGE_POOL');
INSERT INTO #ignorable_waits (wait_type) VALUES ('HADR_FILESTREAM_IOMGR_IOCOMPLETION');
INSERT INTO #ignorable_waits (wait_type) VALUES ('ONDEMAND_TASK_QUEUE');
INSERT INTO #ignorable_waits (wait_type) VALUES ('FT_IFTSHC_MUTEX');
INSERT INTO #ignorable_waits (wait_type) VALUES ('SP_SERVER_DIAGNOSTICS_SLEEP');
INSERT INTO #ignorable_waits (wait_type) VALUES ('QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP');
INSERT INTO #ignorable_waits (wait_type) VALUES ('QDS_PERSIST_TASK_MAIN_LOOP_SLEEP');

SELECT TOP 25 
	ws.wait_type
,	SUM (ws.wait_time_ms) OVER (PARTITION BY ws.wait_type) AS sum_wait_time_ms
,	CAST (100.0 * SUM (ws.wait_time_ms) OVER (PARTITION BY ws.wait_type) / (1. * SUM (ws.wait_time_ms) OVER ()) AS NUMERIC(12,1)) AS pct_wait_time
,	SUM (ws.waiting_tasks_count) OVER (PARTITION BY ws.wait_type) AS sum_waiting_tasks
,	CASE
		WHEN SUM (ws.waiting_tasks_count) OVER (PARTITION BY ws.wait_type) > 0
			THEN CAST (SUM (ws.wait_time_ms) OVER (PARTITION BY ws.wait_type) / (1. * SUM (ws.waiting_tasks_count) OVER (PARTITION BY ws.wait_type)) AS NUMERIC(12,1))
		ELSE 0
	END AS avg_wait_time_ms
,	CURRENT_TIMESTAMP AS sample_time
FROM
	sys.dm_os_wait_stats ws
	LEFT JOIN #ignorable_waits iw ON (WS.wait_type = iw.wait_type)
WHERE
	iw.wait_type IS NULL
ORDER BY
	sum_wait_time_ms DESC
OPTION (RECOMPILE);

--> LISTA MAIORES ESPERAS NO MOMENTO
IF OBJECT_ID ('tempdb..#wait_batches') IS NOT NULL
	DROP TABLE #wait_batches;
IF OBJECT_ID ('tempdb..#wait_data') IS NOT NULL
	DROP TABLE #wait_data;

CREATE TABLE #wait_batches (
	batch_id INT IDENTITY PRIMARY KEY NOT NULL
,	sample_time DATETIME NOT NULL
);

CREATE TABLE #wait_data (
	batch_id INT NOT NULL
,	wait_type NVARCHAR (256) NOT NULL
,	wait_time_ms BIGINT NOT NULL
,	waiting_tasks BIGINT NOT NULL
);
CREATE CLUSTERED INDEX cx_wait_data ON #wait_data(batch_id);

--> USA PROCEDURE TEMPORARIA PARA GRAVAR OS WAITS
IF OBJECT_ID ('tempdb..#get_wait_data') IS NOT NULL
	DROP PROCEDURE #get_wait_data
GO
CREATE PROCEDURE #get_wait_data
	@intervals TINYINT
,	@delay CHAR(12) = '00:00:30.000' -- 30 SECONDS
AS
DECLARE @batch_id INT
	,	@current_interval TINYINT
	,	@msg NVARCHAR (MAX)

SET NOCOUNT ON;
SET @current_interval = 1;

WHILE @current_interval <= @intervals
BEGIN
	INSERT #wait_batches (sample_time)
	SELECT CURRENT_TIMESTAMP;
	SELECT @batch_id = SCOPE_IDENTITY ();

	INSERT #wait_data (
		batch_id
	,	wait_type
	,	wait_time_ms
	,	waiting_tasks
	)
	SELECT
		@batch_id
	,	ws.wait_type
	,	SUM (ws.wait_time_ms) OVER (PARTITION BY ws.wait_type) AS sum_wait_time_ms
	,	SUM (ws.waiting_tasks_count) OVER (PARTITION BY ws.wait_type) AS sum_waiting_tasks
	FROM
		sys.dm_os_wait_stats ws 
		LEFT JOIN #ignorable_waits iw ON (ws.wait_type = iw.wait_type)
	WHERE
		iw.wait_type IS NULL
	ORDER BY
		sum_wait_time_ms DESC;

	SET @msg = CONVERT (CHAR(23), CURRENT_TIMESTAMP, 121) + N': Completed sample ' + CAST (@current_interval AS NVARCHAR(4)) + N' of ' + CAST (@intervals AS NVARCHAR(4)) + '.';
	RAISERROR(@msg, 0, 1);

	SET @current_interval += 1;

	IF @current_interval <= @intervals
		WAITFOR DELAY @delay;
END
GO

--> GERA DUAS AMOSTRAS DE 30 SEGUNDOS CADA
EXEC #get_wait_data @intervals = 2, @delay = '00:00:30.000';
GO

WITH max_batch AS (SELECT TOP 1 batch_id, sample_time FROM #wait_batches ORDER BY batch_id DESC)
SELECT
	second_sample_time	= b.sample_time
,	sample_duration_sec = DATEDIFF (SS, wb.sample_time, b.sample_time)
,	wait_type			= wd1.wait_type
,	wait_time_sec		= CAST ((wd2.wait_time_ms - wd1.wait_time_ms) / 1000. AS NUMERIC(12,1))
,	wait_count			= (wd2.waiting_tasks - wd1.waiting_tasks)
FROM
	max_batch b
	JOIN #wait_data wd2		ON (b.batch_id = wd2.batch_id)
	JOIN #wait_data wd1		ON (wd1.wait_type = wd2.wait_type AND wd1.batch_id = wd2.batch_id)
	JOIN #wait_batches wb	ON (wd1.batch_id = wb.batch_id)
WHERE
	(wd2.waiting_tasks - wd1.waiting_tasks) > 0
ORDER BY
	wait_time_sec DESC
OPTION (RECOMPILE);
GO