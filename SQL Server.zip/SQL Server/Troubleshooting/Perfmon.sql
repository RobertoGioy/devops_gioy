/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR OS CONTADORES DE PERFORMANCE DO SQL SERVER.
 */

 --<01>-- CAPTURAR VALORES DOS CONTADORES PADRAO DO SQL SERVER E DE BASES DE DADOS.
 USE [master]

 DECLARE @instance_name VARCHAR (50) = 'AdventureWorks2014'

 DECLARE  
	@SQLProcessUtilization INT, @PageReadsPerSecond BIGINT, @PageWritesPerSecond BIGINT, @CheckpointPagesPerSecond BIGINT
,	@LazyWritesPerSecond BIGINT, @BatchRequestsPerSecond BIGINT, @CompilationsPerSecond BIGINT, @RecompilationsPerSecond BIGINT
,	@PageLookupsPerSecond BIGINT, @TransactionsPerSecond BIGINT, @LockWaitsPerSecond BIGINT, @PageSplitsPerSecond BIGINT
,	@ReadaheadPagesPerSecond BIGINT, @LatchWaitsPerSecond BIGINT, @LoginsPerSecond BIGINT, @ConnectionResetPerSecond BIGINT
,	@LogoutsPerSecond BIGINT, @TableLockEscalationPerSecond BIGINT, @FreeSpaceScanPerSecond BIGINT, @TransactionDBPerSecond BIGINT
,	@LogCacheReadsPerSecond BIGINT, @BulkCopyRowsPerSecond BIGINT, @BulkCopyThroughputPerSecond BIGINT, @BackupRestoreTroughputPerSecond BIGINT
,	@DBCCLogicalScanBytesPerSecond BIGINT, @ShrinkDataBytesPerSecond BIGINT, @LogFlushPerSecond BIGINT, @LogBytesFlushedPerSecond BIGINT
,	@LogFlushWaitsPerSecond BIGINT, @TrackedTransactionsPerSecond BIGINT, @WriteTransactionsPerSecond BIGINT, @WorkFilesCreatedPerSecond BIGINT
,	@WorkTablesCreatedPerSecond BIGINT, @LockRequestsPerSecond BIGINT, @LockTimeoutsPerSecond BIGINT, @DeadlocksPerSecond BIGINT
,	@stat_date DATETIME

-- TABLE FOR FIRST SAMPLE
DECLARE @RatioStatsX TABLE (
	[object_name]	VARCHAR (128)
,	[counter_name]	VARCHAR (128)
,	[instance_name] VARCHAR (128)
,	[cntr_value]	BIGINT
,	[cntr_type]		INT
);

-- TABLE FOR SECOND SAMPLE
DECLARE @RatioStatsY TABLE (
	[object_name]	VARCHAR (128)
,	[counter_name]	VARCHAR (128)
,	[instance_name] VARCHAR (128)
,	[cntr_value]	BIGINT
,	[cntr_type]		INT
);

INSERT INTO @RatioStatsX (
	[object_name]
,	[counter_name]
,	[instance_name]
,	[cntr_value]
,	[cntr_type])
SELECT
	[object_name]
,	[counter_name]
,	[instance_name]
,	[cntr_value]
,	[cntr_type]
FROM
	sys.dm_os_performance_counters;

SET @stat_date = GETDATE ();

-- FIRST SAMPLE PERFMON SQL SERVER
SELECT TOP 1
	@PageReadsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Page reads/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END;

SELECT TOP 1
	@PageWritesPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Page writes/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END;

SELECT TOP 1
	@CheckpointPagesPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Checkpoint pages/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END;

SELECT TOP 1
	@LazyWritesPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Lazy writes/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END;

SELECT TOP 1
	@PageLookupsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Page lookups/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END;

SELECT TOP 1
	@ReadaheadPagesPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Readahead pages/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END;

SELECT TOP 1
	@BatchRequestsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Batch Requests/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:SQL Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':SQL Statistics' END;

SELECT TOP 1
	@CompilationsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'SQL Compilations/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:SQL Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':SQL Statistics' END;

SELECT TOP 1
	@RecompilationsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'SQL Re-Compilations/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:SQL Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':SQL Statistics' END;

SELECT TOP 1
	@TransactionsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Transactions/sec'
AND	instance_name = '_Total'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END;

SELECT TOP 1
	@LockWaitsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Lock Waits/sec'
AND	instance_name = '_Total'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Locks' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Locks' END;

SELECT TOP 1
	@LockRequestsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Lock Requests/sec'
AND	instance_name = '_Total'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Locks' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Locks' END;

SELECT TOP 1
	@LockTimeoutsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Lock Timeouts/sec'
AND	instance_name = '_Total'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Locks' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Locks' END;

SELECT TOP 1
	@DeadlocksPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Number of Deadlocks/sec'
AND	instance_name = '_Total'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Locks' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Locks' END;

SELECT TOP 1
	@LatchWaitsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Latch Waits/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Latches' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Latches' END;

SELECT TOP 1
	@PageSplitsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Page Splits/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Access Method' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Access Method' END;

SELECT TOP 1
	@TableLockEscalationPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Table Lock Escalations/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Access Method' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Access Method' END;

SELECT TOP 1
	@FreeSpaceScanPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'FreeSpace Scans/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Access Method' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Access Method' END;

SELECT TOP 1
	@WorkFilesCreatedPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Workfiles Created/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Access Method' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Access Method' END;

SELECT TOP 1
	@WorkTablesCreatedPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Worktables Created/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Access Method' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Access Method' END;

SELECT TOP 1
	@LoginsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Logins/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:General Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':General Statistics' END;

SELECT TOP 1
	@ConnectionResetPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Connection Reset/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:General Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':General Statistics' END;

SELECT TOP 1
	@LogoutsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Logouts/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:General Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':General Statistics' END;

-- FISRT SAMPLE PERFMON DATABASE
SELECT TOP 1
	@TransactionDBPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Transactions/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

SELECT TOP 1
	@LogCacheReadsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Log Cache Reads/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

SELECT TOP 1
	@BulkCopyRowsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Bulk Copy Rows/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

SELECT TOP 1
	@BulkCopyThroughputPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Bulk Copy Throughput/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

SELECT TOP 1
	@BackupRestoreTroughputPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Backup/Restore Throughput/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

SELECT TOP 1
	@DBCCLogicalScanBytesPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'DBCC Logical Scan Bytes/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

SELECT TOP 1
	@ShrinkDataBytesPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Shrink Data Movement Bytes/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

SELECT TOP 1
	@LogFlushPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Log Flushes/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

SELECT TOP 1
	@LogBytesFlushedPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Log Bytes Flushed/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

SELECT TOP 1
	@LogFlushWaitsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Log Flush Waits/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

SELECT TOP 1
	@TrackedTransactionsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Tracked Transactions/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

SELECT TOP 1
	@WriteTransactionsPerSecond = cntr_value
FROM
	@RatioStatsX
WHERE
	counter_name = 'Write Transactions/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name;

-- WAIT FOR 5 SECONDS BEFORE TAKING SECOND SAMPLE
WAITFOR DELAY '00:00:05'

-- TABLE FOR SECOND SAMPLE
INSERT INTO @RatioStatsY (
	[object_name]
,	[counter_name]
,	[instance_name]
,	[cntr_value]
,	[cntr_type])
SELECT
	[object_name]
,	[counter_name]
,	[instance_name]
,	[cntr_value]
,	[cntr_type]
FROM
	sys.dm_os_performance_counters;

-- LIST PERFORMANCE COUNTERS FROM SQL SERVER
SELECT
	@@SERVERNAME AS server_name
,	B.[object_name]
,	'Buffer cache hit ratio' AS counter_name
,	CONVERT (FLOAT, (A.cntr_value * 1.0 / B.cntr_value) * 100.0) AS cntr_value
FROM (
	SELECT
		*, 1 X
	FROM
		@RatioStatsY
	WHERE
		counter_name = 'Buffer cache hit ratio'
	AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
) A JOIN (
	SELECT
		*, 1 X
	FROM
		@RatioStatsY
	WHERE
		counter_name = 'Buffer cache hit ratio base'
	AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
) B ON (A.X = B.X)
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Pages reads/sec' AS counter_name
,	(cntr_value - @PageReadsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Pages reads/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Pages writes/sec' AS counter_name
,	(cntr_value - @PageWritesPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Pages writes/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Page life expectancy' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Page life expectancy'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Total pages (KB)' AS counter_name
,	cntr_value * 8192
FROM
	@RatioStatsY
WHERE
	counter_name = 'Total pages'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Free pages (KB)' AS counter_name
,	cntr_value * 8192
FROM
	@RatioStatsY
WHERE
	counter_name = 'Free pages'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Database pages (KB)' AS counter_name
,	cntr_value * 8192
FROM
	@RatioStatsY
WHERE
	counter_name = 'Database pages'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	B.[object_name]
,	'Free pages Percent' AS counter_name
,	CONVERT (FLOAT, (A.cntr_value * 1.0 / B.cntr_value) * 100.0) AS cntr_value
FROM (
	SELECT
		*, 1 X
	FROM
		@RatioStatsY
	WHERE
		counter_name = 'Free pages'
	AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
) A JOIN (
	SELECT
		*, 1 X
	FROM
		@RatioStatsY
	WHERE
		counter_name = 'Total pages'
	AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
) B ON (A.X = B.X)
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Checkpoint pages/sec' AS counter_name
,	(cntr_value - @CheckpointPagesPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Checkpoint pages/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Lazy writes/sec' AS counter_name
,	(cntr_value - @LazyWritesPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Lazy writes/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Page lookups/sec' AS counter_name
,	(cntr_value - @PageLookupsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Page lookups/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Readahead pages/sec' AS counter_name
,	(cntr_value - @ReadaheadPagesPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Readahead pages/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Buffer Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Buffer Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'User Connections' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'User Connections'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:General Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':General Statistics' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Active Temp Tables' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Active Temp Tables'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:General Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':General Statistics' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Logins/sec' AS counter_name
,	(cntr_value - @LoginsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Logins/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:General Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':General Statistics' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Connection Reset/sec' AS counter_name
,	(cntr_value - @ConnectionResetPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Connection Reset/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:General Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':General Statistics' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Logouts/sec' AS counter_name
,	(cntr_value - @LogoutsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Logouts/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:General Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':General Statistics' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Process Blocked' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Process Blocked'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:General Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':General Statistics' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Free Space in tempdb (KB)' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Free Space in tempdb (KB)'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Transactions' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Transactions' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Batch Requests/sec' AS counter_name
,	(cntr_value - @BatchRequestsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Batch Requests/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:SQL Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':SQL Statistics' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'SQL Compilations/sec' AS counter_name
,	(cntr_value - @CompilationsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'SQL Compilations/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:SQL Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':SQL Statistics' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'SQL Re-Compilations/sec' AS counter_name
,	(cntr_value - @RecompilationsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'SQL Re-Compilations/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:SQL Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':SQL Statistics' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Target Server Memory (KB)' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Target Server Memory (KB)'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Memory Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Memory Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Total Server Memory (KB)' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Total Server Memory (KB)'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Memory Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Memory Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Connection Memory (KB)' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Connection Memory (KB)'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Memory Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Memory Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Granted Workspace Memory (KB)' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Granted Workspace Memory (KB)'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Memory Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Memory Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Lock Memory (KB)' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Lock Memory (KB)'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Memory Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Memory Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Optimizer Memory (KB)' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Optimizer Memory (KB)'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Memory Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Memory Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'SQL Cache Memory (KB)' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'SQL Cache Memory (KB)'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Memory Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Memory Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Memory Grants Pending' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Memory Grants Pending'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Memory Manager' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Memory Manager' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Transactions/sec' AS counter_name
,	(cntr_value - @TransactionsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Transactions/sec'
AND instance_name = '_Total'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Lock Waits/sec' AS counter_name
,	(cntr_value - @LockWaitsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Lock Waits/sec'
AND instance_name = '_Total'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Locks' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Locks' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Lock Requests/sec' AS counter_name
,	(cntr_value - @LockRequestsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Lock Requests/sec'
AND instance_name = '_Total'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Locks' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Locks' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Lock Timeouts/sec' AS counter_name
,	(cntr_value - @LockTimeoutsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Lock Timeouts/sec'
AND instance_name = '_Total'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Locks' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Locks' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Number of Deadlocks/sec' AS counter_name
,	(cntr_value - @DeadlocksPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Number of Deadlocks/sec'
AND instance_name = '_Total'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Locks' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Locks' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Latch Waits/sec' AS counter_name
,	(cntr_value - @LatchWaitsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Latch Waits/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Latches' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Latches' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Page Splits/sec' AS counter_name
,	(cntr_value - @PageSplitsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Page Splits/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Access Method' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Access Method' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Table Lock Escalation/sec' AS counter_name
,	(cntr_value - @TableLockEscalationPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Table Lock Escalation/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Access Method' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Access Method' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'FreeSpace Scans/sec' AS counter_name
,	(cntr_value - @FreeSpaceScanPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'FreeSpace Scans/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Access Method' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Access Method' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Workfiles Created/sec' AS counter_name
,	(cntr_value - @WorkFilesCreatedPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Workfiles Created/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Access Method' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Access Method' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Worktables Created/sec' AS counter_name
,	(cntr_value - @WorkTablesCreatedPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Worktables Created/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Access Method' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Access Method' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	B.[object_name]
,	'Page Splits Percent' AS counter_name
,	CONVERT (FLOAT, (A.cntr_value * 1.0 / B.cntr_value) * 100.0) AS cntr_value
FROM (
	SELECT
		*, 1 X
	FROM
		@RatioStatsY
	WHERE
		counter_name = 'Page Splits/sec'
	AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Access Method' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Access Method' END
) A JOIN (
	SELECT
		*, 1 X
	FROM
		@RatioStatsY
	WHERE
		counter_name = 'Batch Requests/sec'
	AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:SQL Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':SQL Statistics' END
) B ON (A.X = B.X)
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Page IO latch waits' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Page IO latch waits'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Wait Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Wait Statistics' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	'Network IO waits' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Network IO waits'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Wait Statistics' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Wait Statistics' END
UNION
SELECT
	@@SERVERNAME AS server_name
,	'schedulers' AS [object_name]
,	'Avg Tasks Count' AS counter_name
,	AVG (current_tasks_count) AS cntr_value
FROM
	sys.dm_os_schedulers
WHERE
	scheduler_id < 255
UNION
SELECT
	@@SERVERNAME AS server_name
,	'schedulers' AS [object_name]
,	'Avg Runnable Tasks Count' AS counter_name
,	AVG (runnable_tasks_count) AS cntr_value
FROM
	sys.dm_os_schedulers
WHERE
	scheduler_id < 255
UNION
SELECT
	@@SERVERNAME AS server_name
,	'schedulers' AS [object_name]
,	'Avg Pending Disk IO Count' AS counter_name
,	AVG (pending_disk_io_count) AS cntr_value
FROM
	sys.dm_os_schedulers
WHERE
	scheduler_id < 255
OPTION (RECOMPILE);

-- LIST PERFORMANCE COUNTERS FROM DATABASE
SELECT
	@@SERVERNAME AS server_name
,	B.instance_name
,	'Log cache hit ratio' AS counter_name
,	CONVERT (FLOAT, (A.cntr_value * 1.0 / B.cntr_value) * 100.0) AS cntr_value
FROM (
	SELECT
		*, 1 X
	FROM
		@RatioStatsY
	WHERE
		counter_name = 'Log cache hit ratio'
	AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
	AND instance_name = @instance_name
) A JOIN (
	SELECT
		*, 1 X
	FROM
		@RatioStatsY
	WHERE
		counter_name = 'Log cache hit ratio base'
	AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
	AND instance_name = @instance_name
) B ON (A.X = B.X)
UNION
SELECT
	@@SERVERNAME AS server_name
,	B.instance_name
,	'Cache hit ratio' AS counter_name
,	CONVERT (FLOAT, (A.cntr_value * 1.0 / B.cntr_value) * 100.0) AS cntr_value
FROM (
	SELECT
		*, 1 X
	FROM
		@RatioStatsY
	WHERE
		counter_name = 'Cache hit ratio'
	AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Catalog Metadata' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Catalog Metadata' END
	AND instance_name = @instance_name
) A JOIN (
	SELECT
		*, 1 X
	FROM
		@RatioStatsY
	WHERE
		counter_name = 'Cache hit ratio base'
	AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Catalog Metadata' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Catalog Metadata' END
	AND instance_name = @instance_name
) B ON (A.X = B.X)
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Cache Entries Count' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Cache Entries Count'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Catalog Metadata' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Catalog Metadata' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Data File(s) Size (KB)' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Data File(s) Size (KB)'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Log File(s) Size (KB)' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Log File(s) Size (KB)'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Log File(s) Used Size (KB)' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Log File(s) Used Size (KB)'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Percent Log Used' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Percent Log Used'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Active Transactions' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Active Transactions'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Transactions/sec' AS counter_name
,	(cntr_value - @TransactionDBPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Transactions/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Log Cache Reads/sec' AS counter_name
,	(cntr_value - @LogCacheReadsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Log Cache Reads/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Bulk Copy Rows/sec' AS counter_name
,	(cntr_value - @BulkCopyRowsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Bulk Copy Rows/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Bulk Copy Throughput/sec' AS counter_name
,	(cntr_value - @BulkCopyThroughputPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Bulk Copy Throughput/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Backup/Restore Throughput/sec' AS counter_name
,	(cntr_value - @BackupRestoreTroughputPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Backup/Restore Throughput/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'DBCC Logical Scan Bytes/sec' AS counter_name
,	(cntr_value - @DBCCLogicalScanBytesPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'DBCC Logical Scan Bytes/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Shrink Data Movement Bytes/sec' AS counter_name
,	(cntr_value - @ShrinkDataBytesPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Shrink Data Movement Bytes/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Log Flushes/sec' AS counter_name
,	(cntr_value - @LogFlushPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Log Flushes/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Log Bytes Flushed/sec' AS counter_name
,	(cntr_value - @LogBytesFlushedPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Log Bytes Flushed/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Log Flush Waits/sec' AS counter_name
,	(cntr_value - @LogFlushWaitsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Log Flush Waits/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Log Flush Wait Time' AS counter_name
,	cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Log Flush Wait Time'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Tracked transactions/sec' AS counter_name
,	(cntr_value - @TrackedTransactionsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Tracked transactions/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
UNION
SELECT
	@@SERVERNAME AS server_name
,	instance_name
,	'Write transactions/sec' AS counter_name
,	(cntr_value - @WriteTransactionsPerSecond) / (CASE WHEN DATEDIFF (SS, @stat_date, GETDATE ()) = 0 THEN 1 ELSE DATEDIFF (SS, @stat_date, GETDATE ()) END) AS cntr_value
FROM
	@RatioStatsY
WHERE
	counter_name = 'Write transactions/sec'
AND [object_name] = CASE WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:Databases' ELSE 'MSSQL$' + RTRIM (@@SERVICENAME) + ':Databases' END
AND instance_name = @instance_name
OPTION (RECOMPILE);
GO