/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR O USO DE MEMORIA PELO SQL SERVER.
 */

--<01>-- VERIFICAR O CONSUMO DE MEMORIA INTERNA DO SQL SERVER.
USE [master]

SELECT
	mo.[type]
,	SUM (mo.page_size_in_bytes * 8) / 1024 AS page_size_mb
FROM
	sys.dm_os_memory_objects mo
	INNER JOIN sys.dm_os_memory_clerks mc ON (MO.page_allocator_address = MC.page_allocator_address)
WHERE
	mc.[type] = 'MEMORYCLERK_SQLGENERAL'
GROUP BY
	mo.[type]
ORDER BY
	2 DESC
OPTION (RECOMPILE);

-- MEMORIA USADA PARA CONSUMO DE XML
SELECT
	@@SERVERNAME AS 'SQL SERVER'
,	mc.[type]
,	SUM (mc.pages_kb) / 1024 AS page_allocated_mb
,	COUNT (*) AS row_count
,	GETDATE () AS data_exec
FROM
	sys.dm_os_memory_clerks mc
WHERE
	mc.[type] = 'MEMORYCLERK_SQLXML'
GROUP BY
	mc.[type]
ORDER BY
	3 DESC
OPTION (RECOMPILE);
GO

--<02>-- RETORNAR INFORMACOES SOBRE A MEMORIA E SEU ESTADO.
USE [master]

-- "Available physical memory is hight" INDICA QUE NAO ESTA SOBRE PRESSAO DE MEMORIA EXTERNA
SELECT
	m.total_physical_memory_kb / 1024 AS total_physical_memory_mb
,	m.available_physical_memory_kb / 1024 AS available_physical_memory_mb
,	m.total_page_file_kb / 1024 AS total_page_file_mb
,	m.available_page_file_kb / 1024 AS available_page_file_mb
,	m.system_cache_kb / 1024 AS system_cache_mb
,	m.system_memory_state_desc
FROM
	sys.dm_os_sys_memory m
OPTION (RECOMPILE);

-- VALOR 0 PARA PROCESS_PHYSICAL_MEMORY_LOW E VALOR 0 PARA PROCESS_VIRTUAL_MEMORY_LOW INDICA QUE NAO ESTA SOB PRESSAO DE MEMORIA.
SELECT
	pm.physical_memory_in_use_kb / 1024 AS sql_server_memory_usage_mb
,	pm.large_page_allocations_kb / 1024 AS large_page_allocations_mb
,	pm.locked_page_allocations_kb / 1024 AS locked_page_allocations_mb
,	pm.page_fault_count
,	pm.memory_utilization_percentage
,	pm.available_commit_limit_kb / 1024 AS available_commit_limit_mb
,	pm.process_physical_memory_low
,	pm.process_virtual_memory_low
FROM
	sys.dm_os_process_memory pm
OPTION (RECOMPILE);
GO

--<03>-- COLETAR INFORMACOES DOS CONTADORES DE PERFORMANCE E MEMORY CLERKS PARA VERIFICAR PRESSAO DE MEMORIA.
USE [master]

/*
 * PAGE LIFE EXPECTANCY (PLE) PARA CADA NUMA NODE
 * PLE BAIXO PODE INDICAR PRESSAO DE MEMORIA (OLHAR TENDENCIA AO LONGO DO TEMPO)
 */
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	instance_name
,	cntr_value AS page_life_expectancy
FROM
	sys.dm_os_performance_counters
WHERE
	[object_name] LIKE N'%Buffer Node%'	-- Handles named instances
	AND counter_name = N'Page life expectancy'
OPTION (RECOMPILE);

-- MEMORY GRANTS PENDING: VALORES ACIMA DE 0 POR LONGO PERIODO PODE INDICAR PRESSAO DE MEMORIA.
SELECT
	@@SERVERNAME AS server_name
,	[object_name]
,	 cntr_value AS memory_grants_pending
FROM
	sys.dm_os_performance_counters
WHERE
	[object_name] LIKE N'%Memory Manager%'	-- Handles named instances
	AND counter_name = N'Memory Grants Pending'
OPTION (RECOMPILE);

/*
 * MEMORY CLERKS USAGE: VEJA VALORES ALTOS PARA CACHESTORE_SQLCP (AD-HOC QUERY PLANS)
 * PLANOS CACHESTORE_SQLCP ARMAZENAM EM CACHE INSTRUCOES SQL OU LOTES QUE NAO ESTAO EM PROCEDIMENTOS ARMAZENADOS, FUNCOES OU GATILHOS.
 * PLANOS CACHESTORE_OBJCP ARMAZENAM EM CACHE OS PLANOS COMPILADOS PARA PROCEDIMENTOS ARMAZENADOS, FUNCOES E GATILHOS.
 */
SELECT
	mc.[type] AS memory_clerk_type
,	SUM (mc.page_size_in_bytes) / 1024 AS page_size_mb
FROM
	sys.dm_os_memory_clerks mc
GROUP BY
	mc.[type]
ORDER BY
	page_size_mb DESC
OPTION (RECOMPILE);
GO