/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR JOBS.
 */

--<01>-- RETORNAROS JOBS DO SQL AGENT E AS INFORMACOES DE CADA CATEGORIA.
USE [msdb]

/*
 * OLHE PARA OS JOBS QUE NAO SAO DE PROPRIEDADE DO SA
 * OLHE PARA OS JOBS QUE TEM UM CONJUNTO NOTIFY_EMAIL_OPERATOR_ID = 0 (NENHUM OPERADOR)
 * OLHE PARA OS JOBS QUE TEM UM NIVEL DE NOTIFY_LEVEL_EMAIL = 0 (SEM E-MAIL ALERTA NUNCA E ENVIADO)
 */
SELECT
	J.name AS job_name
,	J.[description]
,	SUSER_SNAME (J.owner_sid) AS job_owner
,	J.date_created
,	J.[enabled]
,	J.notify_email_operator_id
,	J.notify_level_email
,	C.name AS category_name
FROM
	sysjobs J INNER JOIN syscategories C ON	(J.category_id = C.category_id)
ORDER BY
	J.name
OPTION (RECOMPILE);
GO

--<02>-- CONSULTAR O HISTORICO DE EXECUCAO DE UM JOB.
USE [msdb]

DECLARE @jobname VARCHAR(150) = 'DBAP_Updstats';
DECLARE @rundate VARCHAR(10) = '20150101'

SELECT
	J.name AS jobname
,	H.step_name
,	CONVERT (CHAR(10), CAST (STR (H.run_date, 8, 0) AS DATETIME), 120) + ' ' + STUFF (STUFF (RIGHT ('000000' + CAST (H.run_time AS VARCHAR(6)), 6), 5, 0, ':'), 3, 0, ':') AS execution_time
,	REPLICATE ('0', 2 - LEN (H.run_duration / 3600)) + CAST ((H.run_duration / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((H.run_duration % 3600) / 60)) + CAST (((H.run_duration % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((H.run_duration % 3600) % 60)) + CAST (((H.run_duration % 3600) % 60) AS VARCHAR) AS duration_time
,	CASE H.run_status
		WHEN 0 THEN 'Falha'
		WHEN 1 THEN 'Sucesso'
		WHEN 2 THEN 'Retry'
		WHEN 3 THEN 'Cancelado pelo usu�rio'
		WHEN 4 THEN 'Em execu��o'
	END AS run_status
,	H.[message]
FROM
	sysjobhistory H 
	INNER JOIN sysjobs J ON	(H.job_id = J.job_id)
WHERE
	J.name = @jobname
	AND H.step_name <> '(Job Outcome)'
	AND J.[enabled] = 1
	AND H.run_date = @rundate
ORDER BY
	H.run_time DESC
OPTION (RECOMPILE);
GO

--<03>-- CONSULTAR O HISTORICO DE EXECUCAO DE UM JOB POR STEP.
USE [msdb]

DECLARE @jobname VARCHAR(150) = 'DBAJ_Monitora_Database_Files'
DECLARE @stepname VARCHAR(150) = NULL	-- STEP NAME | NULL
DECLARE @rundate VARCHAR(10) = '20150101'

IF @stepname IS NULL SET @stepname = '%%' ELSE SET @stepname = '%' + @stepname + '%';

SELECT
	T.jobname
,	T.step_id
,	T.step_name
,	T.run_datetime
,	T.run_duration
FROM (
	SELECT 
		A.jobname
	,	A.step_id
	,	A.step_name
	,	A.run_datetime
	,	SUBSTRING (A.run_duration, 1, 2) + ':' + SUBSTRING (A.run_duration, 3, 2) + ':' + SUBSTRING (A.run_duration, 5, 2) AS run_duration
	FROM (
		SELECT DISTINCT
			J.name AS jobname
		,	H.step_id
		,	H.step_name
		,	run_datetime = CONVERT (DATETIME, RTRIM (H.run_date)) + (H.run_time * 9 + H.run_time % 10000 * 6 + H.run_time % 100 * 10) / 216e4
		,	run_duration = RIGHT ('000000' + CONVERT (VARCHAR (6), H.run_duration), 6)
		FROM
			sysjobhistory H 
			INNER JOIN sysjobs J ON	(H.job_id = J.job_id)
		WHERE
			J.name = @jobname
			AND H.run_date = @rundate
			AND H.step_name <> '(Job Outcome)'
			AND H.step_name LIKE @stepname
	) A
) T
ORDER BY
	T.jobname
,	T.run_datetime
OPTION (RECOMPILE);
GO

--<04>-- CONSULTAR JOBS INATIVOS
USE [msdb]

SELECT
	@@SERVERNAME AS serverName
,	J.name AS jobname
,	C.name AS category_name
,	RTRIM (DATEDIFF (DD, CONVERT (DATE, J.date_modified), CONVERT (DATE, GETDATE ()))) + RTRIM ( ' DIAS') AS dias_inativos
FROM
	sysjobs J 
	INNER JOIN syscategories C ON (J.category_id = C.category_id)
WHERE
	J.[enabled] = 0
OPTION (RECOMPILE);
GO

--<05>-- LISTAR OS PACOTES SSIS EXISTENTES.
USE [msdb]

DECLARE @foldername VARCHAR(50) = NULL	-- COLOCAR NOME DA PASTA DO SSIS | NULL

IF @foldername IS NULL SET @foldername = '%%' ELSE SET @foldername = '%' + @foldername + '%';

WITH CTE AS (
	SELECT
		CAST (pf.foldername AS VARCHAR (MAX)) AS folderpath
	,	PF.folderid
	FROM
		sysssispackagefolders PF
	WHERE
		PF.foldername LIKE @foldername
UNION ALL
	SELECT
		CAST (C.folderpath + '\' + F.foldername AS VARCHAR (MAX))
	FROM
		sysssispackagefolders F 
		INNER JOIN CTE C ON	(C.folderid = F.folderid)
)
SELECT
	CTE.folderpath
,	P.name
,	CAST (CAST (P.packagedata AS VARBINARY (MAX)) AS VARCHAR (MAX)) AS package
FROM
	CTE INNER JOIN sysssispackages P ON	(CTE.folderid = P.folderid)
WHERE
	CTE.folderpath NOT LIKE '%Data Collector%'
OPTION (RECOMPILE);
GO

--<06>-- CONSULTAR SE A ULTIMA EXECUCAO DO JOB FALHOU.
USE [msdb]

SELECT 
	J.name
,	CASE T.run_status
		WHEN 0 THEN 'Falha'
		WHEN 1 THEN 'Sucesso'
		WHEN 2 THEN 'Retry'
		WHEN 3 THEN 'Cancelado pelo Usu�rio'
		WHEN 4 THEN 'Em execu��o'
	END AS run_status
,	CONVERT (CHAR (10), CAST (STR (T.run_date,8,0) AS DATETIME), 120) + ' ' + STUFF (STUFF (RIGHT ('000000' + CAST (T.run_time AS VARCHAR (6)),6), 5,5,':'), 3,0,':') AS execution_time
,	T.[message]
FROM
	sysjobs J
	CROSS APPLY (
		SELECT TOP (1)
			H.run_date
		,	H.run_time
		,	H.run_status
		,	H.[message]
		FROM
			sysjobhistory H
		WHERE
			H.step_id = 0
			AND H.job_id = J.job_id
		ORDER BY
			H.instance_id
	) T
WHERE
	T.run_status = 0
ORDER BY
	J.name
OPTION (RECOMPILE);
GO

--<07>-- RELATORIO DAS INFORMACOES DOS JOBS ATIVOS.
USE [msdb]

SELECT DISTINCT
	RANK () OVER (ORDER BY J.job_id) AS job_rank
,	J.name AS job_name
,	C.name AS category_name
,	JS.step_id
,	JS.step_name
,	CASE WHEN J.[enabled] = 1 THEN 'Sim' ELSE 'Nao' END AS IsActive
,	J.[description]
,	JS.command
,	J.date_created
,	J.date_modified
,	SCH.schedule_id
,	STUFF (STUFF (RIGHT ('00000000' + CAST (JS.last_run_date AS VARCHAR (8)), 8), 7, 0, '-'), 5, 0, '-') + ' ' +
	STUFF (STUFF (RIGHT ('000000' + CAST (JS.last_run_time AS VARCHAR (6)), 6), 5, 0, ':'), 3, 0, ':') AS last_execution
,	REPLICATE ('0', 2 - LEN (JS.last_run_duration / 3600)) + CAST ((JS.last_run_duration / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((JS.last_run_duration % 3600) / 60)) + CAST (((JS.last_run_duration % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((JS.last_run_duration % 3600) % 60)) + CAST (((JS.last_run_duration % 3600) % 60) AS VARCHAR) AS last_run_duration
,	STUFF (STUFF (RIGHT ('00000000' + CAST (SCH.next_run_date AS VARCHAR (8)), 8), 7, 0, '-'), 5, 0, '-') + ' ' +
	STUFF (STUFF (RIGHT ('000000' + CAST (SCH.next_run_time AS VARCHAR (6)), 6), 5, 0, ':'), 3, 0, ':') AS next_execution
,	JS.database_name 
,	JS.retry_attempts
,	JS.retry_interval
,	JS.output_file_name
FROM
	sysjobs J
	LEFT JOIN sysjobschedules SCH	ON (J.job_id = SCH.job_id)
	LEFT JOIN sysjobsteps JS		ON (J.job_id = JS.job_id)
	LEFT JOIN syscategories C		ON (J.category_id = C.category_id)
WHERE
	J.[enabled] = 1
	AND JS.database_name NOT IN ('distribution')
	AND J.name NOT IN ('syspolicy_purge_history')
ORDER BY
	job_rank
,	JS.step_id
OPTION (RECOMPILE);
GO