/*
 *	AUTHOR: BETO GIOY
 *	ACTION: PROCESSO PARA CALCULAR VALOR IDEAL DO FILLFACTOR DE UM INDICE
 *	OBSERV:	O FILLFACTOR VARIA DE ACORDO COM O TAMANHO DA CHAVE DO INDICE E O PERCENTUAL DE CRESCIMENTO ESPERADO.
			PARA INSERCOES SEQUENCIAIS USE FILLFACTOR MAIORES, PARA INSERCOES NAO SEQUENCIAIS USE FILLFACTOR MENORES.
			http://lassesen.com/msdn/optimizing_fill_factors_for_sqlserver.pdf
 */

--<01>-- CRIAR FUNCAO PARA CALCULAR O FILLFACTOR PARA OBTER MELHOR TAXA DE TRANSFERENCIA.
USE [master]
GO

/*
 * FILLFACTOR THROUGHPUT E UM VALOR RESULTANTE DO MENOR TEMPO DE LEITURA TOTAL PARA UM INDICE ENTRE O NIVEL DE DESFRAGMENTACAO.
 */
CREATE FUNCTION [dbo].[Fn_OptimalThroughput_FillFactor_ForRamdom]
(
	@KeyBytes FLOAT
,	@GrowthPercentage FLOAT
)
RETURNS INT
AS
BEGIN
	IF (@KeyBytes < 2) SET @KeyBytes = 2;
	IF (@GrowthPercentage > 0.06) SET @GrowthPercentage = 0.06;
	IF (@GrowthPercentage < 0.001) SET @GrowthPercentage = 0.001;

	DECLARE @FillFactor FLOAT, @Rate FLOAT, @Offset FLOAT;

	SET @Rate = -5.2312 * POWER (@KeyBytes, -0.244);
	SET @Offset = 1 - 0.2193 * POWER (@KeyBytes, -0.462);
	SET @FillFactor = CEILING (100 * ((@Rate * @GrowthPercentage) + @Offset));

	IF (@FillFactor < 50) SET @FillFactor = 50;
	IF (@FillFactor > 99) SET @FillFactor = 99;

	RETURN @FillFactor
END
GO

--<02>-- CRIAR FUNCAO PARA CALCULAR O FILLFACTOR PARA OBTER MELHOR DESEMPENHO.
USE [master]
GO

/*
 * FILLFACTOR THRESHOLD E UM VALOR RESULTANTE DO MENOR TEMPO DE LEITURA UNICA PARA UM INDICE ENTRE O NIVEL DE DESFRAGMENTACAO.
 */
CREATE FUNCTION [dbo].[Fn_OptimalThreshold_FillFactor_ForRandom]
(
	@KeyBytes FLOAT
,	@GrowthPercentage FLOAT
)
RETURNS INT
AS
BEGIN
	IF (@KeyBytes < 2) SET @KeyBytes = 2;
	IF (@GrowthPercentage > 0.06) SET @GrowthPercentage = 0.06;
	IF (@GrowthPercentage < 0.001) SET @GrowthPercentage = 0.001;

	DECLARE @FillFactor FLOAT, @Rate FLOAT, @Offset FLOAT;

	SET @Rate = -5.0189 * POWER (@KeyBytes, -0.218);
	SET @Offset = 1 - 0.9774 * POWER (@KeyBytes, -0.574);
	SET @FillFactor = CEILING (100 * ((@Rate * @GrowthPercentage) + @Offset));

	IF (@FillFactor < 50) SET @FillFactor = 50;
	IF (@FillFactor > 99) SET @FillFactor = 99;

	RETURN @FillFactor
END
GO

--<03>-- RETORNAR O PERCENTUAL DE FRAGMENTACAO DOS INDICES.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

SELECT
	PS.[object_id]
,	PS.index_level
,	PS.avg_fragmentation_in_percent
,	PS.fragment_count
,	PS.avg_page_space_used_in_percent
,	PS.record_count
FROM
	sys.dm_db_index_physical_stats (DB_ID (@dbname), NULL, NULL, NULL, 'DETAILED') PS
WHERE
	PS.index_type_desc <> 'HEAP'
	AND PS.alloc_unit_type_desc = 'IN_ROW_DATA'
OPTION (RECOMPILE);
GO

--<04>-- CRIAR TABELAS PARA ACOMPANHAMENTO DA FRAGMENTACAO DE INDICES.
USE [master]
GO

CREATE TABLE [dbo].[AutoFillFactor]
(
	[IndexKey] VARCHAR (50) NOT NULL
,	CONSTRAINT [PK_AutoFillFactor] PRIMARY KEY CLUSTERED ([IndexKey])
)
ON [PRIMARY];

CREATE TABLE [dbo].[IndexTracking]
(
	[DatabaseName] SYSNAME NOT NULL
,	[TableName] SYSNAME NOT NULL
,	[SchemaName] SYSNAME NOT NULL
,	[IndexName] SYSNAME NOT NULL
,	[RecordedAt] DATETIME NOT NULL
,	[IndexKey] VARCHAR (50) NULL
,	[KeySize] INT NOT NULL
,	[IndexBytes] FLOAT NOT NULL
,	[Fillfactor] INT NOT NULL
,	[GrowthPercentage] FLOAT NULL
,	[FragPercentage] FLOAT NOT NULL
,	[ScanTimeEstimate] AS (0.5 * (100 - [FragPercentage]) + (9 * [FragPercentage]))
,	CONSTRAINT [PK_IndexTracking] PRIMARY KEY CLUSTERED ([DatabaseName], [TableName], [SchemaName], [IndexName], [RecordedAt])
)
ON [PRIMARY];
GO

--<05>-- CRIAR STORED PROCEDURE PARA OTIMIZAR FILLFACTOR.
USE [master]
GO

CREATE PROCEDURE [dbo].[dbap_OptimizerFillFactor]
	@dbname SYSNAME
AS
DECLARE @RecordedAt DATETIME;
DECLARE @Mytable VARCHAR (128);
DECLARE @MyIndex VARCHAR (128);
DECLARE @MyFillFactor VARCHAR (3);
DECLARE @stmt VARCHAR (MAX);

SET @RecordedAt = GETDATE ();

INSERT INTO [dbo].[IndexTracking] (
	[DatabaseName]
,	[TableName]
,	[SchemaName]
,	[IndexName]
,	[RecordedAt]
,	[IndexKey]
,	[KeySize]
,	[IndexBytes]
,	[Fillfactor]
,	[FragPercentage]
)
SELECT
	DB_NAME (S.database_id)
,	T.name
,	SCH.name
,	I.name
,	@RecordedAt
,	CAST (S.[object_id] AS VARCHAR (11)) + '_' + CAST (S.index_id AS VARCHAR (11))
,	S.KeySize
,	S.IndexBytes
,	I.fill_factor
,	S.FragPercentage
FROM 
(
	SELECT
		PS.database_id
	,	PS.[object_id]
	,	PS.index_id
	,	MAX (PS.max_record_size_in_bytes) AS [KeySize]
	,	SUM (PS.avg_record_size_in_bytes * PS.page_count) AS [IndexBytes]
	,	SUM (PS.avg_fragmentation_in_percent * PS.page_count) / SUM (PS.page_count) AS [FragPercentage]
	FROM
		sys.dm_db_index_physical_stats (DB_ID (@dbname), NULL, NULL, NULL, 'DETAILED') PS
	WHERE
		ps.index_type_desc IN ('CLUSTERED INDEX', 'NONCLUSTERED INDEX')
		AND PS.alloc_unit_type_desc = 'IN_ROW_DATA'
	GROUP BY
		PS.database_id
	,	PS.[object_id]
	,	PS.index_id
	HAVING
		SUM (PS.page_count) > 0
) S
	JOIN sys.objects T		ON (S.[object_id] = T.[object_id])
	JOIN sys.schemas SCH	ON (T.[schema_id] = SCH.[schema_id])
	JOIN sys.indexes I		ON (S.[object_id] = I.[object_id] AND S.index_id = I.index_id)

UPDATE 
	[dbo].[IndexTracking]
SET
	GrowthPercentage = CASE WHEN [EstStDev] * 2 + [EstAvg] < 0.001 THEN 0.001 ELSE [EstStDev] * 2 + [EstAvg] END
FROM
	[dbo].[IndexTracking]
	JOIN (
		SELECT
			IT.IndexKey
		,	STDEV (IT.IndexBytes) / MAX (IT.IndexBytes) AS [EstStDev]
		,	(MAX (IT.IndexBytes) - MIN (IT.IndexBytes)) / (MIN (IT.IndexBytes) / COUNT (IT.IndexBytes)) AS [EstAvg]
		FROM
			[dbo].[IndexTracking] IT 
			JOIN [dbo].[AutoFillFactor] AF ON (IT.IndexKey = AF.IndexKey)
		WHERE
			IT.RecordedAt > GETDATE () - 7
			AND IT.IndexBytes IS NOT NULL
			AND IT.IndexBytes > 0
		GROUP BY
			IT.IndexKey
	) Estimates
ON	([Estimates].IndexKey = [IndexTracking].IndexKey AND [IndexTracking].RecordedAt = @RecordedAt)

CREATE TABLE #temp (mytable VARCHAR (128), myindex VARCHAR (128),	myFillFactor VARCHAR (3));

INSERT INTO #temp
SELECT
	'[' + IT.SchemaName + '].[' + IT.TableName + ']'
,	IT.IndexName
,	CAST ([dbo].[Fn_OptimalThroughput_FillFactor_ForRamdom](KeySize, GrowthPercentage) AS VARCHAR (3))
FROM
	[dbo].[IndexTracking] IT
WHERE
	IT.RecordedAt = @RecordedAt
	AND IT.IndexKey IN (SELECT IndexKey FROM [dbo].[AutoFillFactor])

DECLARE Index_Cursor CURSOR FOR
SELECT mytable, myindex, myFillFactor FROM #temp

OPEN Index_Cursor
FETCH NEXT FROM Index_Cursor INTO @Mytable, @MyIndex, @MyFillFactor

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @stmt = 'ALTER INDEX [' + @MyIndex + '] ON [' + @Mytable + '] REBUILD WITH (PAD_INDEX=ON, FILLFACTOR= ' + @MyFillFactor + ')';
	EXEC (@stmt);

	FETCH NEXT FROM Index_Cursor INTO @Mytable, @MyIndex, @MyFillFactor
END

CLOSE Index_Cursor;
DEALLOCATE Index_Cursor;

DROP TABLE #temp;
GO

--<06>-- CRIAR QUERY PARA ALTERAR O FILLFACTOR OTIMIZADO EM TEMPO DE EXECUCAO
USE [master]

DECLARE @MyTable VARCHAR (128)
DECLARE @MyIndex VARCHAR (128)
DECLARE @MyFillFactor VARCHAR (3)
DECLARE @MyKeySize INT
DECLARE @stmt VARCHAR (MAX)

DECLARE IndexCursor CURSOR FOR
SELECT
	'[' + s.name + '].[' + t.name + ']' AS TableName
,	'[' + i.name + ']' AS IndexName
,	SUM (c.max_length) AS KeySize
FROM
	sys.tables t
	INNER JOIN sys.schemas s		ON	(t.[schema_id] = s.[schema_id])
	INNER JOIN sys.indexes i		ON	(t.[object_id] = i.[object_id])
	INNER JOIN sys.index_columns ic ON	(t.[object_id] = ic.[object_id])
	INNER JOIN sys.columns c		ON	(t.[object_id] = c.[object_id] AND ic.column_id = c.column_id)
WHERE	-- if first column is an identity we skip it
	i.[object_id] NOT IN (
		SELECT *
		FROM
			sys.indexes ix
			INNER JOIN sys.index_columns ixc	ON	(ix.[object_id] = ixc.[object_id])
			INNER JOIN sys.columns tc			ON	(ix.[object_id] = tc.[object_id] AND ixc.column_id = tc.column_id)
		WHERE
			tc.is_identity = 1
			AND ixc.index_column_id = 1
	)
	AND i.[type] IN (1,2)	-- CLUSTERED & NONCLUSTERED ONLY
	AND ic.key_ordinal > 0	-- MUST BE A KEY COLUMN
GROUP BY
	s.name
,	t.name
,	i.name

OPEN IndexCursor
FETCH NEXT FROM IndexCursor INTO @MyTable, @MyIndex, @MyKeySize

WHILE @@FETCH_STATUS = 0
BEGIN
	IF @MyKeySize <= 900 SET @MyFillFactor = '97';
	IF @MyKeySize <= 848 SET @MyFillFactor = '96';
	IF @MyKeySize <= 403 SET @MyFillFactor = '95';
	IF @MyKeySize <= 222 SET @MyFillFactor = '94';
	IF @MyKeySize <= 135 SET @MyFillFactor = '93';
	IF @MyKeySize <= 89 SET @MyFillFactor = '92';
	IF @MyKeySize <= 61 SET @MyFillFactor = '91';
	IF @MyKeySize <= 44 SET @MyFillFactor = '90';
	IF @MyKeySize <= 33 SET @MyFillFactor = '89';
	IF @MyKeySize <= 25 SET @MyFillFactor = '88';
	IF @MyKeySize <= 20 SET @MyFillFactor = '87';
	IF @MyKeySize <= 16 SET @MyFillFactor = '86';
	IF @MyKeySize <= 13 SET @MyFillFactor = '85';
	IF @MyKeySize <= 10 SET @MyFillFactor = '84';
	IF @MyKeySize <= 9 SET @MyFillFactor = '83';
	IF @MyKeySize <= 7 SET @MyFillFactor = '82';
	IF @MyKeySize <= 6 SET @MyFillFactor = '81';
	IF @MyKeySize <= 5 SET @MyFillFactor = '79';
	IF @MyKeySize <= 4 SET @MyFillFactor = '78';
	IF @MyKeySize <= 3 SET @MyFillFactor = '75';
	IF @MyKeySize <= 2 SET @MyFillFactor = '71';

	SET @stmt = 'ALTER INDEX ' + @MyIndex + ' ON ' + @MyTable + ' REBUILD WITH (PAD_INDEX=ON, FILLFACTOR= ' + @MyFillFactor + ')';
	EXEC (@stmt);

	FETCH NEXT FROM IndexCursor INTO @MyTable, @MyIndex, @MyKeySize
END

CLOSE IndexCursor;
DEALLOCATE IndexCursor;
GO