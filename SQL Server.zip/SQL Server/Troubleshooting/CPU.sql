/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR CUSTOS DE CPU
 */

--<01>-- VERIFICAR O CONSUMO DE CPU DO SQL SERVER NO SERVIDOR.
USE [master]

DECLARE @ts_now BIGINT = (SELECT cpu_ticks / (cpu_ticks / ms_ticks) FROM sys.dm_os_sys_info);

SELECT TOP (50)
	CPU_SQL		= Y.SQLProcessUtilization
,	CPU_System	= Y.SystemIdle
,	CPU_Other	= 100 - Y.SystemIdle - Y.SQLProcessUtilization
,	ServerName	= @@SERVERNAME
,	MachineName = SERVERPROPERTY ('MachineName')
,	ProcessID	= SERVERPROPERTY ('ProcessID')
,	Event_time	= DATEADD(MS, -1 * (@ts_now - Y.[timestamp]), GETDATE ())
FROM (
	SELECT
		X.record.value ('(./Record/@id)[1]', 'int') AS record_id
	,	X.record.value ('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') AS SystemIdle
	,	X.record.value ('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') AS SQLProcessUtilization
	,	X.[timestamp]
	FROM (
		SELECT
			RB.[timestamp]
		,	CONVERT (xml, RB.record) AS record
		FROM 
			sys.dm_os_ring_buffers RB
		WHERE
			RB.ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
			AND RB.record LIKE '%<SystemHealth>%'
	) AS X
) AS Y
ORDER BY
	Y.record_id DESC
OPTION (RECOMPILE);
GO

--<02>-- CONSULTAR O USO DE TEMPO DE CPU POR BASE DE DADOS
USE [master]

SET NOCOUNT ON;

WITH DB_CPU_STATS AS (
	SELECT
		databaseID
	,	database_name = DB_NAME (databaseID)
	,	CPU_time = SUM (QS.total_worker_time)
	FROM
		sys.dm_exec_query_stats QS
		CROSS APPLY (SELECT CONVERT (INT, value) AS databaseID FROM sys.dm_exec_plan_attributes(QS.plan_handle) PA WHERE PA.attribute = 'dbid') AS FDB
	GROUP BY
		databaseID
)
SELECT 
	CPU_Rank = ROW_NUMBER() OVER (ORDER BY CPU_time DESC)
,	database_name
,	CPU_time_sec = CPU_time / 1000000
,	CPU_Percent = CAST (CPU_time * 1.0 / SUM (CPU_time) OVER() * 100.0 AS DECIMAL (5,2))
FROM
	DB_CPU_STATS
WHERE
	databaseID <> 32767	--> RESOURCE DB
ORDER BY
	CPU_Rank
OPTION (RECOMPILE);
GO

--<03>-- RETORNAR AS TOP 50 CONSULTAS CUMULATIVAS COM MAIOR CUSTO DE CPU.
USE [master]

DECLARE @hour INT = 1;
DECLARE @banco SYSNAME = 'AdventureWorks2014';

SELECT TOP (50)
	DB_NAME (QP.dbid) AS database_name
,	QS.last_execution_time
,	QS.execution_count
,	QS.plan_generation_num
,	REPLICATE ('0', 2 - LEN (QS.total_worker_time / QS.execution_count / 1000000 / 3600)) + CAST ((QS.total_worker_time / QS.execution_count / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.total_worker_time / QS.execution_count / 1000000 % 3600) / 60)) + CAST (((QS.total_worker_time / QS.execution_count / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.total_worker_time / QS.execution_count / 1000000 % 3600) % 60)) + CAST (((QS.total_worker_time / QS.execution_count / 1000000 % 3600) % 60) AS VARCHAR) AS AVG_CPU_Time
,	REPLICATE ('0', 2 - LEN (QS.last_worker_time / 1000000 / 3600)) + CAST ((QS.last_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.last_worker_time / 1000000 % 3600) / 60)) + CAST (((QS.last_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.last_worker_time / 1000000 % 3600) % 60)) + CAST (((QS.last_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Last_CPU_Time
,	REPLICATE ('0', 2 - LEN (QS.min_worker_time / 1000000 / 3600)) + CAST ((QS.min_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.min_worker_time / 1000000 % 3600) / 60)) + CAST (((QS.min_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.min_worker_time / 1000000 % 3600) % 60)) + CAST (((QS.min_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Min_CPU_Time
,	REPLICATE ('0', 2 - LEN (QS.max_worker_time / 1000000 / 3600)) + CAST ((QS.max_worker_time / 1000000 / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.max_worker_time / 1000000 % 3600) / 60)) + CAST (((QS.max_worker_time / 1000000 % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((QS.max_worker_time / 1000000 % 3600) % 60)) + CAST (((QS.max_worker_time / 1000000 % 3600) % 60) AS VARCHAR) AS Max_CPU_Time
,	QP.query_plan
,	ST.[text]
FROM
	sys.dm_exec_query_stats QS
	CROSS APPLY sys.dm_exec_query_plan(QS.plan_handle) QP
	CROSS APPLY sys.dm_exec_sql_text(QS.sql_handle) ST
WHERE
	DATEDIFF (HH, QS.last_execution_time, GETDATE ()) <= @hour
	AND QP.[dbid] = DB_ID (@banco)
ORDER BY
	AVG_CPU_Time DESC
OPTION (RECOMPILE);
GO

-- Retorna Consumo de CPU do Servidor Corrente via powershell
CREATE PROCEDURE spFormataRetornoPowershellXml (
	@command_powershell VARCHAR(max),
	@retorno VARCHAR(max) OUTPUT,
	@bitexec BIT = 1 -- define se comando será executado ou não
)
AS
BEGIN
	SET IMPLICIT_TRANSACTIONS OFF;

	DECLARE @retornoPS TABLE (linhaXml VARCHAR(2000), Ordem INT IDENTITY (1,1) PRIMARY KEY);

	DECLARE @cmdPS VARCHAR(MAX), @xmlString VARCHAR(MAX), @cmd VARCHAR (MAX), @xml XML

	SET @cmdPS = 'exec xp_cmdshell ''' + @command_powershell + '''';

	-- tratamento do comando powershell
	INSERT INTO @retornoPS (linhaXml)
	EXEC (@cmdPS);

	SELECT @xmlString = COALESCE(@xmlString, '') + linhaXml
	FROM @retornoPS
	WHERE linhaXml IS NOT NULL
	ORDER BY Ordem
	OPTION (RECOMPILE, MAXDOP = 1);

	SET @xml = @xmlString;

	-- inicia montagem do comando dinâmico
	SELECT @cmd = @cmd 
	+ 'declare @XML xml = ''' + @xmlString + '''; 
	SELECT ' + STUFF ((SELECT ', MAX (CASE WHEN attribute = ''' + attribute + ''' THEN value ELSE '''' END))) AS [' + attribute + ']'
	FROM (
		SELECT DISTINCT [property].VALUE ('@Name', 'varchar(max)') as [attribute]
		FROM @xml.nodes('Objects/Object') as b ([object])
		CROSS APPLY b.object.nodes('./property') as c ([property])) as a FOR XML PATH ('')), 1, 1, ''
	)
	OPTION (RECOMPILE, MAXDOP=1)

	SELECT @cmd = @cmd +
	'FROM (
		SELECT 
			[property].value(''(./text())[1]'', ''varchar(max)'') as [value] 
		, 	[property].value(''@Name'', ''varchar(max)'') as [attribute]
		,	DENSE_RANK() OVER (ORDER BY) [object]) as IdObject
		FROM
			@xml.nodes(''Objects/Object'') as b ([object])
		CROSS APPLY
			b.object.nodes(''./Property'') as c ([property]) discos
		GROUP BY IdObject
		OPTION (RECOMPILE, MAXDOP=1)
	)'

	IF @bitexec = 1
		EXECUTE (@cmd);

	SELECT @retorno = @cmd;

	RETURN;
END
GO

-- CHAMADA
DECLARE @cmd VARCHAR(MAX);
exec spFormataRetornoPowershellXml @command_powershell = '@Powershell -noprofile -command "Get-Counter -counter ''''\Processor(_Total)\% Processor'''' | select -expand countersamples | select @{Name=''''Processor''''; e={$_.CookedValue}} | ConvertTo-XML -As string "', @retorno = @cmd OUTPUT, @bitexec = 1;
GO