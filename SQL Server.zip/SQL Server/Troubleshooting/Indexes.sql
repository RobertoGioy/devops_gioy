/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR INDICES
 */

--<01>-- RETORNAR INFORMACOES SOBRE POSSIVEIS INDICES AUSENTES. LISTAR AS COLUNAS QUE CONTRIBUEM PARA PREDICADOS (INEQULITY_COLUMNS).
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

SELECT
	DB_NAME (ID.database_id) AS databasename
,	OBJECT_NAME (ID.[object_id]) AS tablename
,	ID.equality_columns
,	ID.inequality_columns
,	ID.included_columns
,	ID.[statement] AS [database.schema.table]
FROM
	sys.dm_db_missing_index_details ID
WHERE
	ID.database_id = DB_ID (@dbname)
	AND ID.inequality_columns IS NOT NULL
OPTION (RECOMPILE);
GO

--<02>-- IDENTIFICAR MISSING INDEXES NA BASE DE DADOS CORRENTE.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

SELECT DISTINCT
	OBJECT_NAME (mid.[object_id]) AS tablename
,	CONVERT (DECIMAL(18,2), migs.user_seeks * migs.avg_total_user_cost * (migs.avg_user_impact *0.01)) AS Index_Advantage
,	migs.last_user_seek
,	mid.[statement] AS [database.schema.table]
,	mid.equality_columns
,	mid.inequality_columns
,	mid.included_columns
,	migs.unique_compiles
,	migs.user_seeks
,	migs.avg_user_impact
FROM
	sys.dm_db_missing_index_group_stats AS migs
	INNER JOIN sys.dm_db_missing_index_groups mig	ON (migs.group_handle = mig.index_group_handle) 
	INNER JOIN sys.dm_db_missing_index_details mid	ON (mig.index_handle = mid.index_handle)
	INNER JOIN sys.partitions p						ON (mid.[object_id] = p.[object_id])
WHERE
	mid.database_id = DB_ID (@dbname)
ORDER BY
	Index_Advantage DESC
OPTION (RECOMPILE);
GO

--<03>-- LOCALIZAR MISSING PARA OS PLANOS DE EXECUCAO QUE ESTAO EM CACHE.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

-- OBS: ESTA CONSULTA PODE DEMORAR EM INSTANCIA MUITO OCUPADA.
SELECT TOP(25) 
	OBJECT_NAME (QP.[objectid]) AS objectname
,	QP.query_plan
,	CP.objtype
,	CP.usecounts
FROM
	sys.dm_exec_cached_plans CP
	CROSS APPLY sys.dm_exec_query_plan(CP.plan_handle) QP
WHERE
	QP.dbid = DB_ID (@dbname)
	AND CAST (QP.query_plan AS NVARCHAR(MAX)) LIKE N'%MissingIndex%'
ORDER BY
	CP.usecounts DESC
OPTION (RECOMPILE);
GO

--<04>-- IDENTIFICAR INDICES NAO CLUSTERIZADOS COM ESCRITA > LEITURA (WRITES > READS).
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

SELECT
	OBJECT_NAME (US.[object_id]) AS tablename
,	I.name AS Indexname
,	I.index_id
,	I.is_disabled
,	I.is_hypothetical
,	I.has_filter
,	I.fill_factor
,	US.user_updates AS totalWrites
,	(US.user_seeks + US.user_scans + US.user_lookups) AS totalReads
,	US.user_updates - (US.user_seeks + US.user_scans + US.user_lookups) AS [difference]
FROM
	sys.dm_db_index_usage_stats US
	INNER JOIN sys.indexes I ON	(us.[object_id] = i.[object_id])
WHERE
	OBJECTPROPERTY (us.[object_id], 'IsUserTable') = 1
	AND US.database_id = DB_ID (@dbname)
	AND US.user_updates > (US.user_seeks + US.user_scans + US.user_lookups)
	AND I.index_id > 1
ORDER BY
	[difference] DESC
,	totalWrites DESC
,	totalReads DESC
OPTION (RECOMPILE);
GO

--<05>-- RETORNAR AS INFORMACOES DE FRAGMENTACAO DE TODOS OS INDICES DA BASE DE DADOS.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

/*
 * PARA EFETUAR REBUILD DE TODOS OS INDICES DA TABELA
 * ALTER INDEX ALL ON [TABLENAME] REBUILD WITH (ONLINE=ON, MAXDOP=1);
 *
 * PARA EFETUAR REBUILD DE UM INDICE ESPECIFICO
 * ALTER INDEX [INDEXNAME] ON [TABLENAME] REBUILD WITH (ONLINE=ON, MAXDOP=1);
 *
 * PARA FRAGMENTACAO ABAIXO DE 30% PODE-SE USAR REORGANIZE COM UPDATE STATISTICS
 * ALTER INDEX [INDEXNAME] ON [TABLENAME] REORGANIZE;
 * UPDATE STATISTICS [TABLENAME] [INDEXNAME] WITH FULLSCAN;
 */
SELECT
	DB_NAME (PS.database_id) AS databaseName
,	OBJECT_NAME (PS.[object_id]) AS tableName
,	I.name AS indexName
,	PS.index_id
,	PS.index_type_desc
,	PS.avg_fragmentation_in_percent
,	PS.fragment_count
,	PS.page_count
,	I.fill_factor
,	I.has_filter
,	I.filter_definition
FROM
	sys.dm_db_index_physical_stats (DB_ID (@dbname), NULL, NULL, NULL, 'LIMITED') PS
	INNER JOIN sys.indexes I ON	(PS.[object_id] = I.[object_id] AND PS.index_id = I.index_id)
WHERE
	PS.database_id = DB_ID (@dbname)
	AND PS.page_count > 2500
ORDER BY
	PS.avg_fragmentation_in_percent DESC
OPTION (RECOMPILE);
GO

--<06>-- RETORNAR INFORMACOES DE FRAGMENTACAO DE INDICES PARTICIONADOS.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

/*
 * PARA EFETUAR REBUILD DE INDICES PARTICIONADOS
 * ALTER INDEX [INDEXNAME] ON [TABLENAME] REBUILD PARTITION = [ID] WITH (ONLINE=ON, MAXDOP=1);
 *
 * PARA FRAGMENTACAO ABAIXO DE 30% PODE-SE USAR REORGANIZE COM UPDATE STATISTICS
 * ALTER INDEX [INDEXNAME] ON [TABLENAME] REORGANIZE PARTITION = [ID];
 * UPDATE STATISTICS [TABLENAME] [INDEXNAME] WITH FULLSCAN;
 */
SELECT
	DB_NAME (PS.database_id) AS databaseName
,	OBJECT_NAME (I.[object_id]) AS tableName
,	I.name AS indexName
,	PS.avg_fragmentation_in_percent
,	PS.partition_number
,	ISNULL (FG.name,'PRIMARY') AS filegroupname
,	PF.name AS partitionFunction
,	PRV.value AS boundaryDate
,	PS.fragment_count
,	I.fill_factor
,	P.[rows]
FROM
	sys.dm_db_index_physical_stats (DB_ID (@dbname), NULL, NULL, NULL, 'LIMITED') PS
	INNER JOIN sys.indexes I					ON	(PS.[object_id] = I.[object_id] AND PS.index_id = I.index_id)
	LEFT JOIN sys.partition_schemes SCH			ON (I.data_space_id = SCH.data_space_id)
	LEFT JOIN sys.partition_functions PF		ON	(SCH.function_id = PF.function_id)
	LEFT JOIN sys.partition_range_values PRV	ON	(PF.function_id = PRV.function_id AND PS.partition_number = PRV.boundary_id)
	LEFT JOIN sys.destination_data_spaces DDS	ON (SCH.data_space_id = DDS.partition_scheme_id AND PS.partition_number = DDS.destination_id)
	LEFT JOIN sys.filegroups FG					ON (DDS.data_space_id = FG.data_space_id)
	LEFT JOIN sys.partitions P					ON (I.[object_id] = P.[object_id] AND I.index_id = P.index_id AND PS.[object_id] = P.[object_id] AND PS.index_id = P.index_id AND DDS.destination_id = P.partition_number)
WHERE
	PS.database_id = DB_ID (@dbname)
	AND PS.avg_fragmentation_in_percent > 5
ORDER BY
	indexName
,	PS.avg_fragmentation_in_percent DESC
OPTION (RECOMPILE);
GO

--<07>-- EFETUAR REORGANIZE OU REBUILD CONFORME FRAGMENTACAO DO INDICE.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

DECLARE @objectid INT, @indexid INT, @partitionCount INT, @partitionNum INT, @partitions INT
DECLARE @schema NVARCHAR(128), @objectname NVARCHAR(128), @indexname NVARCHAR(128), @stmt NVARCHAR(4000)
DECLARE @frag FLOAT

SELECT
	PS.[object_id] AS objectid
,	PS.index_id AS indexid
,	PS.partition_number AS partitionNum
,	PS.avg_fragmentation_in_percent AS frag
INTO
	#work
FROM
	sys.dm_db_index_physical_stats (DB_ID (@dbname), NULL, NULL, NULL, 'LIMITED') PS
WHERE
	PS.avg_fragmentation_in_percent > 5
	AND PS.index_id> 0

DECLARE PARTCURSOR CURSOR FOR
SELECT * FROM #work

OPEN PARTCURSOR
FETCH NEXT FROM PARTCURSOR INTO @objectid, @indexid, @partitionNum, @frag

WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT
		@objectname = QUOTENAME (O.name)
	,	@schema = QUOTENAME (s.name)
	FROM
		sys.objects o
		INNER JOIN sys.schemas s ON	(S.[schema_id] = O.[schema_id])
	WHERE
		O.[object_id] = @objectid

	SELECT
		@indexname = QUOTENAME (I.name)
	FROM
		sys.indexes I
	WHERE
		i.[object_id] = @objectid
		AND I.index_id = @indexid

	SELECT 
		@partitionCount = COUNT (*)
	FROM
		sys.partitions P
	WHERE
		P.[object_id] = @objectid
		AND P.index_id = @indexid

	IF (@frag < 30.0) BEGIN
		IF (@partitionCount > 1) BEGIN
			SET @stmt = N'ALTER INDEX ' + @indexname + ' ON ' + @schema + '.' + @objectname + ' REORGANIZE PARTITION = ' + CAST (@partitionNum AS NVARCHAR(10)) + ';';
			SET @stmt = @stmt + N'UPDATE STATISTICS ' + @schema + '.' + @objectname + ' ' + @indexname + ' WITH FULLSCAN;';
		END
		ELSE BEGIN
			SET @stmt = N'ALTER INDEX ' + @indexname + ' ON ' + @schema + '.' + @objectname + ' REORGANIZE;';
			SET @stmt = @stmt + N'UPDATE STATISTICS ' + @schema + '.' + @objectname + ' ' + @indexname + ' WITH FULLSCAN;';
		END
	END

	IF (@frag >= 30.0) BEGIN
		IF (@partitionCount > 1)
			SET @stmt = N'ALTER INDEX ' + @indexname + ' ON ' + @schema + '.' + @objectname + ' REBUILD PARTITION = ' + CAST (@partitionNum AS NVARCHAR(10)) + ';';
		ELSE
			SET @stmt = N'ALTER INDEX ' + @indexname + ' ON ' + @schema + '.' + @objectname + ' REBUILD;';
	END

	EXEC (@stmt);
	PRINT N'Executed: ' + @stmt;

	FETCH NEXT FROM PARTCURSOR INTO @objectid, @indexid, @partitionNum, @frag
END

CLOSE PARTCURSOR;
DEALLOCATE PARTCURSOR;

DROP TABLE #work;
GO

--<08>-- CONSULTAR AS ESTATISTICAS DOS INDICES (READ/WRITE).
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

-- BY READS
SELECT
	OBJECT_NAME (US.[object_id]) AS tableName
,	I.name AS indexName
,	I.index_id
,	(US.user_seeks + US.user_scans + US.user_lookups) AS totalReads
,	US.user_updates AS totalWrites
,	I.type_desc
,	I.fill_factor
,	I.has_filter
,	I.filter_definition
,	US.user_scans
,	US.user_seeks
,	US.user_lookups
FROM
	sys.dm_db_index_usage_stats US
	INNER JOIN sys.indexes I ON	(US.[object_id] = I.[object_id] AND US.index_id = I.index_id)
WHERE
	OBJECTPROPERTY (US.[object_id], 'IsUserTable') = 1
	AND US.database_id = DB_ID (@dbname)
ORDER BY
	totalReads DESC
OPTION (RECOMPILE);

SELECT
	OBJECT_NAME (US.[object_id]) AS tableName
,	I.name AS indexName
,	I.index_id
,	US.user_updates AS totalWrites
,	(US.user_seeks + US.user_scans + US.user_lookups) AS totalReads
,	I.type_desc
,	I.fill_factor
,	I.has_filter
,	I.filter_definition
,	US.last_system_update
,	US.last_user_update
FROM
	sys.dm_db_index_usage_stats US
	INNER JOIN sys.indexes I ON	(US.[object_id] = I.[object_id] AND US.index_id = I.index_id)
WHERE
	OBJECTPROPERTY (US.[object_id], 'IsUserTable') = 1
	AND US.database_id = DB_ID (@dbname)
ORDER BY
	totalWrites DESC
OPTION (RECOMPILE);
GO

--<09>-- CONSULTAR AS ESTATISTICAS DOS INDICES DOS TEMPOS DE ESPERA POR BLOQUEIOS (LOCK WAITS).
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

SELECT
	O.name AS table_name
,	I.name AS index_name
,	OS.index_id
,	OS.partition_number
,	SUM (OS.row_lock_wait_count) AS total_row_lock_waits
,	SUM (OS.row_lock_wait_in_ms / 1000) AS total_row_lock_waits_sec
,	SUM (OS.page_lock_wait_count) AS total_page_lock_waits
,	SUM (OS.page_lock_wait_in_ms / 1000) AS total_page_lock_waits_sec
,	SUM (OS.row_lock_wait_in_ms / 1000) + SUM (OS.page_lock_wait_in_ms / 1000) AS total_lock_waits_sec
,	SUM (OS.page_latch_wait_count) AS total_page_latch_waits
,	SUM (OS.page_latch_wait_in_ms / 1000) AS total_page_latch_waits_sec
,	SUM (OS.page_io_latch_wait_count) AS total_page_io_latch_waits
,	SUM (OS.page_io_latch_wait_in_ms / 1000) AS total_page_io_latch_waits_sec
,	SUM (OS.page_latch_wait_in_ms / 1000) + SUM (OS.page_io_latch_wait_in_ms / 1000) AS total_latch_waits
FROM
	sys.dm_db_index_operational_stats (DB_ID (@dbname), NULL, NULL, NULL) OS
	INNER JOIN sys.objects O ON	(OS.[object_id] = O.[object_id])
	INNER JOIN sys.indexes I ON	(OS.[object_id] = I.[object_id] AND OS.index_id = I.index_id)
WHERE
	O.[object_id] > 100
GROUP BY
	O.name
,	I.name
,	OS.index_id
,	OS.partition_number
HAVING
	SUM (OS.page_lock_wait_in_ms) + SUM (OS.row_lock_wait_in_ms) > 0
ORDER BY
	total_lock_waits_sec DESC
OPTION (RECOMPILE);
GO

--<10>-- EFETUAR REINDEX E UPDATESTATS EM TODAS AS TABELAS DE UM BANCO DE DADOS.
USE [AdventureWorks2014]

EXEC sp_MSforeachtable @command1="PRINT '?' DBCC DBREINDEX ('?', ' ', 80)"
EXEC sp_updatestats
GO

--<11>-- CAPTURAR A DATA DA ULTIMA ATUALIZACAO DE ESTATISTICAS DA TABELA.
USE [AdventureWorks2014]

DECLARE @tablename SYSNAME = 'DatabaseLog';

SELECT
	T.name AS tableName
,	I.name AS indexName
,	STATS_DATE (T.[object_id], I.index_id) AS statsUpdated
FROM
	sys.indexes I 
	INNER JOIN sys.tables T ON (I.[object_id] = T.[object_id])
WHERE
	T.name = @tablename
	AND I.name IS NOT NULL
OPTION (RECOMPILE);
GO

--<12>-- CAPTURAR PERCENTUAL DE ALTERACAO DE UM INDICE DA TABELA.
USE [AdventureWorks2014]

DECLARE @tablename SYSNAME = 'DatabaseLog';

SELECT
	O.name AS table_name
,	X.name AS index_name
,	I.index_id
,	X.type_desc AS index_type
,	I.leaf_update_count * 100.0 / (I.range_scan_count + I.leaf_insert_count + I.leaf_delete_count + I.leaf_update_count + I.leaf_page_merge_count + I.singleton_lookup_count) AS percent_update
FROM
	sys.dm_db_index_operational_stats (db_id (), NULL, NULL, NULL) I
	JOIN sys.objects O ON (O.[object_id] = I.[object_id])
	JOIN sys.indexes X ON (X.[object_id] = I.[object_id] AND X.index_id = I.index_id)
WHERE
	(I.range_scan_count + I.leaf_insert_count + I.leaf_delete_count + I.leaf_update_count + I.leaf_page_merge_count + I.singleton_lookup_count) <> 0
AND	OBJECTPROPERTY (I.[object_id], 'IsUserTable') = 1
AND (O.name = @tablename OR @tablename IS NULL)
ORDER BY
	percent_update
GO