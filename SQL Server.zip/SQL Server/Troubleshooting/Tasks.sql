/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR AS TASKS, THREADS, SCHEDULERS.
 */

--<01>-- CHECAR STATUS DAS TAREFAS NO SERVIDOR (RUNNING, RUNNABLE, SUSPENDED).
USE [master]

SELECT
	TOTAL		= COUNT (*)
,	RUNNABLE	= COUNT (RUNNABLE)
,	RUNNING		= COUNT (RUNNING)
,	SUSPENDED	= COUNT (SUSPENDED)
FROM
	sys.dm_os_tasks T
	PIVOT (SUM(request_id) FOR task_state IN (RUNNABLE, RUNNING, SUSPENDED)) AS P 
WHERE
	P.session_id IS NOT NULL
	AND P.session_id > 50
OPTION (RECOMPILE);
GO

--<02>-- CHECAR AS TAREFAS POR BASE DE DADOS.
USE [master]

SELECT 
	ISNULL (DB_NAME (R.database_id), 'TOTAL') AS database_name
,	COUNT (*) AS total_tasks
FROM
	sys.dm_os_tasks T
	INNER JOIN sys.dm_exec_requests R ON (T.session_id = R.session_id)
WHERE
	R.group_id > 1
	AND T.session_id IS NOT NULL
GROUP BY 
	ROLLUP (DB_NAME (R.database_id))
OPTION (RECOMPILE);

SELECT
	DB_NAME (R.database_id) AS database_name
,	T.task_state
,	COUNT (S.session_id) AS total_sessions
INTO
	#tasks
FROM
	sys.dm_os_tasks T
	INNER JOIN sys.dm_exec_sessions S	ON (T.session_id = S.session_id)
	LEFT JOIN sys.dm_exec_requests R	ON	(T.session_id = R.session_id AND S.session_id = R.session_id)
WHERE
	R.group_id > 1
	AND T.session_id IS NOT NULL
GROUP BY
	DB_NAME (R.database_id)
,	T.task_state
ORDER BY
	total_sessions DESC
,	database_name
OPTION (RECOMPILE);

SELECT
	DBNAME		= ISNULL (P.database_name,'TOTAL')
,	RUNNABLE	= ISNULL (SUM (RUNNABLE),0)
,	RUNNING		= ISNULL (SUM (RUNNING),0)
,	SUSPENDED	= ISNULL (SUM (SUSPENDED),0)
FROM
	#tasks T
	PIVOT (MAX (total_sessions) FOR task_state IN (RUNNABLE, RUNNING, SUSPENDED)) AS P 
GROUP BY
	ROLLUP (P.database_name)
OPTION (RECOMPILE);

DROP TABLE #tasks;
GO