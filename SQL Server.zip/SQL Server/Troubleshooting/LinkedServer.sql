/*
 *	AUTHOR: BETO GIOY
 *	ACTION: CRIAR, MONITORAR E ATRIBUIR PERMISSAO EM LINKED SERVERS.
 */

--<01>-- CRIAR LINKED SERVER.
USE [master]

-- LINKED SERVER COM PROVIDER DO SQL NATIVE CLIENT
EXEC sp_addlinkedserver
	@server		= N'MSTPROD1'	-- NOME DO SERVIDOR
,	@srvproduct = N'SQL'		-- NOME DO PRODUTO
,	@provider	= N'SQLNCLI'	-- NOME DO PROVIDER
,	@datasrc	= N'MSTPROD1'	-- NOME DA FONTE DE DADOS INTERPRETADA PELO OLEDB PROVIDER
,	@location	= NULL			-- LOCAL DA BASE DE DADOS | NULL
,	@provstr	= NULL			-- STRING DE CONEXAO PARA O OLEDB PROVIDER | NULL
,	@catalog	= NULL			-- BASE DE DADOS | NULL
GO

-- LINKED SERVER COM PROVIDER OLEDB
EXEC sp_addlinkedserver
	@server		= N'MSTPROD1'
,	@srvproduct = N'OLE DB Provider for Jet'
,	@provider	= N'Microsoft.Jet.OLEDB.4.0'
,	@datasrc	= N'C:\MSOffice\Access\Samples\Nortwind.accdb'
GO

-- LINKED SERVER COM PROVIDER ACE.OLEDB (PARA VERSOES ATUAIS DO OFFICE)
EXEC sp_addlinkedserver
	@server		= N'MSTPROD1'
,	@srvproduct = N'OLE DB Provider for ACE'
,	@provider	= N'Microsoft.ACE.OLEDB.12.0'
,	@datasrc	= N'C:\MSOffice\Access\Samples\Nortwind.accdb'
GO

-- LINKED SERVER PARA DB2
EXEC sp_addlinkedserver
	@server		= N'BBADB2'
,	@srvproduct = N'Microsoft OLE DB Provider for DB2'
,	@provider	= N'DB2OLEDB'
,	@catalog	= N'DBPEP'
,	@provstr	= N'Initial Catalog=DBPEP; Data Source=BBADB2;HostCCSID=1252;Network Adress=XYZ;Network Port=50000;Package Collection=admin;Default Schema=admin;'
GO

--<02>-- RETORNAR LINKED SERVERS E CONFIGURACOES.
USE [master]

--TESTAR A CONEXAO COM UM LINKED SERVER. SE O TESTE FALHAR, O PROCEDIMENTO GERA UMA EXCECAO COM O MOTIVO DA FALHA.
EXEC sp_testlinkedserver @servername = N'MSTPROD1'

-- RETORNAR A LISTA DE LINKED SERVERS DEFINIDOS NO SERVIDOR LOCAL
EXEC sp_linkedservers

-- DEFINE OPCOES DE SERVIDOR PARA SERVIDORES REMOTOS E VINCULADOS
EXEC sp_serveroption
	@server		= N'MSTPROD1'
,	@optname	= N'option_name'
,	@optvalue	= N'option_value';	-- TRUE | FALSE
GO
/*
 * --> collation compatible		--> lazy schema validation		--> sub
 * --> collation name			--> pub							--> system
 * --> connect timeout			--> query timeout				--> use remote collation
 * --> data acess				--> rpc							--> remote proc transaction promotion
 * --> dist						--> rpc out
 * consulte: http://msdn.microsoft.com/pt-br/library/ms178532.aspx
 */

--<03>-- EXCLUIR LINKED SERVER E SEUS LOGINS.
USE [master]

EXEC sp_dropserver
	@server		= N'MSTPROD1'
,	@droplogins = N'droplogins'
GO

--<04>-- CONCEDER E EXCLUIR PERMISSAO NO LINKED SERVER.
USE [master]

-- VERIFICAR SE USUARIO JA POSSUI PERMISSAO NO LINKED SERVER.
EXEC sp_helplinkedsrvlogin
	@rmtsrvname = N'MSTPROD1'
,	@locallogin = N'NT\cmiranda'
GO

-- CONCEDE PERMISSAO PARA USUARIO NO LINKED SERVER.
EXEC sp_addlinkedsrvlogin
	@rmtsrvname		= N'MSTPROD1'			-- SERVIDOR REMOTO
,	@useself		= N'FALSE'				-- TRUE = LOGON LOCAL | FALSE = LOGON EXPLICIT (USER NAME AND PASSWORD)
,	@locallogin		= N'NT\cmiranda'		-- LOGIN NO SERVIDOR LOCAL
,	@rmtuser		= N'site_cpe_account'	-- LOGIN REMOTO
,	@rmtpassword	= N'block64'			-- SENHA DO LOGIN REMOTO
GO

-- REMOVE UM MAPEAMENTO EXISTENTE UM LOGON NO SERVIDOR LOCAL QUE EXECUTA O SQL SERVER E UM LOGON NO SERVIDOR VINCULADO.
EXEC sp_droplinkedsrvlogin
	@rmtsrvname = N'MSTPROD1'
,	@locallogin = N'NT\cmiranda'
GO

--<05>-- ALTERAR A SENHA DO LINKED SERVER.
USE [master]

DECLARE 
	@server	SYSNAME
,	@rmtuser SYSNAME = 'site_cpe_account'
,	@rmtpassword SYSNAME = 'genesys1@salmo90'

DECLARE reg2 CURSOR LOCAL FOR
SELECT S.name FROM sys.servers S INNER JOIN sys.linked_logins L ON (S.server_id = L.server_id) WHERE L.remote_name = @rmtuser

OPEN reg2
FETCH NEXT FROM reg2 INTO @server

WHILE @@FETCH_STATUS = 0
BEGIN
	EXEC sp_addlinkedsrvlogin
		@rmtsrvname		= @server
	,	@useself		= N'FALSE'
	,	@locallogin		= NULL
	,	@rmtuser		= @rmtuser
	,	@rmtpassword	= @rmtpassword

	FETCH NEXT FROM reg2 INTO @server
END

CLOSE reg2;
DEALLOCATE reg2;
GO

--<06>-- RETORNAR INFORMACOES DO LINKED SERVER.
USE [master]

-- RETORNA A LISTA DE BANCOS DE DADOS NO SERVIDOR VINCULADO.
EXEC sp_catalogs @server_name = N'MSTPROD1';

-- RETORNA OS PRIVILEGIOS DAS COLUNAS DE UMA TABELA DE UM CATALOGO DO SERVIDOR VINCULADO.
/*
 * RETURN:
 *		TABLE_CAT		--> NOME DA BASE DE DADOS
 *		TABLE_SCHEM		--> SCHEMA DA TABELA
 *		TABLE_NAME		--> NOME DA TABELA
 *		COLUMN_NAME		--> NOME DA COLUNA
 *		GRANTOR			--> USUARIO QUE CONCEDEU PERMISSAO NA COLUNA
 *		GRANTEE			--> USUARIO COM PERMISSAO NESTA COLUNA
 *		PRIVILEGE		--> PERMISSOES DISPONIVEIS PARA A COLUNA
 *		IS_GRANTABLE	--> INDICA SE O USUARIO PODE CONCEDER PERMISSAO A OUTRO USUARIO
 */
EXEC sp_column_privileges_ex
	@table_server	= N'MSTPROD1'
,	@table_name		= N'EmailAddress'
,	@table_schema	= N'Person'
,	@table_catalog	= N'AdventureWorks2014'
,	@column_name	= N'EmailAddress';			-- COLUMN NAME | NULL PARA TODAS

-- RETORNA INFORMACOES DE UMA COLUNA DE UMA TABELA DA BASE DE DADOS DO SERVIDOR VINCULADO.
EXEC sp_columns_ex
	@table_server	= N'MSTPROD1'
,	@table_name		= N'EmailAddress'
,	@table_schema	= N'Person'
,	@table_catalog	= N'AdventureWorks2014'
,	@column_name	= N'EmailAddress'
,	@ODBCVer		= NULL;	-- ODBC version

-- RETORNA AS CHAVES ESTRANGEIRAS QUE REFERENCIAM AS CHAVES PRIMARIAS DA TABELA DO SERVIDOR VINCULADO.
EXEC sp_foreignkeys
	@table_server	= N'MSTPROD1'
,	@pktab_name		= N'Person'					-- NOME DA TABELA COM A CHAVE PRIMARIA | NULL
,	@pktab_schema	= N'Person'					-- SCHEMA DA TABELA COM A CHAVE PRIMARIA | NULL
,	@pktab_catalog	= N'AdventureWorks2014';	-- BASE DE DADOS DA TABELA COM A CHAVE PRIMARIA | NULL

-- RETORNA INFORMACOES SOBRE OS INDICES DA TABELA REMOTA ESPECIFICADA.
EXEC sp_indexes
	@table_server	= N'MSTPROD1'
,	@table_name		= N'EmailAddress'
,	@table_schema	= N'Person'
,	@table_catalog	= N'AdventureWorks2014'
,	@index_name		= NULL						-- INDEX NAME | NULL PARA TODOS
,	@is_unique		= NULL;						-- 0 = NON UNIQUE | 1 = UNIQUE | NULL PARA TODOS

-- RETORNA AS COLUNAS DA CHAVE PRIMARIA (UMA LINHA POR COLUNA) DA TABELA REMOTA ESPECIFICADA.
EXEC sp_primarykeys
	@table_server	= N'MSTPROD1'
,	@table_name		= N'EmailAddress'
,	@table_schema	= N'Person'
,	@table_catalog	= N'AdventureWorks2014';

-- RETORNA AS INFORMACOES DE PRIVILEGIO SOBRE A TABELA ESPECIFICADA DO SERVIDOR
EXEC sp_table_privileges_ex
	@table_server	= N'MSTPROD1'
,	@table_name		= N'EmailAddress'
,	@table_schema	= N'Person'
,	@table_catalog	= N'AdventureWorks2014'
,	@fUsePattern	= NULL;						-- 0 | 1 | NULL -> DETERMINA SE OS CARACTERES '_', '%', '[', E ']' SAO INTERPRETADOS COMO CARACTERES CURINGA

-- RETORNA INFORMACOES DA TABELA ESPECIFICADA DO SERVIDOR VINCULADO.
EXEC sp_tables_ex
	@table_server	= N'MSTPROD1'
,	@table_name		= N'EmailAddress'
,	@table_schema	= N'Person'
,	@table_catalog	= N'AdventureWorks2014'
,	@table_type		= NULL
,	@fUsePattern	= NULL;	
GO