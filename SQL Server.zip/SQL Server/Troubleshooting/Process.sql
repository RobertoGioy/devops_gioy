/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR PROCESSOS EM EXECUCAO
 */

--<01>-- LISTAR O STATUS DAS REQUISICOES EM EXECUCAO. CHECAR STATUS DE BLOQUEIOS.
USE [master]

DECLARE @database VARCHAR (30) = 'AdventureWorks2014';
DECLARE @loginame VARCHAR (30) = NULL;
DECLARE @hostname VARCHAR (30) = NULL;
DECLARE @programa VARCHAR (80) = NULL;
DECLARE @sqltexto VARCHAR (99) = 'Production.WorkOrder';

IF @database IS NULL SET @database = '%%' ELSE SET @database = '%' + @database + '%';
IF @loginame IS NULL SET @loginame = '%%' ELSE SET @loginame = '%' + @loginame + '%';
IF @hostname IS NULL SET @hostname = '%%' ELSE SET @hostname = '%' + @hostname + '%';
IF @programa IS NULL SET @programa = '%%' ELSE SET @programa = '%' + @programa + '%';
IF @sqltexto IS NULL SET @sqltexto = '%%' ELSE SET @sqltexto = '%' + @sqltexto + '%';

SELECT
	R.session_id
,	R.blocking_session_id
,	DB_NAME (R.database_id) AS database_name
,	S.login_name
,	R.command
,	R.[status]
,	R.start_time
,	CASE CONVERT (VARCHAR (20), GETDATE () - R.start_time, 108) 
		WHEN '23:59:59' THEN '00:00:00'
		ELSE CONVERT (VARCHAR (20), GETDATE () - R.start_time, 108)
	END AS total_time
,	REPLICATE ('0', 2 - LEN ((R.cpu_time/1000) / 3600)) + CAST (((R.cpu_time/1000) / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN (((R.cpu_time/1000) % 3600) / 60)) + CAST ((((R.cpu_time/1000) % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN (((R.cpu_time/1000) % 3600) % 60)) + CAST ((((R.cpu_time/1000) % 3600) % 60) AS VARCHAR) AS cpu_time
,	REPLICATE ('0', 2 - LEN (((R.total_elapsed_time - R.cpu_time) / 1000) / 3600)) + CAST ((((R.total_elapsed_time - R.cpu_time) / 1000) / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((((R.total_elapsed_time - R.cpu_time) / 1000) % 3600) / 60)) + CAST (((((R.total_elapsed_time - R.cpu_time) / 1000) % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN ((((R.total_elapsed_time - R.cpu_time) / 1000) % 3600) % 60)) + CAST (((((R.total_elapsed_time - R.cpu_time) / 1000) % 3600) % 60) AS VARCHAR) AS total_wait
,	S.[host_name]
,	S.[program_name]
,	S.client_interface_name
,	C.client_net_address
,	C.client_tcp_port
,	R.wait_time
,	R.wait_type
,	R.last_wait_type
,	R.wait_resource
,	R.writes
,	R.reads
,	R.logical_reads
,	R.row_count
,	R.[lock_timeout]
,	G.dop AS Parallelism
,	R.open_transaction_count
,	R.open_resultset_count
,	(SELECT COUNT (*) FROM sys.dm_os_tasks TSK WHERE R.session_id = TSK.session_id) AS Tasks
,	G.query_cost
,	G.requested_memory_kb
,	C.net_transport
,	C.protocol_type
,	ISNULL (SUBSTRING (T.[text], R.statement_start_offset / 2, (CASE WHEN R.statement_end_offset = -1 THEN LEN (CONVERT (NVARCHAR (MAX), T.[text])) * 2 ELSE R.statement_end_offset END - R.statement_start_offset) / 2), '') AS actual_query
,	T.[text]
,	P.query_plan
,	R.plan_handle
,	S.last_request_start_time
,	S.last_request_end_time
,	R.percent_complete
,	R.estimated_completion_time
FROM
	sys.dm_exec_requests R
	INNER JOIN sys.dm_exec_sessions S						ON (R.session_id = S.session_id)
	INNER JOIN sys.dm_exec_connections C					ON	(R.session_id = C.session_id AND S.session_id = C.session_id)
	LEFT JOIN sys.dm_exec_query_memory_grants G				ON	(R.session_id = G.session_id AND S.session_id = G.session_id)
	CROSS APPLY sys.dm_exec_query_plan (R.plan_handle) P
	CROSS APPLY sys.dm_exec_sql_text (R.sql_handle) T
WHERE
	R.group_id > 1
	AND	DB_NAME (R.database_id) LIKE @database
	AND S.login_name LIKE @loginame
	AND S.[host_name] LIKE @hostname
	AND S.[program_name] LIKE @programa
	AND T.[text] LIKE @sqltexto
ORDER BY
	total_time DESC
,	cpu_time DESC
OPTION (RECOMPILE);

--> DBCC FREEPROCCACHE(<plan_handle>);	--> RETIRAR PLANO DE EXECUCAO DO BUFFER CACHE
GO

--<02>-- VERIFICAR SESSOES COM MAIOR TEMPO DE ESPERA.
USE [master]

SELECT
	ES.session_id
,	ES.login_name
,	ES.last_request_start_time
,	WT.wait_type
,	WT.wait_duration_ms / 1000 AS wait_duration_sec
,	ES.[host_name]
,	ES.[program_name]
,	ES.[status]
,	ES.login_time
,	WT.exec_context_id
,	WT.resource_address
,	WT.blocking_task_address
,	WT.blocking_session_id
,	WT.resource_description
,	WT.waiting_task_address
FROM
	sys.dm_os_waiting_tasks WT
	INNER JOIN sys.dm_exec_sessions ES ON (ES.session_id = WT.session_id)
WHERE
	ES.group_id > 1
ORDER BY
	wait_duration_sec
OPTION (RECOMPILE);
GO

--<03>-- RETORNAR TEMPO DAS SESSOES EM STATUS DE SLEEPING.
USE [master]

DECLARE @loginame VARCHAR (30) = NULL;
DECLARE @hostname VARCHAR (30) = NULL;
DECLARE @programa VARCHAR (80) = NULL;

IF @loginame IS NULL SET @loginame = '%%' ELSE SET @loginame = '%' + @loginame + '%';
IF @hostname IS NULL SET @hostname = '%%' ELSE SET @hostname = '%' + @hostname + '%';
IF @programa IS NULL SET @programa = '%%' ELSE SET @programa = '%' + @programa + '%';

SELECT
	S.session_id
,	S.login_time
,	S.[host_name]
,	S.[program_name]
,	S.client_interface_name
,	S.login_name
,	S.last_request_start_time
,	S.last_request_end_time
,	S.[status]
,	REPLICATE ('0', 2 - LEN ((DATEDIFF (MS, S.last_request_start_time, S.last_request_end_time) / 1000) / 3600)) + CAST (((DATEDIFF (MS, S.last_request_start_time, S.last_request_end_time) / 1000) / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN (((DATEDIFF (MS, S.last_request_start_time, S.last_request_end_time) / 1000) % 3600) / 60)) + CAST ((((DATEDIFF (MS, S.last_request_start_time, S.last_request_end_time) / 1000) % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN (((DATEDIFF (MS, S.last_request_start_time, S.last_request_end_time) / 1000) % 3600) % 60)) + CAST ((((DATEDIFF (MS, S.last_request_start_time, S.last_request_end_time) / 1000) % 3600) % 60) AS VARCHAR) AS request_time
,	REPLICATE ('0', 2 - LEN ((DATEDIFF (MS, S.last_request_start_time, GETDATE ()) / 1000) / 3600)) + CAST (((DATEDIFF (MS, S.last_request_start_time, GETDATE ()) / 1000) / 3600) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN (((DATEDIFF (MS, S.last_request_start_time, GETDATE ()) / 1000) % 3600) / 60)) + CAST ((((DATEDIFF (MS, S.last_request_start_time, GETDATE ()) / 1000) % 3600) / 60) AS VARCHAR) + ':' +
	REPLICATE ('0', 2 - LEN (((DATEDIFF (MS, S.last_request_start_time, GETDATE ()) / 1000) % 3600) % 60)) + CAST ((((DATEDIFF (MS, S.last_request_start_time, GETDATE ()) / 1000) % 3600) % 60) AS VARCHAR) AS sleeping_time
,	ST.[text]
FROM
	sys.dm_exec_sessions S
	LEFT JOIN sys.dm_exec_requests R	ON	(S.session_id = R.session_id)
	LEFT JOIN sys.dm_exec_connections C ON (S.session_id = C.session_id)
	CROSS APPLY sys.dm_exec_sql_text(C.most_recent_sql_handle) ST
WHERE
	C.most_recent_sql_handle <> 0x000000000000000000000000000000000000000000000000
	AND S.[status] = 'sleeping'
	AND S.login_name LIKE @loginame
	AND S.[host_name] LIKE @hostname
	AND S.[program_name] LIKE @programa
ORDER BY
	sleeping_time DESC
OPTION (RECOMPILE);
GO

--<04>-- RETORNAR SESSOES EM STATUS DE SLEEPING E COM TRANSACAO ABERTA.
USE [master]

SELECT
	DB_NAME (ST.[dbid]) AS database_name
,	S.session_id
,	S.login_time
,	S.[host_name]
,	S.[program_name]
,	S.client_interface_name
,	S.login_name
,	T.transaction_id
,	ST.[text]
FROM
	sys.dm_exec_sessions S
	INNER JOIN sys.dm_exec_connections C			ON (S.session_id = C.session_id)
	INNER JOIN sys.dm_tran_session_transactions T	ON (S.session_id = T.session_id AND C.session_id = T.session_id)
	CROSS APPLY sys.dm_exec_sql_text(C.most_recent_sql_handle) ST
WHERE
	S.[status] = 'sleeping'
ORDER BY
	S.login_time
OPTION (RECOMPILE);

--> KILL @SPID WITH STATUSONLY;
GO

--<05>-- RETORNAR QUANTAS SESSOES ATIVAS CADA LOGIN POSSUI.
USE [master]

SELECT 
	S.login_name
,	S.[program_name]
,	COUNT (S.session_id) AS count_session_id
FROM
	sys.dm_exec_sessions S
GROUP BY
	S.login_name
,	S.[program_name]
ORDER BY
	count_session_id DESC
OPTION (RECOMPILE);
GO

--<06>-- RETORNAR AS CONEXOES ATIVAS POR IP.
USE [master]

SELECT 
	C.client_net_address
,	S.[program_name]
,	S.[host_name]
,	S.login_name
,	COUNT (C.session_id) AS count_connections
FROM
	sys.dm_exec_sessions S
	INNER JOIN sys.dm_exec_connections C ON	(S.session_id = C.session_id)
GROUP BY
	C.client_net_address
,	S.[program_name]
,	S.[host_name]
,	S.login_name
ORDER BY
	C.client_net_address
,	S.[program_name]
OPTION (RECOMPILE);
GO

--<07>-- RETORNAR AS REQUISICOES COM PAGEIOLATCH.
USE [master]

SELECT
	R.session_id
,	S.login_name
,	S.[program_name]
,	R.start_time
,	R.[status]
,	R.command
,	R.wait_type
,	R.last_wait_type
,	R.logical_reads AS page_reads
,	R.logical_reads * 8192 AS read_KB
,	R.writes AS page_writes
,	R.writes * 8192 AS write_KB
,	T.[text]
FROM
	sys.dm_exec_requests R
	INNER JOIN sys.dm_exec_sessions S ON (R.session_id = S.session_id)
	CROSS APPLY sys.dm_exec_sql_text (R.sql_handle) T
WHERE
	S.is_user_process = 1
	AND	(R.wait_type LIKE 'PAGEIOLATCH%' OR R.last_wait_type LIKE 'PAGEIOLATCH%')
	AND R.session_id <> @@SPID
OPTION (RECOMPILE);
GO

--<07>-- RETORNAR AS TRANSACOES QUE ESTAO CONSUMINDO VERSION STORE.
USE [master]

SELECT
	database_name = DB_NAME (ssu.database_id)
  , at.transaction_begin_time
  , CASE 
		WHEN at.transaction_state IN (0,1) THEN 'INITING'
		WHEN at.transaction_state = 2 THEN 'ACTIVE'
		WHEN at.transaction_state = 3 THEN 'ENDED'
		WHEN at.transaction_state = 4 THEN 'DISTRIBUTED COMMINTING'
		WHEN at.transaction_state = 5 THEN 'WAITING RESOLUTION'
		WHEN at.transaction_state = 6 THEN 'COMMITED'
		WHEN at.transaction_state = 7 THEN 'ROLLBACKING'
		WHEN at.transaction_state = 8 THEN 'ROLLBACKED'
	END AS transaction_state
  , sdt.elapsed_time_seconds
  , es.session_id
  , es.host_name
  , es.program_name
  , es.row_count
  , es.host_process_id
  , user_objects_kb = (ssu.user_objects_alloc_page_count * 8)
  , user_objects_deallococated_kb = (ssu.user_objects_dealloc_page_count * 8)
  , internal_objects_kb = (ssu.internal_objects_alloc_page_count * 8)
  , internal_objects_deallocated_kb = (ssu.internal_objects_dealloc_page_count * 8)
FROM
	sys.dm_tran_active_snapshot_database_transactions sdt
	INNER JOIN sys.dm_tran_active_transactions at			ON (sdt.transaction_id = at.transaction_id)
	INNER JOIN sys.dm_exec_sessions es						ON (sdt.session_id = es.session_id)
	INNER JOIN sys.dm_db_session_space_usage ssu			ON (es.session_id = ssu.session_id)
ORDER BY
	sdt.elapsed_time_seconds DESC
GO
