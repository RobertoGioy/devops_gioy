/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR TABELAS.
 */

--<01>-- VERIFICAR O CONSUMO DAS TABELAS TEMPORARIAS.
USE [tempdb]

SELECT
	ObjectName		= T.name
,	RowsCount		= S.row_count
,	UsedSizeKB		= S.used_page_count * 8
,	ReserverdSizeKB = S.reserved_page_count * 8
FROM
	sys.partitions P
	INNER JOIN sys.dm_db_partition_stats S	ON (P.[partition_id] = S.[partition_id] AND P.partition_number = S.partition_number)
	INNER JOIN sys.tables T					ON (S.[object_id] = T.[object_id])
ORDER BY
	UsedSizeKB DESC
OPTION (RECOMPILE);
GO

--<02>-- LISTAR AS TABELAS DE UM BANCO DE DADOS QUE POSSUEM INDICE CLUSTERED E AS QUE SAO HEAP.
USE [AdventureWorks2014]

DECLARE @tablename VARCHAR (90)
DECLARE @count INT

CREATE TABLE #tables (tbid INT IDENTITY(1,1), name VARCHAR (90));
CREATE TABLE #results (tbname SYSNAME, nrows BIGINT, reserved VARCHAR (15), data VARCHAR (15), index_size VARCHAR (15), unused VARCHAR (15));

INSERT INTO #tables
SELECT name FROM sys.tables WHERE [type] = 'U' ORDER BY name;

SET @count = 1;

WHILE @count < (SELECT COUNT (tbid) FROM #tables)
BEGIN
	SELECT @tablename = name FROM #tables WHERE tbid = @count

	INSERT INTO #results
	EXEC sp_spaceused @tablename;

	SET @count = @count + 1
END

SELECT
	DB_NAME () AS dbname
,	tbname
,	nrows
,	reserved
,	data
,	index_size
,	unused
,	ISNULL ((SELECT 'Heap' FROM sysindexes I INNER JOIN sysobjects O ON (I.id = O.id) WHERE indid = 0 AND xtype = 'U' AND #results.tbname = OBJECT_NAME (I.id)), '') AS Heap
FROM
	#results
ORDER BY
	3 DESC
OPTION (RECOMPILE);

DROP TABLE #tables, #results;

-- VERIFICAR TABELAS QUE NAO POSSUI INDICES
SELECT *
FROM
	sysindexes i INNER JOIN sysobjects o ON (i.id = o.id)
WHERE
	indid = 0
	AND xtype = 'U'
	AND NOT EXISTS (SELECT 1 FROM sysindexes a WHERE a.id = i.id AND a.indid > 0)
OPTION (RECOMPILE);
GO

--<03>-- CONSULTAR O USO DO BUFFER CACHE PELOS OBJETOS (TABELAS, INDICES) DO BANCO DE DADOS.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014'

-- ESTA QUERY AJUDA A IDENTIFICAR POSSIVEIS CANDIDATOS A COMPRESSAO DE DADOS.
SELECT
	OBJECT_NAME (SP.[object_id]) AS ObjectName
,	SP.index_id
,	CAST (COUNT (*) / 128.0 AS DECIMAL(10,2)) AS buffer_size_mb
,	COUNT (*) AS buffer_count
,	SP.[rows]
,	SP.data_compression_desc
FROM
	sys.allocation_units AU
	INNER JOIN sys.dm_os_buffer_descriptors BD	ON (AU.allocation_unit_id = BD.allocation_unit_id)
	INNER JOIN sys.partitions SP				ON (AU.container_id = SP.hobt_id)
WHERE
	BD.database_id = DB_ID (@dbname)
	AND SP.[object_id] > 100
GROUP BY
	SP.[object_id]
,	SP.index_id
,	SP.data_compression_desc
,	SP.[rows]
ORDER BY
	buffer_count DESC
OPTION (RECOMPILE);
GO

--<04>-- RETORNAR O NOME DAS TABELAS, QUANTIDADE DE REGISTROS E STATUS DE COMPRESSAO PARA CLUSTERED E HEAP.
USE [AdventureWorks2014]

SELECT
	OBJECT_NAME (P.[object_id]) AS ObjectName
,	SUM (P.[rows]) AS RowsCount
,	P.data_compression_desc
FROM
	sys.partitions P
WHERE
	P.index_id < 2	-- IGNORE THE PARTITIONS FROM THE NON-CLUSTERED INDEX IF ANY
	AND OBJECT_NAME (P.[object_id]) NOT LIKE N'sys%'
	AND OBJECT_NAME (P.[object_id]) NOT LIKE N'queue_%'
	AND OBJECT_NAME (P.[object_id]) NOT LIKE N'filestream_tombstone%'
	AND OBJECT_NAME (P.[object_id]) NOT LIKE N'fulltext%'
	AND OBJECT_NAME (P.[object_id]) NOT LIKE N'ifts_comp_fragments%'
	AND OBJECT_NAME (P.[object_id]) NOT LIKE N'xml_index_nodes%'
GROUP BY
	P.[object_id]
,	P.data_compression_desc
ORDER BY
	RowsCount DESC
OPTION (RECOMPILE);
GO

--<05>-- VERIFICAR QUANDO FORAM ATUALIZADAS AS ESTATISTICAS SOBRE TODOS OS INDICES DAS TABELAS.
USE [AdventureWorks2014]

SELECT
	SCHEMA_NAME (O.[schema_id]) + '.' + O.name AS [object_name]
,	O.type_desc
,	I.name AS index_name
,	STATS_DATE (I.[object_id], I.index_id) AS statistics_date
,	S.auto_created
,	S.no_recompute
,	S.user_created
,	PS.row_count
,	PS.used_page_count
FROM
	sys.objects O
	INNER JOIN sys.indexes I				ON (O.[object_id] = I.[object_id])
	INNER JOIN sys.stats S					ON (I.[object_id] = S.[object_id] AND I.index_id = S.stats_id)
	INNER JOIN sys.dm_db_partition_stats PS ON (O.[object_id] = PS.[object_id] AND I.index_id = PS.index_id)
WHERE
	O.[type] IN ('U', 'V')
	AND PS.row_count > 0
ORDER BY
	statistics_date DESC
OPTION (RECOMPILE);
GO