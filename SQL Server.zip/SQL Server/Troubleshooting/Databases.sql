/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR BANCOS DE DADOS
 */

--<01>-- LISTAR OS NOMES E PATHS DOS ARQUIVOS DAS BASES DE DADOS.
USE [master]

SELECT
	DB_NAME (MF.database_id) AS database_name
,	MF.[file_id]
,	MF.name AS [file_name]
,	MF.physical_name
,	MF.type_desc
,	MF.state_desc
,	MF.is_percent_growth
,	CONVERT (BIGINT, MF.growth / 128.0) AS growth_mb
,	CONVERT (BIGINT, MF.size / 128.0) AS size_mb
,	CONVERT (BIGINT, MF.max_size / 128.0) AS max_size_mb
FROM
	sys.master_files MF
WHERE
	MF.database_id > 4
	AND (MF.database_id <> 32767 OR MF.database_id = 2)
ORDER BY
	database_name
,	MF.[file_id]
OPTION (RECOMPILE);
GO

--<02>-- VERIFICAR AS PROPRIEDADES DAS BASES DE DADOS (RECOVERY MODEL, LOG FILE SIZE, LOG FILE USAGE ETC).
USE [master]

SELECT
	DB.name AS database_name
,	DB.recovery_model_desc
,	DB.log_reuse_wait_desc
,	PC2.cntr_value AS log_size_kb
,	PC1.cntr_value AS log_used_kb
,	CAST (CAST (PC1.cntr_value AS FLOAT) / CAST (PC2.cntr_value AS FLOAT) AS DECIMAL (18,2)) * 100.0 AS log_used_perc
,	DB.[compatibility_level]
,	DB.page_verify_option_desc
,	DB.is_auto_create_stats_on
,	DB.is_auto_update_stats_on
,	DB.is_auto_update_stats_async_on
,	DB.is_parameterization_forced
,	DB.snapshot_isolation_state_desc
,	DB.is_read_committed_snapshot_on
,	DB.is_auto_close_on
,	DB.is_auto_shrink_on
,	DB.is_cdc_enabled
FROM
	sys.databases DB
	INNER JOIN sys.dm_os_performance_counters PC1 ON (DB.name = PC1.instance_name)
	INNER JOIN sys.dm_os_performance_counters PC2 ON (DB.name = PC2.instance_name)
WHERE
	PC1.counter_name LIKE 'Log File(s) Used Size (KB)%'
	AND PC2.counter_name LIKE 'Log File(s) Size (KB)%'
	AND PC2.cntr_value > 0
OPTION (RECOMPILE);
GO

--<03>-- OBTER A CONTAGEM DE VIRTUAL LOG FILES DOS BANCOS DE DADOS

-- CONTAGEM DE VLF ALTO PODE AFETAR O DESEMPENHO DE GRAVACAO
-- PODE FAZER COM QUE RESTAURACAO E RECUPERACAO DEMOREM MUITO MAIS TEMPO
-- TENTE MANTER SUAS CONTAGENS VLF ABAIXO DE 200, NA MAIORIA DOS CASOS
USE [master]

CREATE TABLE #VLFINFO (
	fileID INT
,	fileSize BIGINT
,	startOffSet BIGINT
,	FSeqNo BIGINT
,	[status] BIGINT
,	parity BIGINT
,	createLSN NUMERIC (38)
);

CREATE TABLE #VLFCountResults (database_name SYSNAME, VLFCount INT);

EXEC sp_MSforeachdb N'
USE [?];

INSERT INTO #VLFINFO
EXEC sp_executesql N''DBCC LOGINFO ([?])'';
INSERT INTO #VLFCountResults
SELECT DB_NAME(), COUNT (*) FROM #VLFINFO;

TRUNCATE TABLE #VLFINFO';

SELECT database_name, VLFCount FROM #VLFCountResults ORDER BY VLFCount DESC;

DROP TABLE #VLFCountResults, #VLFINFO;
GO

--<04>-- LISTAR OS ESPACOS LIVRES DE TODOS OS DATAFILES DA BASE DE DADOS.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';
DECLARE @type_desc VARCHAR (5) = NULL	--> ROWS | LOG | NULL
DECLARE @stmt VARCHAR (MAX)

IF DB_ID (@dbname) IS NULL RETURN;
IF @type_desc IS NULL SET @type_desc = '%%' ELSE SET @type_desc = '%' + @type_desc + '%';

SET @stmt = '
USE [' + @dbname + '];
SELECT
	MF.type_desc
,	MF.name
,	MF.physical_name
,	FG.name AS filegroupname
,	CAST (MF.size * 0.0078125 AS NUMERIC (10,2)) AS size_mb
,	CAST ((FILEPROPERTY (MF.name, ''SpaceUsed'') / 128) AS DECIMAL (10,2)) AS space_used_mb
,	CAST (((MF.size - FILEPROPERTY (MF.name, ''SpaceUsed'')) / 128) AS DECIMAL (10,2)) AS free_space_mb
,	CAST ((CONVERT (BIGINT, FILEPROPERTY (MF.name, ''SpaceUsed'')) * 100.0 / MF.size) AS DECIMAL (10,2)) AS used_percent
,	CAST (((MF.size - FILEPROPERTY (MF.name, ''SpaceUsed'')) * 100.0 / MF.size) AS DECIMAL (10,2)) AS free_percent
FROM
	sys.master_files MF
	LEFT JOIN sys.filegroups FG ON (MF.data_space_id = FG.data_space_id)
WHERE
	DB_NAME (MF.database_id) = ''' + @dbname + '''
	AND MF.type_desc LIKE ''' + @type_desc + '''
ORDER BY
	MF.type_desc
,	MF.name;';

EXECUTE sp_executesql @stmt;
GO

--<05>-- CONSULTAR INFORMACOES DOS ARQUIVOS DE DADOS DE DADOS.
USE [AdventureWorks2014]

SELECT
	DS.name AS groupname
,	DF.[file_id]
,	LEFT(DF.physical_name,1) AS driver_letter
,	DF.name AS logical_name
,	DF.type_desc
,	DF.state_desc
,	DF.max_size / 128 AS max_size_mb
,	DF.growth / 128 AS growth_mb
,	DF.size / 128 AS size_mb
,	CAST (CAST (FILEPROPERTY (DF.name, 'SpaceUsed') AS DECIMAL (10,2)) / 128 AS DECIMAL (10,2)) AS used_space_mb
,	CAST ((DF.size / 128) - CAST (FILEPROPERTY (DF.name, 'SpaceUsed') AS DECIMAL (10,2)) / 128 AS DECIMAL (10,2)) AS free_space_mb
FROM
	sys.database_files DF
	LEFT JOIN sys.data_spaces DS ON	(DF.data_space_id = DS.data_space_id)
ORDER BY
	groupname DESC
,	df.[file_id]
OPTION (RECOMPILE);
GO

--<06>-- CONSOLIDAR O TAMANHO DOS FILEGROUPS DE TODAS AS BASES DE DADOS.
USE [master]

CREATE TABLE #DBTEMP (
	dbname SYSNAME
,	tamanho NUMERIC (10,2)
,	ocupado NUMERIC (10,2)
,	livre NUMERIC (10,2)
);

DECLARE @dbname SYSNAME
DECLARE DB_CURSOR CURSOR LOCAL FOR
SELECT name FROM sys.databases WHERE [state] = 0 ORDER BY name;

OPEN DB_CURSOR
FETCH NEXT FROM DB_CURSOR INTO @dbname

WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE @stmt VARCHAR (MAX)

	SET @stmt = 'USE [' + @dbname + '];'
	SET @stmt = @stmt + '
	INSERT INTO #DBTEMP
	SELECT
		''' + @dbname + '''
	,	SUM (CAST ((F.size * 8) / 1024.0 AS NUMERIC (10,2)))
	,	SUM (CAST ((FILEPROPERTY (F.name, ''SpaceUsed'') * 8) / 1024.0 AS NUMERIC (10,2)))
	,	SUM (CAST (((F.size - FILEPROPERTY (F.name, ''SpaceUsed'')) * 8) / 1024.0 AS NUMERIC (10,2)))
	FROM
		sysfiles F
	WHERE
		(F.[status] & 64 = 0)';

	EXEC sp_executesql @stmt

	FETCH NEXT FROM DB_CURSOR INTO @dbname
END

CLOSE DB_CURSOR;
DEALLOCATE DB_CURSOR;

SELECT dbname, tamanho, ocupado, livre, CONVERT (NUMERIC (10,2), (livre / tamanho) * 100) AS livre_perc FROM #DBTEMP;
DROP TABLE #DBTEMP;
GO

--<07>-- CONSOLIDAR TAMANHO DOS FILEGROUPS DE UMA BASE DE DADOS.
USE [AdventureWorks2014]

SELECT
	F.name AS NameOfFile
,	G.groupname
,	F.[filename]
,	CONVERT (NUMERIC (10,2), F.size / 128.0) AS data_size_mb
,	CONVERT (NUMERIC (10,2), F.size / 128.0 - CAST (FILEPROPERTY (F.name, 'SpaceUsed') AS INT) / 128.0) AS space_used_mb
,	CONVERT (NUMERIC (10,2), 100 - ((F.size / 128.0 - CAST (FILEPROPERTY (F.name, 'SpaceUsed') AS INT) / 128.0) * 100) / (F.size / 128.0)) AS free_percent
FROM
	dbo.sysfiles F
	INNER JOIN dbo.sysfilegroups G ON (F.groupid = G.groupid)
OPTION (RECOMPILE);

EXECUTE [master]..xp_fixeddrives;
GO

--<08>-- RETORNAR AS ESTATISTICAS DE E/S PARA ARQUIVOS DE DADOS E DE LOG.
USE [master]

DECLARE @dbname SYSNAME = 'AdventureWorks2014';

SELECT
	DB_NAME (FS.database_id) AS database_name
,	FS.[file_id]
,	F.[filename]
,	FS.sample_ms / 360000 AS sample_hour					--> HORAS DESDE QUE O SERVIDOR FOI INICIADO
,	FS.num_of_reads											--> NUMERO DE LEITURAS EMITIDAS NO ARQUIVO
,	FS.num_of_bytes_read / 1048576 AS total_read_mb			--> NUMERO TOTAL DE LEITURA NO ARQUIVO EM MB
,	fs.io_stall_read_ms / 360000 AS io_stall_read_hour		--> TEMPO TOTAL, EM HORAS, QUE USUARIOS AGUARDARAM PELAS LEITURAS EMITIDAS NO ARQUIVO
,	FS.num_of_writes										--> NUMERO DE GRAVACOES EFETUADAS NO ARQUIVO
,	FS.num_of_bytes_written / 1048576 AS total_written_mb	--> NUMERO TOTAL DE GRAVACOES NO ARQUIVO EM MB
,	FS.io_stall_write_ms / 360000 AS io_stall_write_hour	--> TEMPO TOTAL, EM HORAS, QUE USUARIOS AGUARDARAM O TERMINO DAS GRAVACOES NO ARQUIVO
,	FS.io_stall / 360000 AS io_stall_hour					--> TEMPO TOTAL, EM HORAS, QUE USUARIOS AGUARDARAM ATE O TERMINO DE E/S NO ARQUIVO
,	FS.size_on_disk_bytes / 1048576 AS size_on_disl_mb		--> TAMANHO DO ARQUIVO EM MB
,	FS.file_handle
FROM
	sys.dm_io_virtual_file_stats (DB_ID (@dbname), NULL) FS
	INNER JOIN sysfiles F ON (FS.[file_id] = F.[fileid])
WHERE
	FS.database_id = DB_ID (@dbname)
OPTION (RECOMPILE);
GO

--<09>-- MOVER UM ARQUIVO DE UMA BASE DE DADOS PARA OUTRO DISCO/DIRETORIO.
USE [master]

SELECT name, physical_name AS CurrentLocation FROM sys.master_files WHERE database_id = DB_ID ('AdventureWorks2014');

--> MODIFICAR A ENTRADA DO ARQUIVO COM O NOVO CAMINHO
ALTER DATABASE [AdventureWorks2014] MODIFY FILE (NAME='AdventureWorks2014_Data', FILENAME='F:\DADOS03B\AdventureWorks2014_Data.mdf');

ALTER DATABASE [AdventureWorks2014] SET OFFLINE WITH ROLLBACK IMMEDIATE;

--> COPIAR ARQUIVO PARA OUTRO DISCO/DIRETORIO
EXEC xp_cmdshell 'MOVE /Y F:\DADOS01B\AdventureWorks2014_Data.mdf F:\DADOS03B\';

EXEC xp_cmdshell 'DIR F:\DADOS03B\';

ALTER DATABASE [AdventureWorks2014] SET ONLINE

SELECT name, physical_name AS CurrentLocation FROM sys.master_files WHERE database_id = DB_ID ('AdventureWorks2014');
GO