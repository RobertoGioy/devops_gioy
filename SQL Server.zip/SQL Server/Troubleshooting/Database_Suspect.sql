-- adicionar datafiles e logfiles quando o banco estiver em suspect ou offline
USE Master
GO
EXEC sp_add_log_file_recover_suspect_db db1, logfile2, '<diretorio>\logfile.ldf', '1MB';
EXEC sp_add_data_file_recover_suspect_db db1, fg1, file2, '<diretorio>\datafile.mdf', '1MB';

--links
/*
https://docs.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-add-log-file-recover-suspect-db-transact-sql

https://docs.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-add-data-file-recover-suspect-db-transact-sql

*/