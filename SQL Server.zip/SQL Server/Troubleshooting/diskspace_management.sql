/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR OS DISCOS E MOUNT POINTS DE UMA INSTANCIA
 */

 SET NOCOUNT ON;

DECLARE @sql VARCHAR (800);

-- verify disks
SET @sql = 'powershell.exe -c "Get-WmiObject -Class Win32_Volume -Filter ''DriveType = 3'' | select name,capacity,freespace | foreach{$_.name+''|''+$_.capacity/1048576+''%''+$_.freespace/1048576+''*''}"'

CREATE TABLE #output (line VARCHAR (255));
CREATE TABLE #powershell (line VARCHAR (255));
CREATE TABLE #drivers (drive CHAR (1));
CREATE TABLE #instances (instance VARCHAR (50));
CREATE TABLE #diskspace (drivename VARCHAR (100), capacity DECIMAL (19,2), freespace DECIMAL (19,2));

CREATE TABLE #disks (
	diskname	VARCHAR (100) NULL
  , subdir		VARCHAR (150) NULL
  , depth		INT NULL
  , disktype	VARCHAR (50) NULL
  , content		VARCHAR (250) NULL
);

CREATE TABLE #diskend (
diskname	VARCHAR (100) NULL
, disktype	VARCHAR (50) NULL
, content		VARCHAR (250) NULL
);

CREATE TABLE #disk_management (
sql_version		VARCHAR (20)
, active_node		SQL_VARIANT
, instance_name	SQL_VARIANT
, drivename		VARCHAR (100)
, disk_type		VARCHAR (30)
, content			VARCHAR (30)
, capacity		BIGINT
, freespace		BIGINT
, spaceused		BIGINT
, reportdate		DATETIME
);

INSERT #output
EXEC master.dbo.xp_cmdshell @sql

INSERT #diskspace
SELECT	RTRIM (LTRIM (SUBSTRING (line, 1, CHARINDEX ('|', line) - 1))) AS drivename
	  , ROUND (CAST (RTRIM (LTRIM (SUBSTRING (line, CHARINDEX ('|', line) + 1, (CHARINDEX ('%', line) - 1) - CHARINDEX ('|', line)))) AS DECIMAL (19,2)), 0) AS capacity
	  , ROUND (CAST (RTRIM (LTRIM (SUBSTRING (line, CHARINDEX ('%', line) + 1, (CHARINDEX ('*', line) - 1) - CHARINDEX ('%', line)))) AS DECIMAL (19,2)), 0) AS freespace
FROM	#output
WHERE	line LIKE '[A-Z][:]%'
ORDER BY drivename

-- verify instances
SET @sql = 'powershell.exe -noprofile -command "Get-Service | Where-Object {$_.Name - like ''MSSQL$*'' -or $_.Name -eq ''MSSSQLSERVER'' -and $_.status -eq ''Running''} | select name | foreach{$_.name+''|''}"'

INSERT #powershell
EXEC master.dbo.xp_cmdshell @sql

INSERT #instances
SELECT RTRIM (LTRIM (SUBSTRING (line, 1, CHARINDEX ('|', line) - 1))) FROM #powershell

-- caso tenha mais que 1 instancia no mesmo node usa a funcao fn_servershareddrives () para apresentar apenas os discos apresentados para a instancia em questao.
IF (SELECT COUNT (instance) FROM #instances WHERE instance IS NOT NULL) > 1
	INSERT #drivers
	SELECT DriveName FROM ::fn_servershareddrives ()
ELSE
	INSERT #drivers
	SELECT DISTINCT LEFT (line,1) FROM #output

DECLARE @tsql VARCHAR (100), @cdiscos VARCHAR (100);

DECLARE Disk_Cursor CURSOR FOR
	SELECT	A.drivename 
	FROM	#diskspace A JOIN #drivers B ON (A.drivename LIKE B.drive + '%')
	WHERE	LEN (A.drivename) = 3 AND A.drivename <> 'C:\'

OPEN Disk_Cursor
FETCH NEXT FROM Disk_Cursor INTO @cdiscos

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @tsql = 'DIR ' + @cdiscos + ' /ad /b';

	INSERT #disks (subdir)
	EXEC master.dbo.xp_cmdshell @tsql

	UPDATE	#disks
	SET		diskname = @cdiscos
	WHERE	diskname IS NULL

	FETCH NEXT FROM Disk_Cursor INTO @cdiscos
END

CLOSE Disk_Cursor;
DEALLOCATE Disk_Cursor;

-- descobre os discos tipo mount volume
UPDATE	#disks
SET		diskname = A.diskname + A.subdir + '\'
	  , subdir = NULL
	  , disktype = 'Mount Volume'
FROM	#disks A JOIN #diskspace B ON (A.diskname + A.subdir + '\' = B.drivename)

-- descobre os discos f�sicos
UPDATE	#disks
SET		disktype = 'Disk'
WHERE	disktype IS NULL

-- atualiza coluna content com o conteudo encontrado no disco e subdiretorios
UPDATE	#disks
SET		content = 
		CASE 
			WHEN UPPER (diskname) LIKE '%TEMPDB%' THEN 'Tempdb'
			WHEN UPPER (diskname) LIKE '%DADOS%' THEN 'Dados'
			WHEN UPPER (diskname) LIKE '%LOG%' THEN 'Log'
			WHEN UPPER (diskname) LIKE '%BACKUP%' THEN 'Backup'
			WHEN UPPER (diskname) LIKE '%BACKTRAN%' THEN 'BackTran'
			WHEN UPPER (diskname) LIKE '%MSSQL%' THEN 'InsSQL'
		END
WHERE	content IS NULL

UPDATE	#disks
SET		content = 
		CASE 
			WHEN UPPER (subdir) LIKE '%TEMPDB%' THEN 'Tempdb'
			WHEN UPPER (subdir) LIKE '%DADOS%' THEN 'Dados'
			WHEN UPPER (subdir) LIKE '%LOG%' THEN 'Log'
			WHEN UPPER (subdir) LIKE '%BACKUP%' THEN 'Backup'
			WHEN UPPER (subdir) LIKE '%BACKTRAN%' THEN 'BackTran'
			WHEN UPPER (subdir) LIKE '%MSSQL%' THEN 'InsSQL'
		END
WHERE	content IS NULL

-- classifica os discos sem pastas como "sem uso"
UPDATE	#disks
SET		content = '-- *Sem Uso*'
WHERE	diskname NOT IN (SELECT diskname FROM #disks WHERE content IS NOT NULL)

DECLARE @disktype VARCHAR (50), @content VARCHAR (30);

DECLARE DiskEnd_Cursor CURSOR FOR
	SELECT	diskname, disktype, content
	FROM	#disks
	WHERE	content IS NOT NULL
	ORDER BY diskname

OPEN DiskEnd_Cursor
FETCH NEXT FROM DiskEnd_Cursor INTO @cdiscos, @disktype, @content

WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT @content = CASE WHEN @content = 'BackTran' THEN 'Backup' ELSE @content END

	IF NOT EXISTS (SELECT diskname FROM #diskend WHERE diskname = @cdiscos AND content LIKE '%' + @content + '%')
		INSERT INTO #diskend VALUES (@cdiscos, @disktype, @content)
	ELSE
		IF NOT EXISTS (SELECT diskname FROM #diskend WHERE diskname = @cdiscos AND content LIKE '%' + @content + '%')
			UPDATE	#diskend 
			SET		content = content + ' + ' + @content
			WHERE	diskname = @cdiscos

	FETCH NEXT FROM DiskEnd_Cursor INTO @cdiscos, @disktype, @content
END

CLOSE DiskEnd_Cursor;
DEALLOCATE DiskEnd_Cursor;

-- insere resultados na tabela de gestao
INSERT #disk_management
SELECT 
	CASE
		WHEN (@@MICROSOFTVERSION / 0X01000000) = 8 THEN 'SQL 2000'
		WHEN (@@MICROSOFTVERSION / 0X01000000) = 9 THEN 'SQL 2005'
		WHEN (@@MICROSOFTVERSION / 0X01000000) = 10 THEN 'SQL 2008'
		WHEN (@@MICROSOFTVERSION / 0X01000000) = 11 THEN 'SQL 2012'
		WHEN (@@MICROSOFTVERSION / 0X01000000) = 12 THEN 'SQL 2014'
	END
  , SERVERPROPERTY ('ComputerNamePhysicalNetBIOS')
  , SERVERPROPERTY ('servername')
  , DE.diskname
  ,	DE.disktype
  , DE.content
  , DS.capacity
  , DS.freespace
  , DS.capacity - DS.freespace
  , GETDATE ()
FROM
	#diskend DE JOIN #diskspace DS ON (DE.diskname = DS.drivename)
WHERE
	DS.drivename NOT LIKE '%MSDTC%'

-- relatorio simplificado do resultado
SELECT	sql_version
	  , active_node
	  ,	instance_name
	  , drivename
	  , disk_type
	  , content
	  , capacity
	  , freespace
	  , spaceused
	  , CAST ((CONVERT (DECIMAL, spaceused) / CONVERT (DECIMAL, capacity)) * 100. AS DECIMAL (19,2)) AS [% Used]
FROM	#disk_management
ORDER BY drivename	


DROP TABLE #output, #powershell, #instances, #drivers, #diskspace, #disks, #diskend, #disk_management;