/*
 *	AUTHOR: BETO GIOY
 *	ACTION: MONITORAR E ANALISAR INFORMACOES DO SQL SERVER E DO WINDOWS CLUSTER.
 */

--<01>-- VERIFICAR STATUS DO CLUSTER E SEUS RECURSOS.
USE [master]

DECLARE @stmt VARCHAR (255)

SELECT @stmt = 'xp_cmdshell ''%systemroot%\system32\cluster.exe /CLUSTER:' + @@SERVERNAME + ' GROUP'''
EXECUTE (@stmt);	--> MOSTRA O STATUS DOS GRUPOS DO CLUSTER
SELECT @stmt = 'xp_cmdshell ''%systemroot%\system32\cluster.exe /CLUSTER:' + @@SERVERNAME + ' RESOURCE'''
EXECUTE (@stmt);	--> MOSTRA O STATUS DOS RECURSOS DO CLUSTER
SELECT @stmt = 'xp_cmdshell ''%systemroot%\system32\cluster.exe /CLUSTER:' + @@SERVERNAME + ' NODE'''
EXECUTE (@stmt);	--> MOSTRA O STATUS DOS NODES DO CLUSTER
SELECT @stmt = 'xp_cmdshell ''%systemroot%\system32\cluster.exe /CLUSTER:' + @@SERVERNAME + ' NETINT'''
EXECUTE (@stmt);	--> MOSTRA O STATUS DAS INTERFACES DE REDE DO CLUSTER
SELECT @stmt = 'xp_cmdshell ''%systemroot%\system32\cluster.exe /CLUSTER:' + @@SERVERNAME + ' NET'''
EXECUTE (@stmt);	--> MOSTRA O STATUS DAS PLACAS DE REDE DO CLUSTER
GO

--<02>-- VERIFICAR INFORMACOES DA INSTANCIA DO SQL SERVER.
USE [master]

DECLARE @start_sql DATETIME, @porta_sql INT, @ip_sql VARCHAR (48);

SELECT @start_sql = login_time FROM sys.dm_exec_sessions WHERE session_id = 1;
SELECT TOP 1 @porta_sql = local_tcp_port FROM sys.dm_exec_connections;
SELECT TOP 1 @ip_sql = local_net_address FROM sys.dm_exec_connections;

SELECT
	InstanceName	= SERVERPROPERTY ('servername')
,	IsClustered		= CASE WHEN SERVERPROPERTY ('IsClustered') = 1 THEN 'Sim' ELSE 'Nao' END
,	ActiveNode		= SERVERPROPERTY ('ComputerNamePhysicalNetBIOS')
,	Startup_Date	= @start_sql
,	SQL_Edition		= SERVERPROPERTY ('edition')
,	SQL_Version		= SERVERPROPERTY ('productversion')
,	ServicePack		= SERVERPROPERTY ('productlevel')
,	Collation		= SERVERPROPERTY ('Collation')
,	IP_Address		= @ip_sql
,	PortNumber		= @porta_sql

-- STATUS DAS BASES DE DADOS
SELECT name, DATABASEPROPERTYEX (name, 'Status') AS [Status] FROM sysdatabases;

-- LISTA NODES DO CLUSTER
SELECT CN.NodeName, CN.is_current_owner, CN.[status_description] FROM sys.dm_os_cluster_nodes CN OPTION (RECOMPILE);

-- LISTA ERRO OU SUCESSO NO RESTART DO SQL SERVER
EXEC xp_readerrorlog 0, 1, 'Recovery';
EXEC xp_readerrorlog 0, 1, 'CHECKDB';
EXEC xp_readerrorlog 0, 1, 'MS DTC';
GO

--<03>-- VERIFICAR INFORMACOESDO SERVIDOR SQL SERVER.
USE [master]

CREATE TABLE #msver1 (
	indexID			INT NULL
,	name			VARCHAR (200) NULL
,	internalValue	INT NULL
,	characterValue	SYSNAME NULL
);

INSERT INTO #msver1 EXEC xp_msver;

CREATE TABLE #CPU (NumberOfProcessors VARCHAR (100));
INSERT INTO #CPU
EXEC xp_cmdshell 'powershell "gwmi win32_computersystem | fl NumberOfProcessors, NumberOfLogicalProcessors, Manufacture"';
DELETE #CPU WHERE NumberOfProcessors IS NULL;

SELECT
	ServerName = @@SERVERNAME
,	MachineName = SERVERPROPERTY ('ComputerNamePhysicalNetBIOS')
,	Manufacturer = (SELECT NumberOfProcessors FROM #CPU WHERE NumberOfProcessors LIKE 'Manufacturer%')
,	LogicalCPUCount = I.cpu_count
,	HyperthreadRatio = I.hyperthread_ratio
,	PhysicalCPUCount = (I.cpu_count / I.hyperthread_ratio)
,	Edition = SERVERPROPERTY ('edition')
,	ProductVersion = SERVERPROPERTY ('productversion')
,	ServicePack = SERVERPROPERTY ('productlevel')
,	WindowsVersion = (SELECT characterValue FROM #msver1 WHERE indexID = 15)
,	PhysicalMemoryMB = (SELECT internalValue FROM #msver1 WHERE indexID = 19)
,	StartInstance = I.sqlserver_start_time
,	[Affinity] = I.affinity_type_desc -- >= SQL Server 2008 R2
,	NumberOfProcessors = (SELECT NumberOfProcessors FROM #CPU WHERE NumberOfProcessors LIKE 'NumberOfProcessors%')
,	NumberOfLogicalProcessors = (SELECT NumberOfProcessors FROM #CPU WHERE NumberOfProcessors LIKE 'NumberOfLogicalProcessors%')
,	MaxWorkersCount = I.max_workers_count
,	NumaNodes = (SELECT DISTINCT memory_node_id FROM sys.dm_os_memory_clerks)
,	SQLInstallDate = (SELECT create_date FROM sys.server_principals WHERE name = N'AUTHORITY\SYSTEM' OR name = N'AUTHORITY\NETWORK SERVICE')
FROM
	sys.dm_os_sys_info I
OPTION (RECOMPILE);

-- RETORNA OS NUMA NODES
SELECT
	N.node_id
,	N.node_state_desc
,	N.memory_node_id
,	N.online_scheduler_count
,	N.active_worker_count
,	N.avg_load_balance
,	N.resource_monitor_state
FROM
	sys.dm_os_nodes N
WHERE
	N.node_state_desc <> N'ONLINE DAC'
OPTION (RECOMPILE);

-- RETORNA O MODELO DO SERVIDOR
EXEC xp_readerrorlog 0, 1, 'Manufacturer';

-- RETORNA O TIPO DE PROCESSADOR DO SERVIDOR
EXEC xp_instance_regread 
	N'HKEY_LOCAL_MACHINE'
,	N'HARDWARE\DESCRIPTION\System\CentralProcessor\0'
,	N'ProcessorNameString';

DROP TABLE #CPU, #msver1;
GO

--<04>-- DESCOBRIR A CONTA QUE GERENCIA O SQL SERVER. XP_REGREAD TRAZ O VALOR DAS CHAVES DO REGISTRO DO WINDOWS.
USE [master]

/*
Example:
DECLARE @test VARCHAR (20)
EXEC xp_regread
	@rootkey	= N'HKEY_LOCAL_MACHINE'
,	@key		= N'SOFTWARE\Test'
,	@value_name = N'TestValue'
,	@value		= @test OUTPUT
GO
SELECT @test
GO
*/
DECLARE @instanceName NVARCHAR (128) = NULL	--> INSTANCE NAME | NULL

DECLARE @regkey NVARCHAR (256), @accnt NVARCHAR (128)

IF (@instanceName IS NULL)
	SELECT @regkey = N'SYSTEM\CurrentControlSet\Services\MSSQLServer';
ELSE
	SELECT @regkey = N'SYSTEM\CurrentControlSet\Services\MSSQL$' + @instanceName;

EXEC xp_regread
	@rootkey	= N'HKEY_LOCAL_MACHINE'
,	@key		= @regkey
,	@value_name = N'ObjectName'
,	@value		= @accnt OUTPUT

SELECT @@SERVERNAME AS Servidor, @accnt AS Conta;
GO

--<05>-- RETORNAR AS CONFIGURACOES DO SQL SERVER.
USE [master]

SELECT
	SC.name
,	SC.value
,	SC.value_in_use
,	SC.minimum
,	SC.maximum
,	SC.[description]
,	SC.is_dynamic
,	SC.is_advanced
FROM
	sys.configurations SC
ORDER BY
	SC.name
OPTION (RECOMPILE);

/*
--> PARA ALTERAR ALGUMA CONFIGURACAO EXECUTE OS PROCEDIMENTOS ABAIXO:

EXEC sp_configure 'show advanced options', 1
GO
RECONFIGURE
GO
EXEC sp_configure '<name>', <value>
GO
RECONFIGURE
GO
EXEC sp_configure 'show advanced options', 0
GO
RECONFIGURE
GO
*/
GO

--<06>-- CONSULTAR ERROS REGISTRADOS NO ERRORLOG DO SQL SERVER.
USE [master]

/*
 * SP_REAERRORLOG - This procedure takes four parameters:
 *
 * 1. Value of error log file you want to read: 0 = current, 1 = Archive #1, 2 = Archive #2, etc.
 * 2. Log file type: 1 OR NULL = error log, 2 = SQL Agent Log
 * 3. Search String 1: String one you want to search for
 * 4. Search String 2: String two you want to search for further refine the results
 *
 */
EXEC sp_readerrorlog 0, 1, 'local node';					-- LOCAL NODE
EXEC sp_readerrorlog 0, 1, 'listening on';					-- SERVER IP / PORT
EXEC sp_readerrorlog 0, 1, 'Server Process ID is';			-- SERVER PROCESS ID
EXEC sp_readerrorlog 0, 1, 'Dedicated admin connection';	-- DAC
EXEC sp_readerrorlog 0, 1, 'CPUs';							-- DETECTED CPU

EXEC sp_readerrorlog 0, 1, 'Using locked pages';			-- MEMORY PRIVILEGE
EXEC sp_readerrorlog 0, 1, 'lock memory privilege';

EXEC sp_readerrorlog 0, 1, 'memory allocation failure';		-- MEMORY ISSUE
EXEC sp_readerrorlog 0, 1, 'insufficient system memory';
EXEC sp_readerrorlog 0, 1, 'out of memory';
EXEC sp_readerrorlog 0, 1, 'insufficient memory';

EXEC sp_readerrorlog 0, 1, 'Starting up';					-- DB STARTUP
EXEC sp_readerrorlog 0, 1, 'Recovery is complete';			-- SYSTEM RECOVERY
EXEC sp_readerrorlog 0, 1, 'occurrence(s) of I/O requests';	-- I/O OCCURRENCE

/*
 * XP_READERRORLOG - Even though sp_readerrorlog accepts only 4 parameters, the extended stored procedure accepts at least 7 parameters.
 *
 * If this extended stored procedure is called directly the parameters are as follows:
 *
 * 1. Value of error log file you want to read: 0 = current, 1 = Archive #1, 2 = Archive #2, etc.
 * 2. Log file type: 1 OR NULL = error log, 2 = SQL Agent Log
 * 3. Search String 1: String one you want to search for
 * 4. Search String 2: String two you want to search for further refine the results
 * 5. Search from start time
 * 6. Search from end time
 * 7. Sort order for results: N'asc' = ascending, N'desc' = descending
 *
 */
EXEC xp_readerrorlog
GO